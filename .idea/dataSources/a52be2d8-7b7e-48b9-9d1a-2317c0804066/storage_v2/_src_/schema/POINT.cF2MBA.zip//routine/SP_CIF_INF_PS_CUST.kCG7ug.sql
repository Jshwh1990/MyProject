create PROCEDURE SP_CIF_INF_PS_CUST(IV_JOBID  IN VARCHAR2,
                                               IV_OPERID IN VARCHAR2,
                                               ON_RESULT OUT NUMBER)
--*******************************************************************************
  -- CopyRight (c) 2018, 融丰银行                                               *
  -- All rights reserved.                                                       *
  --                                                                            *
  -- 文件名称 : SP_CIF_INF_PS_CUST.prc                                          *
  -- 摘    要 : A03_零售客户信息表                                              *
  -- 工程模块 : crmapp.04_27                                                    *
  -- 当前版本 : V1.0.0                                                          *
  -- 作    者 : YCY                                                             *
  -- 完成日期 : 2018/01/24                                                      *
  -- 错误码段 : 40270 - 40279                                                   *
  --*****************************************************************************
 IS
  V_WORK_DATE  VARCHAR2(8);
  V_RETCODE    VARCHAR2(6) := '000000'; --程序/日志返回码
  V_MSG        VARCHAR2(1000); --程序执行信息
  V_TABNAME    VARCHAR2(100); --表名
  V_RETERRFLG  VARCHAR2(1); --日志标志 I(information) W(waring) E(error)
  V_ERRCODE    VARCHAR2(10) := '40279'; --程序执行出错返回码
  V_RETSUBCODE VARCHAR2(3); --程序子返回码
  V_TABLEEXIST NUMBER; --是否存在表名
BEGIN

  /*判断信息历史表数据是否存在，不存在则创建*/
  SELECT COUNT(1) INTO V_TABLEEXIST FROM TEMP_CIF_INF_PS_CUST;

  IF V_TABLEEXIST = 0 THEN
    INSERT /*+APPEND*/
    INTO TEMP_CIF_INF_PS_CUST NOLOGGING
      SELECT * FROM CIF_INF_PS_CUST;
    COMMIT;
  END IF;

  /*获得业务时间*/
  SELECT WORK_DATE INTO V_WORK_DATE FROM SYS_PARA_DATE_NEW;

  V_RETCODE    := '40270';
  V_RETSUBCODE := '001';
  V_RETERRFLG  := 'I';
  V_MSG        := '程序执行开始';
  SP_WRITEDETAILLOG(V_WORK_DATE,
                    IV_JOBID,
                    IV_OPERID,
                    V_MSG,
                    V_RETCODE,
                    V_RETSUBCODE,
                    V_RETERRFLG);

  V_RETCODE    := '40271';
  V_TABNAME    := 'CIF_INF_PS_CUST';
  V_RETERRFLG  := 'I';
  V_RETSUBCODE := '001';
  /*清空对私客户信息表*/
  EXECUTE IMMEDIATE 'TRUNCATE TABLE CIF_INF_PS_CUST';
  /*写日志*/
  V_MSG := V_TABNAME || '表记录成功清除';
  SP_WRITEDETAILLOG(V_WORK_DATE,
                    IV_JOBID,
                    IV_OPERID,
                    V_MSG,
                    V_RETCODE,
                    V_RETSUBCODE,
                    V_RETERRFLG);

  V_RETCODE := '40272';
  /*加载数据到对私客户信息表*/
  INSERT /*+APPEND*/
  INTO CIF_INF_PS_CUST NOLOGGING
    (CUST_NO, --客户号
     AREA_NO, --区域号
     CUST_NAME, --客户名称
     CERT_TYPE, --证件类型
     CERT_NO, --证件号
     SEX, --性别
     IS_BANK_SIGN, --本行员工标志
     OPEN_DATE, --开户日期
     OPEN_ORG, --开户机构
     BELONG_ORG, --归属机构
     CUST_LEVEL, --客户等级
     CREDIT_LEVEL, --信用等级
     CUST_STATE, --客户状态
     TEL_NO, --电话
     ADDRESS, --地址
     EMAIL, --邮箱
     MANAGER_NO, --客户经理编号
     STATE, --分配状态
     MODIFY_DATE, --更新日期
     IS_SMALL_CO)
    SELECT TO_CHAR(A.CIF_NO) CUST_NO, --客户编号
           100 AREA_NO, --区域号
           NVL(A.NAME, 0) CUST_NAME, --客户名
           NVL(B.ID_TYPE, 0) CERT_TYPE, --证件类型
           NVL(B.ID_NO, 0) CERT_NO, --证件号
           CASE
             WHEN C.SEX = 'M' THEN
              '男'
             WHEN C.SEX = 'F' THEN
              '女'
           END SEX, --性别
           NULL IS_BANK_SIGN, --是否本行员工
           CASE
             WHEN A.CRT_DATE = 0 THEN
              '19001231'
             ELSE
              TO_CHAR(A.CRT_DATE)
           END OPEN_DATE, --开户日期
           A.LEGAL_BR_NO OPEN_ORG, --开户机构
           A.LEGAL_BR_NO BELONG_ORG, --归属机构
           A.CIF_LVL CUST_LEVEL, --客户等级
           NULL CREDIT_LEVEL, --信用等级
           A.STS CUST_STATE, --客户状态  *注销 1正常
           C.PHONE TEL_NO, --电话
           C.ADDR ADDRESS, --地址
           C.EMAIL EMAIL, --邮箱
           A.CRT_TEL MANAGER_NO, --建立柜员
           '0' STATE, --分配状态
           CASE
             WHEN A.MODIFY_DATE = 0 THEN
              TO_DATE(V_WORK_DATE, 'YYYYMMDD')
             WHEN SUBSTR(A.MODIFY_DATE, 5, 2) > 12 THEN
              TO_DATE(V_WORK_DATE, 'YYYYMMDD')
             WHEN SUBSTR(A.MODIFY_DATE, 7, 2) > 31 THEN
              TO_DATE(V_WORK_DATE, 'YYYYMMDD')
             ELSE
              TO_DATE(A.MODIFY_DATE, 'YYYYMMDD')
           END MODIFY_DATE, --更新日期
           'N' IS_SMALL_CO --是否小微客户
      FROM A_CBS_CIF_BASIC_INF A --客户基本信息表
      LEFT JOIN A_CBS_CIF_ID_CODE_REL B --客户证件与客户号对照表
        ON A.CIF_NO = B.CIF_NO
       AND B.MAIN_FLAG = '1' --只取主证件号，否则客户号有重复
      LEFT JOIN A_CBS_CIF_PER_INF C --客户个人信息表
        ON A.CIF_NO = C.CIF_NO
      LEFT JOIN TEMP_CIF_INF_PS_CUST tmp --备份表
        ON A.CIF_NO = tmp.CUST_NO
     WHERE A.TYPE = '1'; --A.TYPE='1'个人，A.TYPE='2'对公

  V_TABNAME := 'CIF_INF_PS_CUST';
  V_MSG     := V_TABNAME || '成功写入' || SQL%ROWCOUNT || '条记录';
  COMMIT;
  /*更新分配状态*/
  UPDATE CIF_INF_PS_CUST T
     SET T.STATE = '1'
   WHERE T.STATE = '0'
     AND EXISTS
   (SELECT 1 FROM OP_AS_AR_SA_CUST B WHERE T.CUST_NO = B.RES_ID);
  COMMIT;
  UPDATE CIF_INF_PS_CUST T
     SET T.STATE = '0'
   WHERE T.STATE = '1'
     AND NOT EXISTS
   (SELECT 1 FROM OP_AS_AR_SA_CUST B WHERE T.CUST_NO = B.RES_ID);
  COMMIT;
  /*写日志*/
  SP_WRITEDETAILLOG(V_WORK_DATE,
                    IV_JOBID,
                    IV_OPERID,
                    V_MSG,
                    V_RETCODE,
                    V_RETSUBCODE,
                    V_RETERRFLG);

  V_RETCODE := '40274';
  V_TABNAME := 'CIF_INF_PS_CUST';
  V_MSG     := V_TABNAME || '表成功写入数据';
  /*写日志*/
  V_RETSUBCODE := '001';
  SP_WRITEDETAILLOG(V_WORK_DATE,
                    IV_JOBID,
                    IV_OPERID,
                    V_MSG,
                    V_RETCODE,
                    V_RETSUBCODE,
                    V_RETERRFLG);

  /*清空临时表*/
  EXECUTE IMMEDIATE 'TRUNCATE TABLE TEMP_CIF_INF_PS_CUST';

  V_RETCODE    := '40275';
  V_RETSUBCODE := '001';
  V_RETERRFLG  := 'I';
  V_MSG        := '程序执行结束';
  SP_WRITEDETAILLOG(V_WORK_DATE,
                    IV_JOBID,
                    IV_OPERID,
                    V_MSG,
                    V_RETCODE,
                    V_RETSUBCODE,
                    V_RETERRFLG);

  ON_RESULT := 0;

  /*异常处理*/
EXCEPTION
  WHEN OTHERS THEN
    V_RETERRFLG := 'E';
    V_RETCODE   := V_ERRCODE;
    V_MSG       := 'SQLCODE:' || V_TABNAME || '表' ||
                   SUBSTR(SQLERRM, 1, 500);
    ON_RESULT   := SQLCODE;
    ROLLBACK;
    SP_WRITEDETAILLOG(V_WORK_DATE,
                      IV_JOBID,
                      IV_OPERID,
                      V_MSG,
                      V_RETCODE,
                      V_RETSUBCODE,
                      V_RETERRFLG);
    RETURN;
END;

/

