create PROCEDURE SP_SYS_PARA_DATE(iv_ThisDay IN VARCHAR2,
                                             on_Result  OUT INTEGER)
--*****************************************************************************
  -- CopyRight (c) 2014, 泸州银行                                               *
  -- All rights reserved.                                                       *
  --                                                                            *
  -- 文件名称 : SP_SYS_PARA_DATE.prc                                             *
  -- 摘    要 : 设置业务日期                                                    *
  -- 工程模块 :                                                                 *
  -- 当前版本 : V1.0.0                                                          *
  -- 作    者 : zqh                                                             *
  -- 完成日期 : 2014/09/12                                                      *
  -- 错误码段 :                                                                 *
  --*****************************************************************************
  --WORK_DATE       VARCHAR2(8) Y                工作日期
  --PRE_DATE        VARCHAR2(8) Y                工作日期前一天的日期
  --AFT_DATE        VARCHAR2(8) Y                工作日期后一天的日期
  --DAY_THISYEAR    NUMBER(3)   Y                年初至本日天数
  --DAY_THISQUATER  NUMBER(3)   Y                季初至本日天数
  --DAY_THISMONTH   NUMBER(3)   Y                月初至本日天数
  --BEGINDAY_YEAR   VARCHAR2(8) Y                本年开始日期
  --BEGINDAY_QUATER VARCHAR2(8) Y                本季开始日期
  --BEGINDAY_MONTH  VARCHAR2(8) Y                本月开始日期
  --STEP            NUMBER(2)   Y                当前跑批到哪一步
  --STATUS          VARCHAR2(1) Y                跑批的状态 0-报批正常结束 1-正在跑批  2-跑批结束，但有错误
 AS
  d_RQ              DATE;
  v_WORK_DATE       VARCHAR2(8);
  v_PRE_DATE        VARCHAR2(8);
  v_AFT_DATE        VARCHAR2(8);
  n_DAY_THISYEAR    NUMBER(3);
  n_DAY_THISQUATER  NUMBER(3);
  n_DAY_THISMONTH   NUMBER(3);
  v_BEGINDAY_YEAR   VARCHAR2(8);
  v_BEGINDAY_QUATER VARCHAR2(8);
  v_BEGINDAY_MONTH  VARCHAR2(8);
BEGIN
  v_WORK_DATE       := iv_ThisDay;
  d_RQ              := TO_DATE(iv_ThisDay, 'YYYYMMDD');
  v_PRE_DATE        := TO_CHAR(d_RQ - 1, 'YYYYMMDD');
  v_AFT_DATE        := TO_CHAR(d_RQ + 1, 'YYYYMMDD');
  n_DAY_THISYEAR    := TO_CHAR(d_RQ, 'DDD');
  n_DAY_THISQUATER  := d_RQ - TRUNC(d_RQ, 'Q') + 1;
  n_DAY_THISMONTH   := TO_CHAR(d_RQ, 'DD');
  v_BEGINDAY_YEAR   := TO_CHAR(d_RQ, 'YYYY') || '0101';
  v_BEGINDAY_QUATER := TO_CHAR(TRUNC(d_RQ, 'Q'), 'YYYYMMDD');
  v_BEGINDAY_MONTH  := TO_CHAR(TRUNC(d_RQ, 'MONTH'), 'YYYYMMDD');
  EXECUTE IMMEDIATE 'TRUNCATE TABLE SYS_PARA_DATE_NEW';

  INSERT INTO SYS_PARA_DATE_NEW
    (WORK_DATE,
     PRE_DATE,
     AFT_DATE,
     DAY_THISYEAR,
     DAY_THISQUATER,
     DAY_THISMONTH,
     BEGINDAY_YEAR,
     BEGINDAY_QUATER,
     BEGINDAY_MONTH,
     STEP,
     STATUS)
  VALUES
    (v_WORK_DATE,
     v_PRE_DATE,
     v_AFT_DATE,
     n_DAY_THISYEAR,
     n_DAY_THISQUATER,
     n_DAY_THISMONTH,
     v_BEGINDAY_YEAR,
     v_BEGINDAY_QUATER,
     v_BEGINDAY_MONTH,
     0,
     0);
  COMMIT;

  on_Result := 0;
  RETURN;
EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    on_Result := SQLCODE;

END;

/

