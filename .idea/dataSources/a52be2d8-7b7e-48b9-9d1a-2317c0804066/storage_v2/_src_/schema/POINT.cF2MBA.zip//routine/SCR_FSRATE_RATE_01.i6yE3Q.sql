create FUNCTION SCR_FSRATE_RATE_01(PT_VALUE     IN NUMBER,
                                           FS_VALUE       IN NUMBER,
                                           BASE_SCORE     IN NUMBER,
                                          LEAST_SCORE     IN NUMBER,
                                          MOST_SCORE      IN NUMBER
                                          )
  RETURN NUMBER IS
  /* 过程、函数简要描述信息
  **********************************************************
  *  存储过程名:  完成率按比率增减法
  *  建立日期  :  2018-02-20
  *  作者      :
  *  模块      :  评分模型
  *  功能描述  :  完成率按比率
  *  输入参数  ：
  *  输出参数  ：
  *  来源表    ：
  *  目标表    :
  *   备注     ：1、基本分*（完成值/任务值）；
                 2、PT_VALUE 任务值 FS_VALUE 完成值 BASE_SCORE 基本分
                 3、任务值为空时成绩为0 任务值为0时成绩为基本分
  *------------------------------------------------------------
  *  修改历史
  *  序号    日期      修改人      修改原因
  ************************************************************ */
  O_VAL    NUMBER(12, 2);
BEGIN
  IF (PT_VALUE = '' OR PT_VALUE IS NULL) THEN
    O_VAL := 0;
    RETURN O_VAL;
  END IF;
  IF (PT_VALUE = 0) THEN
    O_VAL := BASE_SCORE;
    RETURN O_VAL;
  END IF;

  IF (PT_VALUE IS NOT NULL) OR (FS_VALUE IS NOT NULL)
     THEN
    IF FS_VALUE <= PT_VALUE THEN
    O_VAL := BASE_SCORE * (FS_VALUE / PT_VALUE);--基础分*（完成值/任务值）
     ELSE
    O_VAL := BASE_SCORE * (FS_VALUE / PT_VALUE);--基础分*（完成值/任务值）
    END IF;
  ELSE
    O_VAL := NULL;
  END IF;

 IF (LEAST_SCORE IS NOT NULL and O_VAL IS NOT NULL and O_VAL<LEAST_SCORE)
      THEN O_VAL:=LEAST_SCORE;
  END IF;

  IF (MOST_SCORE IS NOT NULL  and O_VAL IS NOT NULL and O_VAL>MOST_SCORE)
      THEN O_VAL:=MOST_SCORE;
  END IF;



  RETURN O_VAL;
END;

/

