create FUNCTION FNC_G_ALC (P_BAL DECIMAL,P_AMT DECIMAL,P_StartAmt DECIMAL,P_EndAmt DECIMAL,P_AVAL DECIMAL,P_AMTSEG INT,P_BALFLAG INT)
/* 过程、函数简要描述信息
  **********************************************************
  *  存储过程名:  金额分段分配计算生成函数
  *  建立日期  :  2013-03-20
  *  作者      :  linyd
  *  模块      :
  *  功能描述  :
  *  输入参数  ： P_TABLE 来源表 ，P_INS_TABLE 目标表
  *               P_RECALC 计算类型：10为当日业绩计算，20为外部回算，30为内部回算
  *  输出参数  ： RETCODE 0为正确1为错误， RETMSG错误信息
  *  来源表    ： OP_AS_RT_DICT_FIELD  OP_AS_RT_DICT_TABLE
  *  目标表    :
  *   备注     ：
  *------------------------------------------------------------
  *  修改历史
  *  序号    日期      修改人      修改原因
  ************************************************************ */
RETURN DECIMAL IS
ALCAMT DECIMAL(26,6);
BEGIN
  IF P_AMTSEG <2 THEN  --按原来的方式，以余额为主，落在区间里就按这个区间的分例比率执行
/*    ALCAMT := CASE WHEN P_BAL BETWEEN NVL(P_StartAmt,0) AND NVL(P_EndAmt,99999999999999999999.999999) THEN 1
                   ELSE 0
                   END;*/
    ALCAMT :=  P_AMT * P_AVAL  ;
  ELSE
    IF P_BALFLAG = 1 THEN --是余额
      ALCAMT := CASE WHEN P_BAL >= NVL(P_EndAmt,99999999999999999999.999999) THEN (NVL(P_EndAmt,99999999999999999999.999999) - NVL(P_StartAmt,0)) * P_AVAL
                     WHEN (case when P_BAL <0 then 0 else P_BAL end) BETWEEN NVL(P_StartAmt,0) AND NVL(P_EndAmt,99999999999999999999.999999) THEN  (P_BAL - NVL(P_StartAmt,0))  * P_AVAL
                     ELSE 0
                     END;
    ELSE
      ALCAMT := CASE WHEN P_BAL >= NVL(P_EndAmt,99999999999999999999.999999) THEN NVL(P_EndAmt,99999999999999999999.999999)/P_BAL * P_AMT * P_AVAL
                     WHEN P_BAL > 0 AND P_BAL BETWEEN NVL(P_StartAmt,0) AND NVL(P_EndAmt,99999999999999999999.999999) AND P_BAL>0 THEN  (P_BAL - NVL(P_StartAmt,0)) * P_AMT * P_AVAL /P_BAL
                     WHEN P_BAL <= 0 AND NVL(P_StartAmt,0)=0 THEN P_AMT * P_AVAL
                     ELSE 0
                     END;
    END IF;
  END IF;
  RETURN ALCAMT ;
END
;

/

