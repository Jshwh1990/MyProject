create PROCEDURE SP_CIF_DAT_PS_ACCT_LOAN_HIS(IV_JOBID  IN VARCHAR2,
                                                        IV_OPERID IN VARCHAR2,
                                                        ON_RESULT OUT NUMBER)
--*******************************************************************************
  -- CopyRight (c) 2017, 融丰银行                                         *
  -- All rights reserved.                                                       *
  --                                                                            *
  -- 文件名称 : SP_CIF_DAT_PS_ACCT_LOAN_HIS.prc                                 *
  -- 摘    要 : A03_零售贷款数据历史加载                                        *
  -- 工程模块 : crmapp.04_27                                                    *
  -- 当前版本 : V1.0.0                                                          *
  -- 作    者 : LYH                                                            *
  -- 完成日期 : 2018/03/15                                                     *
  -- 错误码段 : 40270 - 40279                                                   *
  --*****************************************************************************
 IS
  V_WORK_DATE  VARCHAR2(8);
  V_RETCODE    VARCHAR2(6) := '000000'; --程序/日志返回码
  V_MSG        VARCHAR2(1000); --程序执行信息
  V_TABNAME    VARCHAR2(100); --表名
  V_RETERRFLG  VARCHAR2(1); --日志标志 I(information) W(waring) E(error)
  V_ERRCODE    VARCHAR2(10) := '40279'; --程序执行出错返回码
  V_RETSUBCODE VARCHAR2(3); --程序子返回码
  V_JOBID      VARCHAR2(50) := IV_JOBID;
  V_OPERID     VARCHAR2(50) := IV_OPERID;
  V_LAST_DAY   VARCHAR2(8); --当前业务日期的上一天日期
  TO_WORK_DATE DATE;
  q_day        number; --季天数
BEGIN

  /*获得业务时间*/
  SELECT WORK_DATE INTO V_WORK_DATE FROM SYS_PARA_DATE_NEW;
  TO_WORK_DATE := TO_DATE(V_WORK_DATE, 'YYYYMMDD');
  V_LAST_DAY   := TO_CHAR(TO_WORK_DATE - 1, 'YYYYMMDD'); --当前业务日期的上一天日期
  select to_date(V_WORK_DATE, 'yyyymmdd') -
         trunc(to_date(V_WORK_DATE, 'yyyymmdd'), 'q')
    into q_day
    from dual;

  V_RETCODE    := '40270';
  V_RETSUBCODE := '001';
  V_RETERRFLG  := 'I';
  V_MSG        := '程序执行开始';
  SP_WRITEDETAILLOG(V_WORK_DATE,
                    V_JOBID,
                    V_OPERID,
                    V_MSG,
                    V_RETCODE,
                    V_RETSUBCODE,
                    V_RETERRFLG);

  V_RETCODE    := '40271';
  V_TABNAME    := 'CIF_DAT_PS_ACCT_LOAN_HIS';
  V_RETERRFLG  := 'I';
  V_RETSUBCODE := '001';

  /*清空表分区*/
  EXECUTE IMMEDIATE 'ALTER TABLE CIF_DAT_PS_ACCT_LOAN_HIS TRUNCATE PARTITION P_' ||
                    V_WORK_DATE;
  /*写日志*/
  V_MSG := V_TABNAME || '表分区记录成功清除';
  SP_WRITEDETAILLOG(V_WORK_DATE,
                    V_JOBID,
                    V_OPERID,
                    V_MSG,
                    V_RETCODE,
                    V_RETSUBCODE,
                    V_RETERRFLG);

  V_RETCODE := '40272';
  /*加载数据到零售贷款数据历史表*/
  INSERT /*+APPEND*/
  INTO CIF_DAT_PS_ACCT_LOAN_HIS NOLOGGING
    (ACCT_NO, --账号
     HIS_START_DATE, --数据开始日期
     HIS_END_DATE, --数据结束日期
     TAR_DATE, --指标日期
     AREA_NO, --区域号
     BIZ_CUST_NO, --原业务系统客户号
     ACCT_NAME, --户名
     BUSINESS_TYPE, --业务品种
     ACCT_STATE, --账户状态
     OCCUR_TYPE, --发生类型
     CURRENCY, --币种
     TERM, --期限
     SUBJ_CODE, --科目
     PRD_CODE, --产品代码
     CONTRACT_NO, --贷款合同号
     LOAN_WAY, --贷款投向
     ASSURE_MODEL, --担保方式
     RETURN_TYPE, --还款方式
     FETCHDATE, --还款日
     OPEN_DATE, --贷款日期
     OPEN_ORG, --开户机构
     END_DATE, --到期日期
     LOAN_STATE, --贷款形态
     LEVEL_FIVE, --五级分类
     PAY_TIMES, --还款期次
     AMT_PUT, -- 结清金额
     AMT_PAY, --已还本金
     AMT_DELAY, --拖欠本金
     ACCRUAL_DELAY, --拖欠利息
     RATE, --利率
     ACCRUAL_SHOULD, --应收利息
     ACCRUAL_FACT, --实收利息
     ACCRUAL_FACT_A, --累积实收利息
     BAL, --贷款余额
     M_BAL_S, --余额月累计数
     Y_BAL_S, --余额年累计数
     FTP_RATE, --贷款FTP价格
     BAL_PROFIT_S, --应收模拟利润
     BAL_PROFIT_F, --实收模拟利润
     BAL_FEE, --营销费用
     STAT_TIME, --统计日期
     CUST_LVL, --客户等级
     IS_SMALL_CO, --是否小微客户
     IS_NEW, --是否当年新增客户
     BAL_AVG_M, --月日均余额
     BAL_AVG_Y, --年日均余额
     BAL_LAST_Y, --上年末余额
     BAL_LAST_AVG_Y, --上年末日均
     WHE_SPEC_LINE, --是否特殊条线设置
     BASE_ACCT_NO, --原系统贷款账号
     TERM_DAY, --期限日
     TERM_MON, --期限月
     YA_INT_EPS_AMT, --年利息支出
     CD_INT_EPS_AMT, --当日利息支出
     FIN_BR_NO, --核算机构号
     OVER_DAYS, --逾期天数
     LOAN_TYPE,
     bal_last_m, --上月末余额
     bal_add_m, --本月余额增长（余额-上月末余额）
     bal_add_y, --本年余额增长（余额-上年末余额）
     bal_add_avg_y, --本年年日均增长（年日均-年初余额）
     Q_BAL_S,
     BAL_AVG_Q, --季日均余额 
     vou_amt, -- 担保合同总金额
     LOAN_AMT,
     settl_date, --本金结清日期
     CONT_AMT, --   合同金额
     ENDORSE_AMT, --  审批金额
     TAXES
     )
    SELECT A.ACCT_NO, --账号
           V_WORK_DATE, --数据开始日期
           V_WORK_DATE, --数据结束日期
           A.TAR_DATE, --指标日期
           A.AREA_NO, --区域号
           A.BIZ_CUST_NO, --原业务系统客户号
           A.ACCT_NAME, --户名
           A.BUSINESS_TYPE, --业务品种
           A.ACCT_STATE, --账户状态
           A.OCCUR_TYPE, --发生类型
           A.CURRENCY, --币种
           A.TERM, --期限
           A.SUBJ_CODE, --科目
           A.PRD_CODE, --产品代码
           A.CONTRACT_NO, --贷款合同号
           A.LOAN_WAY, --贷款投向
           A.ASSURE_MODEL, --担保方式
           A.RETURN_TYPE, --还款方式
           A.FETCHDATE, --还款日
           A.OPEN_DATE, --贷款日期
           A.OPEN_ORG, --开户机构
           A.END_DATE, --到期日期
           A.LOAN_STATE, --贷款形态
           A.LEVEL_FIVE, --五级分类
           A.PAY_TIMES, --还款期次
           A.AMT_PUT, --发放金额
           A.AMT_PAY, --已还本金
           A.AMT_DELAY, --拖欠本金
           A.ACCRUAL_DELAY, --拖欠利息
           A.RATE, --利率
           A.ACCRUAL_SHOULD, --应收利息
           A.ACCRUAL_FACT, --实收利息
           A.ACCRUAL_FACT_A, --累积实收利息
           A.BAL, --贷款余额
           (CASE
             WHEN SUBSTR(V_WORK_DATE, 7, 2) = '01' THEN
              A.BAL
             ELSE
              (A.BAL + NVL(B.M_BAL_S, 0))
           END) M_BAL_S, --余额月累计数
           (CASE
             WHEN TO_CHAR(TO_WORK_DATE, 'DDD') = '001' THEN
              A.BAL
             ELSE
              (A.BAL + NVL(B.Y_BAL_S, 0))
           END) Y_BAL_S, --余额年累计数
           A.FTP_RATE, --贷款FTP价格
           A.BAL_PROFIT_S, --应收模拟利润
           A.BAL_PROFIT_F, --实收模拟利润
           A.BAL_FEE, --营销费用
           A.STAT_TIME, --统计日期
           A.CUST_LVL, --客户等级
           A.IS_SMALL_CO, --是否小微客户
           A.IS_NEW, --是否当年新增客户
           (CASE
             WHEN SUBSTR(V_WORK_DATE, 7, 2) = '01' THEN
              A.BAL
             ELSE
              (A.BAL + NVL(B.M_BAL_S, 0)) /
              (TO_NUMBER(SUBSTR(V_WORK_DATE, 7, 2)))
           END) BAL_AVG_M, --月日均余额
           (CASE
             WHEN TO_CHAR(TO_WORK_DATE, 'DDD') = '001' THEN
              A.BAL
             ELSE
              (A.BAL + NVL(B.Y_BAL_S, 0)) /
              (TO_NUMBER(TO_CHAR(TO_DATE(V_WORK_DATE, 'YYYYMMDD'), 'DDD')))
           END) BAL_AVG_Y, --年日均余额
           NVL(C.BAL, 0), --上年末余额
           -- NVL(C.BAL / FNC_GET_DAYS(V_WORK_DATE, 'LYE'), 0) BAL_LAST_AVG_Y, --上年末日均
           C.BAL_AVG_Y BAL_LAST_AVG_Y, --上年末日均
           A.WHE_SPEC_LINE, --是否特殊条线设置
           A.BASE_ACCT_NO, --原系统贷款账号
           A.TERM_DAY, --期限日
           A.TERM_MON, --期限月
           A.YA_INT_EPS_AMT, --年利息支出
           A.CD_INT_EPS_AMT, --当日利息支出
           A.FIN_BR_NO, --核算机构号
           A.OVER_DAYS, --逾期天数
           A.LOAN_TYPE,
           NVL(D.BAL, 0), --上月末余额
           NVL(A.BAL, 0) - nvl(D.BAL, 0), --本月余额增长（余额-上月末余额）
           NVL(A.BAL, 0) - NVL(C.BAL, 0), --本年余额增长（余额-上年末余额）
           (CASE
             WHEN TO_CHAR(TO_WORK_DATE, 'DDD') = '001' THEN
              nvl(A.BAL, 0) - NVL(C.BAL, 0)
             ELSE
              (A.BAL + NVL(B.Y_BAL_S, 0)) /
              (TO_NUMBER(TO_CHAR(TO_DATE(V_WORK_DATE, 'YYYYMMDD'), 'DDD'))) -
              nvl(C.BAL_AVG_Y, 0)
           END), --本年年日均增长（年日均-年初年日均）
           case
             when trunc(to_date(v_work_date, 'yyyymmdd'), 'q') =
                  to_date(v_work_date, 'YYYYMMDD') then
              A.BAL
             else
              (A.BAL + nvl(B.Q_BAL_S, 0))
           end, --季累积数据
           case
             when trunc(to_date(v_work_date, 'yyyymmdd'), 'q') =
                  to_date(v_work_date, 'YYYYMMDD') then
              A.BAL
             else
              (A.BAL + nvl(B.Q_BAL_S, 0)) / q_day
           end BAL_AVG_Q, --季日均
           a.vou_amt, -- 担保合同总金额
           A.LOAN_AMT,
           a.settl_date, --本金结清日期
           a.CONT_AMT, --   合同金额
           a.ENDORSE_AMT, --  审批金额
           A.TAXES
      FROM CIF_DAT_PS_ACCT_LOAN A
      LEFT JOIN CIF_DAT_PS_ACCT_LOAN_HIS B
        ON A.ACCT_NO = B.ACCT_NO
       AND B.HIS_START_DATE = V_LAST_DAY --业务日期前一天
      LEFT JOIN CIF_DAT_PS_ACCT_LOAN_HIS C
        ON A.ACCT_NO = C.ACCT_NO
       AND C.HIS_START_DATE =
           TO_CHAR(TRUNC(TO_WORK_DATE, 'YYYY') - 1, 'YYYYMMDD') --上年末
      LEFT JOIN CIF_DAT_PS_ACCT_LOAN_HIS D
        ON A.ACCT_NO = D.ACCT_NO
       AND D.HIS_START_DATE =
           TO_CHAR(trunc(to_date(V_WORK_DATE, 'yyyymmdd'), 'mm') - 1,
                   'YYYYMMDD'); --上月末
  V_TABNAME := 'CIF_DAT_PS_ACCT_LOAN_HIS';
  V_MSG     := V_TABNAME || '成功写入' || SQL%ROWCOUNT || '条记录';
  COMMIT;

  /*写日志*/
  SP_WRITEDETAILLOG(V_WORK_DATE,
                    V_JOBID,
                    V_OPERID,
                    V_MSG,
                    V_RETCODE,
                    V_RETSUBCODE,
                    V_RETERRFLG);

  V_RETCODE := '40274';
  V_TABNAME := 'CIF_DAT_PS_ACCT_LOAN_HIS';
  V_MSG     := V_TABNAME || '表成功写入数据';
  /*写日志*/
  V_RETSUBCODE := '001';
  SP_WRITEDETAILLOG(V_WORK_DATE,
                    V_JOBID,
                    V_OPERID,
                    V_MSG,
                    V_RETCODE,
                    V_RETSUBCODE,
                    V_RETERRFLG);

  V_RETCODE    := '40275';
  V_RETSUBCODE := '001';
  V_RETERRFLG  := 'I';
  V_MSG        := '程序执行结束';
  SP_WRITEDETAILLOG(V_WORK_DATE,
                    V_JOBID,
                    V_OPERID,
                    V_MSG,
                    V_RETCODE,
                    V_RETSUBCODE,
                    V_RETERRFLG);

  ON_RESULT := 0;

  /*异常处理*/
EXCEPTION
  WHEN OTHERS THEN
    V_RETERRFLG := 'E';
    V_RETCODE   := V_ERRCODE;
    V_MSG       := 'SQLCODE:' || V_TABNAME || '表' ||
                   SUBSTR(SQLERRM, 1, 500);
    ON_RESULT   := SQLCODE;
    ROLLBACK;
    SP_WRITEDETAILLOG(V_WORK_DATE,
                      V_JOBID,
                      V_OPERID,
                      V_MSG,
                      V_RETCODE,
                      V_RETSUBCODE,
                      V_RETERRFLG);
    RETURN;
END;
/

