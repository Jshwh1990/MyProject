create PROCEDURE PRC_13_SC_MODIFY
(
	S_DATE    VARCHAR,
	E_DATE    VARCHAR,
	CALC_TYPE INT,
	RETCODE   OUT INT,
	RETMSG    OUT VARCHAR
)
/* 过程、函数简要描述信息
  **********************************************************
  *  存储过程名:  零售客户修正
  *  建立日期  :  2013-03-20
  *  作者      :  linyd
  *  模块      :  业绩分配规模
  *  功能描述  :  根据客户分配修正主账户、账户、流水等分配规则
  *  输入参数  ： s_date 处理日期,e_date 处理结束日期,flow_id流水
  *               calc_type 计算类型：10为当日业绩计算，20为外部回算，30为内部回算
  *  输出参数  ： RETCODE 0为正确1为错误， RETMSG错误信息
  *  来源表    ： SYS_ORGANIZATION 机构表，OP_AS_AD_SA_CUST 零售客户规则明细表，CIF_INF_PS_MAIN 零售主账户信息表
                  CIF_INF_PS_ACCT_DEPS 零售存款账户信息表，CIF_INF_PS_ACCT_LOAN 零售贷款账户信息表，
                  CIF_DAT_PS_FLOW 零售业务流水表， CIF_DAT_PS_SIGN_FLOW 零售签约流水表
  *  目标表    :  OP_AS_AD_SA_MAIN 零售主账户规则明细表，OP_AS_AD_SA_DEPS 零售存款账户分配规则明细表,
                  OP_AS_AD_SA_LOAN 零售贷款账户分配规则明细表,OP_AS_AD_SA_FLOW 零售业务流水分配规则明细表,
                  OP_AS_AD_SA_SIGN 零售签约流水分配规则明细表
  *   备注     ：存储过程名 PRC_13_SC_MODIFY 里的13为跑批号，SC第1个S为零售，第2个C为客户业务类型号
  *------------------------------------------------------------
  *  修改历史
  *  序号    日期      修改人      修改原因
  ************************************************************ */
 IS
	P_SQL       LONG;
	INS_SQL     VARCHAR2(1000);
	SEL_SQL     VARCHAR2(4000);
	WHE_SQL     VARCHAR2(500);
	STEP_ID     VARCHAR2(30);
	RECORD_TIME TIMESTAMP;
	P_STEP_ID   VARCHAR2(30);
	FLOW_ID     VARCHAR2(32);
	MAX_NUM     INT;
	MIN_NUM     INT;
	MAX_LEV     INT;
BEGIN
	FLOW_ID := FNC_GEN_FLOW_ID();
	STEP_ID := 'LYD_13_SC_MODIFY_';
	SELECT MAX(ORG_LEVEL) INTO MAX_NUM FROM SYS_ORGANIZATION;
	SELECT MIN(ORG_LEVEL) INTO MIN_NUM FROM SYS_ORGANIZATION;
	MAX_LEV := MAX_NUM;
	--清空分配明细表
	RECORD_TIME := SYSDATE;
	RETMSG      := '清空客户分配明细表临时表-出错误';
	P_STEP_ID   := STEP_ID || '1';
	P_SQL       := 'TRUNCATE TABLE OP_AS_AD_SA_CUST_TEMP';
	EXECUTE IMMEDIATE P_SQL;
	PRC_SYS_MONITOR_LOG(FLOW_ID,
											S_DATE,
											E_DATE,
											P_STEP_ID,
											RECORD_TIME,
											'PRC_13_SC_MODIFY',
											1,
											'清空客户分配明细表临时表.[OP_AS_AD_SA_CUST_TEMP]',
											P_SQL,
											RECORD_TIME,
											1);
	--根据机构层级关系生成客户 + 叶子机构的分配明细
	LOOP
		EXIT WHEN MAX_NUM < MIN_NUM;
		--客户不存在分配的修正，如果客户已经分配，不管分配情况统一认为按高级分配优先
		RECORD_TIME := SYSDATE;
		RETMSG      := '客户分配修正明细表-出现错误_' || MAX_NUM;
		P_STEP_ID   := STEP_ID || '2_' || MAX_NUM;
		INS_SQL     := 'INSERT /*+append*/ INTO OP_AS_AD_SA_CUST_TEMP nologging (ID, res_id,area_no,al_type,al_in,start_date,end_date,al_way,al_rate,start_amt,end_amt,al_org,org_lev)';
		SEL_SQL     := ' SELECT sys_guid(),l1.res_id,l1.area_no,l1.al_type,l1.al_in,l1.start_date,l1.end_date,';
		SEL_SQL     := SEL_SQL ||
									 'l1.al_way,l1.al_rate,l1.start_amt,l1.end_amt,l2.org_no,l2.org_level';
		SEL_SQL     := SEL_SQL || ' FROM OP_AS_AD_SA_CUST l1,Sys_Organization l2';
		--whe_sql :=' WHERE l1.org_lev='||MAX_NUM||' AND l2.org_level='||MAX_LEV;
		WHE_SQL := ' WHERE l1.org_lev=' || MAX_NUM;
		WHE_SQL := WHE_SQL || ' AND l2.org_seq LIKE  ''%''||l1.al_org||''%''';
		WHE_SQL := WHE_SQL ||
							 'AND NOT EXISTS (SELECT 1 FROM OP_AS_AD_SA_CUST_TEMP l3 WHERE l3.res_id=l1.res_id)';
		P_SQL   := INS_SQL || SEL_SQL || WHE_SQL;
		EXECUTE IMMEDIATE P_SQL;
		PRC_SYS_MONITOR_LOG(FLOW_ID,
												S_DATE,
												E_DATE,
												P_STEP_ID,
												RECORD_TIME,
												'PRC_13_SC_MODIFY',
												1,
												'插入客户分配明细表临时表.[OP_AS_AD_SA_CUST_TEMP]',
												P_SQL,
												RECORD_TIME,
												1);

		/*--客户已经存在分配的修正，且分配的对象不一样
    RECORD_TIME :=SYSDATE;
    RETMSG:='修正分配明细表-出现错误_'||MAX_NUM;
    P_STEP_ID :=STEP_ID||'3_'||MAX_NUM;
    sel_sql :='SELECT sys_guid(),l1.res_id,l1.area_no,l1.al_type,l1.al_in,l1.start_date,l1.end_date,';
    sel_sql :=sel_sql||'l1.al_way,(nvl(l1.al_rate,0)-NVL(l3.al_rate,0)) al_rate,';
    sel_sql :=sel_sql||'l1.start_amt,l1.end_amt,l2.org_no,l2.org_level';
    sel_sql :=sel_sql||' FROM OP_AS_AD_CO_CUST l1,Sys_Organization l2,OP_AS_AD_CO_CUST_TEMP l3';
    whe_sql :=' WHERE l1.org_lev='||MAX_NUM||' AND l2.org_level='||MAX_LEV;
    whe_sql :=whe_sql||' AND l2.org_seq LIKE  ''%''||l1.al_org||''%''';
    whe_sql :=whe_sql||'AND l1.res_id=l3.res_id AND L1.AL_IN <> L3.AL_IN AND l1.al_rate > l3.al_rate';
    p_sql :=ins_sql||sel_sql||whe_sql;
    EXECUTE IMMEDIATE p_sql;
    prc_sys_monitor_log(flow_id,s_date,e_date,P_STEP_ID,RECORD_TIME,'PRC_13_CC_MODIFY',1,'插入客户分配明细表临时表.[OP_AS_AD_CO_CUST_TEMP]',p_sql,RECORD_TIME,1);*/

		MAX_NUM := MAX_NUM - 1;
	END LOOP;

	--修正主账户分配
	RECORD_TIME := SYSDATE;
	RETMSG      := '客户分配修正存款账户分配-出现错误_';
	P_STEP_ID   := STEP_ID || '3_1';
	INS_SQL     := 'INSERT /*+append*/ INTO OP_AS_AD_SA_MAIN nologging (ID, res_id,area_no,al_type,al_in,start_date,end_date,al_way,al_rate,start_amt,end_amt,RES_ORG)';
	SEL_SQL     := ' SELECT sys_guid(),l1.MAIN_ACCT_NO,l1.area_no,l2.al_type,l2.al_in,l2.start_date,l2.end_date,l2.al_way,l2.al_rate,l2.start_amt,l2.end_amt,l1.OPEN_ORG';
	SEL_SQL     := SEL_SQL || ' FROM CIF_INF_PS_MAIN l1,OP_AS_AD_SA_CUST_TEMP l2';
	WHE_SQL     := ' WHERE l1.cust_no=l2.res_id AND l1.open_org=l2.al_org';
	WHE_SQL     := WHE_SQL ||
								 ' AND NOT EXISTS (SELECT 1 FROM OP_AS_AD_SA_MAIN l3 WHERE l3.res_id=l1.MAIN_ACCT_NO)';
	P_SQL       := INS_SQL || SEL_SQL || WHE_SQL;
	EXECUTE IMMEDIATE P_SQL;
	PRC_SYS_MONITOR_LOG(FLOW_ID,
											S_DATE,
											E_DATE,
											P_STEP_ID,
											RECORD_TIME,
											'PRC_13_SC_MODIFY',
											1,
											'客户分配修正主账户分配表.[OP_AS_AD_SA_MAIN]',
											P_SQL,
											RECORD_TIME,
											1);

	--修正存款账户分配，对于存款账户已经分配，不管分配是否100%分配出去，都按账户分配处理
	RECORD_TIME := SYSDATE;
	RETMSG      := '客户分配修正存款账户分配-出现错误_';
	P_STEP_ID   := STEP_ID || '3_2';
	INS_SQL     := 'INSERT /*+append*/ INTO op_as_ad_sa_deps nologging (ID, res_id,area_no,al_type,al_in,start_date,end_date,al_way,al_rate,start_amt,end_amt,RES_ORG)';
	SEL_SQL     := ' SELECT sys_guid(),l1.acct_no,l1.area_no,l2.al_type,l2.al_in,l2.start_date,l2.end_date,l2.al_way,l2.al_rate,l2.start_amt,l2.end_amt,l1.OPEN_ORG';
	SEL_SQL     := SEL_SQL || ' FROM cif_inf_ps_acct_deps l1,OP_AS_AD_SA_CUST_TEMP l2';
	WHE_SQL     := ' WHERE l1.cust_no=l2.res_id AND l1.open_org=l2.al_org';
	WHE_SQL     := WHE_SQL ||
								 ' AND NOT EXISTS (SELECT 1 FROM op_as_ad_sa_deps l3 WHERE l3.res_id=l1.acct_no)';
	P_SQL       := INS_SQL || SEL_SQL || WHE_SQL;
	EXECUTE IMMEDIATE P_SQL;
	PRC_SYS_MONITOR_LOG(FLOW_ID,
											S_DATE,
											E_DATE,
											P_STEP_ID,
											RECORD_TIME,
											'PRC_13_SC_MODIFY',
											1,
											'客户分配修正存款账户分配表.[OP_AS_AD_SA_DEPS]',
											P_SQL,
											RECORD_TIME,
											1);

	--修正贷款账户分配
	RECORD_TIME := SYSDATE;
	RETMSG      := '客户分配修正贷款账户分配-出现错误_';
	P_STEP_ID   := STEP_ID || '3_3';
	INS_SQL     := 'INSERT /*+append*/ INTO op_as_ad_sa_loan nologging (ID, res_id,area_no,al_type,al_in,start_date,end_date,al_way,al_rate,start_amt,end_amt,RES_ORG)';
	SEL_SQL     := ' SELECT sys_guid(),l1.acct_no,l1.area_no,l2.al_type,l2.al_in,l2.start_date,l2.end_date,l2.al_way,l2.al_rate,l2.start_amt,l2.end_amt,l1.OPEN_ORG';
	SEL_SQL     := SEL_SQL || ' FROM cif_inf_ps_acct_loan l1,OP_AS_AD_SA_CUST_TEMP l2';
	WHE_SQL     := ' WHERE l1.cust_no=l2.res_id AND l1.open_org=l2.al_org';
	WHE_SQL     := WHE_SQL ||
								 ' AND NOT EXISTS (SELECT 1 FROM op_as_ad_sa_loan l3 WHERE l3.res_id=l1.acct_no)';
	P_SQL       := INS_SQL || SEL_SQL || WHE_SQL;
	EXECUTE IMMEDIATE P_SQL;
	PRC_SYS_MONITOR_LOG(FLOW_ID,
											S_DATE,
											E_DATE,
											P_STEP_ID,
											RECORD_TIME,
											'PRC_13_SC_MODIFY',
											1,
											'客户分配修正贷款账户分配表.[OP_AS_AD_SA_LOAN]',
											P_SQL,
											RECORD_TIME,
											1);

	--修正业务流水分配
	RECORD_TIME := SYSDATE;
	RETMSG      := '客户分配修正业务流水分配-出现错误_';
	P_STEP_ID   := STEP_ID || '3_4';
	INS_SQL     := 'INSERT /*+append*/ INTO OP_AS_AD_SA_FLOW nologging (ID, res_id,area_no,al_type,al_in,start_date,end_date,al_way,al_rate,start_amt,end_amt,RES_ORG)';
	SEL_SQL     := ' SELECT sys_guid(),l1.flow_id,l1.area_no,l2.al_type,l2.al_in,l2.start_date,l2.end_date,l2.al_way,l2.al_rate,l2.start_amt,l2.end_amt,l1.OPEN_ORG';
	SEL_SQL     := SEL_SQL || ' FROM CIF_DAT_PS_FLOW l1,OP_AS_AD_SA_CUST_TEMP l2';
	WHE_SQL     := ' WHERE l1.biz_cust_no=l2.res_id AND l1.open_org=l2.al_org AND l1.tar_date=''' ||
								 S_DATE || '''';
	WHE_SQL     := WHE_SQL ||
								 ' AND NOT EXISTS (SELECT 1 FROM OP_AS_AD_SA_FLOW l3 WHERE l3.res_id=l1.flow_id)';
	P_SQL       := INS_SQL || SEL_SQL || WHE_SQL;
	EXECUTE IMMEDIATE P_SQL;
	PRC_SYS_MONITOR_LOG(FLOW_ID,
											S_DATE,
											E_DATE,
											P_STEP_ID,
											RECORD_TIME,
											'PRC_13_SC_MODIFY',
											1,
											'客户分配修正业务流水分配表.[OP_AS_AD_SA_FLOW]',
											P_SQL,
											RECORD_TIME,
											1);

	--修正签约流水分配
	RECORD_TIME := SYSDATE;
	RETMSG      := '客户分配修正签约流水分配-出现错误_';
	P_STEP_ID   := STEP_ID || '3_5';
	INS_SQL     := 'INSERT /*+append*/ INTO OP_AS_AD_SA_SIGN nologging (ID, res_id,area_no,al_type,al_in,start_date,end_date,al_way,al_rate,start_amt,end_amt,RES_ORG)';
	SEL_SQL     := ' SELECT sys_guid(),l1.flow_id,l1.area_no,l2.al_type,l2.al_in,l2.start_date,l2.end_date,l2.al_way,l2.al_rate,l2.start_amt,l2.end_amt,l1.OPEN_ORG';
	SEL_SQL     := SEL_SQL || ' FROM CIF_DAT_PS_SIGN_FLOW l1,OP_AS_AD_SA_CUST_TEMP l2';
	WHE_SQL     := ' WHERE l1.biz_cust_no=l2.res_id AND l1.open_org=l2.al_org AND l1.tar_date=''' ||
								 S_DATE || '''';
	WHE_SQL     := WHE_SQL ||
								 ' AND NOT EXISTS (SELECT 1 FROM OP_AS_AD_SA_SIGN l3 WHERE l3.res_id=l1.flow_id)';
	P_SQL       := INS_SQL || SEL_SQL || WHE_SQL;
	EXECUTE IMMEDIATE P_SQL;
	PRC_SYS_MONITOR_LOG(FLOW_ID,
											S_DATE,
											E_DATE,
											P_STEP_ID,
											RECORD_TIME,
											'PRC_13_SC_MODIFY',
											1,
											'客户分配修正签约流水分配表.[OP_AS_AD_SA_SIGN]',
											P_SQL,
											RECORD_TIME,
											1);

	COMMIT;
	RETCODE := 0;
	RETMSG  := '完成';
EXCEPTION
	WHEN OTHERS THEN
		ROLLBACK;
		RETCODE := -1;
		RETMSG  := '客户分配修正明细-执行错误[' || SQLERRM || ']. ' || RETMSG;
		PRC_SYS_MONITOR_LOG(FLOW_ID,
												S_DATE,
												E_DATE,
												P_STEP_ID,
												RECORD_TIME,
												'PRC_13_SC_MODIFY',
												4,
												RETMSG,
												P_SQL,
												RECORD_TIME,
												1);
END;

/

