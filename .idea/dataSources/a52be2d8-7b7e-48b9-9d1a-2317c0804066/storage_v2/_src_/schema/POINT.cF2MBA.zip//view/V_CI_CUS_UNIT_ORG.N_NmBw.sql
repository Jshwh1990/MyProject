create view V_CI_CUS_UNIT_ORG as
  select A.CUST_NO         ,      --客户号
       A.DEPS_BAL        ,      --存款余额
       A.DEPS_BAL_AVG_M  ,      --存款月日均
       A.DEPS_BAL_AVG_Y  ,      --存款年日均
       A.LOAN_BAL        ,      --贷款余额
       A.LOAN_BAL_M      ,      --贷款月日均
       A.LOAN_BAL_Y      ,      --贷款年日均
       A.OPN_ORG         ,      --开户机构
       A.CD_INT_EPS_AMT  ,      --当日利息支出
       A.MA_INT_EPS_AMT  ,      --月累计利息支出
       A.QA_INT_EPS_AMT  ,      --季累计利息支出
       A.YA_INT_EPS_AMT  ,      --年累计利息支出
       A.ACCRUAL_SHOULD  ,      --当日应收利息
       A.ACCRUAL_SHOULD_A,      --累计应收利息
       A.ACCRUAL_FACT    ,      --当日实收利息
       A.ACCRUAL_FACT_A  ,      --累计实收利息
       A.SYS_DATE               --数据日期
  from CI_CUS_UNIT_ORG A
 where not exists (select 1 from CI_CUS_UNIT_COMBINE B where (A.CUST_NO=B.CUST_NO or A.CUST_NO=B.COMBINED_CUST_NO) and B.STATE='1')
union all
select M.CUST_NO         ,      --客户号
       sum(nvl(N.DEPS_BAL,0))        ,      --存款余额
       sum(nvl(N.DEPS_BAL_AVG_M,0))  ,      --存款月日均
       sum(nvl(N.DEPS_BAL_AVG_Y,0))  ,      --存款年日均
       sum(nvl(N.LOAN_BAL,0))        ,      --贷款余额
       sum(nvl(N.LOAN_BAL_M,0))      ,      --贷款月日均
       sum(nvl(N.LOAN_BAL_Y,0))      ,      --贷款年日均
       M.OPN_ORG         ,      --开户机构
       sum(nvl(N.CD_INT_EPS_AMT,0))  ,      --当日利息支出
       sum(nvl(N.MA_INT_EPS_AMT,0))  ,      --月累计利息支出
       sum(nvl(N.QA_INT_EPS_AMT,0))  ,      --季累计利息支出
       sum(nvl(N.YA_INT_EPS_AMT,0))  ,      --年累计利息支出
       sum(nvl(N.ACCRUAL_SHOULD,0))  ,      --当日应收利息
       sum(nvl(N.ACCRUAL_SHOULD_A,0)),      --累计应收利息
       sum(nvl(N.ACCRUAL_FACT,0))    ,      --当日实收利息
       sum(nvl(N.ACCRUAL_FACT_A,0))  ,      --累计实收利息
       M.SYS_DATE               --数据日期
  from
      (select * from CI_CUS_UNIT_ORG I
        where exists (select 1 from CI_CUS_UNIT_COMBINE K where I.CUST_NO=K.CUST_NO and K.STATE='1')) M
left join
      (select * from CI_CUS_UNIT_ORG J
        where exists (select 1 from CI_CUS_UNIT_COMBINE L where (J.CUST_NO=L.CUST_NO or J.CUST_NO=L.COMBINED_CUST_NO) and L.STATE='1')) N
       on M.CUST_NO=N.CUST_NO
group by M.CUST_NO,M.OPN_ORG,M.SYS_DATE

/

