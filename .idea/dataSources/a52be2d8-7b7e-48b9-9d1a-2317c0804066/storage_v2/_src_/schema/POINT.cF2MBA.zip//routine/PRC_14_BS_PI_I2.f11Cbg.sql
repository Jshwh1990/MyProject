create PROCEDURE PRC_14_BS_PI_I2
(
	S_DATE    VARCHAR,
	E_DATE    VARCHAR,
	CALC_TYPE INT,
	RETCODE   OUT INT,
	RETMSG    OUT VARCHAR
)
/* 过程、函数简要描述信息
  **********************************************************
  *  存储过程名:  业务量（对公、零售）数据表生成
  *  建立日期  :  2013-03-20
  *  作者      :  linyd
  *  模块      :  业绩计算
  *  功能描述  :  业绩计算人员数据生成
  *  输入参数  ： s_date 处理日期,e_date 处理结束日期,flow_id流水
  *               calc_type 计算类型：10为当日业绩计算，20为外部回算，30为内部回算
  *  输出参数  ： RETCODE 0为正确1为错误， RETMSG错误信息
  *  来源表    ： OP_AS_AD_CO_DEPS 对公存款分配规则明细表， CIF_DAT_CO_ACCT_DEPS 对公存款数据表
  *  目标表    :  PI_I3_BS_FLOW 业务量考核数据表
  *   备注     ：存储过程名 PRC_14_CD_PI_I2 里的14为跑批号，CD第1个C为对公，第2个D为存款业务类型号
  *------------------------------------------------------------
  *  修改历史
  *  序号    日期      修改人      修改原因
  ************************************************************ */
 IS
	P_SQL       LONG;
	STEP_ID     VARCHAR2(30);
	RECORD_TIME TIMESTAMP;
	P_STEP_ID   VARCHAR2(30);
	FLOW_ID     VARCHAR2(32);
	P_CNT       INT;
BEGIN
	FLOW_ID := FNC_GEN_FLOW_ID();
	STEP_ID := 'LYD_14_PI_I2_BS_DEPS_';

	--删除业务量临时表
	RECORD_TIME := SYSDATE;
	RETMSG      := '删除业务量临时表-出错误';
	P_STEP_ID   := STEP_ID || '6_1';
	SELECT COUNT(1) INTO P_CNT FROM COLS WHERE UPPER(TABLE_NAME) = 'RE_PI_I4_BS_FLOW';
	IF P_CNT > 0 THEN
		P_SQL := 'DROP TABLE RE_PI_I4_BS_FLOW';
		EXECUTE IMMEDIATE P_SQL;
	END IF;
	PRC_SYS_MONITOR_LOG(FLOW_ID,
											S_DATE,
											E_DATE,
											P_STEP_ID,
											RECORD_TIME,
											'PRC_14_BS_PI_I2',
											1,
											'删除业务量临时表.[RE_PI_I4_BS_FLOW]',
											P_SQL,
											RECORD_TIME,
											1);

	--创建业务量临时表
	RECORD_TIME := SYSDATE;
	RETMSG      := '创建业务量临时表-出错误';
	P_STEP_ID   := STEP_ID || '6_2';
	P_SQL       := FNC_GET_I4_TBLSQL('PI_I4_BS_FLOW', 'RE_PI_I4_BS_FLOW');
	EXECUTE IMMEDIATE P_SQL;
	PRC_SYS_MONITOR_LOG(FLOW_ID,
											S_DATE,
											E_DATE,
											P_STEP_ID,
											RECORD_TIME,
											'PRC_14_BS_PI_I2',
											1,
											'创建业务量临时表.[RE_PI_I4_BS_FLOW]',
											P_SQL,
											RECORD_TIME,
											1);

	--人员产品数据到业务量临时表
	RECORD_TIME := SYSDATE;
	RETMSG      := '人员产品数据到业务量临时表-出错误';
	P_STEP_ID   := STEP_ID || '6_3';
	P_SQL       := FNC_INS_RE_I4('PI_I4_BS_FLOW');
	P_SQL       := P_SQL || FNC_GET_I4_REFROMSQL('PI_I3_BS_FLOW',
																							 'PI_I4_BS_FLOW',
																							 CALC_TYPE,
																							 S_DATE,
																							 E_DATE);
	EXECUTE IMMEDIATE P_SQL;
	PRC_SYS_MONITOR_LOG(FLOW_ID,
											S_DATE,
											E_DATE,
											P_STEP_ID,
											RECORD_TIME,
											'PRC_14_BS_PI_I2',
											1,
											'人员产品数据到业务量临时表.[RE_PI_I4_BS_FLOW]',
											P_SQL,
											RECORD_TIME,
											1);

	--删除层级业务量临时表
	RECORD_TIME := SYSDATE;
	RETMSG      := '删除层级业务量临时表-出错误';
	P_STEP_ID   := STEP_ID || '6_4';
	SELECT COUNT(1)
		INTO P_CNT
		FROM COLS
	 WHERE UPPER(TABLE_NAME) = 'NEW_PI_I4_BS_FLOW';
	IF P_CNT > 0 THEN
		P_SQL := 'DROP TABLE NEW_PI_I4_BS_FLOW';
		EXECUTE IMMEDIATE P_SQL;
	END IF;
	PRC_SYS_MONITOR_LOG(FLOW_ID,
											S_DATE,
											E_DATE,
											P_STEP_ID,
											RECORD_TIME,
											'PRC_14_BS_PI_I2',
											1,
											'删除层级业务量临时表.[NEW_PI_I4_BS_FLOW]',
											P_SQL,
											RECORD_TIME,
											1);

	--创建层级业务量临时表
	RECORD_TIME := SYSDATE;
	RETMSG      := '创建层级业务量临时表-出错误';
	P_STEP_ID   := STEP_ID || '6_5';
	P_SQL       := FNC_GET_I4_TBLSQL('PI_I4_BS_FLOW', 'NEW_PI_I4_BS_FLOW');
	EXECUTE IMMEDIATE P_SQL;
	PRC_SYS_MONITOR_LOG(FLOW_ID,
											S_DATE,
											E_DATE,
											P_STEP_ID,
											RECORD_TIME,
											'PRC_14_BS_PI_I2',
											1,
											'创建层级业务量临时表.[NEW_PI_I4_BS_FLOW]',
											P_SQL,
											RECORD_TIME,
											1);

	--临时层业务量数据层层汇总
	RECORD_TIME := SYSDATE;
	RETMSG      := '临时层业务量数据层层汇总-出错误';
	P_STEP_ID   := STEP_ID || '6_6';
	P_SQL       := FNC_INS_NEW_I4('PI_I4_BS_FLOW');
	P_SQL       := P_SQL || FNC_GET_NEW_I4('PI_I4_BS_FLOW', CALC_TYPE, S_DATE, E_DATE);
	EXECUTE IMMEDIATE P_SQL;
	PRC_SYS_MONITOR_LOG(FLOW_ID,
											S_DATE,
											E_DATE,
											P_STEP_ID,
											RECORD_TIME,
											'PRC_14_BS_PI_I2',
											1,
											'临时层业务量数据层层汇总.[NEW_PI_I4_BS_FLOW]',
											P_SQL,
											RECORD_TIME,
											1);

	--清空业务量表数据
	RECORD_TIME := SYSDATE;
	RETMSG      := '清空业务量层数据-出错误';
	P_STEP_ID   := STEP_ID || '6_7';
	P_SQL       := 'DELETE FROM PI_I4_BS_FLOW WHERE TAR_DATE=''' || S_DATE || '''';
	EXECUTE IMMEDIATE P_SQL;
	PRC_SYS_MONITOR_LOG(FLOW_ID,
											S_DATE,
											E_DATE,
											P_STEP_ID,
											RECORD_TIME,
											'PRC_14_BS_PI_I2',
											1,
											'清空业务量层数据.[PI_I4_BS_FLOW]',
											P_SQL,
											RECORD_TIME,
											1);

	--业务量临时表到业务量表
	RECORD_TIME := SYSDATE;
	RETMSG      := '业务量临时表到业务量表-出错误';
	P_STEP_ID   := STEP_ID || '6_8';
	P_SQL       := FNC_GET_I4_ORGINSSQL('PI_I4_BS_FLOW');
	P_SQL       := P_SQL || FNC_GET_I4_NEWFROMSQL('PI_I4_BS_FLOW',
																								'NEW_PI_I4_BS_FLOW',
																								CALC_TYPE,
																								S_DATE,
																								E_DATE);
	EXECUTE IMMEDIATE P_SQL;
	PRC_SYS_MONITOR_LOG(FLOW_ID,
											S_DATE,
											E_DATE,
											P_STEP_ID,
											RECORD_TIME,
											'PRC_14_BS_PI_I2',
											1,
											'业务量临时表到业务量表.[PI_I4_BS_FLOW]',
											P_SQL,
											RECORD_TIME,
											1);

	COMMIT;
	RETCODE := 0;
	RETMSG  := '完成';
EXCEPTION
	WHEN OTHERS THEN
		ROLLBACK;
		RETCODE := SQLCODE;
		RETMSG  := '人员数据表-执行错误[' || SQLERRM || ']. ' || RETMSG;
		PRC_SYS_MONITOR_LOG(FLOW_ID,
												S_DATE,
												E_DATE,
												P_STEP_ID,
												RECORD_TIME,
												'PRC_14_BS_PI_I2',
												4,
												RETMSG,
												P_SQL,
												RECORD_TIME,
												1);
END;

/

