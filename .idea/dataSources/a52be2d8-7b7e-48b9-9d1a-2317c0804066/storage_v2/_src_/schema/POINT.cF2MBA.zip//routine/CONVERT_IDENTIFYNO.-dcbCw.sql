create FUNCTION Convert_Identifyno(Pi_Identifyno VARCHAR2) RETURN VARCHAR2 IS
      l_Idtfno      VARCHAR2(40);
      l_Check_Point VARCHAR2(1);
      v_leng INT;
   BEGIN
      -- 本过程不作证件号检查, 需要检查的请在外层调用 Check_Identifyno
      l_Idtfno := TRIM(Pi_Identifyno);
      IF Length(l_Idtfno) = 15 THEN
         --将15位转化成18位
       SELECT nvl2(translate(l_Idtfno,'\1234567890','\'),'0',l_Idtfno) INTO v_leng FROM dual;
         IF v_leng <>0 THEN
           l_Idtfno := Substr(l_Idtfno,
                              1,
                              6) || '19' || Substr(l_Idtfno,
                                                   7,
                                                   9);
           l_Check_Point := Get_Check_Point(l_Idtfno);
           l_Idtfno := l_Idtfno || l_Check_Point;
         END IF;
      ELSE
      l_Idtfno :=substr(l_Idtfno,1,length(l_Idtfno)-1)||
               CASE WHEN substr(l_Idtfno,length(l_Idtfno),1)='x' THEN 'X'
                    WHEN substr(l_Idtfno,length(l_Idtfno),1)='*' THEN 'X'
               ELSE substr(l_Idtfno,length(l_Idtfno),1)
               END ;
      END IF;

      RETURN l_Idtfno;

   END Convert_Identifyno;

/

