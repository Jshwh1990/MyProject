create PROCEDURE PRC_20_IC_CTL
(
	S_DATE    VARCHAR,
	E_DATE    VARCHAR,
	CALC_TYPE INTEGER,
	OI_RETURN OUT INTEGER,
	OV_RETMSG OUT VARCHAR
) IS
	/***************************************************************************
    功能模块：指标计算总调过程
    过程名  ：prc_20_ic_ctl.prc
    参数    ：@s_date 开始日期（yyyymmdd) @e_date 结束日期 @calc_type 计算类型：0-全部指标 1-基础指标 2-派生指标 3-劳动
    程序逻辑：按日期循环计算指标
    编写人  ：Lihl
    编写日期：2013-5-8
    更新日期：2013-5-8
  ****************************************************************************/
	VD_DATE       DATE;
	VV_WORK_DATE  VARCHAR(8);
	VI_SUB_RETURN INTEGER;
	VV_SUB_RETMSG VARCHAR(200);
	--vi_cnt        Integer;
	VV_RULE_ORIG VARCHAR(2000); --派生指标计算规则原始串
	VV_COL_DEL   CHAR(2) := 'T('; --派生指标规则串中基础指标分隔符T('xxx')
	VI_START_POS INTEGER; --派生指标特殊字符开始位置
	VI_END_POS   INTEGER; --派生指标特殊结束开始位置
	VV_SUB_OBJ   VARCHAR(30); --派生指标开始到结束位置截取的内容
BEGIN
	--如果开始日期比结束日期大，则退出
	IF S_DATE > E_DATE THEN
		OI_RETURN := -1;
		OV_RETMSG := '[错误]输入开始日期大于结束日期！';
		RETURN;
	END IF;
	FOR I IN 0 .. TO_DATE(E_DATE, 'yyyymmdd') - TO_DATE(S_DATE, 'yyyymmdd')
	LOOP
		VD_DATE      := TO_DATE(S_DATE, 'yyyymmdd') + I;
		VV_WORK_DATE := TO_CHAR(VD_DATE, 'yyyymmdd');
		--手工指标处理
		DELETE FROM PI_CM_QTY
		 WHERE TARGET_DATE = VV_WORK_DATE
			 AND TARGET_CODE LIKE 'I%';
		INSERT INTO PI_CM_QTY
			(MANAGER_NO, AREA_NO, TARGET_DATE, TARGET_CODE, TARGET_VALUE, LOAD_DATE)
			SELECT MANAGER_NO,
						 NVL(AREA_NO, (SELECT AREA_NO FROM PI_CM_QTY WHERE ROWNUM <= 1)),
						 VV_WORK_DATE,
						 A.TARGET_CODE,
						 TARGET_VALUE,
						 TO_CHAR(REC_DAT, 'yyyymmdd')
				FROM PI_CM_QTY_HAND A,
						 (SELECT TARGET_CODE, MAX(TARGET_DATE) TARGET_DATE
								FROM PI_CM_QTY_HAND
							 WHERE TARGET_DATE <= VV_WORK_DATE
							 GROUP BY TARGET_CODE) B
			 WHERE A.TARGET_CODE = B.TARGET_CODE
				 AND A.TARGET_DATE = B.TARGET_DATE;
		COMMIT;
		DELETE FROM PI_ORG_QTY
		 WHERE TARGET_DATE = VV_WORK_DATE
			 AND TARGET_CODE LIKE 'I%';
		INSERT INTO PI_ORG_QTY
			(ORG_NO, AREA_NO, TARGET_DATE, TARGET_CODE, TARGET_VALUE, LOAD_DATE)
			SELECT ORG_NO,
						 NVL(AREA_NO, (SELECT AREA_NO FROM PI_CM_QTY WHERE ROWNUM <= 1)),
						 VV_WORK_DATE,
						 A.TARGET_CODE,
						 TARGET_VALUE,
						 TO_CHAR(REC_DAT, 'yyyymmdd')
				FROM PI_ORG_QTY_HAND A,
						 (SELECT TARGET_CODE, MAX(TARGET_DATE) TARGET_DATE
								FROM PI_ORG_QTY_HAND
							 WHERE TARGET_DATE <= VV_WORK_DATE
							 GROUP BY TARGET_CODE) B
			 WHERE A.TARGET_CODE = B.TARGET_CODE
				 AND A.TARGET_DATE = B.TARGET_DATE;
		FOR RECHAND IN (SELECT DISTINCT TARGET_CODE
											FROM PI_CM_QTY_HAND
										 WHERE TARGET_DATE = VV_WORK_DATE
										UNION
										SELECT DISTINCT TARGET_CODE
											FROM PI_ORG_QTY_HAND
										 WHERE TARGET_DATE = VV_WORK_DATE)
		LOOP
			PRC_IDX_WRITE_LOG(VV_WORK_DATE,
												RECHAND.TARGET_CODE,
												'PRC_20_IC_CTL',
												1,
												'',
												'insert into PI_%_QTY select * from PI_%_QTY_HAND');
		END LOOP;
		COMMIT;
		--基础指标计算
		IF CALC_TYPE IN (0, 1) THEN
			FOR REC IN (SELECT A.TRG_CODE
										FROM OP_TRG_QTY_INFO A,
												 (SELECT T.*,
																 ROW_NUMBER() OVER(PARTITION BY T.TRG_ID ORDER BY T.ENABLE_DATE DESC) RNK
														FROM OP_TRG_QTY_BASE T
													 WHERE VD_DATE >= T.ENABLE_DATE) B
									 WHERE A.TRG_ID = B.TRG_ID
										 AND A.STATUS = '1'
										 AND A.DEL_FLAG = '0'
										 AND B.RNK = 1
										 AND A.TRG_TYPE = 'B'
										 AND A.TRG_ATTRIBUTE = '00')
			LOOP
				PRC_SUB_IC_BASE(VV_WORK_DATE, REC.TRG_CODE, VI_SUB_RETURN, VV_SUB_RETMSG);
				IF VI_SUB_RETURN <> 0 THEN
					OI_RETURN := -1;
					OV_RETMSG := '[错误]基础指标[' || REC.TRG_CODE || ']计算出错.{' || VV_SUB_RETMSG || '}';
					RETURN;
				END IF;
			END LOOP;
		END IF;
		--派生指标计算
		IF CALC_TYPE IN (0, 2) THEN
			EXECUTE IMMEDIATE 'Truncate Table pi_tmp_kpi_derv';
			EXECUTE IMMEDIATE 'Truncate Table pi_tmp_kpi_derv_lvl';
			/*循环计算基础指标的同比环比类指标*/
			FOR REC IN (SELECT A.TRG_CODE
										FROM OP_TRG_QTY_INFO A,
												 (SELECT T.*,
																 ROW_NUMBER() OVER(PARTITION BY T.TRG_ID ORDER BY T.ENABLE_DATE DESC) RNK
														FROM OP_TRG_QTY_BASE T
													 WHERE VD_DATE >= T.ENABLE_DATE) B
									 WHERE A.TRG_ID = B.TRG_ID
										 AND A.STATUS = '1'
										 AND A.DEL_FLAG = '0'
										 AND B.RNK = 1
										 AND A.TRG_TYPE = 'B'
										 AND A.TRG_ATTRIBUTE <> '00')
			LOOP
				PRC_SUB_IC_DERV(VV_WORK_DATE, REC.TRG_CODE, VI_SUB_RETURN, VV_SUB_RETMSG);
				IF VI_SUB_RETURN <> 0 THEN
					OI_RETURN := -1;
					OV_RETMSG := '[错误]基础比较指标[' || REC.TRG_CODE || ']计算出错.{' || VV_SUB_RETMSG || '}';
					RETURN;
				END IF;
			END LOOP;
			/*计算派生指标级别*/
			FOR REC IN (SELECT A.TRG_CODE, B.RULE_RESOLVE
										FROM OP_TRG_QTY_INFO A,
												 (SELECT T.*,
																 ROW_NUMBER() OVER(PARTITION BY T.TRG_ID ORDER BY T.ENABLE_DATE DESC) RNK
														FROM OP_TRG_QTY_BASE T
													 WHERE VD_DATE >= T.ENABLE_DATE) B
									 WHERE A.TRG_ID = B.TRG_ID
										 AND A.STATUS = '1'
										 AND A.DEL_FLAG = '0'
										 AND B.RNK = 1
										 AND A.TRG_TYPE = 'D'
										 AND A.TRG_ATTRIBUTE = '00')
			LOOP
				--清除日志表对应记录
				DELETE FROM PI_KPI_CALC_LOG
				 WHERE DTA_DATE = VV_WORK_DATE
					 AND TRG_CODE = REC.TRG_CODE;
				VV_RULE_ORIG := REC.RULE_RESOLVE;
				WHILE LENGTH(VV_RULE_ORIG) > 0
				LOOP
					IF INSTR(VV_RULE_ORIG, VV_COL_DEL) <= 0 THEN
						EXIT;
					END IF;
					VI_START_POS := INSTR(VV_RULE_ORIG, VV_COL_DEL);
					VI_END_POS   := INSTR(VV_RULE_ORIG, '''', VI_START_POS + 3);
					VV_SUB_OBJ   := SUBSTR(VV_RULE_ORIG,
																 VI_START_POS + 3,
																 VI_END_POS - VI_START_POS - 3);
					INSERT INTO PI_TMP_KPI_DERV VALUES (REC.TRG_CODE, VV_SUB_OBJ);
					VV_RULE_ORIG := SUBSTR(VV_RULE_ORIG, VI_END_POS + 1);
				END LOOP;
			END LOOP;
			/*插入派生指标中同比环比类指标，和其他派生指标一同计算级别*/
			FOR RECDC IN (SELECT A.TRG_CODE
											FROM OP_TRG_QTY_INFO A,
													 (SELECT T.*,
																	 ROW_NUMBER() OVER(PARTITION BY T.TRG_ID ORDER BY T.ENABLE_DATE DESC) RNK
															FROM OP_TRG_QTY_BASE T
														 WHERE VD_DATE >= T.ENABLE_DATE) B
										 WHERE A.TRG_ID = B.TRG_ID
											 AND A.STATUS = '1'
											 AND A.DEL_FLAG = '0'
											 AND B.RNK = 1
											 AND A.TRG_TYPE = 'D'
											 AND A.TRG_ATTRIBUTE <> '00')
			LOOP
				--清除日志表对应记录
				DELETE FROM PI_KPI_CALC_LOG
				 WHERE DTA_DATE = VV_WORK_DATE
					 AND TRG_CODE = RECDC.TRG_CODE;
				INSERT INTO PI_TMP_KPI_DERV
				VALUES
					(RECDC.TRG_CODE,
					 SUBSTR(RECDC.TRG_CODE, 1, LENGTH(RECDC.TRG_CODE) - 2) || '00');
			END LOOP;
			/*\*将不能计算的派生指标（基础指标没有完成）写入错误日志*\
      For rec In (Select a.derv_code, wm_concat(base_code) base_code
                    From (Select Distinct derv_code, base_code
                            From pi_tmp_kpi_derv
                           Where substr(base_code, 1, 1) = 'B') a
                    Left Join pi_kpi_calc_log b
                      On a.base_code = b.trg_code
                     And b.dta_date = vv_work_date
                   Group By a.derv_code
                  Having Min(Case
                    When b.trg_code Is Null Then
                     0
                    Else
                     1
                  End) = 0) Loop
        prc_idx_write_log(vv_work_date, rec.derv_code, 'PRC_SUB_IC_DERV', -1, '基础指标未成功运行：' ||
                           rec.base_code, ''); --write log
      End Loop;
      --判断如果存在基础指标未成功运行的，则退出程序
      Select Count(*)
        Into vi_cnt
        From pi_kpi_calc_log
       Where dta_date = vv_work_date
         And trg_code Like 'D%'
         And status = -1;
      If vi_cnt > 0 Then
        oi_return := -1;
        ov_retmsg := '[错误]派生指标计算出错.{依赖基础指标未成功运行}';
        Return;
      End If;*/
			--递归派生指标与指标依赖关系，计算派生表层级（取最大递归级别），只取可以成功计算的派生指标
			INSERT INTO PI_TMP_KPI_DERV_LVL
				SELECT DERV_CODE, BASE_CODE, LEVEL
					FROM (SELECT DISTINCT DERV_CODE, BASE_CODE
									FROM PI_TMP_KPI_DERV T
								 WHERE NOT EXISTS (SELECT 1
													FROM PI_KPI_CALC_LOG
												 WHERE DTA_DATE = VV_WORK_DATE
													 AND TRG_CODE = T.DERV_CODE
													 AND STATUS = -1)) A
				 START WITH A.BASE_CODE IN
										(SELECT A.BASE_CODE
											 FROM (SELECT DISTINCT DERV_CODE, BASE_CODE
															 FROM PI_TMP_KPI_DERV
															WHERE SUBSTR(BASE_CODE, 1, 1) IN ('B', 'I')) A
											 LEFT JOIN PI_KPI_CALC_LOG B
												 ON A.BASE_CODE = B.TRG_CODE
												AND B.DTA_DATE = VV_WORK_DATE
											GROUP BY A.BASE_CODE
										 HAVING MIN(CASE
											 WHEN B.TRG_CODE IS NULL THEN
												0
											 ELSE
												1
										 END) = 1)
				CONNECT BY PRIOR DERV_CODE = BASE_CODE;
			--开始按派生指标级别循环计算
			FOR REC IN (SELECT DERV_CODE, MAX(DERV_LVL) DERV_LVL
										FROM PI_TMP_KPI_DERV_LVL
									 GROUP BY DERV_CODE
									 ORDER BY DERV_LVL)
			LOOP
				PRC_SUB_IC_DERV(VV_WORK_DATE, REC.DERV_CODE, VI_SUB_RETURN, VV_SUB_RETMSG);
				IF VI_SUB_RETURN <> 0 THEN
					OI_RETURN := -1;
					OV_RETMSG := '[错误]派生指标[' || REC.DERV_CODE || ']计算出错.{' || VV_SUB_RETMSG || '}';
					RETURN;
				END IF;
			END LOOP;
		END IF;
		--劳动竞赛指标计算
		IF CALC_TYPE IN (0, 3) THEN
			FOR REC IN (SELECT A.TRG_CODE
										FROM OP_TRG_QTY_INFO A,
												 (SELECT T.*,
																 ROW_NUMBER() OVER(PARTITION BY T.TRG_ID ORDER BY T.ENABLE_DATE DESC) RNK
														FROM OP_TRG_QTY_BASE T
													 WHERE VD_DATE >= T.ENABLE_DATE) B
									 WHERE A.TRG_ID = B.TRG_ID
										 AND A.STATUS = '1'
										 AND A.DEL_FLAG = '0'
										 AND B.RNK = 1
										 AND A.END_DATE >= VD_DATE --超过结束日期则不计算
										 AND A.START_DATE <= VD_DATE --小于开始日期则不计算
										 AND A.TRG_TYPE = 'L')
			LOOP
				PRC_SUB_IC_LABOR(VV_WORK_DATE, REC.TRG_CODE, VI_SUB_RETURN, VV_SUB_RETMSG);
				IF VI_SUB_RETURN <> 0 THEN
					OI_RETURN := -1;
					OV_RETMSG := '[错误]劳动竞赛指标[' || REC.TRG_CODE || ']计算出错.{' || VV_SUB_RETMSG || '}';
					RETURN;
				END IF;
			END LOOP;
		END IF;
	END LOOP;
	COMMIT;
	OI_RETURN := 0;
	OV_RETMSG := '完成';
EXCEPTION
	WHEN OTHERS THEN
		OI_RETURN := SQLCODE;
		OV_RETMSG := SUBSTR(SQLERRM, 1, 200);
		ROLLBACK;
END;

/

