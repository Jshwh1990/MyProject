create PROCEDURE PRC_05_RB
(
	S_DATE    VARCHAR,
	E_DATE    VARCHAR,
	CALC_TYPE INT,
	RETCODE   OUT INT,
	RETMSG    OUT VARCHAR
)
/* 过程、函数简要描述信息
  **********************************************************
  *  存储过程名:  回算处理
  *  建立日期  :  2013-03-20
  *  作者      :  linyd
  *  模块      :  回算处理
  *  功能描述  :  回算处理
  *  输入参数  ： s_date 处理日期,e_date 处理结束日期,flow_id流水
  *               calc_type 计算类型：10为当日业绩计算，20为外部回算，30为内部回算
  *  输出参数  ： RETCODE 0为正确1为错误， RETMSG错误信息
  *  来源表    ：
  *  目标表    :
  *   备注     ：
  *------------------------------------------------------------
  *  修改历史
  *  序号    日期      修改人      修改原因
  ************************************************************ */
 IS
	P_SQL       LONG;
	RECORD_TIME TIMESTAMP;
	FLOW_ID     VARCHAR2(32);
	P_STEP_ID   VARCHAR2(30);
	STEP_ID     VARCHAR2(30);
	RB_DATE     INT; --最大允许回算天数
	RB_START    DATE; --回算开始日期
	RB_END      DATE; --回算结束日期
	TO_STR      VARCHAR2(8);
BEGIN
	RB_DATE  := 0; --最大允许回算天数
	RB_START := TO_DATE(S_DATE, 'YYYYMMDD') - RB_DATE;
	RB_END   := TO_DATE(S_DATE, 'YYYYMMDD') - 1;
	FLOW_ID  := FNC_GEN_FLOW_ID();
	STEP_ID  := 'LYD_05_RB_';

	/*--每周六才处理回算
  if to_char(to_date(s_date, 'yyyymmdd'), 'd') <> '7' and
     to_date(s_date, 'yyyymmdd') <>
     last_day(add_months(to_date(s_date, 'yyyymmdd'), -1)) + 3 then
    RETCODE := 0;
    return;
  end if;*/

	--把回算表数据标志为回算处理，状态为2
	RECORD_TIME := SYSDATE;
	P_STEP_ID   := STEP_ID || '01';
	RETMSG      := '回算表数据标志为回算处理--失败';
	P_SQL       := 'UPDATE OP_AS_RT_TIME_RECALC SET STATUS = 2 WHERE STATUS = 0'; --修改回算的条件（1改为0）*/
	EXECUTE IMMEDIATE P_SQL;
	RETMSG := '回算表数据标志为回算处理完成.[OP_AS_RT_TIME_RECALC]';
	PRC_SYS_MONITOR_LOG(FLOW_ID,
											S_DATE,
											E_DATE,
											P_STEP_ID,
											RECORD_TIME,
											'PRC_05_RB',
											1,
											RETMSG,
											P_SQL,
											RECORD_TIME,
											1);

	--更改回算开始日期和最大允许回算天数的大者
	RECORD_TIME := SYSDATE;
	P_STEP_ID   := STEP_ID || '02';
	RETMSG      := '更改回算开始日期和最大允许回算天数的大者--失败';
	TO_STR      := TO_CHAR(RB_START, 'YYYYMMDD');
	P_SQL       := 'UPDATE OP_AS_RT_TIME_RECALC a SET a.S_DATE_R=greatest(to_date(''' ||
								 TO_STR ||
								 ''',''yyyymmdd''),a.S_DATE_R),a.E_DATE_R=greatest(to_date(''' ||
								 TO_STR || ''',''yyyymmdd''),a.S_DATE_R) WHERE a.STATUS= 2 ';
	EXECUTE IMMEDIATE P_SQL;
	RETMSG := '更改回算开始日期处理完成.[OP_AS_RT_TIME_RECALC]';
	PRC_SYS_MONITOR_LOG(FLOW_ID,
											S_DATE,
											E_DATE,
											P_STEP_ID,
											RECORD_TIME,
											'PRC_05_RB',
											1,
											RETMSG,
											P_SQL,
											RECORD_TIME,
											1);

	--获取内部回算起始结束日
	SELECT MIN(S_DATE_R) INTO RB_START FROM OP_AS_RT_TIME_RECALC WHERE STATUS = 2;
	IF RB_START IS NULL THEN
		RB_START := TO_DATE('30001231', 'YYYYMMDD');
	END IF;
	IF RB_END IS NULL THEN
		RB_END := TO_DATE('10000101', 'YYYYMMDD');
	END IF;
	--循环批次
	P_STEP_ID := STEP_ID || '03';
	WHILE (RB_START <= RB_END)
	LOOP
		TO_STR    := TO_CHAR(RB_START, 'YYYYMMDD');
		P_STEP_ID := STEP_ID || '03';
		P_STEP_ID := P_STEP_ID || '_' || RB_START;
		--分配规则存储过程集合
		RECORD_TIME := SYSDATE;
		PRC_01_AD(TO_STR, TO_STR, CALC_TYPE, RETCODE, RETMSG);
		IF RETCODE <> 0
			 OR RETCODE IS NULL THEN
			RETMSG := '分配规则存储过程集合-执行出错';
			PRC_SYS_MONITOR_LOG(FLOW_ID,
													TO_STR,
													TO_STR,
													P_STEP_ID,
													RECORD_TIME,
													'PRC_01_AD',
													4,
													RETMSG,
													'',
													RECORD_TIME,
													1);
			ROLLBACK;
			RETURN;
		ELSE
			RETMSG := '分配规则存储过程集合-执行成功';
			PRC_SYS_MONITOR_LOG(FLOW_ID,
													TO_STR,
													TO_STR,
													P_STEP_ID,
													RECORD_TIME,
													'PRC_01_AD',
													1,
													RETMSG,
													'',
													RECORD_TIME,
													1);
		END IF;
		--分配明细修正存储过程集合
		RECORD_TIME := SYSDATE;
		PRC_02_MD(TO_STR, TO_STR, CALC_TYPE, RETCODE, RETMSG);
		IF RETCODE <> 0
			 OR RETCODE IS NULL THEN
			RETMSG := '分配明细修正存储过程集合-执行出错';
			PRC_SYS_MONITOR_LOG(FLOW_ID,
													TO_STR,
													TO_STR,
													P_STEP_ID,
													RECORD_TIME,
													'PRC_02_MD',
													4,
													RETMSG,
													'',
													RECORD_TIME,
													1);
			ROLLBACK;
			RETURN;
		ELSE
			RETMSG := '分配明细修正存储过程集合-执行成功';
			PRC_SYS_MONITOR_LOG(FLOW_ID,
													TO_STR,
													TO_STR,
													P_STEP_ID,
													RECORD_TIME,
													'PRC_02_MD',
													1,
													RETMSG,
													'',
													RECORD_TIME,
													1);
		END IF;
		--数据计算存储过程集合
		RECORD_TIME := SYSDATE;
		PRC_03_PI(TO_STR, TO_STR, CALC_TYPE, RETCODE, RETMSG);
		IF RETCODE <> 0
			 OR RETCODE IS NULL THEN
			RETMSG := '数据计算存储过程集合-执行出错';
			PRC_SYS_MONITOR_LOG(FLOW_ID,
													TO_STR,
													TO_STR,
													P_STEP_ID,
													RECORD_TIME,
													'PRC_03_PI',
													4,
													RETMSG,
													'',
													RECORD_TIME,
													1);
			ROLLBACK;
			RETURN;
		ELSE
			RETMSG := '数据计算存储过程集合-执行成功';
			PRC_SYS_MONITOR_LOG(FLOW_ID,
													TO_STR,
													TO_STR,
													P_STEP_ID,
													RECORD_TIME,
													'PRC_03_PI',
													1,
													RETMSG,
													'',
													RECORD_TIME,
													1);
		END IF;
		--指标计算存储过程集合,回算时只有周末或月末才回算指标
		/*
    IF RB_START = (TRUNC(RB_START, 'd') + 6) OR
       RB_START = last_day(RB_START) THEN
       */
		RECORD_TIME := SYSDATE;
		PRC_04_IC(TO_STR, TO_STR, CALC_TYPE, RETCODE, RETMSG);
		IF RETCODE <> 0
			 OR RETCODE IS NULL THEN
			RETMSG := '指标计算存储过程集合-执行出错';
			PRC_SYS_MONITOR_LOG(FLOW_ID,
													TO_STR,
													TO_STR,
													P_STEP_ID,
													RECORD_TIME,
													'PRC_04_IC',
													4,
													RETMSG,
													'',
													RECORD_TIME,
													1);
			ROLLBACK;
			RETURN;
		ELSE
			RETMSG := '指标计算存储过程集合-执行成功';
			PRC_SYS_MONITOR_LOG(FLOW_ID,
													TO_STR,
													TO_STR,
													P_STEP_ID,
													RECORD_TIME,
													'PRC_04_IC',
													1,
													RETMSG,
													'',
													RECORD_TIME,
													1);
		END IF;
		/*
        END IF;
    */
		RB_START := RB_START + 1;

		--更新回算表日期,回算跑完一天执行一天
		RECORD_TIME := SYSDATE;
		RETMSG      := '更新回算表日期--失败';
		TO_STR      := TO_CHAR(RB_START, 'YYYYMMDD');
		P_SQL       := 'UPDATE OP_AS_RT_TIME_RECALC SET S_DATE_R =to_date(''' || TO_STR ||
									 ''',''yyyymmdd'') WHERE STATUS = 2 AND S_DATE_R < to_date(''' ||
									 TO_STR || ''',''yyyymmdd'') ';
		EXECUTE IMMEDIATE P_SQL;
		RETMSG := '更新回算表日期处理完成.[OP_AS_RT_TIME_RECALC]';
		PRC_SYS_MONITOR_LOG(FLOW_ID,
												TO_STR,
												TO_STR,
												P_STEP_ID,
												RECORD_TIME,
												'PRC_05_RB',
												1,
												RETMSG,
												P_SQL,
												RECORD_TIME,
												1);
	END LOOP;

	--备份单一回算历史表
	RECORD_TIME := SYSDATE;
	P_STEP_ID   := STEP_ID || '04';
	RETMSG      := '备份回算历史表--失败';
	P_SQL       := 'INSERT INTO OP_AS_RT_TIME_RECALC_HIS(HIS_START_DATE, RES_ID, AREA_NO, RULE_TABLE,RES_ORG,S_DATE_R,E_DATE_R,STATUS,MODIFY_DATE)';
	P_SQL       := P_SQL || ' SELECT ''' || S_DATE ||
								 ''',RES_ID, AREA_NO, RULE_TABLE, RES_ORG, S_DATE_R, E_DATE_R, STATUS,MODIFY_DATE';
	P_SQL       := P_SQL || ' FROM OP_AS_RT_TIME_RECALC ';
	P_SQL       := P_SQL || ' WHERE STATUS = 2';
	EXECUTE IMMEDIATE P_SQL;
	RETMSG := '备份回算历史表--完成';
	PRC_SYS_MONITOR_LOG(FLOW_ID,
											S_DATE,
											E_DATE,
											P_STEP_ID,
											RECORD_TIME,
											'PRC_05_RB',
											1,
											RETMSG,
											P_SQL,
											RECORD_TIME,
											1);
	--删除单一回算原表
	RECORD_TIME := SYSDATE;
	P_STEP_ID   := STEP_ID || '05';
	RETMSG      := '删除回算原表--失败';
	P_SQL       := 'DELETE FROM OP_AS_RT_TIME_RECALC WHERE STATUS = 2';
	EXECUTE IMMEDIATE P_SQL;
	RETMSG := '删除回算原表--完成';
	PRC_SYS_MONITOR_LOG(FLOW_ID,
											S_DATE,
											E_DATE,
											P_STEP_ID,
											RECORD_TIME,
											'PRC_05_RB',
											1,
											RETMSG,
											P_SQL,
											RECORD_TIME,
											1);

	RETCODE := 0;
	--回算处理完成
	RECORD_TIME := SYSDATE;
	P_STEP_ID   := STEP_ID || '06';
	RETMSG      := '回算处理-完成';
	PRC_SYS_MONITOR_LOG(FLOW_ID,
											S_DATE,
											E_DATE,
											P_STEP_ID,
											RECORD_TIME,
											'PRC_05_RB',
											1,
											RETMSG,
											'',
											RECORD_TIME,
											1);

EXCEPTION
	WHEN OTHERS THEN
		ROLLBACK;
		RETCODE := -1;
		RETMSG  := '回算处理-执行错误-' || SQLERRM;
		PRC_SYS_MONITOR_LOG(FLOW_ID,
												S_DATE,
												E_DATE,
												P_STEP_ID,
												RECORD_TIME,
												'PRC_05_RB',
												4,
												RETMSG,
												P_SQL,
												RECORD_TIME,
												1);
END;

/

