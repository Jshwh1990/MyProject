create PROCEDURE SP_WRITEDETAILLOG(iv_period       IN VARCHAR2,
                                              iv_jobid        IN VARCHAR2,
                                              iv_operid       IN VARCHAR2,
                                              iv_EvtDesc      IN VARCHAR2,
                                              iv_ErrorCode    IN VARCHAR2,
                                              iv_ErrorSubCode IN VARCHAR2,
                                              iv_ErrorFlag    IN VARCHAR2) IS
  PRAGMA AUTONOMOUS_TRANSACTION;
  v_Period  VARCHAR2(8) := iv_period;
  v_jobid   VARCHAR2(50) := iv_jobid;
  v_OperID  VARCHAR2(50) := iv_operid;
  v_EvtDesc VARCHAR(4000) := '';
  v_sql     VARCHAR2(4000) := '';

BEGIN

  v_EvtDesc := 'crmapp.' || iv_ErrorFlag || ':' || iv_ErrorCode || '/' ||
               iv_ErrorSubCode || ':' || iv_EvtDesc;

  v_sql := 'INSERT INTO   SYS_EVENT_DETAIL' ||
           '  (EVENTSEQ,jobid,PERIOD,OPERID,INSERTTIME,EVENTMSG ) VALUES ' ||
           '(SEQ_LOG.NEXTVAL,:v_jobid,:v_Period,:v_OperID,SYSTIMESTAMP,:v_EvtDesc)';
  EXECUTE IMMEDIATE v_sql
    using v_jobid, v_Period, v_OperID, v_EvtDesc;

  COMMIT;
END;

/

