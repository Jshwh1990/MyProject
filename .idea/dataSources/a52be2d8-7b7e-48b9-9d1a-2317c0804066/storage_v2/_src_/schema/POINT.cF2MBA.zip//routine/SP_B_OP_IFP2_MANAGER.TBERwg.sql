create PROCEDURE SP_B_OP_IFP2_MANAGER(IV_JOBID  IN VARCHAR2,
                                                 IV_OPERID IN VARCHAR2,
                                                 ON_RESULT OUT NUMBER)
--*******************************************************************************
  -- CopyRight (c) 2017, 融丰                                               *
  -- All rights reserved.                                                       *
  --                                                                            *
  -- 文件名称 : SP_B_OP_IFP2_MANAGER.prc                                        *
  -- 摘    要 : A03_手机银行关联人存款数据表加载                                          *
  -- 工程模块 : crmapp.04_27                                                    *
  -- 当前版本 : V1.0.0                                                          *
  -- 作    者 : WXH                                                             *
  -- 完成日期 : 2017/02/09                                                      *
  -- 错误码段 : 40270 - 40279                                                   *
  --*****************************************************************************
 IS
  V_WORK_DATE  VARCHAR2(8);
  V_RETCODE    VARCHAR2(6) := '000000'; --程序/日志返回码
  V_MSG        VARCHAR2(1000); --程序执行信息
  V_TABNAME    VARCHAR2(100); --表名
  V_RETERRFLG  VARCHAR2(1); --日志标志 I(information) W(waring) E(error)
  V_ERRCODE    VARCHAR2(10) := '40279'; --程序执行出错返回码
  V_RETSUBCODE VARCHAR2(3); --程序子返回码
  --V_JOBID      VARCHAR2(50) := 'SP_B_OP_IFP2_MANAGER_LX';
  --V_OPERID     VARCHAR2(50) := 'ZHUY';
  V_JOBID  VARCHAR2(50) := IV_JOBID;
  V_OPERID VARCHAR2(50) := IV_OPERID;
  --V_YEAR_FIRST DATE; --年初
BEGIN

  /*获得业务时间*/
  SELECT WORK_DATE INTO V_WORK_DATE FROM SYS_PARA_DATE_NEW;

  --把日期处理成年初
  --V_YEAR_FIRST := TO_DATE(FNC_GET_DATE(V_WORK_DATE, 'YB'), 'YYYYMMDD');

  V_RETCODE    := '40270';
  V_RETSUBCODE := '001';
  V_RETERRFLG  := 'I';
  V_MSG        := '程序执行开始';
  SP_WRITEDETAILLOG(V_WORK_DATE,
                    V_JOBID,
                    V_OPERID,
                    V_MSG,
                    V_RETCODE,
                    V_RETSUBCODE,
                    V_RETERRFLG);

  V_RETCODE    := '40271';
  V_TABNAME    := 'B_OP_IFP2_MANAGER';
  V_RETERRFLG  := 'I';
  V_RETSUBCODE := '001';
  /*清空手机银行关联人存款数据表*/
  EXECUTE IMMEDIATE 'TRUNCATE TABLE B_OP_IFP2_MANAGER';
  EXECUTE IMMEDIATE 'TRUNCATE TABLE B_OP_IFP2_MANAGER_TEMP';

  --删除不是融丰的数据（上线的时候删除该部分代码。ods下发数据的时候会过滤）
  /*  DELETE from a_ifp2_cif_manage_inf t where t.LEGAL_BR_NO not like '6%';
  COMMIT;
  DELETE from a_ifp2_cif_manage_rel t where t.LEGAL_BR_NO not like '6%';
  COMMIT;*/

  /*写日志*/
  V_MSG := V_TABNAME || '表记录成功清除';
  SP_WRITEDETAILLOG(V_WORK_DATE,
                    V_JOBID,
                    V_OPERID,
                    V_MSG,
                    V_RETCODE,
                    V_RETSUBCODE,
                    V_RETERRFLG);

  V_RETCODE := '40272';

  /*加载数据到手机银行关联人存款数据表*/
  -----第一步：客户经理
  INSERT /*+APPEND*/
  INTO B_OP_IFP2_MANAGER_TEMP NOLOGGING
    (ac_no, --帐号
     ac_id, --帐户id
     ac_seqn, --帐户序号
     mang, --经理代码（存款关联人）
     mang_name, --经理代码（存款关联人）名称
     crt_date, --建立日期
     canl_date, --解除日期
     mang_inviter, --存款关联人的邀请人
     mang_inviter_name, --存款关联人的邀请人名称
     super_no, --inviter上级(存款关联人的邀请人上级)
     super_no_name, --inviter上级(存款关联人的邀请人上级)名称
     cif_no, --客户代码
     performance_no, --业绩归属人
     PERFORMANCE_NAME, --业绩归属人名称
     --sum_bal ,--存款累计数（存款额度）
     OPN_BR_NO,
     PRDT_NO,
     WORK_DATE,
     MANG_CIF_NO,
     MANG_CLIN_NO,
     MANG_IDNO)
    select tp.ac_no, ---帐号
           tp.ac_id, --帐户id
           tp.ac_seqn, --帐户序号
           tp.mang, --经理代码（存款关联人）
           tp.mang_name,
           tp.crt_date,
           tp.canl_date,
           tp.mang_inviter, --存款关联人的邀请人
           tp.name,
           case
             when mm.mang_out is not null then
              mm.mang_out
             when (mm.mang_out is null and mm.mang_in is not null) then
              mm.mang_in
             else
              tp.mang_inviter
           end super_no, --super_no,--inviter上级
           case
             when mm.mang_out is not null then
              mm.mang_name_out
             when (mm.mang_out is null and mm.mang_in is not null) then
              mm.MANG_NAME_IN
             else
              tp.name
           end super_no_name, --super_no,--inviter上级
           tp.cif_no, --客户代码
           --bal--余额
           case
             when mm.mang_out is not null then
              mm.mang_out
             when (mm.mang_out is null and mm.mang_in is not null) then
              mm.mang_in
             else
              tp.mang_inviter
           end performance_no, --b.mang_in--performance_no--业绩归属人
           case
             when mm.mang_out is not null then
              mm.mang_name_out
             when (mm.mang_out is null and mm.mang_in is not null) then
              mm.MANG_NAME_IN
             else
              tp.name
           end performance_no_name, --业绩归属人名称
           --tp.sum_bal,
           TP.OPN_BR_NO,
           TP.PRDT_NO,
           V_WORK_DATE,
           TP.MANG_CIF_NO,
           TP.MANG_CLIN_NO,
           TP.MANG_IDNO
    
      from (select t.ac_no, ---帐号
                   t.ac_id, --帐户id
                   t.ac_seqn, --帐户序号
                   t.mang, --经理代码（存款关联人）
                   nvl(emp.emp_name, f.MANG_NAME) as mang_name, --经理代码（存款关联人）名称
                   nvl(crt.cif_no, emp.emp_no) as MANG_CIF_NO, --存款关联人核心客户号
                   nvl(crt.cif_clino, emp.emp_no) as MANG_CLIN_NO, --存款关联人12位客户号
                   nvl(crt.CIF_IDNO, emp.cert_no) AS MANG_IDNO, --存款关联人身份证
                   t.crt_date,
                   t.canl_date,
                   case
                     when t.mang like '6%' then
                      t.mang
                     when (t.mang not like '6%' and f.mang_out is not null) then
                      f.mang_out
                     when (t.mang not like '6%' and f.mang_out is null and
                          f.mang_in is not null) then
                      f.mang_in
                     else
                      t.mang
                   end mang_inviter, --存款关联人的邀请人
                   case
                     when t.mang like '6%' then
                      emp.emp_name
                     when (t.mang not like '6%' and f.mang_out is not null) then
                      f.mang_name_out
                     when (t.mang not like '6%' and f.mang_out is null and
                          f.mang_in is not null) then
                      f.mang_name_in
                     else
                      nvl(emp.emp_name, f.MANG_NAME)
                   end name, --存款关联人的邀请人的名称
                   t.cif_no, --客户代码
                   T.OPN_BR_NO,
                   T.PRDT_NO
              from a_ifp2_cif_manage_rel t --25054
              left join (select emp_no, cert_no，emp_name
                          from sys_employee
                        -- where STATUS = '1' 关联人是员工
                        ) emp
                on t.mang = emp.emp_no
              left join a_ifp2_eci_cif_register_bak crt
                on crt.CIF_IDNO = emp.cert_no
              left join (select *
                          from a_ifp2_cif_manage_inf
                         where mang_sts = '01'
                           and mang is not null) f
                on f.mang = crt.cif_no
             where t.mang is not null
               and t.mang like '6%') tp
      left join (select *
                   from a_ifp2_cif_manage_inf
                  where mang_sts = '01'
                    and mang is not null) mm
        on mm.mang = tp.mang_inviter;
  commit;

  -----第二步：银行家
  INSERT /*+APPEND*/
  INTO B_OP_IFP2_MANAGER_TEMP NOLOGGING
    (ac_no, --帐号
     ac_id, --帐户id
     ac_seqn, --帐户序号
     mang, --经理代码（存款关联人）
     mang_name, --经理代码（存款关联人）名称
     crt_date, --建立日期
     canl_date, --解除日期
     mang_inviter, --存款关联人的邀请人
     mang_inviter_name, --存款关联人的邀请人名称
     super_no, --inviter上级(存款关联人的邀请人上级)
     super_no_name, --inviter上级(存款关联人的邀请人上级)名称
     cif_no, --客户代码
     performance_no, --业绩归属人
     PERFORMANCE_NAME, --业绩归属人名称
     --sum_bal ,--存款累计数（存款额度）
     OPN_BR_NO,
     PRDT_NO,
     WORK_DATE,
     MANG_CIF_NO,
     MANG_CLIN_NO,
     MANG_IDNO)
    select tp.ac_no, ---帐号
           tp.ac_id, --帐户id
           tp.ac_seqn, --帐户序号
           tp.mang, --经理代码（存款关联人）
           tp.mang_name,
           tp.crt_date,
           tp.canl_date,
           tp.mang_inviter, --存款关联人的邀请人
           tp.name,
           case
             when mm.mang_out is not null then
              mm.mang_out
             when (mm.mang_out is null and mm.mang_in is not null) then
              mm.mang_in
             else
              tp.mang_inviter
           end super_no, --super_no,--inviter上级
           case
             when mm.mang_out is not null then
              mm.mang_name_out
             when (mm.mang_out is null and mm.mang_in is not null) then
              mm.MANG_NAME_IN
             else
              tp.name
           end super_no_name, --super_no,--inviter上级
           tp.cif_no, --客户代码
           --bal--余额
           case
             when mm.mang_out is not null then
              mm.mang_out
             when (mm.mang_out is null and mm.mang_in is not null) then
              mm.mang_in
             else
              tp.mang_inviter
           end performance_no, --b.mang_in--performance_no--业绩归属人
           case
             when mm.mang_out is not null then
              mm.mang_name_out
             when (mm.mang_out is null and mm.mang_in is not null) then
              mm.MANG_NAME_IN
             else
              tp.name
           end performance_no_name, --业绩归属人名称
           --tp.sum_bal,
           TP.OPN_BR_NO,
           TP.PRDT_NO,
           V_WORK_DATE,
           TP.MANG_CIF_NO,
           TP.MANG_CLIN_NO,
           TP.MANG_IDNO
      from (select t.ac_no, ---帐号
                   t.ac_id, --帐户id
                   t.ac_seqn, --帐户序号
                   t.mang, --经理代码（存款关联人）
                   f.MANG_NAME, --经理代码（存款关联人）名称
                   crt.cif_no as MANG_CIF_NO, --核心客户号
                   crt.cif_clino as MANG_CLIN_NO,
                   crt.CIF_IDNO as MANG_IDNO, --存款关联人身份证
                   t.crt_date,
                   t.canl_date,
                   case
                     when f.mang_out is not null then
                      f.mang_out
                     when (f.mang_out is null and f.mang_in is not null) then
                      f.mang_in
                     else
                      t.mang
                   end mang_inviter, --存款关联人的邀请人
                   case
                     when f.mang_out is not null then
                      f.mang_name_out
                     when (f.mang_out is null and f.mang_in is not null) then
                      f.mang_name_in
                     else
                      f.MANG_NAME
                   end name, --存款关联人的邀请人的名称
                   t.cif_no, --客户代码
                   T.OPN_BR_NO,
                   T.PRDT_NO
              from a_ifp2_cif_manage_rel t --25054
              left join a_ifp2_eci_cif_register_bak crt
                on crt.cif_no = t.mang
              left join (select *
                          from a_ifp2_cif_manage_inf
                         where mang_sts = '01'
                           and mang is not null) f
                on f.mang = t.mang
             where t.mang is not null
               and t.mang not like '6%') tp
      left join (select *
                   from a_ifp2_cif_manage_inf
                  where mang_sts = '01'
                    and mang is not null) mm
        on mm.mang = tp.mang_inviter;

  COMMIT;
  --第三步，加工存款关联人和存款关联人邀请人的核心客户号，
  --以及处理存款关联人是银行家的显示12位客户号
  --并将业绩归属人既是银行家又是客户经理的处理为客户经理
  INSERT /*+APPEND*/
  INTO B_OP_IFP2_MANAGER NOLOGGING
    (ac_no, --帐号
     ac_id, --帐户id
     ac_seqn, --帐户序号
     mang, --经理代码（存款关联人）
     mang_name, --经理代码（存款关联人）名称
     crt_date, --建立日期
     canl_date, --解除日期
     mang_inviter, --存款关联人的邀请人
     mang_inviter_name, --存款关联人的邀请人名称
     super_no, --inviter上级(存款关联人的邀请人上级)
     super_no_name, --inviter上级(存款关联人的邀请人上级)名称
     cif_no, --客户代码
     performance_no, --业绩归属人
     PERFORMANCE_NAME, --业绩归属人名称
     --sum_bal ,--存款累计数（存款额度）
     OPN_BR_NO,
     PRDT_NO,
     WORK_DATE,
     MANG_CIF_NO, --存款关联人核心客户号
     INVITER_CIF_NO --存款关联人的邀请人核心客户号
     )
    SELECT TEMP.ac_no, --帐号
           TEMP.ac_id, --帐户id
           TEMP.ac_seqn, --帐户序号
           (case
             when temp.mang like '6%' then
              temp.mang
             else
              NVL(temp.mang_clin_no, temp.mang) --若为员工则展示员工号，若为银行家则展示12位的客户号
           end) mang, --经理代码（存款关联人）
           TEMP.mang_name, --经理代码（存款关联人）名称
           TEMP.crt_date, --建立日期
           TEMP.canl_date, --解除日期
           (case
             when temp.mang_inviter like '6%' then
              temp.mang_inviter
             else
              NVL(CUST.CLINO,temp.mang_inviter) --若为员工则展示员工号，若为银行家则展示12的客户号
           end) mang_inviter, --存款关联人的邀请人
           TEMP.mang_inviter_name, --存款关联人的邀请人名称
           TEMP.super_no, --inviter上级(存款关联人的邀请人上级)
           TEMP.super_no_name, --inviter上级(存款关联人的邀请人上级)名称
           TEMP.cif_no, --客户代码
           nvl(PER.EMP_NO,temp.performance_no) AS performance_no, --业绩归属人
           temp.performance_name, --业绩归属人名称
           TEMP.OPN_BR_NO,
           TEMP.PRDT_NO,
           TEMP.WORK_DATE,
           NVL(TEMP.MANG_CLIN_NO, TEMP.MANG) as MANG_CLIN_NO, --存款关联人12客户号
           NVL(CUST.CLINO, TEMP.MANG_INVITER) AS INVITER_CIF_NO
      FROM B_OP_IFP2_MANAGER_TEMP TEMP
      LEFT JOIN (SELECT ECIO.CIF_NO AS CIFNO,
                        ECIO.CIF_CLINO AS CLINO,
                        nvl(EMPO.EMP_NO, ECIO.CIF_NO) AS EMPNO
                   FROM A_IFP2_ECI_CIF_REGISTER_BAK ECIO
                   LEFT JOIN (select EMP_NO, EMP_NAME, ORG_NO, CERT_NO
                               from SYS_EMPLOYEE EMPO
                             -- where status = '1' --只取在岗的员工
                             ) EMPO
                     ON ECIO.CIF_IDNO = EMPO.CERT_NO) CUST
        ON (TEMP.mang_inviter = CUST.EMPNO)
      LEFT JOIN (SELECT ECI.CIF_NO,
                        ECI.CIF_CLINO,
                        nvl(EMP.EMP_NO, ECI.CIF_NO) as EMP_NO
                   FROM A_IFP2_ECI_CIF_REGISTER_BAK ECI
                   LEFT JOIN (select EMP_NO, EMP_NAME, ORG_NO, CERT_NO
                               from SYS_EMPLOYEE EMP
                             -- where status = '1' --只取在岗的员工
                             ) EMP
                     ON ECI.CIF_IDNO = EMP.CERT_NO) PER
        ON TEMP.performance_no = PER.EMP_NO;
  COMMIT;

  V_TABNAME := 'B_OP_IFP2_MANAGER';
  V_MSG     := V_TABNAME || '成功写入' || SQL%ROWCOUNT || '条记录';
  COMMIT;

  /*写日志*/
  SP_WRITEDETAILLOG(V_WORK_DATE,
                    V_JOBID,
                    V_OPERID,
                    V_MSG,
                    V_RETCODE,
                    V_RETSUBCODE,
                    V_RETERRFLG);

  V_RETCODE := '40274';
  V_TABNAME := 'B_OP_IFP2_MANAGER';
  V_MSG     := V_TABNAME || '表成功写入数据';
  /*写日志*/
  V_RETSUBCODE := '001';
  SP_WRITEDETAILLOG(V_WORK_DATE,
                    V_JOBID,
                    V_OPERID,
                    V_MSG,
                    V_RETCODE,
                    V_RETSUBCODE,
                    V_RETERRFLG);

  V_RETCODE    := '40275';
  V_RETSUBCODE := '001';
  V_RETERRFLG  := 'I';
  V_MSG        := '程序执行结束';
  SP_WRITEDETAILLOG(V_WORK_DATE,
                    V_JOBID,
                    V_OPERID,
                    V_MSG,
                    V_RETCODE,
                    V_RETSUBCODE,
                    V_RETERRFLG);

  ON_RESULT := 0;

  /*异常处理*/
EXCEPTION
  WHEN OTHERS THEN
    V_RETERRFLG := 'E';
    V_RETCODE   := V_ERRCODE;
    V_MSG       := 'SQLCODE:' || V_TABNAME || '表' ||
                   SUBSTR(SQLERRM, 1, 500);
    ON_RESULT   := SQLCODE;
    ROLLBACK;
    SP_WRITEDETAILLOG(V_WORK_DATE,
                      V_JOBID,
                      V_OPERID,
                      V_MSG,
                      V_RETCODE,
                      V_RETSUBCODE,
                      V_RETERRFLG);
    RETURN;
END;
/

