create PROCEDURE SP_CIF_DAT_PS_FLOW(IV_JOBID  IN VARCHAR2,
                                               IV_OPERID IN VARCHAR2,
                                               ON_RESULT OUT NUMBER)
--*******************************************************************************
  -- CopyRight (c) 2018, 融丰银行                                               *
  -- All rights reserved.                                                       *
  --                                                                            *
  -- 文件名称 : SP_CIF_DAT_PS_FLOW.prc                                     *
  -- 摘    要 : A03_个人业务流水数据表加载                                          *
  -- 工程模块 : crmapp.04_27                                                    *
  -- 当前版本 : V1.0.0                                                          *
  -- 作    者 :  lyh                                                            *
  -- 完成日期 : 2018/01/25                                                      *
  -- 错误码段 : 40270 - 40279                                                   *
  --*****************************************************************************
 IS
  V_WORK_DATE  VARCHAR2(8);
  V_RETCODE    VARCHAR2(6) := '000000'; --程序/日志返回码
  V_MSG        VARCHAR2(1000); --程序执行信息
  V_TABNAME    VARCHAR2(100); --表名
  V_RETERRFLG  VARCHAR2(1); --日志标志 I(information) W(waring) E(error)
  V_ERRCODE    VARCHAR2(10) := '40279'; --程序执行出错返回码
  V_RETSUBCODE VARCHAR2(3); --程序子返回码
BEGIN

  /*获得业务时间及相关参数*/
  SELECT WORK_DATE INTO V_WORK_DATE FROM SYS_PARA_DATE_NEW;

  V_RETCODE    := '40270';
  V_RETSUBCODE := '001';
  V_RETERRFLG  := 'I';
  V_MSG        := '程序执行开始';
  SP_WRITEDETAILLOG(V_WORK_DATE,
                    IV_JOBID,
                    IV_OPERID,
                    V_MSG,
                    V_RETCODE,
                    V_RETSUBCODE,
                    V_RETERRFLG);

  V_RETCODE    := '40271';
  V_TABNAME    := 'CIF_DAT_PS_FLOW';
  V_RETERRFLG  := 'I';
  V_RETSUBCODE := '001';
  /*清空个人流水数据表*/
  /*清空表分区*/
  EXECUTE IMMEDIATE 'ALTER TABLE CIF_DAT_PS_FLOW TRUNCATE PARTITION P_' ||
                    V_WORK_DATE;
  --重建索引
  EXECUTE IMMEDIATE 'ALTER INDEX PK_CIF_DAT_PS_FLOW REBUILD';

  /*写日志*/
  V_MSG := V_TABNAME || '表记录成功清除';
  SP_WRITEDETAILLOG(V_WORK_DATE,
                    IV_JOBID,
                    IV_OPERID,
                    V_MSG,
                    V_RETCODE,
                    V_RETSUBCODE,
                    V_RETERRFLG);

  V_RETCODE := '40272';

  /*加载数据到个人流水数据表*/
  INSERT /*+APPEND*/
  INTO CIF_DAT_PS_FLOW NOLOGGING
    (flow_id, -- 交易流水id
     tar_date, -- 交易日期
     area_no, -- 区域号
     acct_no, -- 账号
     main_acct_no, -- 主账号
     biz_cust_no, -- 原业务系统客户号
     acct_name, -- 户名
     biz_type_big, -- 业务大类
     biz_type_small, -- 业务小类
     currency, -- 币种
     subj_code, -- 科目
     prd_code, -- 产品代码
     bal_tra, -- 交易金额
     num_tra, -- 交易笔数
     income_hand, -- 手续费手收
     bal_cash, -- 兑付金额
     tra_chan_type, -- 交易渠道类型
     open_org, -- 交易机构号
     manager_no, -- 客户经理编号
     stat_time, -- 统计日期
     state, -- 分配状态
     is_small_co --  是否小微客户
     )
  
    SELECT t.SERIALID,
           V_WORK_DATE,
           100,
           t.SERIALNO,
           t.SERIALNO,
           0,
           '',
           'N',
           'N',
           'CNY',
           '0',
           '0',
           0,
           1,
           0,
           0,
           t.SERVICETYPE,
           t.BRANCH,
           t.TELLER,
           TO_DATE(T.BUSINESSDATE, 'YYYYMMDD'),
           '0',
           'N'
      FROM A_CNT_TWFT_TRADERECORDS t
     WHERE T.BUSINESSDATE = V_WORK_DATE
       and t.status = '1'; --只取正常结束的

  COMMIT;
  V_MSG := V_TABNAME || '成功写入' || SQL%ROWCOUNT || '条记录';
  COMMIT;
  /*更新分配状态*/
  UPDATE CIF_DAT_PS_FLOW T
     SET T.STATE = '1'
   WHERE t.tar_date = V_WORK_DATE
     and T.STATE = '0'
     AND EXISTS
   (SELECT 1 FROM OP_AS_AR_SA_FLOW B WHERE t.flow_id = B.RES_ID);
  COMMIT;
  UPDATE CIF_DAT_PS_FLOW T
     SET T.STATE = '0'
   WHERE t.tar_date = V_WORK_DATE
     and T.STATE = '1'
     AND NOT EXISTS
   (SELECT 1 FROM OP_AS_AR_SA_FLOW B WHERE t.flow_id = B.RES_ID);
  COMMIT;

  /*写日志*/
  SP_WRITEDETAILLOG(V_WORK_DATE,
                    IV_JOBID,
                    IV_OPERID,
                    V_MSG,
                    V_RETCODE,
                    V_RETSUBCODE,
                    V_RETERRFLG);

  V_RETCODE    := '40275';
  V_RETSUBCODE := '001';
  V_RETERRFLG  := 'I';
  V_MSG        := '程序执行结束';
  SP_WRITEDETAILLOG(V_WORK_DATE,
                    IV_JOBID,
                    IV_OPERID,
                    V_MSG,
                    V_RETCODE,
                    V_RETSUBCODE,
                    V_RETERRFLG);

  ON_RESULT := 0;
  /*异常处理*/
EXCEPTION
  WHEN OTHERS THEN
    V_RETERRFLG := 'E';
    V_RETCODE   := V_ERRCODE;
    V_MSG       := 'SQLCODE:' || V_TABNAME || '表' ||
                   SUBSTR(SQLERRM, 1, 500);
    ON_RESULT   := SQLCODE;
    ROLLBACK;
    SP_WRITEDETAILLOG(V_WORK_DATE,
                      IV_JOBID,
                      IV_OPERID,
                      V_MSG,
                      V_RETCODE,
                      V_RETSUBCODE,
                      V_RETERRFLG);
    RETURN;
END;
/

