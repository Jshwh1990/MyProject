create PROCEDURE PRC_02_MD
(
	S_DATE    VARCHAR,
	E_DATE    VARCHAR,
	CALC_TYPE INT,
	RETCODE   OUT INT,
	RETMSG    OUT VARCHAR
)
/* 过程、函数简要描述信息
  **********************************************************
  *  存储过程名:  分配明细修正存储过程集合
  *  建立日期  :  2013-03-20
  *  作者      :  linyd
  *  模块      :  业绩分配规模
  *  功能描述  :  分配明细修正存储过程集合
  *  输入参数  ： s_date 处理日期,e_date 处理结束日期,flow_id流水
  *               calc_type 计算类型：10为当日业绩计算，20为外部回算，30为内部回算
  *  输出参数  ： RETCODE 0为正确1为错误， RETMSG错误信息
  *  来源表    ：
  *  目标表    :
  *   备注     ：存储过程名 PRC_01_AD
  *------------------------------------------------------------
  *  修改历史
  *  序号    日期      修改人      修改原因
  ************************************************************ */
 IS
	RECORD_TIME TIMESTAMP;
	FLOW_ID     VARCHAR2(32);
	P_STEP_ID   VARCHAR2(30);
	STEP_ID     VARCHAR2(30);
BEGIN
	FLOW_ID := FNC_GEN_FLOW_ID();
	STEP_ID := 'LYD_02_MD_';

	--零售主账户修正
	RECORD_TIME := SYSDATE;
	P_STEP_ID   := STEP_ID || '01';
	PRC_12_SM_MODIFY(S_DATE, E_DATE, CALC_TYPE, RETCODE, RETMSG);
	IF RETCODE <> 0
		 OR RETCODE IS NULL THEN
		RETMSG := '零售主账户修正-执行出错';
		PRC_SYS_MONITOR_LOG(FLOW_ID,
												S_DATE,
												E_DATE,
												P_STEP_ID,
												RECORD_TIME,
												'PRC_12_SM_MODIFY',
												4,
												RETMSG,
												'',
												RECORD_TIME,
												1);
		ROLLBACK;
		RETURN;
	ELSE
		RETMSG := '零售主账户修正-执行成功';
		PRC_SYS_MONITOR_LOG(FLOW_ID,
												S_DATE,
												E_DATE,
												P_STEP_ID,
												RECORD_TIME,
												'PRC_12_SM_MODIFY',
												1,
												RETMSG,
												'',
												RECORD_TIME,
												1);
	END IF;

	--对公客户修正
	RECORD_TIME := SYSDATE;
	P_STEP_ID   := STEP_ID || '02';
	PRC_13_CC_MODIFY(S_DATE, E_DATE, CALC_TYPE, RETCODE, RETMSG);
	IF RETCODE <> 0
		 OR RETCODE IS NULL THEN
		RETMSG := '对公客户修正-执行出错';
		PRC_SYS_MONITOR_LOG(FLOW_ID,
												S_DATE,
												E_DATE,
												P_STEP_ID,
												RECORD_TIME,
												'PRC_13_CC_MODIFY',
												4,
												RETMSG,
												'',
												RECORD_TIME,
												1);
		ROLLBACK;
		RETURN;
	ELSE
		RETMSG := '对公客户修正-执行成功';
		PRC_SYS_MONITOR_LOG(FLOW_ID,
												S_DATE,
												E_DATE,
												P_STEP_ID,
												RECORD_TIME,
												'PRC_13_CC_MODIFY',
												1,
												RETMSG,
												'',
												RECORD_TIME,
												1);
	END IF;

	--零售客户修正
	RECORD_TIME := SYSDATE;
	P_STEP_ID   := STEP_ID || '03';
	PRC_13_SC_MODIFY(S_DATE, E_DATE, CALC_TYPE, RETCODE, RETMSG);
	IF RETCODE <> 0
		 OR RETCODE IS NULL THEN
		RETMSG := '零售客户修正-执行出错';
		PRC_SYS_MONITOR_LOG(FLOW_ID,
												S_DATE,
												E_DATE,
												P_STEP_ID,
												RECORD_TIME,
												'PRC_13_SC_MODIFY',
												4,
												RETMSG,
												'',
												RECORD_TIME,
												1);
		ROLLBACK;
		RETURN;
	ELSE
		RETMSG := '零售客户修正-执行成功';
		PRC_SYS_MONITOR_LOG(FLOW_ID,
												S_DATE,
												E_DATE,
												P_STEP_ID,
												RECORD_TIME,
												'PRC_13_SC_MODIFY',
												1,
												RETMSG,
												'',
												RECORD_TIME,
												1);
	END IF;

EXCEPTION
	WHEN OTHERS THEN
		ROLLBACK;
		RETCODE := -1;
		RETMSG  := '分配明细修正存储过程集合-执行错误-' || SQLERRM;
		PRC_SYS_MONITOR_LOG(FLOW_ID,
												S_DATE,
												E_DATE,
												P_STEP_ID,
												RECORD_TIME,
												'PRC_02_MD',
												4,
												RETMSG,
												'',
												RECORD_TIME,
												1);
END;

/

