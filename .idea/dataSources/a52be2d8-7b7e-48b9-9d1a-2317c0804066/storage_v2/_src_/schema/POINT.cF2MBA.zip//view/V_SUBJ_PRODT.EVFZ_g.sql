create view V_SUBJ_PRODT as
  select a.prdt_no, --产品号
       a.title prdt_name, --产品名称
       c.acc_no, --科目号
       c.ACC_NAME --科目名称
  from a_cbs_td_parm a, a_cbs_DC_ACC_REL b, a_cbs_com_item c
 where a.dc_code = b.dc_code
   and b.data_code = '0152' --如果是要取利息的科目将'0152'换成'0153'
   and b.ACC_HRT = c.acc_hrt
 group by a.prdt_no, --产品号
          a.title,
          title, --产品名称
          c.acc_no, --科目号
          c.ACC_NAME
union all
select a.prdt_no, --产品号
       a.title prdt_name, --产品名称
       c.acc_no, --科目号
       c.ACC_NAME --科目名称
  from a_cbs_dd_parm a, a_cbs_DC_ACC_REL b, a_cbs_com_item c
 where a.dc_code = b.dc_code
   and b.data_code = '0152' --如果是要取利息的科目将'0152'换成'0153'
   and b.ACC_HRT = c.acc_hrt
 group by a.prdt_no, --产品号
          a.title,
          title, --产品名称
          c.acc_no, --科目号
          c.ACC_NAME
/

