create Function fnc_get_ic_param(p_grp_cd Varchar,
                                            p_itm_cd Varchar,
                                            p_date   Varchar) Return Number Is
  /***************************************************************************
    功能模块：派生指标配置中返回参数值
    目标表  ：
    过程名  ：fnc_get_ic_param.prc
    参数    ：@p_grp_cd 参数组编码
    程序逻辑：根据组编码与参数项编码从参数表得到值；
    编写人  ：Lihl
    编写日期：2013-5-9
    更新日期：2013-5-9
  ****************************************************************************/
  on_return Number; --返回参数值
Begin
  Begin
    Select to_number(v.param_item_value)
      Into on_return
      From op_par_value v
     Where v.param_group_code = p_grp_cd
       And v.param_item_code = p_itm_cd
       And to_date(p_date, 'yyyymmdd') Between v.start_dat And v.end_dat;
  Exception
    When no_data_found Then
      --如果找不到该值，则置为参数组默认值
      Select to_number(g.param_default_value)
        Into on_return
        From op_par_group g
       Where g.param_group_code = p_grp_cd;
  End;
  Return on_return;
End;

/

