create PROCEDURE PRC_00_START
(
	S_DATE    VARCHAR,
	E_DATE    VARCHAR,
	CALC_TYPE INT,
	RETCODE   OUT INT,
	RETMSG    OUT VARCHAR
)
/* 过程、函数简要描述信息
  **********************************************************
  *  存储过程名:  绩效总调
  *  建立日期  :  2013-03-20
  *  作者      :  linyd
  *  模块      :  绩效总调
  *  功能描述  :  绩效总调
  *  输入参数  ： s_date 处理日期,e_date 处理结束日期,flow_id流水
  *               calc_type 计算类型：10为当日业绩计算，20为外部回算，30为内部回算
  *  输出参数  ： RETCODE 0为正确1为错误， RETMSG错误信息
  *  来源表    ：
  *  目标表    :
  *   备注     ：
  *------------------------------------------------------------
  *  修改历史
  *  序号    日期      修改人      修改原因
  ************************************************************ */
 IS
	RECORD_TIME TIMESTAMP;
	FLOW_ID     VARCHAR2(32);
	P_STEP_ID   VARCHAR2(30);
	STEP_ID     VARCHAR2(30);
	P_SQL       LONG;
	--RATE_NUM    INT;
	--ON_RESULT   NUMBER(5);
BEGIN
	FLOW_ID := FNC_GEN_FLOW_ID();
	STEP_ID := 'LYD_00_START_';

	--清空分配计算日志表
	P_SQL := 'TRUNCATE TABLE SYS_MONITOR_LOG';
	EXECUTE IMMEDIATE P_SQL;
	--清空指标计算日志表
	P_SQL := 'TRUNCATE TABLE PI_KPI_CALC_LOG';
	EXECUTE IMMEDIATE P_SQL;

	--柜员自动分配
	/*RECORD_TIME := SYSDATE;
  P_STEP_ID   := STEP_ID || '00';
  SP_GY_FENPEI('', '', RETCODE);
  IF RETCODE <> 0
     OR RETCODE IS NULL THEN
    RETMSG := '柜员自动分配-执行出错';
    PRC_SYS_MONITOR_LOG(FLOW_ID,
                        S_DATE,
                        E_DATE,
                        P_STEP_ID,
                        RECORD_TIME,
                        'SP_GY_FENPEI',
                        4,
                        RETMSG,
                        '',
                        RECORD_TIME,
                        1);
    ROLLBACK;
    RETURN;
  ELSE
    RETMSG := '柜员自动分配-执行成功';
    PRC_SYS_MONITOR_LOG(FLOW_ID,
                        S_DATE,
                        E_DATE,
                        P_STEP_ID,
                        RECORD_TIME,
                        'SP_GY_FENPEI',
                        1,
                        RETMSG,
                        '',
                        RECORD_TIME,
                        1);
  END IF;*/

	--业绩分配初始化处理
	/*RECORD_TIME := SYSDATE;
  P_STEP_ID   := STEP_ID || '00';
  PRC_10_RULE_INIT(S_DATE, E_DATE, RETCODE, RETMSG);
  IF RETCODE <> 0
     OR RETCODE IS NULL THEN
    RETMSG := '业绩分配初始化处理-执行出错';
    PRC_SYS_MONITOR_LOG(FLOW_ID,
                        S_DATE,
                        E_DATE,
                        P_STEP_ID,
                        RECORD_TIME,
                        'prc_10_rule_init',
                        4,
                        RETMSG,
                        '',
                        RECORD_TIME,
                        1);
    ROLLBACK;
    RETURN;
  ELSE
    RETMSG := '业绩分配初始化处理-执行成功';
    PRC_SYS_MONITOR_LOG(FLOW_ID,
                        S_DATE,
                        E_DATE,
                        P_STEP_ID,
                        RECORD_TIME,
                        'prc_10_rule_init',
                        1,
                        RETMSG,
                        '',
                        RECORD_TIME,
                        1);
  END IF;*/

	--业绩回算处理
	RECORD_TIME := SYSDATE;
  P_STEP_ID   := STEP_ID || '01';
  PRC_05_RB(S_DATE, E_DATE, CALC_TYPE, RETCODE, RETMSG);
  IF RETCODE <> 0
     OR RETCODE IS NULL THEN
    RETMSG := '业绩回算处理-执行出错';
    PRC_SYS_MONITOR_LOG(FLOW_ID,
                        S_DATE,
                        E_DATE,
                        P_STEP_ID,
                        RECORD_TIME,
                        'PRC_05_RB',
                        4,
                        RETMSG,
                        '',
                        RECORD_TIME,
                        1);
    ROLLBACK;
    RETURN;
  ELSE
    RETMSG := '业绩回算处理-执行成功';
    PRC_SYS_MONITOR_LOG(FLOW_ID,
                        S_DATE,
                        E_DATE,
                        P_STEP_ID,
                        RECORD_TIME,
                        'PRC_05_RB',
                        1,
                        RETMSG,
                        '',
                        RECORD_TIME,
                        1);
  END IF;

	--分配规则存储过程集合
	RECORD_TIME := SYSDATE;
	P_STEP_ID   := STEP_ID || '02';
	PRC_01_AD(S_DATE, E_DATE, CALC_TYPE, RETCODE, RETMSG);
	IF RETCODE <> 0
		 OR RETCODE IS NULL THEN
		RETMSG := '分配规则存储过程集合-执行出错';
		PRC_SYS_MONITOR_LOG(FLOW_ID,
												S_DATE,
												E_DATE,
												P_STEP_ID,
												RECORD_TIME,
												'PRC_01_AD',
												4,
												RETMSG,
												'',
												RECORD_TIME,
												1);
		ROLLBACK;
		RETURN;
	ELSE
		RETMSG := '分配规则存储过程集合-执行成功';
		PRC_SYS_MONITOR_LOG(FLOW_ID,
												S_DATE,
												E_DATE,
												P_STEP_ID,
												RECORD_TIME,
												'PRC_01_AD',
												1,
												RETMSG,
												'',
												RECORD_TIME,
												1);
	END IF;

	--分配明细修正存储过程集合
	RECORD_TIME := SYSDATE;
	P_STEP_ID   := STEP_ID || '03';
	PRC_02_MD(S_DATE, E_DATE, CALC_TYPE, RETCODE, RETMSG);
	IF RETCODE <> 0
		 OR RETCODE IS NULL THEN
		RETMSG := '分配明细修正存储过程集合-执行出错';
		PRC_SYS_MONITOR_LOG(FLOW_ID,
												S_DATE,
												E_DATE,
												P_STEP_ID,
												RECORD_TIME,
												'PRC_02_MD',
												4,
												RETMSG,
												'',
												RECORD_TIME,
												1);
		ROLLBACK;
		RETURN;
	ELSE
		RETMSG := '分配明细修正存储过程集合-执行成功';
		PRC_SYS_MONITOR_LOG(FLOW_ID,
												S_DATE,
												E_DATE,
												P_STEP_ID,
												RECORD_TIME,
												'PRC_02_MD',
												1,
												RETMSG,
												'',
												RECORD_TIME,
												1);
	END IF;

	--数据计算存储过程集合
	RECORD_TIME := SYSDATE;
	P_STEP_ID   := STEP_ID || '04';
	PRC_03_PI(S_DATE, E_DATE, CALC_TYPE, RETCODE, RETMSG);
	IF RETCODE <> 0
		 OR RETCODE IS NULL THEN
		RETMSG := '数据计算存储过程集合-执行出错';
		PRC_SYS_MONITOR_LOG(FLOW_ID,
												S_DATE,
												E_DATE,
												P_STEP_ID,
												RECORD_TIME,
												'PRC_03_PI',
												4,
												RETMSG,
												'',
												RECORD_TIME,
												1);
		ROLLBACK;
		RETURN;
	ELSE
		RETMSG := '数据计算存储过程集合-执行成功';
		PRC_SYS_MONITOR_LOG(FLOW_ID,
												S_DATE,
												E_DATE,
												P_STEP_ID,
												RECORD_TIME,
												'PRC_03_PI',
												1,
												RETMSG,
												'',
												RECORD_TIME,
												1);
	END IF;

	/*--任务口径数据计算存储过程集合
	RECORD_TIME := SYSDATE;
	P_STEP_ID   := STEP_ID || '04a';
	TGT_01_IC(S_DATE, E_DATE, CALC_TYPE, RETCODE, RETMSG);
	IF RETCODE <> 0
		 OR RETCODE IS NULL THEN
		RETMSG := '任务口径数据计算存储过程集合-执行出错';
		PRC_SYS_MONITOR_LOG(FLOW_ID,
												S_DATE,
												E_DATE,
												P_STEP_ID,
												RECORD_TIME,
												'TGT_01_IC',
												4,
												RETMSG,
												'',
												RECORD_TIME,
												1);
		ROLLBACK;
		RETURN;
	ELSE
		RETMSG := '任务口径数据计算存储过程集合-执行成功';
		PRC_SYS_MONITOR_LOG(FLOW_ID,
												S_DATE,
												E_DATE,
												P_STEP_ID,
												RECORD_TIME,
												'TGT_01_IC',
												1,
												RETMSG,
												'',
												RECORD_TIME,
												1);
	END IF;
*/
	--指标计算存储过程集合
	RECORD_TIME := SYSDATE;
	P_STEP_ID   := STEP_ID || '05';
	PRC_04_IC(S_DATE, E_DATE, CALC_TYPE, RETCODE, RETMSG);
	IF RETCODE <> 0
		 OR RETCODE IS NULL THEN
		RETMSG := '指标计算存储过程集合-执行出错';
		PRC_SYS_MONITOR_LOG(FLOW_ID,
												S_DATE,
												E_DATE,
												P_STEP_ID,
												RECORD_TIME,
												'PRC_04_IC',
												4,
												RETMSG,
												'',
												RECORD_TIME,
												1);
		ROLLBACK;
		RETURN;
	ELSE
		RETMSG := '指标计算存储过程集合-执行成功';
		PRC_SYS_MONITOR_LOG(FLOW_ID,
												S_DATE,
												E_DATE,
												P_STEP_ID,
												RECORD_TIME,
												'PRC_04_IC',
												1,
												RETMSG,
												'',
												RECORD_TIME,
												1);
	END IF;

	/*--机构和人员考核方案自动计算
	RECORD_TIME := SYSDATE;
	P_STEP_ID   := STEP_ID || '06';
	PRC_EWM_AUTO_COUNT(S_DATE, E_DATE, RETCODE, RETMSG);
	IF RETCODE <> 0
		 OR RETCODE IS NULL THEN
		RETMSG := '机构和人员考核方案自动计算-执行出错';
		PRC_SYS_MONITOR_LOG(FLOW_ID,
												S_DATE,
												E_DATE,
												P_STEP_ID,
												RECORD_TIME,
												'PRC_EWM_AUTO_COUNT',
												4,
												RETMSG,
												'',
												RECORD_TIME,
												1);
		ROLLBACK;
		RETURN;
	ELSE
		RETMSG := '机构和人员考核方案自动计算-执行成功';
		PRC_SYS_MONITOR_LOG(FLOW_ID,
												S_DATE,
												E_DATE,
												P_STEP_ID,
												RECORD_TIME,
												'PRC_EWM_AUTO_COUNT',
												1,
												RETMSG,
												'',
												RECORD_TIME,
												1);
	END IF;
*/
	--机构和人员薪资计算
	/*RECORD_TIME := SYSDATE;
	P_STEP_ID   := STEP_ID || '07';
	PRC_SAL_COUNT(S_DATE, E_DATE, RETCODE, RETMSG);
	IF RETCODE <> 0
		 OR RETCODE IS NULL THEN
		RETMSG := '机构和人员薪资计算-执行出错';
		PRC_SYS_MONITOR_LOG(FLOW_ID,
												S_DATE,
												E_DATE,
												P_STEP_ID,
												RECORD_TIME,
												'PRC_SAL_COUNT',
												4,
												RETMSG,
												'',
												RECORD_TIME,
												1);
		ROLLBACK;
		RETURN;
	ELSE
		RETMSG := '机构和人员薪资计算-执行成功';
		PRC_SYS_MONITOR_LOG(FLOW_ID,
												S_DATE,
												E_DATE,
												P_STEP_ID,
												RECORD_TIME,
												'PRC_SAL_COUNT',
												1,
												RETMSG,
												'',
												RECORD_TIME,
												1);
	END IF;
*/
	RECORD_TIME := SYSDATE;
	P_STEP_ID   := STEP_ID || 'OK';
	RETMSG      := '绩效总调-执行成功';
	PRC_SYS_MONITOR_LOG(FLOW_ID,
											S_DATE,
											E_DATE,
											P_STEP_ID,
											RECORD_TIME,
											'PRC_00_START',
											8,
											RETMSG,
											'',
											RECORD_TIME,
											1);

	/*IF TO_CHAR(SYSDATE, 'MMDD') = '1231' THEN
    PRC_MO_PLAN_CYC();
  END IF;*/

	/*SELECT COUNT(1) INTO RATE_NUM FROM B_1_ACCT_RATE_OUT T WHERE T.TAR_DATE = S_DATE;
	IF RATE_NUM > 0 THEN
		SP_RPT_COMP_DEBT_RAT('rpt_comp', 'rpt_comp', ON_RESULT);

	END IF;
*/
	RETCODE := 0;

EXCEPTION
	WHEN OTHERS THEN
		ROLLBACK;
		RETCODE := -1;
		RETMSG  := '绩效总调-执行错误-' || SQLERRM;
		PRC_SYS_MONITOR_LOG(FLOW_ID,
												S_DATE,
												E_DATE,
												P_STEP_ID,
												RECORD_TIME,
												'PRC_00_START',
												4,
												RETMSG,
												'',
												RECORD_TIME,
												1);
END;

/

