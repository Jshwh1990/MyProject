create PROCEDURE PRC_T_SCH_TASK_INSTANCE
(
  I_DATE VARCHAR,
  RETMSG OUT VARCHAR
) IS
  --更新调度实例表
  P_DATE      DATE;
  P_SQL       VARCHAR2(2000);
  P_TASK_ID   VARCHAR2(40);
  P_DEP_GROUP VARCHAR2(100);
  P_DEP_TASK  VARCHAR2(1000);
  P_DEP_TASK2 VARCHAR2(1000);
  P_TEMP      VARCHAR2(2000);
  P_TEMP2     VARCHAR2(2000);
  TEMP        VARCHAR2(1000);
  K           INTEGER;

  CURSOR CUR1(IDATE DATE) IS
    SELECT TRIM(A.TASK_ID), TRIM(A.DEP_GROUP), TRIM(B.DEP_TASK)
      FROM T_SCH_TASK_INSTANCE A, T_TASK_SCH_DESC B
     WHERE A.TASK_ID = B.TASK_ID
       AND PROC_FLAG <> '2'
       AND RUN_DATE = IDATE
       AND (B.DEP_GROUP IS NOT NULL OR LENGTH(TRIM(B.DEP_GROUP)) > 0);

  CURSOR CUR2(ID VARCHAR) IS
    SELECT TRIM(TASK_ID)
      FROM T_SCH_TASK_GROUP_DESC
     WHERE GROUP_ID = ID
     ORDER BY TASK_ID;

BEGIN
  RETMSG := '';
  P_DATE := TO_DATE(I_DATE, 'YYYYMMDD');

  INSERT INTO T_SCH_TASK_INSTANCE
    (TASK_ID,
     RUN_DATE,
     DEP_GROUP,
     DEP_TASK,
     TASK_SHELL,
     PROC_FLAG,
     CUST_PARA,
     START_TIME,
     END_TIME,
     CANRUNFLAG,
     ALL_TIME,
     SHELL_RET,
     STD_RES_CNT,
     APP_NAME)
    SELECT TASK_ID,
           P_DATE,
           DEP_GROUP,
           DEP_TASK,
           TASK_SHELL,
           '0',
           CUST_PARA,
           NULL,
           NULL,
           '0',
           NULL,
           NULL,
           NULL,
           APP_NAME
      FROM T_TASK_SCH_DESC A
     WHERE NOT EXISTS (SELECT 1
              FROM T_SCH_TASK_INSTANCE B
             WHERE A.TASK_ID = B.TASK_ID
               AND RUN_DATE = P_DATE);

  COMMIT;

  OPEN CUR1(P_DATE);

  LOOP
    FETCH CUR1
      INTO P_TASK_ID, P_DEP_GROUP, P_DEP_TASK;
    EXIT WHEN CUR1 %NOTFOUND;

    P_TEMP2 := P_DEP_TASK;
    TEMP    := P_DEP_GROUP; --temp保存所有组，中间用逗号隔开
    K       := 1;

    LOOP
      EXIT WHEN K = 0;
      SELECT INSTR(TEMP, ',', 1) INTO K FROM DUAL; --查询第一个逗号在字符串中的位置(p_dep_group非空且不等于'')
      IF K = 0 --只有一个组
       THEN
        OPEN CUR2(TEMP);
        P_TEMP := '';
        LOOP
          FETCH CUR2
            INTO P_DEP_TASK2;
          EXIT WHEN CUR2 %NOTFOUND;
          P_TEMP := P_TEMP || ',' || P_DEP_TASK2;
        END LOOP;
        CLOSE CUR2;
      ELSE
        OPEN CUR2(SUBSTR(TEMP, 1, K - 1)); --查询第一个组的依赖任务
        P_TEMP := '';
        LOOP
          FETCH CUR2
            INTO P_DEP_TASK2;
          EXIT WHEN CUR2 %NOTFOUND;
          P_TEMP := P_TEMP || ',' || P_DEP_TASK2;
        END LOOP;
        CLOSE CUR2;
      END IF;

      TEMP := SUBSTR(TEMP, K + 1, LENGTH(TEMP)); --temp中去掉第一个组

      --p_temp保存当前组的所有任务，p_temp2保存当前任务的所有依赖任务
      IF (SUBSTR(P_TEMP, 1, 1) = ',' AND
         (P_TEMP2 IS NULL OR LENGTH(TRIM(P_TEMP2)) = 0)) THEN
        P_TEMP2 := SUBSTR(P_TEMP, 2, LENGTH(P_TEMP) - 1);
      ELSE
        IF (SUBSTR(P_TEMP, 1, 1) = ',' AND
           (P_TEMP2 IS NOT NULL AND LENGTH(TRIM(P_TEMP2)) > 0)) THEN
          P_TEMP2 := P_TEMP2 || P_TEMP;
        END IF;
      END IF;
    END LOOP;

    P_SQL := 'update T_SCH_TASK_INSTANCE set dep_task=''' || P_TEMP2 ||
             ''' where task_id=''' || P_TASK_ID || ''' and run_date=''' || P_DATE || '''';
    EXECUTE IMMEDIATE P_SQL;
  END LOOP;

  CLOSE CUR1;
  COMMIT;

  RETMSG := '更新完成';
END;

/

