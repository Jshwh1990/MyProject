create PROCEDURE PRC_EWM_CM_DT_SS
(
	P_WAYID   IN VARCHAR,
	P_SEGCODE IN VARCHAR,
	IS_ADJ    IN INT,
	RETCODE   OUT INT,
	ERRMSG    OUT VARCHAR
) IS
	/* 过程、函数简要描述信息
  **********************************************************
  *  存储过程名: 机构计算成绩汇总过程
  *  建立日期  : 2013-05-29
  *  作者      : zhuy
  *  模块      : 绩效考核管理
  *  功能描述  : 机构考核方案成绩汇总计算
  *  输入参数  ：P_WAYID 方案ID P_WAYCODE 方案代码, IS_ADJ 是否调整得分
  *  输出参数  ：RETCODE 成功为0 ,ERRMSG 错误信息
  *   备注     :
  *------------------------------------------------------------
  *  修改历史
  *  序号    日期      修改人      修改原因
  ************************************************************ */
	V_SCORE_ALL   NUMBER(12, 2); --方案计算得分
	V_SCORE_ADJ_1 NUMBER(12, 2); --增减比例调整后得分
	V_SCORE_ADJ   NUMBER(12, 2); --增减幅度调整后得分
	V_WAY_ID      VARCHAR2(64);
	V_SEG_CODE    VARCHAR2(64);
	V_STAFF_ID    VARCHAR2(64);

	CURSOR CUR IS
		SELECT WAY_ID, SEG_CODE, STAFF_ID, SUM(A_SCORE)
			FROM (SELECT A.WAY_ID,
									 A.SEG_CODE,
									 A.STAFF_ID,
									 A.TARGET_CODE,
									 A.CALC_SCORE,
									 A.ADJ_SCORE,
									 A.ADJ_EFF_FLAG,
									 CASE
										 WHEN ADJ_EFF_FLAG = '1' THEN
											NVL(ADJ_SCORE, CALC_SCORE)
										 ELSE
											CALC_SCORE
									 END A_SCORE
							FROM MO_EWM_CM_DT A
						 WHERE A.WAY_ID = P_WAYID
							 AND NVL(A.SEG_CODE, ' ') = P_SEGCODE
						UNION ALL
						SELECT B.WAY_ID,
									 B.SEG_CODE,
									 B.STAFF_ID,
									 B.TARGET_CODE,
									 B.TARGET_VALUE CALC_SCORE,
									 B.TARGET_VALUE ADJ_SCORE,
									 '0' ADJ_EFF_FLAG,
									 B.TARGET_VALUE A_SCORE
							FROM MO_HEY_CM_PROP_TRG B
						 WHERE B.WAY_ID = P_WAYID
							 AND NVL(B.SEG_CODE, ' ') = P_SEGCODE)
		 GROUP BY WAY_ID, SEG_CODE, STAFF_ID;

BEGIN

	--清空方案汇总数据
	DELETE FROM MO_EWM_CM_DT_SS
	 WHERE WAY_ID = P_WAYID
		 AND NVL(SEG_CODE, ' ') = P_SEGCODE;
	COMMIT;

	OPEN CUR;
	LOOP
		FETCH CUR
			INTO V_WAY_ID, V_SEG_CODE, V_STAFF_ID, V_SCORE_ALL;
		EXIT WHEN CUR % NOTFOUND;
		IF IS_ADJ = 1 THEN
			IF V_SCORE_ALL <> 0 THEN
				--增减比例调整
				V_SCORE_ADJ := 1000 * (V_SCORE_ALL - 1000) /
											 (1000 + ABS(V_SCORE_ALL - 1000));
				--增减比例调整后得分
				V_SCORE_ADJ_1 := 1000 + V_SCORE_ADJ;
				--增减幅度调整
				IF V_SCORE_ADJ = 0 THEN
					V_SCORE_ADJ := 1000;
				ELSIF ABS(V_SCORE_ADJ / 1000) > 0
							AND ABS(V_SCORE_ADJ / 1000) <= 0.1 THEN
					V_SCORE_ADJ := 1000 + V_SCORE_ADJ;
				ELSIF ABS(V_SCORE_ADJ / 1000) > 0.1
							AND ABS(V_SCORE_ADJ / 1000) <= 0.25 THEN
					V_SCORE_ADJ := 1000 + V_SCORE_ADJ / ABS(V_SCORE_ADJ) * 1000 * 0.1 +
												 V_SCORE_ADJ / ABS(V_SCORE_ADJ) * (ABS(V_SCORE_ADJ) - 100) * 0.5;
				ELSIF ABS(V_SCORE_ADJ / 1000) > 0.25
							AND ABS(V_SCORE_ADJ / 1000) <= 0.4 THEN
					V_SCORE_ADJ := 1000 + V_SCORE_ADJ / ABS(V_SCORE_ADJ) * 175 +
												 V_SCORE_ADJ / ABS(V_SCORE_ADJ) * (ABS(V_SCORE_ADJ) - 175) * 0.4;
				ELSIF ABS(V_SCORE_ADJ / 1000) > 0.4
							AND ABS(V_SCORE_ADJ / 1000) <= 0.55 THEN
					V_SCORE_ADJ := 1000 + V_SCORE_ADJ / ABS(V_SCORE_ADJ) * 235 +
												 V_SCORE_ADJ / ABS(V_SCORE_ADJ) * (ABS(V_SCORE_ADJ) - 235) * 0.3;
				ELSIF ABS(V_SCORE_ADJ / 1000) > 0.55 THEN
					V_SCORE_ADJ := 1000 + V_SCORE_ADJ / ABS(V_SCORE_ADJ) * 280 +
												 V_SCORE_ADJ / ABS(V_SCORE_ADJ) * (ABS(V_SCORE_ADJ) - 280) * 0.2;
				END IF;
			ELSE
				V_SCORE_ADJ := 0;
			END IF;
		ELSE
			V_SCORE_ADJ := V_SCORE_ALL;
		END IF;
		INSERT INTO MO_EWM_CM_DT_SS
			(DT_ID, WAY_ID, SEG_CODE, STAFF_ID, CALC_SCORE, ADJ_SCORE, ADJ_SCORE_1,PARAM_VALUE)
		VALUES
			(SYS_GUID(),
			 V_WAY_ID,
			 V_SEG_CODE,
			 V_STAFF_ID,
			 V_SCORE_ALL,
			 V_SCORE_ADJ,
			 V_SCORE_ADJ_1,
       SCR_SCORE_PARAM_VALUE(V_SCORE_ALL, '0'));
	END LOOP;
	CLOSE CUR;
	COMMIT;

	RETCODE := 0;
EXCEPTION
	WHEN OTHERS THEN
		ROLLBACK;
		RETCODE := SQLCODE;
		ERRMSG  := SUBSTR(SQLERRM, 1, 200);
		PRC_SYS_EWM_LOG(P_WAYID, P_SEGCODE, '员工汇总计算', '', RETCODE, ERRMSG);
END;

/

