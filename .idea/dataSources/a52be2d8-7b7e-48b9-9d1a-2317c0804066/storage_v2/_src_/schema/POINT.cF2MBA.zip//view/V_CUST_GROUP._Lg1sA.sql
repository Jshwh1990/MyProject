create view V_CUST_GROUP as
  SELECT G.ID,
       G.GROUP_NAME,
       G.GROUP_TYPE,
       G.GROUP_DESC,
       G.WHE_SHARE,
       G.STATUS,
       G.CUST_TYPE,
       G.CREATE_EMP_NO
  FROM (SELECT PG.ID,
               PG.GROUP_NAME,
               PG.GROUP_TYPE,
               PG.GROUP_DESC,
               PG.WHE_SHARE,
               PG.STATUS,
               'P' CUST_TYPE,
               PG.CREATE_EMP_NO
          FROM CI_GRP_PERSON_GROUP PG
        UNION ALL
        SELECT UG.ID,
               UG.GROUP_NAME,
               UG.GROUP_TYPE,
               UG.GROUP_DESC,
               UG.WHE_SHARE,
               UG.STATUS,
               UG.CUST_TYPE,
               UG.CREATE_EMP_NO
					FROM CI_GRP_UNIT_GROUP UG) G
/

