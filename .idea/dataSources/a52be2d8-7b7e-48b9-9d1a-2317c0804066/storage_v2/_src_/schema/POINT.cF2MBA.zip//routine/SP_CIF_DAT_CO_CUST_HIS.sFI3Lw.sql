create PROCEDURE SP_CIF_DAT_CO_CUST_HIS
(
	IV_JOBID  IN VARCHAR2,
	IV_OPERID IN VARCHAR2,
	ON_RESULT OUT NUMBER
)
--*******************************************************************************
	-- CopyRight (c) 2017, 融丰银行                                         *
	-- All rights reserved.                                                       *
	--                                                                            *
	-- 文件名称 : SP_CIF_DAT_CO_CUST_HIS.prc                                      *
	-- 摘    要 : A03_对公客户数据历史加载                                        *
	-- 工程模块 : crmapp.04_27                                                    *
	-- 当前版本 : V1.0.0                                                          *
	-- 作    者 : WXH                                                             *
	-- 完成日期 : 2017/02/09                                                      *
	-- 错误码段 : 40270 - 40279                                                   *
	--*****************************************************************************
 IS
	V_WORK_DATE VARCHAR2(8);
	V_RETCODE   VARCHAR2(6) := '000000'; --程序/日志返回码
	V_MSG       VARCHAR2(1000); --程序执行信息
	V_TABNAME   VARCHAR2(100); --表名
	--V_NUMBER     NUMBER;
	V_RETERRFLG  VARCHAR2(1); --日志标志 I(information) W(waring) E(error)
	V_ERRCODE    VARCHAR2(10) := '40279'; --程序执行出错返回码
	V_RETSUBCODE VARCHAR2(3); --程序子返回码
	--V_JOBID      VARCHAR2(32) := 'SP_CIF_DAT_CO_CUST_HIS';
	--V_OPERID     VARCHAR2(32) := 'ZHUY';
	V_JOBID  VARCHAR2(50) := IV_JOBID;
	V_OPERID VARCHAR2(50) := IV_OPERID;
BEGIN

	/*获得业务时间*/
	SELECT WORK_DATE INTO V_WORK_DATE FROM SYS_PARA_DATE_NEW;

	V_RETCODE    := '40270';
	V_RETSUBCODE := '001';
	V_RETERRFLG  := 'I';
	V_MSG        := '程序执行开始';
	SP_WRITEDETAILLOG(V_WORK_DATE,
										V_JOBID,
										V_OPERID,
										V_MSG,
										V_RETCODE,
										V_RETSUBCODE,
										V_RETERRFLG);

	V_RETCODE    := '40271';
	V_TABNAME    := 'CIF_DAT_CO_CUST_HIS';
	V_RETERRFLG  := 'I';
	V_RETSUBCODE := '001';

	/*清空表分区*/
	EXECUTE IMMEDIATE 'ALTER TABLE CIF_DAT_CO_CUST_HIS TRUNCATE PARTITION P_' ||
										V_WORK_DATE;
	/*写日志*/
	V_MSG := V_TABNAME || '表分区记录成功清除';
	SP_WRITEDETAILLOG(V_WORK_DATE,
										IV_JOBID,
										IV_OPERID,
										V_MSG,
										V_RETCODE,
										V_RETSUBCODE,
										V_RETERRFLG);

	V_RETCODE := '40272';
	/*加载数据到对公客户数据历史表*/
	INSERT /*+append*/
	INTO CIF_DAT_CO_CUST_HIS NOLOGGING
		(CUST_NO,
		 TAR_DATE,
		 HIS_START_DATE,
		 HIS_END_DATE,
		 AREA_NO,
		 OPEN_ORG,
		 DEPS_NUM,
		 LOAN_NUM,
		 IS_NEW,
		 BASE_ACCT_NUM,
		 STAT_TIME,
		 IS_SMALL_CO,
		 CUST_LVL,
		 CUST_NUM,
		 CUST_NUM_DAY10W,
		 IS_NOTE_SIGN,
		 IS_NET_SIGN)
		SELECT CUST_NO,
					 TAR_DATE,
					 V_WORK_DATE,
					 V_WORK_DATE,
					 AREA_NO,
					 OPEN_ORG,
					 DEPS_NUM,
					 LOAN_NUM,
					 IS_NEW,
					 BASE_ACCT_NUM,
					 STAT_TIME,
					 IS_SMALL_CO,
					 CUST_LVL,
					 CUST_NUM,
					 CUST_NUM_DAY10W,
					 IS_NOTE_SIGN,
					 IS_NET_SIGN
			FROM CIF_DAT_CO_CUST;
	V_TABNAME := 'CIF_DAT_CO_CUST_HIS';
	V_MSG     := V_TABNAME || '成功写入' || SQL%ROWCOUNT || '条记录';
	COMMIT;

	/*写日志*/
	SP_WRITEDETAILLOG(V_WORK_DATE,
										V_JOBID,
										V_OPERID,
										V_MSG,
										V_RETCODE,
										V_RETSUBCODE,
										V_RETERRFLG);

	V_RETCODE := '40274';
	V_TABNAME := 'CIF_DAT_CO_CUST_HIS';
	V_MSG     := V_TABNAME || '表成功写入数据';
	/*写日志*/
	V_RETSUBCODE := '001';
	SP_WRITEDETAILLOG(V_WORK_DATE,
										V_JOBID,
										V_OPERID,
										V_MSG,
										V_RETCODE,
										V_RETSUBCODE,
										V_RETERRFLG);

	V_RETCODE    := '40275';
	V_RETSUBCODE := '001';
	V_RETERRFLG  := 'I';
	V_MSG        := '程序执行结束';
	SP_WRITEDETAILLOG(V_WORK_DATE,
										V_JOBID,
										V_OPERID,
										V_MSG,
										V_RETCODE,
										V_RETSUBCODE,
										V_RETERRFLG);

	ON_RESULT := 0;

	/*异常处理*/
EXCEPTION
	WHEN OTHERS THEN
		V_RETERRFLG := 'E';
		V_RETCODE   := V_ERRCODE;
		V_MSG       := 'SQLCODE:' || V_TABNAME || '表' || SUBSTR(SQLERRM, 1, 500);
		ON_RESULT   := SQLCODE;
		ROLLBACK;
		SP_WRITEDETAILLOG(V_WORK_DATE,
											V_JOBID,
											V_OPERID,
											V_MSG,
											V_RETCODE,
											V_RETSUBCODE,
											V_RETERRFLG);
		RETURN;
END;

/

