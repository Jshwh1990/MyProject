create FUNCTION Scr_FsQty_Rate(PT_VALUE     IN NUMBER,
                                          FS_VALUE     IN NUMBER,
                                          BASE_SCORE   IN NUMBER,
                                          REDUCE_VALUE IN NUMBER,
                                          REDUCE_SCORE IN NUMBER,
                                          LOW_SCORE    IN NUMBER,
                                          ADD_VALUE    IN NUMBER,
                                          ADD_SCORE    IN NUMBER,
                                          HIGH_SCORE   IN NUMBER)
  RETURN NUMBER IS
  /* 过程、函数简要描述信息
  **********************************************************
  *  存储过程名:  完成率按量增减法
  *  建立日期  :  2013-03-20
  *  作者      :  linyd
  *  模块      :  评分模型
  *  功能描述  :  完成率按量增减法
  *  输入参数  ：
  *  输出参数  ：
  *  来源表    ：
  *  目标表    :
  *   备注     ：1、 任务完成，得基本分；
                 2、 未完成，每减少   （元） , 扣   分   扣分不超过  分 ；
                 3、 未完成时，不填写默认按比例得分；
                 4、 超额完成时，每增加   （元） ,  加   分  加分不超过  分 ；
                 5、 超额时，不填写值默认为按比例得分；
                 6、PT_VALUE 任务值 FS_VALUE 完成值 BASE_SCORE 基本分
                 7、任务值为空时成绩为0 任务值为0时成绩为基本分
  *------------------------------------------------------------
  *  修改历史
  *  序号    日期      修改人      修改原因
  ************************************************************ */
  O_VAL    NUMBER(12, 2);
  OVER_VAL NUMBER(20, 6);
BEGIN
  IF (PT_VALUE = '' OR PT_VALUE IS NULL) THEN
    O_VAL := 0;
    RETURN O_VAL;
  END IF;
/*  IF (PT_VALUE = 0) THEN
    O_VAL := BASE_SCORE;
    RETURN O_VAL;
  END IF;*/

  IF (PT_VALUE IS NOT NULL) OR (FS_VALUE IS NOT NULL) OR
     (ADD_VALUE IS NOT NULL) OR (REDUCE_VALUE IS NOT NULL) OR
     (PT_VALUE <> 0) THEN
    IF FS_VALUE <= PT_VALUE THEN
      IF (REDUCE_VALUE IS NULL AND LOW_SCORE IS NULL) THEN
              IF (PT_VALUE = 0) THEN
                  O_VAL := BASE_SCORE;
                  RETURN O_VAL;
              END IF;
        O_VAL := BASE_SCORE * (FS_VALUE / PT_VALUE);
      ELSIF (REDUCE_VALUE IS NULL AND LOW_SCORE IS NOT NULL) THEN
              IF (PT_VALUE = 0) THEN
                  O_VAL := BASE_SCORE;
                  RETURN O_VAL;
              END IF;
        O_VAL := BASE_SCORE * (FS_VALUE / PT_VALUE);
        O_VAL := GREATEST(O_VAL, LOW_SCORE);
      ELSIF (REDUCE_VALUE IS NOT NULL AND LOW_SCORE IS NOT NULL) THEN
        OVER_VAL := (FS_VALUE - PT_VALUE);
        O_VAL    := TRUNC(ABS(OVER_VAL) / REDUCE_VALUE) * REDUCE_SCORE;
        IF (O_VAL > LOW_SCORE) THEN
          O_VAL := BASE_SCORE - LOW_SCORE;
        ELSE
          O_VAL := BASE_SCORE - O_VAL;
        END IF;
      ELSE
        OVER_VAL := (FS_VALUE - PT_VALUE);
        O_VAL    := TRUNC(ABS(OVER_VAL) / REDUCE_VALUE) * REDUCE_SCORE;
        O_VAL    := BASE_SCORE - O_VAL;
      END IF;
    ELSE
      IF (ADD_VALUE IS NULL AND HIGH_SCORE IS NULL) THEN
              IF (PT_VALUE = 0) THEN
                  O_VAL := BASE_SCORE;
                  RETURN O_VAL;
              END IF;
        O_VAL := BASE_SCORE * (FS_VALUE / PT_VALUE);
      ELSIF (ADD_VALUE IS NULL AND HIGH_SCORE IS NOT NULL) THEN
              IF (PT_VALUE = 0) THEN
                  O_VAL := BASE_SCORE;
                  RETURN O_VAL;
              END IF;
        O_VAL := BASE_SCORE * (FS_VALUE / PT_VALUE);
        O_VAL := LEAST(O_VAL, HIGH_SCORE);
      ELSIF (ADD_VALUE IS NOT NULL AND HIGH_SCORE IS NOT NULL) THEN
        OVER_VAL := (FS_VALUE - PT_VALUE);
        O_VAL    := TRUNC(ABS(OVER_VAL) / ADD_VALUE) * ADD_SCORE;
        IF (O_VAL > HIGH_SCORE) THEN
          O_VAL := BASE_SCORE + HIGH_SCORE;
        ELSE
          O_VAL := BASE_SCORE + O_VAL;
        END IF;
      ELSE
        OVER_VAL := (FS_VALUE - PT_VALUE);
        O_VAL    := TRUNC(ABS(OVER_VAL) / ADD_VALUE) * ADD_SCORE;
        O_VAL    := BASE_SCORE + O_VAL;
      END IF;
    END IF;
  ELSE
    O_VAL := NULL;
  END IF;
  RETURN O_VAL;
END;

/

