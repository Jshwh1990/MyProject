create view V_CI_BIZ_UNIT_DEPOSIT_ACCOUNT as
  SELECT A.ACCOUNT_NO     ,--账号
       CASE
				 WHEN B.CUST_NO IS NULL THEN
					 A.BIZ_CUST_SYSTEM
         ELSE
					 B.CUST_NO||'#D'
       END BIZ_CUST_SYSTEM,--业务客户号 + ‘#’ + 业务系统类型
			 A.SUBJ_CODE, --科目号
       A.PRD_CODE       ,--产品编号
       A.OPEN_ORG_NO    ,--开户机构
       NVL(B.CUST_NO,A.BIZ_CUST_NO) BIZ_CUST_NO,--原业务系统客户号
       A.BIZ_SYSTEM_TYPE,--源系统类型
       A.CATEGORY       ,--种类
       A.BAL            ,--当前余额
       A.CURRENCY       ,--币种
       A.RATE           ,--利率
       A.BEGIN_YEAR_BAL ,--年初余额
       A.LENDER_ITERMS  ,--贷方笔数
       A.LENDER_AMT     ,--贷方金额
       A.DEBIT_ITERMS   ,--借方笔数
       A.DEBIT_AMT      ,--借方金额
       A.OPEN_DATE      ,--开户日期
       A.CANNEL_DATE    ,--销户日期
       A.LOAN_RELA      ,--是否建立存贷挂钩关系
       A.ACCOUNT_STATUS ,--账户状态
       A.MANAGER_NO     ,--客户经理
       A.CATE_CODE      ,--业务类别
       A.BAL_AVG_M      ,--月日均余额
       A.BAL_AVG_Q      ,--季日均
       A.BAL_AVG_Y      ,--年日均余额
       A.DUEDATE        ,--到期日
       A.ACCOUNT_TYPE   ,--账户类型
       A.AGRM_BAL_AMT   ,--协定余额
       A.AGRM_BAL_EFF_DT,--协定余额开始日
       A.AGRM_BAL_END_DT,--协定余额结束日
       A.AGRM_INT_AMT   ,--协定利息
       A.AGRM_INT_RATE  ,--协定利率
       A.CD_INT_EPS_AMT ,--当日利息支出
       A.MA_INT_EPS_AMT ,--月累计利息支出
       A.QA_INT_EPS_AMT ,--季累计利息支出
       A.YA_INT_EPS_AMT  --年累计利息支出
  FROM CI_BIZ_UNIT_DEPOSIT_ACCOUNT A
  LEFT JOIN CI_CUS_UNIT_COMBINE B
    ON B.COMBINED_CUST_NO = A.BIZ_CUST_NO
		AND B.STATE = '1'

/

