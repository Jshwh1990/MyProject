create view V_VCUST_UNIT as
  SELECT
       u.CUST_NO,
       u.CUST_NAME,
       u.CERT_TYPE,
       u.CERT_NO,
       u.BELONG_ORG_NO,
       u.BELONG_EMP_NO,
       '' CELL_PHONE,
        CASE WHEN(u.SML_CLT_F='N') THEN 'C'
        ELSE 'S' END CUST_TYPE
FROM V_CI_CUS_UNIT u
where u.unit_type='1'
/

