create view V_RPT_COMP_DEBT_RAT as
  select nvl(a.sys_date,b.sys_date) as sys_date,
  nvl(a.org_no,b.org_no) as org_no,
  c.org_name as org_name,
  nvl(a.p_bal,0) as p_bal,
  nvl(a.p_bal_avg_y,0) as p_bal_avg_y,
  nvl(a.p_int_amt_exp,0) as p_int_amt_exp,
  --a.p_debt_rat,
  nvl(round(case when a.p_bal_avg_y = 0 then 0 else a.p_int_amt_exp/a.p_bal_avg_y end,6),0) as p_debt_rat,
  b.s_bal as s_bal,
  b.s_bal_avg_y as s_bal_avg_y,
  b.s_int_amt_exp as s_int_amt_exp,
  --b.s_debt_rat,
  round(case when b.s_bal_avg_y = 0 then 0 else b.s_int_amt_exp/b.s_bal_avg_y end,6) as s_debt_rat,
  b.c_bal as c_bal,
  b.c_bal_avg_y as c_bal_avg_y,
  b.c_int_amt_exp as c_int_amt_exp,
  --b.c_debt_rat
  round(case when b.c_bal_avg_y = 0 then 0 else b.c_int_amt_exp/b.c_bal_avg_y end,6) as c_debt_rat
    from
  RPT_PS_COMP_DEBT_RAT a
  full join RPT_CO_COMP_DEBT_RAT b
  ON a.org_no = b.org_no
  and a.sys_date = b.sys_date
  left join sys_organization c
  on nvl(a.org_no,b.org_no) = c.org_no

/

