create PROCEDURE SP_CIF_OP_AS_AR_CO_LOAN(IV_JOBID  IN VARCHAR2,
                                                    IV_OPERID IN VARCHAR2,
                                                    ON_RESULT OUT NUMBER)
--*******************************************************************************
  -- CopyRight (c) 2018, 融丰银行                                               *
  -- All rights reserved.                                                       *
  --                                                                            *
  -- 文件名称 : SP_CIF_OP_AS_AR_CO_LOAN.prc                                          *
  -- 摘    要 : 对公贷款分配表数据加工                                          *
  -- 工程模块 : crmapp.04_27                                                    *
  -- 当前版本 : V1.0.0                                                          *
  -- 作    者 : lyh                                                           *
  -- 完成日期 : 2018/03/15                                                     *
  -- 错误码段 : 40270 - 40279                                                   *
  --*****************************************************************************
 IS
  V_WORK_DATE  VARCHAR2(8);
  V_RETCODE    VARCHAR2(6) := '000000'; --程序/日志返回码
  V_MSG        VARCHAR2(1000); --程序执行信息
  V_TABNAME    VARCHAR2(100); --表名
  V_RETERRFLG  VARCHAR2(1); --日志标志 I(information) W(waring) E(error)
  V_ERRCODE    VARCHAR2(10) := '40279'; --程序执行出错返回码
  V_RETSUBCODE VARCHAR2(3); --程序子返回码
  V_JOBID      VARCHAR2(50) := IV_JOBID;
  V_OPERID     VARCHAR2(50) := IV_OPERID;
BEGIN

  /*获得业务时间*/
  SELECT WORK_DATE INTO V_WORK_DATE FROM SYS_PARA_DATE_NEW;
  ----记录日志
  V_RETCODE    := '40270';
  V_RETSUBCODE := '001';
  V_RETERRFLG  := 'I';
  V_MSG        := '程序执行开始';
  SP_WRITEDETAILLOG(V_WORK_DATE,
                    V_JOBID,
                    V_OPERID,
                    V_MSG,
                    V_RETCODE,
                    V_RETSUBCODE,
                    V_RETERRFLG);

  V_RETCODE    := '40271';
  V_TABNAME    := 'OP_AS_AR_CO_LOAN';
  V_RETERRFLG  := 'I';
  V_RETSUBCODE := '001';
  /*删除跑批分配的数据*/
/*  execute immediate 'alter table OP_AS_AR_CO_LOAN enable row movement';
  execute immediate 'alter table OP_AS_AR_CO_LOAN shrink space cascade';
  execute immediate 'alter table OP_AS_AR_CO_LOAN disable  row movement';*/
  DELETE FROM OP_AS_AR_CO_LOAN T WHERE T.OP_TYPE = '0';
  COMMIT;
  /*写日志*/
  V_MSG := V_TABNAME || '表记录成功清除';
  SP_WRITEDETAILLOG(V_WORK_DATE,
                    V_JOBID,
                    V_OPERID,
                    V_MSG,
                    V_RETCODE,
                    V_RETSUBCODE,
                    V_RETERRFLG);

  V_RETCODE := '40272';
  /*加载跑批分配的数据，不包括之前跑批的时候已经分配并且业绩发生过转移的数据(OP_TYPE = '1')*/

  INSERT /*+APPEND*/
  INTO OP_AS_AR_CO_LOAN NOLOGGING
    (id, --分配序号
     res_id, --分配资源id
     area_no, --区域号
     res_name, --资源名称
     res_org, --资源机构号
     res_prd, --资源产品
     cust_no, --客户号
     cust_name, --客户名称
     open_org, --开户机构
     al_way, --分配方式: 1按比例分配 2按金额分配
     al_in, --分配对象
     start_date, --开始日期
     end_date, --结束日期
     al_rate, --分配比率
     start_amt, --开始额度
     end_amt, --结束额度
     status, --生效状态
     orderby, --顺序号
     modify_date, --修改日期
     operator, --修改操作员
     al_row_rate, --原始分配比例
     al_factor, --分配系数
     is_small_co, --是否小微客户
     OP_TYPE,
     LOAN_TYPE)
    SELECT SYS_GUID(), --
           A.BILL_NO, --借据号
           100, --
           A.CIF_NAME, --客户名称
           A.FINA_BR_NO, --账务机构
           A.PRD_NO, --产品号
           A.CIF_NO, --客户号
           A.CIF_NAME, --客户名称
           A.FINA_BR_NO, --账务机构
           1, --
           T.JOB_NUMBER, --客户经理
           TO_DATE(A.LOAN_START_DATE, 'YYYYMMDD'), --贷款起始日
           TO_DATE('99991231', 'YYYYMMDD'), --贷款终止日
           100, --
           null, --
           null, --
           1, --
           1, --
           NVL(TO_DATE(A.UP_DATE, 'YYYYMMDD'), SYSDATE), --最近修改日期
           T.JOB_NUMBER, --客户经理
           100, --
           1, --
           'N',
           '0',
           '信贷'
      FROM A_CMS_DUE_LOAN_ACC A
      JOIN A_CMS_TBL_ORG_USER T
        ON A.MANG_NO = T.Username --(Username信贷客户经理号)
      -- AND T.OP_STS = '1' --只取启用的员工
      JOIN SYS_EMPLOYEE B
        ON T.JOB_NUMBER = B.EMP_NO --因为表A_CMS_TBL_ORG_USER中的部分JOB_NUMBER与员工表中的EMP_NO对应不起来，所以找不到员工所在的机构，导致I3层数据比I4层金额多
    --现在只取可以关联到的员工
      JOIN SYS_ORGANIZATION C --因为人员所在的机构比机构表中的机构多，会造成I3层数据比I4层金额多
    --现在只取可以关联到机构的员工
        ON B.ORG_NO = C.ORG_NO
     WHERE A.CIF_TYPE = '1' --1:对公，2：个人
       and not exists (select op.res_id
              from OP_AS_AR_CO_LOAN op
             where a.bill_no = op.res_id
               and op.op_type = '1');
commit;
 --加载供应链分配数据
  INSERT /*+APPEND*/
  INTO OP_AS_AR_CO_LOAN NOLOGGING
    (id, --分配序号
     res_id, --分配资源id
     area_no, --区域号
     res_name, --资源名称
     res_org, --资源机构号
     res_prd, --资源产品
     cust_no, --客户号
     cust_name, --客户名称
     open_org, --开户机构
     al_way, --分配方式: 1按比例分配 2按金额分配
     al_in, --分配对象
     start_date, --开始日期
     end_date, --结束日期
     al_rate, --分配比率
     start_amt, --开始额度
     end_amt, --结束额度
     status, --生效状态
     orderby, --顺序号
     modify_date, --修改日期
     operator, --修改操作员
     al_row_rate, --原始分配比例
     al_factor, --分配系数
     is_small_co, --是否小微客户
     OP_TYPE,
     LOAN_TYPE)
    select SYS_GUID(),
           A.BILL_NO,
           100,
           rel.NAME,
           '600001',
           A.PROD_NO,
           rel.CIF_NO,
           rel.NAME,
           '600001',
           1,
           A.EMP_NO,
           to_date(A.OPEN_DATE,'yyyymmdd'),
           to_date(A.END_DATE,'yyyymmdd'),
           100,
           null,
           null,
           1,
           1,
           SYSDATE,
           A.EMP_NO,
           100,
           1,
           'N',
           '0',
           '供应链'
      from A_GYL_LOANINFORMATION A
      LEFT JOIN A_CBS_CIF_ID_CODE_REL rel --根据证件号码关联取核心客户号
        ON A.ID_NO = rel.ID_NO
     JOIN SYS_EMPLOYEE B
        ON a.emp_no = B.EMP_NO --因为表A_CMS_TBL_ORG_USER中的部分JOB_NUMBER与员工表中的EMP_NO对应不起来，所以找不到员工所在的机构，导致I3层数据比I4层金额多
    --现在只取可以关联到的员工
      JOIN SYS_ORGANIZATION C --因为人员所在的机构比机构表中的机构多，会造成I3层数据比I4层金额多
    --现在只取可以关联到机构的员工
        ON B.ORG_NO = C.ORG_NO
     WHERE A.CIF_TYPE = '1' --1:对公，2：个人
       and not exists (select op.res_id
              from OP_AS_AR_CO_LOAN op
             where a.bill_no = op.res_id
               and op.op_type = '1');
  COMMIT;
  V_TABNAME := 'OP_AS_AR_CO_LOAN';
  V_MSG     := V_TABNAME || '成功写入' || SQL%ROWCOUNT || '条记录';
  COMMIT;

  /*写日志*/
  SP_WRITEDETAILLOG(V_WORK_DATE,
                    V_JOBID,
                    V_OPERID,
                    V_MSG,
                    V_RETCODE,
                    V_RETSUBCODE,
                    V_RETERRFLG);

  V_RETCODE := '40274';
  V_TABNAME := 'OP_AS_AR_CO_LOAN';
  V_MSG     := V_TABNAME || '表成功写入数据';
  /*写日志*/
  V_RETSUBCODE := '001';
  SP_WRITEDETAILLOG(V_WORK_DATE,
                    V_JOBID,
                    V_OPERID,
                    V_MSG,
                    V_RETCODE,
                    V_RETSUBCODE,
                    V_RETERRFLG);

  V_RETCODE    := '40275';
  V_RETSUBCODE := '001';
  V_RETERRFLG  := 'I';
  V_MSG        := '程序执行结束';
  SP_WRITEDETAILLOG(V_WORK_DATE,
                    V_JOBID,
                    V_OPERID,
                    V_MSG,
                    V_RETCODE,
                    V_RETSUBCODE,
                    V_RETERRFLG);

  ON_RESULT := 0;

  /*异常处理*/
EXCEPTION
  WHEN OTHERS THEN
    V_RETERRFLG := 'E';
    V_RETCODE   := V_ERRCODE;
    V_MSG       := 'SQLCODE:' || V_TABNAME || '表' ||
                   SUBSTR(SQLERRM, 1, 500);
    ON_RESULT   := SQLCODE;
    ROLLBACK;
    SP_WRITEDETAILLOG(V_WORK_DATE,
                      V_JOBID,
                      V_OPERID,
                      V_MSG,
                      V_RETCODE,
                      V_RETSUBCODE,
                      V_RETERRFLG);
    RETURN;
END;

/

