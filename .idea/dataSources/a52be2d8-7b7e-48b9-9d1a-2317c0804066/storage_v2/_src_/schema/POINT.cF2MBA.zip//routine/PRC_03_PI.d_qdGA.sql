create PROCEDURE PRC_03_PI
(
	S_DATE    VARCHAR,
	E_DATE    VARCHAR,
	CALC_TYPE INT,
	RETCODE   OUT INT,
	RETMSG    OUT VARCHAR
)
/* 过程、函数简要描述信息
  **********************************************************
  *  存储过程名:  数据计算存储过程集合
  *  建立日期  :  2013-03-20
  *  作者      :  linyd
  *  模块      :  业绩分配规模
  *  功能描述  :  分配明细修正存储过程集合
  *  输入参数  ： s_date 处理日期,e_date 处理结束日期,flow_id流水
  *               calc_type 计算类型：10为当日业绩计算，20为外部回算，30为内部回算
  *  输出参数  ： RETCODE 0为正确1为错误， RETMSG错误信息
  *  来源表    ：
  *  目标表    :
  *   备注     ：存储过程名 PRC_01_AD
  *------------------------------------------------------------
  *  修改历史
  *  序号    日期      修改人      修改原因
  ************************************************************ */
 IS
	RECORD_TIME TIMESTAMP;
	FLOW_ID     VARCHAR2(32);
	P_STEP_ID   VARCHAR2(30);
	STEP_ID     VARCHAR2(30);
BEGIN
	FLOW_ID := FNC_GEN_FLOW_ID();
	STEP_ID := 'LYD_03_PI_';

	--对公客户数据表生成
	RECORD_TIME := SYSDATE;
	P_STEP_ID   := STEP_ID || '01';
	PRC_14_CC_PI_I2(S_DATE, E_DATE, CALC_TYPE, RETCODE, RETMSG);
	IF RETCODE <> 0
		 OR RETCODE IS NULL THEN
		RETMSG := '对公客户数据表生成-执行出错';
		PRC_SYS_MONITOR_LOG(FLOW_ID,
												S_DATE,
												E_DATE,
												P_STEP_ID,
												RECORD_TIME,
												'PRC_14_CC_PI_I2',
												4,
												RETMSG,
												'',
												RECORD_TIME,
												1);
		ROLLBACK;
		RETURN;
	ELSE
		RETMSG := '对公客户数据表生成-执行成功';
		PRC_SYS_MONITOR_LOG(FLOW_ID,
												S_DATE,
												E_DATE,
												P_STEP_ID,
												RECORD_TIME,
												'PRC_14_CC_PI_I2',
												1,
												RETMSG,
												'',
												RECORD_TIME,
												1);
	END IF;

	--对公存款数据表生成
	RECORD_TIME := SYSDATE;
	P_STEP_ID   := STEP_ID || '02';
	PRC_14_CD_PI_I2(S_DATE, E_DATE, CALC_TYPE, RETCODE, RETMSG);
	IF RETCODE <> 0
		 OR RETCODE IS NULL THEN
		RETMSG := '对公存款数据表生成-执行出错';
		PRC_SYS_MONITOR_LOG(FLOW_ID,
												S_DATE,
												E_DATE,
												P_STEP_ID,
												RECORD_TIME,
												'PRC_14_CD_PI_I2',
												4,
												RETMSG,
												'',
												RECORD_TIME,
												1);
		ROLLBACK;
		RETURN;
	ELSE
		RETMSG := '对公存款数据表生成-执行成功';
		PRC_SYS_MONITOR_LOG(FLOW_ID,
												S_DATE,
												E_DATE,
												P_STEP_ID,
												RECORD_TIME,
												'PRC_14_CD_PI_I2',
												1,
												RETMSG,
												'',
												RECORD_TIME,
												1);
	END IF;

	--对公贷款数据表生成
	RECORD_TIME := SYSDATE;
	P_STEP_ID   := STEP_ID || '03';
	PRC_14_CL_PI_I2(S_DATE, E_DATE, CALC_TYPE, RETCODE, RETMSG);
	IF RETCODE <> 0
		 OR RETCODE IS NULL THEN
		RETMSG := '对公贷款数据表生成-执行出错';
		PRC_SYS_MONITOR_LOG(FLOW_ID,
												S_DATE,
												E_DATE,
												P_STEP_ID,
												RECORD_TIME,
												'PRC_14_CL_PI_I2',
												4,
												RETMSG,
												'',
												RECORD_TIME,
												1);
		ROLLBACK;
		RETURN;
	ELSE
		RETMSG := '对公贷款数据表生成-执行成功';
		PRC_SYS_MONITOR_LOG(FLOW_ID,
												S_DATE,
												E_DATE,
												P_STEP_ID,
												RECORD_TIME,
												'PRC_14_CL_PI_I2',
												1,
												RETMSG,
												'',
												RECORD_TIME,
												1);
	END IF;

	--对公业务流水数据生成
	RECORD_TIME := SYSDATE;
	P_STEP_ID   := STEP_ID || '04';
	PRC_14_CF_PI_I2(S_DATE, E_DATE, CALC_TYPE, RETCODE, RETMSG);
	IF RETCODE <> 0
		 OR RETCODE IS NULL THEN
		RETMSG := '对公业务流水数据生成-执行出错';
		PRC_SYS_MONITOR_LOG(FLOW_ID,
												S_DATE,
												E_DATE,
												P_STEP_ID,
												RECORD_TIME,
												'PRC_14_CF_PI_I2',
												4,
												RETMSG,
												'',
												RECORD_TIME,
												1);
		ROLLBACK;
		RETURN;
	ELSE
		RETMSG := '对公业务流水数据生成-执行成功';
		PRC_SYS_MONITOR_LOG(FLOW_ID,
												S_DATE,
												E_DATE,
												P_STEP_ID,
												RECORD_TIME,
												'PRC_14_CF_PI_I2',
												1,
												RETMSG,
												'',
												RECORD_TIME,
												1);
	END IF;

	--对公签约流水数据生成
	RECORD_TIME := SYSDATE;
	P_STEP_ID   := STEP_ID || '05';
	PRC_14_CS_PI_I2(S_DATE, E_DATE, CALC_TYPE, RETCODE, RETMSG);
	IF RETCODE <> 0
		 OR RETCODE IS NULL THEN
		RETMSG := '对公签约流水数据生成-执行出错';
		PRC_SYS_MONITOR_LOG(FLOW_ID,
												S_DATE,
												E_DATE,
												P_STEP_ID,
												RECORD_TIME,
												'PRC_14_CS_PI_I2',
												4,
												RETMSG,
												'',
												RECORD_TIME,
												1);
		ROLLBACK;
		RETURN;
	ELSE
		RETMSG := '对公签约流水数据生成-执行成功';
		PRC_SYS_MONITOR_LOG(FLOW_ID,
												S_DATE,
												E_DATE,
												P_STEP_ID,
												RECORD_TIME,
												'PRC_14_CS_PI_I2',
												1,
												RETMSG,
												'',
												RECORD_TIME,
												1);
	END IF;

	--零售客户数据生成
	RECORD_TIME := SYSDATE;
	P_STEP_ID   := STEP_ID || '06';
	PRC_14_SC_PI_I2(S_DATE, E_DATE, CALC_TYPE, RETCODE, RETMSG);
	IF RETCODE <> 0
		 OR RETCODE IS NULL THEN
		RETMSG := '零售客户数据生成-执行出错';
		PRC_SYS_MONITOR_LOG(FLOW_ID,
												S_DATE,
												E_DATE,
												P_STEP_ID,
												RECORD_TIME,
												'PRC_14_SC_PI_I2',
												4,
												RETMSG,
												'',
												RECORD_TIME,
												1);
		ROLLBACK;
		RETURN;
	ELSE
		RETMSG := '零售客户数据生成-执行成功';
		PRC_SYS_MONITOR_LOG(FLOW_ID,
												S_DATE,
												E_DATE,
												P_STEP_ID,
												RECORD_TIME,
												'PRC_14_SC_PI_I2',
												1,
												RETMSG,
												'',
												RECORD_TIME,
												1);
	END IF;

	--零售主账户数据生成
	RECORD_TIME := SYSDATE;
	P_STEP_ID   := STEP_ID || '07';
	PRC_14_SM_PI_I2(S_DATE, E_DATE, CALC_TYPE, RETCODE, RETMSG);
	IF RETCODE <> 0
		 OR RETCODE IS NULL THEN
		RETMSG := '零售主账户数据生成-执行出错';
		PRC_SYS_MONITOR_LOG(FLOW_ID,
												S_DATE,
												E_DATE,
												P_STEP_ID,
												RECORD_TIME,
												'PRC_14_SM_PI_I2',
												4,
												RETMSG,
												'',
												RECORD_TIME,
												1);
		ROLLBACK;
		RETURN;
	ELSE
		RETMSG := '零售主账户数据生成-执行成功';
		PRC_SYS_MONITOR_LOG(FLOW_ID,
												S_DATE,
												E_DATE,
												P_STEP_ID,
												RECORD_TIME,
												'PRC_14_SM_PI_I2',
												1,
												RETMSG,
												'',
												RECORD_TIME,
												1);
	END IF;

	--零售存款数据生成
	RECORD_TIME := SYSDATE;
	P_STEP_ID   := STEP_ID || '08';
	PRC_14_SD_PI_I2(S_DATE, E_DATE, CALC_TYPE, RETCODE, RETMSG);
	IF RETCODE <> 0
		 OR RETCODE IS NULL THEN
		RETMSG := '零售存款数据生成-执行出错';
		PRC_SYS_MONITOR_LOG(FLOW_ID,
												S_DATE,
												E_DATE,
												P_STEP_ID,
												RECORD_TIME,
												'PRC_14_SD_PI_I2',
												4,
												RETMSG,
												'',
												RECORD_TIME,
												1);
		ROLLBACK;
		RETURN;
	ELSE
		RETMSG := '零售存款数据生成-执行成功';
		PRC_SYS_MONITOR_LOG(FLOW_ID,
												S_DATE,
												E_DATE,
												P_STEP_ID,
												RECORD_TIME,
												'PRC_14_SD_PI_I2',
												1,
												RETMSG,
												'',
												RECORD_TIME,
												1);
	END IF;

	--零售贷款数据生成
	RECORD_TIME := SYSDATE;
	P_STEP_ID   := STEP_ID || '09';
	PRC_14_SL_PI_I2(S_DATE, E_DATE, CALC_TYPE, RETCODE, RETMSG);
	IF RETCODE <> 0
		 OR RETCODE IS NULL THEN
		RETMSG := '零售贷款数据生成-执行出错';
		PRC_SYS_MONITOR_LOG(FLOW_ID,
												S_DATE,
												E_DATE,
												P_STEP_ID,
												RECORD_TIME,
												'PRC_14_SL_PI_I2',
												4,
												RETMSG,
												'',
												RECORD_TIME,
												1);
		ROLLBACK;
		RETURN;
	ELSE
		RETMSG := '零售贷款数据生成-执行成功';
		PRC_SYS_MONITOR_LOG(FLOW_ID,
												S_DATE,
												E_DATE,
												P_STEP_ID,
												RECORD_TIME,
												'PRC_14_SL_PI_I2',
												1,
												RETMSG,
												'',
												RECORD_TIME,
												1);
	END IF;

	--零售业务流水数据生成
	RECORD_TIME := SYSDATE;
	P_STEP_ID   := STEP_ID || '10';
	PRC_14_SF_PI_I2(S_DATE, E_DATE, CALC_TYPE, RETCODE, RETMSG);
	IF RETCODE <> 0
		 OR RETCODE IS NULL THEN
		RETMSG := '零售业务流水数据生成-执行出错';
		PRC_SYS_MONITOR_LOG(FLOW_ID,
												S_DATE,
												E_DATE,
												P_STEP_ID,
												RECORD_TIME,
												'PRC_14_SF_PI_I2',
												4,
												RETMSG,
												'',
												RECORD_TIME,
												1);
		ROLLBACK;
		RETURN;
	ELSE
		RETMSG := '零售业务流水数据生成-执行成功';
		PRC_SYS_MONITOR_LOG(FLOW_ID,
												S_DATE,
												E_DATE,
												P_STEP_ID,
												RECORD_TIME,
												'PRC_14_SF_PI_I2',
												1,
												RETMSG,
												'',
												RECORD_TIME,
												1);
	END IF;

	--零售签约流水数据生成
	RECORD_TIME := SYSDATE;
	P_STEP_ID   := STEP_ID || '11';
	PRC_14_SS_PI_I2(S_DATE, E_DATE, CALC_TYPE, RETCODE, RETMSG);
	IF RETCODE <> 0
		 OR RETCODE IS NULL THEN
		RETMSG := '零售签约流水数据生成-执行出错';
		PRC_SYS_MONITOR_LOG(FLOW_ID,
												S_DATE,
												E_DATE,
												P_STEP_ID,
												RECORD_TIME,
												'PRC_14_SS_PI_I2',
												4,
												RETMSG,
												'',
												RECORD_TIME,
												1);
		ROLLBACK;
		RETURN;
	ELSE
		RETMSG := '零售签约流水数据生成-执行成功';
		PRC_SYS_MONITOR_LOG(FLOW_ID,
												S_DATE,
												E_DATE,
												P_STEP_ID,
												RECORD_TIME,
												'PRC_14_SS_PI_I2',
												1,
												RETMSG,
												'',
												RECORD_TIME,
												1);
	END IF;

	--业务量考核流水数据生成
	/*RECORD_TIME := SYSDATE;
  P_STEP_ID   := STEP_ID || '04';
  PRC_14_BS_PI_I2(S_DATE, E_DATE, CALC_TYPE, RETCODE, RETMSG);
  IF RETCODE <> 0
     OR RETCODE IS NULL THEN
    RETMSG := '业务量流水数据生成-执行出错';
    PRC_SYS_MONITOR_LOG(FLOW_ID,
                        S_DATE,
                        E_DATE,
                        P_STEP_ID,
                        RECORD_TIME,
                        'PRC_14_BS_PI_I2',
                        4,
                        RETMSG,
                        '',
                        RECORD_TIME,
                        1);
    ROLLBACK;
    RETURN;
  ELSE
    RETMSG := '业务量流水数据生成-执行成功';
    PRC_SYS_MONITOR_LOG(FLOW_ID,
                        S_DATE,
                        E_DATE,
                        P_STEP_ID,
                        RECORD_TIME,
                        'PRC_14_BS_PI_I2',
                        1,
                        RETMSG,
                        '',
                        RECORD_TIME,
                        1);
  END IF;*/

EXCEPTION
	WHEN OTHERS THEN
		ROLLBACK;
		RETCODE := -1;
		RETMSG  := '数据计算存储过程集合-执行错误-' || SQLERRM;
		PRC_SYS_MONITOR_LOG(FLOW_ID,
												S_DATE,
												E_DATE,
												P_STEP_ID,
												RECORD_TIME,
												'PRC_03_PI',
												4,
												RETMSG,
												'',
												RECORD_TIME,
												1);
END;

/

