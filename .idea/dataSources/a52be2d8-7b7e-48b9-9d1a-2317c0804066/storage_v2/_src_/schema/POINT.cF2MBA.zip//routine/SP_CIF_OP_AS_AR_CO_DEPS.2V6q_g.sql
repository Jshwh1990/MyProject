create PROCEDURE SP_CIF_OP_AS_AR_CO_DEPS(IV_JOBID  IN VARCHAR2,
                                                    IV_OPERID IN VARCHAR2,
                                                    ON_RESULT OUT NUMBER)
--*******************************************************************************
  -- CopyRight (c) 2018, 融丰银行                                               *
  -- All rights reserved.                                                       *
  --                                                                            *
  -- 文件名称 : SP_CIF_OP_AS_AR_CO_DEPS.prc                                          *
  -- 摘    要 : 对公存款分配表数据加工                                          *
  -- 工程模块 : crmapp.04_27                                                    *
  -- 当前版本 : V1.0.0                                                          *
  -- 作    者 : lyh                                                           *
  -- 完成日期 : 2018/03/15                                                     *
  -- 错误码段 : 40270 - 40279                                                   *
  --*****************************************************************************
 IS
  V_WORK_DATE  VARCHAR2(8);
  V_RETCODE    VARCHAR2(6) := '000000'; --程序/日志返回码
  V_MSG        VARCHAR2(1000); --程序执行信息
  V_TABNAME    VARCHAR2(100); --表名
  V_RETERRFLG  VARCHAR2(1); --日志标志 I(information) W(waring) E(error)
  V_ERRCODE    VARCHAR2(10) := '40279'; --程序执行出错返回码
  V_RETSUBCODE VARCHAR2(3); --程序子返回码
  V_JOBID      VARCHAR2(50) := IV_JOBID;
  V_OPERID     VARCHAR2(50) := IV_OPERID;
BEGIN

  /*获得业务时间*/
  SELECT WORK_DATE INTO V_WORK_DATE FROM SYS_PARA_DATE_NEW;
  ----记录日志
  V_RETCODE    := '40270';
  V_RETSUBCODE := '001';
  V_RETERRFLG  := 'I';
  V_MSG        := '程序执行开始';
  SP_WRITEDETAILLOG(V_WORK_DATE,
                    V_JOBID,
                    V_OPERID,
                    V_MSG,
                    V_RETCODE,
                    V_RETSUBCODE,
                    V_RETERRFLG);

  V_RETCODE    := '40271';
  V_TABNAME    := 'OP_AS_AR_CO_DEPS';
  V_RETERRFLG  := 'I';
  V_RETSUBCODE := '001';
  /*删除跑批分配的数据*/
  /*  execute immediate 'alter table OP_AS_AR_CO_DEPS enable row movement';
  execute immediate 'alter table OP_AS_AR_CO_DEPS shrink space cascade';
  execute immediate 'alter table OP_AS_AR_CO_DEPS disable  row movement';*/

  DELETE FROM OP_AS_AR_CO_DEPS T WHERE T.OP_TYPE = '0';
  COMMIT;
  /*写日志*/
  V_MSG := V_TABNAME || '成功删除对公存款账号中跑批分配的数据';
  SP_WRITEDETAILLOG(V_WORK_DATE,
                    V_JOBID,
                    V_OPERID,
                    V_MSG,
                    V_RETCODE,
                    V_RETSUBCODE,
                    V_RETERRFLG);

  V_RETCODE := '40272';
  /*加载跑批分配的数据，不包括之前跑批的时候已经分配并且业绩发生过转移的数据(OP_TYPE = '1')*/

  INSERT /*+APPEND*/
  INTO OP_AS_AR_CO_DEPS NOLOGGING
    (id, --分配序号
     res_id, --分配资源id
     area_no, --区域号
     res_name, --资源名称
     res_org, --资源机构号
     res_prd, --资源产品
     cust_no, --客户号
     cust_name, --客户名称
     open_org, --开户机构
     al_way, --分配方式: 1按比例分配 2按金额分配
     al_in, --分配对象
     start_date, --开始日期
     end_date, --结束日期
     al_rate, --分配比率
     start_amt, --开始额度
     end_amt, --结束额度
     status, --生效状态
     orderby, --顺序号
     modify_date, --修改日期
     operator, --修改操作员
     al_row_rate, --原始分配比例
     al_factor, --分配系数
     is_small_co, --是否小微客户
     OP_TYPE,
     MAIN_ACCT_NO,
     AC_SEQ
     
     )
    SELECT SYS_GUID(),
           A.AC_ID || A.AC_SEQN, -- 账户id
           100, --
           D.NAME, -- 账户名称
           A.OPN_BR_NO, -- 账户开户机构
           A.PRDT_NO, -- 产品号
           A.CIF_NO, -- 客户代码
           D.NAME, -- 账户名称
           A.OPN_BR_NO, -- 账户开户机构
           '1', -- 1
           A.MANG, -- 经理代码
           CASE
             WHEN A.CRT_DATE = 0 THEN
              TO_DATE('19001231', 'YYYYMMDD')
             ELSE
              TO_date(to_char(A.CRT_DATE), 'yyyymmdd')
           END, -- 建立日期
           case
             when A.CANL_DATE = 99999999 then
              to_date('99991231', 'yyyymmdd')
             else
              TO_date(to_char(A.CANL_DATE), 'yyyymmdd')
           end, -- 解除日期
           A.PERCENT, -- 比例
           NULL, --
           NULL, --
           1, --
           1, --
           CASE
             WHEN A.CRT_DATE = 0 THEN
              TO_DATE('19001231', 'YYYYMMDD')
             ELSE
              NVL(TO_DATE(A.tx_date, 'YYYYMMDD'), SYSDATE)
           END,
           A.MANG, -- 经理代码 , --
           A.PERCENT, --
           1, --
           'N', --
           '0',
           a.ac_no,
           A.AC_SEQN
      FROM A_CBS_CIF_MGER_REL A
    /*     JOIN SYS_EMPLOYEE B
        ON A.MANG = B.EMP_NO --因为表A_CBS_CIF_MGER_REL中的部分MANG与员工表中的EMP_NO对应不起来，所以找不到员工所在的机构，导致I3层数据比I4层金额多
      JOIN SYS_ORGANIZATION C --因为人员所在的机构比机构表中的机构多，会造成I3层数据比I4层金额多
    --现在只取可以关联到机构的员工
        ON B.ORG_NO = C.ORG_NO --现在只取可以关联到的员工*/
      LEFT JOIN A_CBS_CIF_BASIC_INF D
        ON A.CIF_NO = D.CIF_NO
     WHERE a.stat = '1' --只取分配状态正常的 
       and (A.CIF_NO NOT LIKE '1%' or A.CIF_NO is null) --客户号以‘1’开头即为个人存款，以其他数字开头即为对公存款
       and not exists (select op.res_id
              from OP_AS_AR_CO_DEPS op
             where a.ac_id || a.ac_seqn = op.res_id
               and op.op_type = '1');

  COMMIT;

  V_TABNAME := 'OP_AS_AR_CO_DEPS';
  V_MSG     := V_TABNAME || '成功写入' || SQL%ROWCOUNT || '条记录';
  COMMIT;

  /*写日志*/
  SP_WRITEDETAILLOG(V_WORK_DATE,
                    V_JOBID,
                    V_OPERID,
                    V_MSG,
                    V_RETCODE,
                    V_RETSUBCODE,
                    V_RETERRFLG);

  V_RETCODE := '40274';
  V_TABNAME := 'OP_AS_AR_CO_DEPS';
  V_MSG     := V_TABNAME || '表成功写入数据';
  /*写日志*/
  V_RETSUBCODE := '001';
  SP_WRITEDETAILLOG(V_WORK_DATE,
                    V_JOBID,
                    V_OPERID,
                    V_MSG,
                    V_RETCODE,
                    V_RETSUBCODE,
                    V_RETERRFLG);

  V_RETCODE    := '40275';
  V_RETSUBCODE := '001';
  V_RETERRFLG  := 'I';
  V_MSG        := '程序执行结束';
  SP_WRITEDETAILLOG(V_WORK_DATE,
                    V_JOBID,
                    V_OPERID,
                    V_MSG,
                    V_RETCODE,
                    V_RETSUBCODE,
                    V_RETERRFLG);

  ON_RESULT := 0;

  /*异常处理*/
EXCEPTION
  WHEN OTHERS THEN
    V_RETERRFLG := 'E';
    V_RETCODE   := V_ERRCODE;
    V_MSG       := 'SQLCODE:' || V_TABNAME || '表' ||
                   SUBSTR(SQLERRM, 1, 500);
    ON_RESULT   := SQLCODE;
    ROLLBACK;
    SP_WRITEDETAILLOG(V_WORK_DATE,
                      V_JOBID,
                      V_OPERID,
                      V_MSG,
                      V_RETCODE,
                      V_RETSUBCODE,
                      V_RETERRFLG);
    RETURN;
END;
/

