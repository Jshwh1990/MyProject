create PROCEDURE SP_CIF_DAT_PS_ACCT_DEPS_HIS(IV_JOBID  IN VARCHAR2,
                                                        IV_OPERID IN VARCHAR2,
                                                        ON_RESULT OUT NUMBER)
--*******************************************************************************
  -- CopyRight (c) 2017, 融丰银行                                         *
  -- All rights reserved.                                                       *
  --                                                                            *
  -- 文件名称 : SP_CIF_DAT_PS_ACCT_DEPS_HIS.prc                                 *
  -- 摘    要 : A03_对公存款息数据历史加载                                      *
  -- 工程模块 : crmapp.04_27                                                    *
  -- 当前版本 : V1.0.0                                                          *
  -- 作    者 : WXH                                                             *
  -- 完成日期 : 2017/02/09                                                      *
  -- 错误码段 : 40270 - 40279                                                   *
  --*****************************************************************************
 IS
  V_WORK_DATE  VARCHAR2(8);
  V_RETCODE    VARCHAR2(6) := '000000'; --程序/日志返回码
  V_MSG        VARCHAR2(1000); --程序执行信息
  V_TABNAME    VARCHAR2(100); --表名
  V_RETERRFLG  VARCHAR2(1); --日志标志 I(information) W(waring) E(error)
  V_ERRCODE    VARCHAR2(10) := '40279'; --程序执行出错返回码
  V_RETSUBCODE VARCHAR2(3); --程序子返回码
  V_JOBID      VARCHAR2(50) := IV_JOBID;
  V_OPERID     VARCHAR2(50) := IV_OPERID;
  TO_WORK_DATE DATE;
BEGIN

  /*获得业务时间*/
  SELECT WORK_DATE INTO V_WORK_DATE FROM SYS_PARA_DATE_NEW;
  TO_WORK_DATE := TO_DATE(V_WORK_DATE, 'YYYYMMDD');

  V_RETCODE    := '40270';
  V_RETSUBCODE := '001';
  V_RETERRFLG  := 'I';
  V_MSG        := '程序执行开始';
  SP_WRITEDETAILLOG(V_WORK_DATE,
                    V_JOBID,
                    V_OPERID,
                    V_MSG,
                    V_RETCODE,
                    V_RETSUBCODE,
                    V_RETERRFLG);

  V_RETCODE    := '40271';
  V_TABNAME    := 'CIF_DAT_PS_ACCT_DEPS_HIS';
  V_RETERRFLG  := 'I';
  V_RETSUBCODE := '001';

  /*清空表分区*/
  EXECUTE IMMEDIATE 'ALTER TABLE CIF_DAT_PS_ACCT_DEPS_HIS TRUNCATE PARTITION P_' ||
                    V_WORK_DATE;
  /*写日志*/
  V_MSG := V_TABNAME || '表分区记录成功清除';
  SP_WRITEDETAILLOG(V_WORK_DATE,
                    V_JOBID,
                    V_OPERID,
                    V_MSG,
                    V_RETCODE,
                    V_RETSUBCODE,
                    V_RETERRFLG);

  V_RETCODE := '40272';
  /*加载数据到个人存款数据历史表*/
  INSERT /*+APPEND*/
  INTO CIF_DAT_PS_ACCT_DEPS_HIS NOLOGGING
    (ACCT_NO, --账号
     MAIN_ACCT_NO,
     AC_SEQ,
     HIS_START_DATE, --数据开始日期
     HIS_END_DATE, --数据结束日期
     TAR_DATE, --指标日期
     AREA_NO, --区域号
     BIZ_CUST_NO, --原业务系统客户号
     ACCT_NAME, --户名
     ACCT_TYPE, --账户类型
     ACCT_STATE, --账户状态
     CURRENCY, --币种
     TERM, --存期
     SUBJ_CODE, --科目
     PRD_CODE, --产品代码
     OPEN_DATE, --开户日期
     OPEN_ORG, --开户机构
     END_DATE, --到期日期
     LAST_TRD_DATE, --上笔业务活动日期
     BAL, --余额
     M_BAL_S, --余额月累计数
     Y_BAL_S, --余额年累计数
     BAL_AVG_M, --月日均余额
     BAL_LAST, --昨日余额
     BAL_AVG_Y, --年日均余额
     BAL_M_H, --当月最高余额
     BAL_STATIC_Y, --当年存量余额
     BAL_ADD_Y, --当年增量余额
     BAL_LAST_Y, --上年末余额
     BAL_LAST_AVG_Y, --上年末日均
     RATE, --利率
     RATE_FTP, --FTP价格
     BAL_PROFIT, --模拟利润
     BAL_FEE, --营销费用
     AMT_D_Y, --借方发生额(年)
     AMT_C_Y, --贷方发生额(年)
     STAT_TIME, --统计日期
     IS_NEW, --是否当年新增客户
     CUST_LVL, --客户等级
     IS_SMALL_CO, --是否小微客户
     WHE_SPEC_LINE, --是否特殊条线设置
     YA_INT_EPS_AMT, --年利息支出
     SUB_ACCT_NO, --子账户序号
     CD_INT_EPS_AMT, --当日利息支出
     DEPS_TYPE
     )
    SELECT A.ACCT_NO, --账号
           A.MAIN_ACCT_NO,
           A.AC_SEQ,
           V_WORK_DATE, --数据开始日期
           V_WORK_DATE, --数据结束日期
           A.TAR_DATE, --指标日期
           A.AREA_NO, --区域号
           A.BIZ_CUST_NO, --原业务系统客户号
           A.ACCT_NAME, --户名
           A.ACCT_TYPE, --账户类型
           A.ACCT_STATE, --账户状态
           A.CURRENCY, --币种
           A.TERM, --存期
           A.SUBJ_CODE, --科目
           A.PRD_CODE, --产品代码
           A.OPEN_DATE, --开户日期
           A.OPEN_ORG, --开户机构
           A.END_DATE, --到期日期
           A.LAST_TRD_DATE, --上笔业务活动日期
           A.BAL, --余额
           (CASE
             WHEN SUBSTR(V_WORK_DATE, 7, 2) = '01' THEN
              A.BAL
             ELSE
              (A.BAL + NVL(B.M_BAL_S, 0))
           END) M_BAL_S, --余额月累计数
           (CASE
             WHEN TO_CHAR(TO_WORK_DATE, 'DDD') = '001' THEN
              A.BAL
             ELSE
              (A.BAL + NVL(B.Y_BAL_S, 0))
           END) Y_BAL_S, --余额年累计数
           (CASE
             WHEN SUBSTR(V_WORK_DATE, 7, 2) = '01' THEN
              A.BAL
             ELSE
              (A.BAL + NVL(B.M_BAL_S, 0)) /
              (TO_NUMBER(SUBSTR(V_WORK_DATE, 7, 2)))
           END) BAL_AVG_M, --月日均余额
           A.BAL_LAST, --昨日余额
           (CASE
             WHEN TO_CHAR(TO_WORK_DATE, 'DDD') = '001' THEN
              A.BAL
             ELSE
              (A.BAL + NVL(B.Y_BAL_S, 0)) /
              (TO_NUMBER(TO_CHAR(TO_DATE(V_WORK_DATE, 'YYYYMMDD'), 'DDD')))
           END) BAL_AVG_Y, --年日均余额
           A.BAL_M_H, --当月最高余额
           A.BAL_STATIC_Y, --当年存量余额
           A.BAL_ADD_Y, --当年增量余额
           NVL(C.BAL, 0), --上年末余额
           --NVL(C.BAL / FNC_GET_DAYS(V_WORK_DATE, 'LYE'), 0) BAL_LAST_AVG_Y, --上年末日均
           c.bal_avg_y,
           A.RATE, --利率
           A.RATE_FTP, --FTP价格
           A.BAL_PROFIT, --模拟利润
           A.BAL_FEE, --营销费用
           A.AMT_D_Y, --借方发生额(年)
           A.AMT_C_Y, --贷方发生额(年)
           A.STAT_TIME, --统计日期
           A.IS_NEW, --是否当年新增客户
           A.CUST_LVL, --客户等级
           A.IS_SMALL_CO, --是否小微客户
           A.WHE_SPEC_LINE, --是否特殊条线设置
           A.YA_INT_EPS_AMT, --年利息支出
           A.SUB_ACCT_NO, --子账户序号
           A.CD_INT_EPS_AMT, --当日利息支出
           A.DEPS_TYPE
      FROM CIF_DAT_PS_ACCT_DEPS A
      LEFT JOIN CIF_DAT_PS_ACCT_DEPS_HIS B
        ON A.ACCT_NO = B.ACCT_NO
       AND B.HIS_START_DATE =
           TO_CHAR(TO_DATE(V_WORK_DATE, 'YYYYMMDD') - 1, 'YYYYMMDD') --业务日期前一天
      LEFT JOIN CIF_DAT_PS_ACCT_DEPS_HIS C
        ON A.ACCT_NO = C.ACCT_NO
       AND C.HIS_START_DATE =
           TO_CHAR(TRUNC(TO_DATE(V_WORK_DATE, 'YYYYMMDD'), 'YYYY') - 1,
                   'YYYYMMDD'); --上年末;;;
  COMMIT;

  V_MSG := V_TABNAME || '成功写入' || SQL%ROWCOUNT || '条记录';
  COMMIT;
  /*写日志*/
  SP_WRITEDETAILLOG(V_WORK_DATE,
                    V_JOBID,
                    V_OPERID,
                    V_MSG,
                    V_RETCODE,
                    V_RETSUBCODE,
                    V_RETERRFLG);

  V_RETCODE := '40274';
  V_MSG     := V_TABNAME || '表成功写入数据';
  /*写日志*/
  V_RETSUBCODE := '001';
  SP_WRITEDETAILLOG(V_WORK_DATE,
                    V_JOBID,
                    V_OPERID,
                    V_MSG,
                    V_RETCODE,
                    V_RETSUBCODE,
                    V_RETERRFLG);

  V_RETCODE    := '40275';
  V_RETSUBCODE := '001';
  V_RETERRFLG  := 'I';
  V_MSG        := '程序执行结束';
  SP_WRITEDETAILLOG(V_WORK_DATE,
                    V_JOBID,
                    V_OPERID,
                    V_MSG,
                    V_RETCODE,
                    V_RETSUBCODE,
                    V_RETERRFLG);

  ON_RESULT := 0;

  /*异常处理*/
EXCEPTION
  WHEN OTHERS THEN
    V_RETERRFLG := 'E';
    V_RETCODE   := V_ERRCODE;
    V_MSG       := 'SQLCODE:' || V_TABNAME || '表' ||
                   SUBSTR(SQLERRM, 1, 500);
    ON_RESULT   := SQLCODE;
    ROLLBACK;
    SP_WRITEDETAILLOG(V_WORK_DATE,
                      V_JOBID,
                      V_OPERID,
                      V_MSG,
                      V_RETCODE,
                      V_RETSUBCODE,
                      V_RETERRFLG);
    RETURN;
END;
/

