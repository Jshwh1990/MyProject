create PROCEDURE SP_SYS_EMPLOYEE(IV_JOBID  IN VARCHAR2,
                                            IV_OPERID IN VARCHAR2,
                                            ON_RESULT OUT NUMBER)
--*******************************************************************************
  -- CopyRight (c) 2018, 融丰银行                                               *
  -- All rights reserved.                                                       *
  --                                                                            *
  -- 文件名称 : SYS_EMPLOYEE.prc                                          *
  -- 摘    要 : A03_员工表                                              *
  -- 工程模块 : crmapp.04_27                                                    *
  -- 当前版本 : V1.0.0                                                          *
  -- 作    者 : LYH                                                            *
  -- 完成日期 : 2018/03/16                                                      *
  -- 错误码段 : 40270 - 40279                                                   *
  --*****************************************************************************
 IS
  V_WORK_DATE  VARCHAR2(8);
  V_RETCODE    VARCHAR2(6) := '000000'; --程序/日志返回码
  V_MSG        VARCHAR2(1000); --程序执行信息
  V_TABNAME    VARCHAR2(100); --表名
  V_RETERRFLG  VARCHAR2(1); --日志标志 I(information) W(waring) E(error)
  V_ERRCODE    VARCHAR2(10) := '40279'; --程序执行出错返回码
  V_RETSUBCODE VARCHAR2(3); --程序子返回码
  --V_TABLEEXIST NUMBER; --是否存在表名
BEGIN

  /*获得业务时间*/
  SELECT WORK_DATE INTO V_WORK_DATE FROM SYS_PARA_DATE_NEW;

  V_RETCODE    := '40270';
  V_RETSUBCODE := '001';
  V_RETERRFLG  := 'I';
  V_MSG        := '程序执行开始';
  SP_WRITEDETAILLOG(V_WORK_DATE,
                    IV_JOBID,
                    IV_OPERID,
                    V_MSG,
                    V_RETCODE,
                    V_RETSUBCODE,
                    V_RETERRFLG);

  V_RETCODE    := '40271';
  V_TABNAME    := 'SYS_EMPLOYEE';
  V_RETERRFLG  := 'I';
  V_RETSUBCODE := '001';
  /*清空员工表*/
  /*DELETE FROM SYS_EMPLOYEE T WHERE T.EMP_NO <> 'admin';
  COMMIT;*/
  /*  DELETE FROM SYS_EMPLOYEE_HIS T WHERE T.EMP_NO <> 'admin';
  COMMIT;*/
  /*写日志*/
  V_MSG := V_TABNAME || '表记录成功清除';
  SP_WRITEDETAILLOG(V_WORK_DATE,
                    IV_JOBID,
                    IV_OPERID,
                    V_MSG,
                    V_RETCODE,
                    V_RETSUBCODE,
                    V_RETERRFLG);

  V_RETCODE := '40272';
  /*加载数据到员工表*/
  INSERT INTO SYS_EMPLOYEE
    (emp_no, --员工编号
     emp_name, --员工名
     org_no, --机构号
     job_title, --工作岗位
     status, --生效状态
     user_level, --用户等级
     headship, --职务
     sex, --性别
     birthday, --出生日期
     cert_type, --证件类型
     cert_no, --证件号码
     mobile, --手机号码
     home_address, --家庭住址
     private_email, --私人邮箱
     in_date, --入职日期
     OUT_DATE, --离职日期
     education --学历
     )
    SELECT A.CUR_STAFF_NO,
           A.NAME,
           B.CUR_DEP_NO,
           NVL(A.TEL_DESC, 0),
           (CASE
             WHEN A.STS = '1' THEN
              '1'
             ELSE
              '4'
           END) STS,
           A.HIRE_TYPE,
           A.STAFF_POST,
           A.SEX,
           (case
             when a.birth_date = 0 or a.birth_date is null then
              to_date('99991231', 'yyyymmdd')
             else
              TO_DATE(A.BIRTH_DATE, 'YYYYMMDD')
           end) BIRTH_DATE,
           A.ID_TYPE,
           A.ID_NO,
           A.PHONE_NO,
           A.ADDR,
           A.EMAIL,
           (case
             when A.HIRE_DATE = 0 or A.HIRE_DATE is null then
              to_date('99991231', 'yyyymmdd')
             else
              TO_DATE(A.HIRE_DATE, 'YYYYMMDD')
           end) HIRE_DATE,
           /*  case
             when a.lst_date is null then
              to_date('99991231', 'yyyymmdd')
             else
              to_date(to_char(a.lst_date), 'yyyymmdd')
           end OUT_DATE,*/
           to_date('99991231', 'yyyymmdd') OUT_DATE,
           A.EDU
      FROM A_FMS_STAFF_INFO A
      LEFT JOIN A_FMS_COM_DEPARTMENT B
        ON A.DEP_NO = B.DEP_NO
     where A.CUR_STAFF_NO <> '00000000'
       and A.CUR_STAFF_NO <> '60100099'
       AND A.CUR_STAFF_NO NOT IN (SELECT EMP.EMP_NO FROM SYS_EMPLOYEE EMP); --20180712增量加载
  commit;
  --用户表中插入新增的员工（客户经理角色）
  insert into rbac_user
    (id, --1
     login_name,
     name,
     password,
     area_no,
     inval_date,
     auth_mode,
     status,
     unlock_time,
     menu_type,
     last_login,
     err_count,
     start_date,
     end_date,
     valid_time,
     mac_code,
     ip_address,
     email,
     password_salt,
     remark,
     role_id,
     emp_no)
    select seq_rbac_user.nextval,
           EMP_NO,
           EMP_NAME,
           '2260c70c47728c37263af47fb1e8668a030ad56a',
           null,
           null,
           null,
           '1',
           null,
           null,
           null,
           '1',
           null,
           null,
           '99999',
           null,
           null,
           null,
           '4ddb8ead6e33316f' ， '',
           '196270', --客户经理角色id
           EMP_NO
      from sys_employee a
     where a.emp_no not in (select b.login_name from rbac_user b);
  commit;
  --用户可查看机构表中添加新增的员工
  insert into rbac_user_view_org
    (user_id, org_no)
    select a.id, b.org_no
      from rbac_user a
      left join sys_employee b
        on a.login_name = b.emp_no
     where a.id not in (select c.user_id from rbac_user_view_org c);
  commit;
  --用户可管理机构表中添加新增的员工
  insert into rbac_user_mng_org
    (user_id, org_no)
    select a.id, b.org_no
      from rbac_user a
      left join sys_employee b
        on a.login_name = b.emp_no
     where a.id not in (select c.user_id from rbac_user_mng_org c);
  commit;

  V_TABNAME := 'SYS_EMPLOYEE';
  V_MSG     := V_TABNAME || '成功写入' || SQL%ROWCOUNT || '条记录';
  COMMIT;

  /*写日志*/
  SP_WRITEDETAILLOG(V_WORK_DATE,
                    IV_JOBID,
                    IV_OPERID,
                    V_MSG,
                    V_RETCODE,
                    V_RETSUBCODE,
                    V_RETERRFLG);

  V_RETCODE := '40274';
  V_TABNAME := 'SYS_EMPLOYEE';
  V_MSG     := V_TABNAME || '表成功写入数据';

  ON_RESULT := 0;

  /*异常处理*/
EXCEPTION
  WHEN OTHERS THEN
    V_RETERRFLG := 'E';
    V_RETCODE   := V_ERRCODE;
    V_MSG       := 'SQLCODE:' || V_TABNAME || '表' ||
                   SUBSTR(SQLERRM, 1, 500);
    ON_RESULT   := SQLCODE;
    ROLLBACK;
    SP_WRITEDETAILLOG(V_WORK_DATE,
                      IV_JOBID,
                      IV_OPERID,
                      V_MSG,
                      V_RETCODE,
                      V_RETSUBCODE,
                      V_RETERRFLG);
    RETURN;
END;
/

