create PROCEDURE SP_CIF_INF_CO_ACCT_DEPS(IV_JOBID  IN VARCHAR2,
                                                    IV_OPERID IN VARCHAR2,
                                                    ON_RESULT OUT NUMBER)
--*******************************************************************************
  -- CopyRight (c) 2018, 融丰银行                                               *
  -- All rights reserved.                                                       *
  --                                                                            *
  -- 文件名称 : SP_CIF_INF_CO_ACCT_DEPS.prc                                     *
  -- 摘    要 : A03_对公存款信息表加载                                          *
  -- 工程模块 : crmapp.04_27                                                    *
  -- 当前版本 : V1.0.0                                                          *
  -- 作    者 : YCY                                                             *
  -- 完成日期 : 2018/01/24                                                      *
  -- 错误码段 : 40270 - 40279                                                   *
  --*****************************************************************************
 IS
  V_WORK_DATE  VARCHAR2(8);
  TO_WORK_DATE DATE;
  V_RETCODE    VARCHAR2(6) := '000000'; --程序/日志返回码
  V_MSG        VARCHAR2(1000); --程序执行信息
  V_TABNAME    VARCHAR2(100); --表名
  V_RETERRFLG  VARCHAR2(1); --日志标志 I(information) W(waring) E(error)
  V_ERRCODE    VARCHAR2(10) := '40279'; --程序执行出错返回码
  V_RETSUBCODE VARCHAR2(3); --程序子返回码
  V_TABLEEXIST NUMBER; --是否存在表名
BEGIN

  /*获得业务时间*/
  SELECT WORK_DATE INTO V_WORK_DATE FROM SYS_PARA_DATE_NEW;
  TO_WORK_DATE := TO_DATE(V_WORK_DATE, 'YYYYMMDD');

  /*判断对公存款临时表数据是否存在, 若不存在，则插入对公存款数据*/
  SELECT COUNT(1) INTO V_TABLEEXIST FROM TEMP_CIF_INF_CO_ACCT_DEPS;
  IF V_TABLEEXIST = 0 THEN
    INSERT /*+APPEND*/
    INTO TEMP_CIF_INF_CO_ACCT_DEPS NOLOGGING
      SELECT * FROM CIF_INF_CO_ACCT_DEPS;
    COMMIT;
  END IF;

  V_RETCODE    := '40270';
  V_RETSUBCODE := '001';
  V_RETERRFLG  := 'I';
  V_MSG        := '程序执行开始';
  SP_WRITEDETAILLOG(V_WORK_DATE,
                    IV_JOBID,
                    IV_OPERID,
                    V_MSG,
                    V_RETCODE,
                    V_RETSUBCODE,
                    V_RETERRFLG);

  V_RETCODE    := '40271';
  V_TABNAME    := 'CIF_INF_CO_ACCT_DEPS';
  V_RETERRFLG  := 'I';
  V_RETSUBCODE := '001';
  /*清空对公存款信息表*/
  EXECUTE IMMEDIATE 'TRUNCATE TABLE CIF_INF_CO_ACCT_DEPS';
  /*写日志*/
  V_MSG := V_TABNAME || '表记录成功清除';
  SP_WRITEDETAILLOG(V_WORK_DATE,
                    IV_JOBID,
                    IV_OPERID,
                    V_MSG,
                    V_RETCODE,
                    V_RETSUBCODE,
                    V_RETERRFLG);

  V_RETCODE := '40272';
  /*加载数据到对公存款账户信息表--正常存款*/
  --加载核心活期
  INSERT /*+APPEND*/
  INTO CIF_INF_CO_ACCT_DEPS NOLOGGING
    (ACCT_NO, --帐号
     AREA_NO, --区域号
     MAIN_ACCT_NO, --主账号
     AC_SEQ,
     CUST_NO, --客户号
     CUST_NAME, --客户名称
     ACCT_TYPE, --帐号类型
     CURRENCY, --币种,
     TERM, --存期
     PRD_CODE, --产品代码
     OPEN_DATE, --开户日期
     OPEN_ORG, --开户机构
     END_DATE, --到期日期
     BELONG_ORG, --归属机构
     BAL, --余额
     BAL_AVG_Y, --年日均
     MANAGER_NO, --客户经理编号
     STATE, --分配状态
     MODIFY_DATE, --更新日期
     ACCT_STATE, --账户状态
     IS_SMALL_CO, --是否小微企业
     BELONG_TYPE, --客户归属机构类型：1.前台更改，0：后台自动每日更新
     DEPS_TYPE)

    SELECT A.AC_ID || A.AC_SEQN ACCT_NO, --账号
           '100',
           REL.AC_NO,
           A.AC_SEQN,
           A.CIF_NO CUST_ID, --客户号
           B.NAME,
           A.AC_TYPE, --账户类型
           A.CUR_NO CURRENCY, --币种
           0,
           A.PRDT_NO PRD_CODE, --产品代码
           TO_CHAR(A.OPN_DATE) OPEN_DATE, --开户日期
           A.OPN_BR_NO OPEN_ORG, --开户机构
           (CASE
             WHEN A.VAL_DATE = 0 THEN
              99991231
             WHEN A.VAL_DATE = 99999999 THEN
              99991231
             ELSE
              A.VAL_DATE
           END) end_date,
           A.OPN_BR_NO OPEN_ORG, --开户机构
           A.BAL BAL, --余额
           NULL BAL_AVG_Y, --年日均余额
           NULL MANAGER_NO, --客户经理编号
           '0', --NVL(TMP.STATE, '0') STATE, --分配状态
           TO_WORK_DATE MODIFY_DATE, --更新日期
           A.AC_STS, --账户状态
           'N' IS_SMALL_CO, --是否小微企业
           NVL(TMP.BELONG_TYPE, '0'), --客户归属机构类型：1.前台更改，0：后台自动每日更新
           '核心活期'
      FROM A_CBS_DD_MST A --活期存款主文件（核心）
      LEFT JOIN A_CBS_CIF_BASIC_INF B --客户基本信息表
        ON A.CIF_NO = B.CIF_NO
      LEFT JOIN TEMP_CIF_INF_CO_ACCT_DEPS TMP --备份表
        ON A.AC_ID||A.AC_SEQN = TMP.ACCT_NO
      LEFT JOIN (SELECT T.AC_NO, T.AC_ID, T.AC_SEQN
                   FROM A_CBS_MDM_AC_REL T
                  WHERE T.MAIN_IND = '1'
                    AND (T.NOTE_STS = '0' or t.note_sts = '1' or
                        t.note_sts = '#')) REL
        ON A.AC_ID = REL.AC_ID
     WHERE A.CIF_NO NOT like '1%'
       AND a.ac_sts <> '*';
  COMMIT;
  --加载核心定期
  INSERT /*+APPEND*/
  INTO CIF_INF_CO_ACCT_DEPS NOLOGGING
    (ACCT_NO, --帐号
     AREA_NO, --区域号
     MAIN_ACCT_NO, --主账号
     AC_SEQ,
     CUST_NO, --客户号
     CUST_NAME, --客户名称
     ACCT_TYPE, --帐号类型
     CURRENCY, --币种,
     TERM, --存期
     PRD_CODE, --产品代码
     OPEN_DATE, --开户日期
     OPEN_ORG, --开户机构
     END_DATE, --到期日期
     BELONG_ORG, --归属机构
     BAL, --余额
     BAL_AVG_Y, --年日均
     MANAGER_NO, --客户经理编号
     STATE, --分配状态
     MODIFY_DATE, --更新日期
     ACCT_STATE, --账户状态
     IS_SMALL_CO, --是否小微企业
     BELONG_TYPE, --客户归属机构类型：1.前台更改，0：后台自动每日更新
     DEPS_TYPE)
    SELECT A.AC_ID || A.AC_SEQN ACCT_NO, --账号
           '100',
           REL.AC_NO,
           A.AC_SEQN,
           A.CIF_NO CUST_ID, --客户号
           B.NAME,
           '1' ACCT_TYPE, --账户类型
           A.CUR_NO CURRENCY, --币种
           (CASE
             WHEN C.TERM_TYPE = 'Y' THEN
              C.TERM * 365
             WHEN C.TERM_TYPE = 'M' THEN
              C.TERM * 30
             ELSE
              NVL(C.TERM, 0)
           END) term,
           A.PRDT_NO PRD_CODE, --产品代码
           TO_CHAR(A.OPN_DATE) OPEN_DATE, --开户日期
           A.OPN_BR_NO OPEN_ORG, --开户机构
           TO_CHAR(A.MTR_DATE) END_DATE, --到期日期
           A.OPN_BR_NO OPEN_ORG, --开户机构
           A.BAL BAL, --余额
           NULL BAL_AVG_Y, --年日均余额
           NULL MANAGER_NO, --客户经理编号
           '0', --NVL(TMP.STATE, '0') STATE, --分配状态
           TO_WORK_DATE MODIFY_DATE, --更新日期
           A.AC_STS, --账户状态
           'N' IS_SMALL_CO, --是否小微企业
           NVL(TMP.BELONG_TYPE, '0'), --客户归属机构类型：1.前台更改，0：后台自动每日更新
           '核心定期'
      FROM A_CBS_TD_MST A --定期存款主文件（核心）
      LEFT JOIN A_CBS_CIF_BASIC_INF B --客户基本信息表
        ON A.Cif_No = B.CIF_NO
      LEFT JOIN TEMP_CIF_INF_CO_ACCT_DEPS TMP --备份表
        ON A.AC_ID||A.AC_SEQN = TMP.ACCT_NO
      LEFT JOIN (SELECT T.AC_NO, T.AC_ID, T.AC_SEQN
                   FROM A_CBS_MDM_AC_REL T
                  WHERE T.MAIN_IND = '1'
                    AND (T.NOTE_STS = '0' or t.note_sts = '1' or
                        t.note_sts = '#')) REL
        ON A.AC_ID = REL.AC_ID
      LEFT JOIN A_CBS_TD_PARM C
        ON A.PRDT_NO = C.PRDT_NO
     WHERE A.CIF_NO NOT like '1%'
       AND a.ac_sts <> '*';

  COMMIT;
  V_MSG := V_TABNAME || '成功写入' || SQL%ROWCOUNT || '条记录';
  COMMIT;

  /*更新分配状态*/
  UPDATE CIF_INF_CO_ACCT_DEPS T
     SET T.STATE = '1'
   WHERE T.STATE = '0'
     AND EXISTS
   (SELECT 1 FROM OP_AS_AR_CO_DEPS B WHERE T.ACCT_NO = B.RES_ID);
  COMMIT;
  UPDATE CIF_INF_CO_ACCT_DEPS T
     SET T.STATE = '0'
   WHERE T.STATE = '1'
     AND NOT EXISTS
   (SELECT 1 FROM OP_AS_AR_CO_DEPS B WHERE T.ACCT_NO = B.RES_ID);
  COMMIT;
  /*写日志*/
  SP_WRITEDETAILLOG(V_WORK_DATE,
                    IV_JOBID,
                    IV_OPERID,
                    V_MSG,
                    V_RETCODE,
                    V_RETSUBCODE,
                    V_RETERRFLG);

  /*清空临时表*/
  EXECUTE IMMEDIATE 'TRUNCATE TABLE TEMP_CIF_INF_CO_ACCT_DEPS';

  V_RETCODE    := '40275';
  V_RETSUBCODE := '001';
  V_RETERRFLG  := 'I';
  V_MSG        := '程序执行结束';
  SP_WRITEDETAILLOG(V_WORK_DATE,
                    IV_JOBID,
                    IV_OPERID,
                    V_MSG,
                    V_RETCODE,
                    V_RETSUBCODE,
                    V_RETERRFLG);

  ON_RESULT := 0;

  /*异常处理*/
EXCEPTION
  WHEN OTHERS THEN
    V_RETERRFLG := 'E';
    V_RETCODE   := V_ERRCODE;
    V_MSG       := 'SQLCODE:' || V_TABNAME || '表' ||
                   SUBSTR(SQLERRM, 1, 500);
    ON_RESULT   := SQLCODE;
    ROLLBACK;
    SP_WRITEDETAILLOG(V_WORK_DATE,
                      IV_JOBID,
                      IV_OPERID,
                      V_MSG,
                      V_RETCODE,
                      V_RETSUBCODE,
                      V_RETERRFLG);
    RETURN;
END;

/

