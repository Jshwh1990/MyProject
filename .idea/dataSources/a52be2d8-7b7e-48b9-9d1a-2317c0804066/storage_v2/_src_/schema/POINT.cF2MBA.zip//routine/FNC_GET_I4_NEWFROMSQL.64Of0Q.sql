create FUNCTION FNC_GET_I4_NEWFROMSQL
(
  P_INS_TABLE VARCHAR,
  P_TEMP_TABLE VARCHAR,
  P_RECALC INT, --计算类型：10为当日业绩计算，20为外部回算，30为内部回算
  P_SDAT VARCHAR,
  P_EDAT VARCHAR
)
/* 过程、函数简要描述信息
  **********************************************************
  *  存储过程名:  查询语句生成函数
  *  建立日期  :  2013-03-20
  *  作者      :  linyd
  *  模块      :
  *  功能描述  :
  *  输入参数  ： P_TABLE 来源表 ，P_INS_TABLE 目标表，P_SDAT 处理日期,P_EDAT 处理结束日期
  *               P_RECALC 计算类型：10为当日业绩计算，20为外部回算，30为内部回算
  *  输出参数  ： RETCODE 0为正确1为错误， RETMSG错误信息
  *  来源表    ： OP_AS_AR_CO_CUST  对公客户分配表
  *  目标表    :   对公客户分配规则明细表
  *   备注     ：
  *------------------------------------------------------------
  *  修改历史
  *  序号    日期      修改人      修改原因
  ************************************************************ */
RETURN VARCHAR IS
  FROMSQL VARCHAR(30000) ;
  S_POS SMALLINT DEFAULT 1;
  E_POS SMALLINT ;
  T_INS_TABLE_HIS VARCHAR(128);
  T_LAST_DAT VARCHAR(10);
  T_ONSQL VARCHAR(4000);
  CNT SMALLINT;
  T_JOIN VARCHAR(30);
  T_ONSQL2 VARCHAR2(4000);
  KEYFIELD VARCHAR2(100);
  is_y_last INT;
  is_q_last INT;
  is_m_last INT;

BEGIN
  --判断表是否可用
  SELECT COUNT(1) INTO CNT FROM OP_AS_RT_DICT_TABLE WHERE INS_TABLE_CODE=UPPER(P_INS_TABLE) AND ENABLE = 1 ;
  IF CNT <= 0 THEN
    RETURN NULL;
  END IF ;
  --SELECT INS_FIELD_CODE INTO KEYFIELD FROM OP_AS_RT_DICT_FIELD WHERE INS_TABLE_CODE=UPPER(P_INS_TABLE) AND INS_ENABLE = 1 AND IS_KEY = 1;
  --设置当前临时表名
  T_INS_TABLE_HIS :=P_INS_TABLE;
  IF TO_DATE(P_SDAT,'YYYYMMDD')=trunc(TO_DATE(P_SDAT,'YYYYMMDD'),'month') THEN
    is_m_last :=1;
  END IF;
  IF TO_DATE(P_SDAT,'YYYYMMDD')=trunc(TO_DATE(P_SDAT,'YYYYMMDD'),'Q') THEN
    is_q_last :=1;
  END IF;
  IF TO_DATE(P_SDAT,'YYYYMMDD')=trunc(TO_DATE(P_SDAT,'YYYYMMDD'),'YEAR') THEN
    is_y_last :=1;
  END IF;

  --上日日期
  T_LAST_DAT := TO_CHAR(TO_DATE(P_SDAT,'YYYYMMDD') - 1,'YYYYMMDD');

  T_ONSQL := '#';
  FROMSQL := '#';
  T_ONSQL2 := '#';
  SELECT MAX(SNO) INTO E_POS FROM OP_AS_RT_DICT_FIELD WHERE INS_TABLE_CODE=UPPER(P_INS_TABLE);
  WHILE(S_POS<=E_POS) LOOP
    SELECT COUNT(1) INTO CNT FROM OP_AS_RT_DICT_FIELD WHERE INS_TABLE_CODE=UPPER(P_INS_TABLE) AND SNO = S_POS AND INS_ENABLE = 1;
    IF CNT > 0 THEN
       SELECT FROMSQL ||','||CASE WHEN IS_CALC = 0 THEN 'NVL(T0.'||FROM_FIELD_CODE||',T1.'||INS_FIELD_CODE||')'
                                  WHEN IS_SUM = 0 AND IS_CALC = 1 THEN 'NVL(T0.'||FROM_FIELD_CODE||',0)'
                                  WHEN IS_SUM=5 AND IS_CALC = 1 AND is_y_last=1 THEN 'NVL(T0.'||FROM_FIELD_CODE||',0)'
                                  WHEN IS_SUM=3 AND IS_CALC = 1 AND is_q_last=1 THEN 'NVL(T0.'||FROM_FIELD_CODE||',0)'
                                  WHEN IS_SUM=2 AND IS_CALC = 1 AND is_m_last=1 THEN 'NVL(T0.'||FROM_FIELD_CODE||',0)'
                                  ELSE 'NVL(T0.'||FROM_FIELD_CODE||',0) + NVL(T1.'||INS_FIELD_CODE||',0)'
                             END INTO FROMSQL
       FROM OP_AS_RT_DICT_FIELD
       WHERE INS_TABLE_CODE =UPPER(P_INS_TABLE) AND SNO = S_POS ;

      SELECT COUNT(1) INTO CNT FROM OP_AS_RT_DICT_FIELD WHERE INS_TABLE_CODE=UPPER(P_INS_TABLE) AND SNO = S_POS AND INS_ENABLE = 1 AND IS_PRIMARY_KEY = 1;
      IF CNT > 0 THEN
        SELECT T_ONSQL ||'AND T1.'||INS_FIELD_CODE ||' = T0.'||FROM_FIELD_CODE ||' ' INTO T_ONSQL
        FROM OP_AS_RT_DICT_FIELD
        WHERE INS_TABLE_CODE=UPPER(P_INS_TABLE) AND SNO = S_POS AND INS_ENABLE = 1 AND IS_PRIMARY_KEY = 1;
      END IF;

      SELECT COUNT(1) INTO CNT FROM OP_AS_RT_DICT_FIELD WHERE INS_TABLE_CODE=UPPER(P_INS_TABLE) AND SNO = S_POS AND INS_ENABLE = 1 AND IS_PRIMARY_KEY = 1 AND FROM_TABLE_CODE <> '#';
      IF CNT > 0 THEN
        SELECT T_ONSQL2 ||'AND A.'||INS_FIELD_CODE ||' = B.'||INS_FIELD_CODE ||' ' INTO T_ONSQL2
        FROM OP_AS_RT_DICT_FIELD
        WHERE INS_TABLE_CODE=UPPER(P_INS_TABLE) AND SNO = S_POS AND INS_ENABLE = 1 AND IS_PRIMARY_KEY = 1 AND FROM_TABLE_CODE <> '#';
      END IF;
    END IF;
    S_POS := S_POS + 1;
  END LOOP;
  T_ONSQL := REPLACE(T_ONSQL,'#AND','');
  T_ONSQL2 := REPLACE(T_ONSQL2,'#AND','');
  FROMSQL := REPLACE(FROMSQL,'#,','');
  FROMSQL := 'SELECT '||FROMSQL|| ',NVL(T0.TAR_DATE,''' ||P_SDAT||''')';
  --拼FROM语句
  T_JOIN := 'FULL';
  FROMSQL := FROMSQL ||' FROM '||P_TEMP_TABLE||' T0 '||T_JOIN||' JOIN (SELECT * FROM '||T_INS_TABLE_HIS||' WHERE TAR_DATE = '''||T_LAST_DAT||''') T1 ON ';
  FROMSQL := FROMSQL || T_ONSQL;
  RETURN FROMSQL;
END
;

/

