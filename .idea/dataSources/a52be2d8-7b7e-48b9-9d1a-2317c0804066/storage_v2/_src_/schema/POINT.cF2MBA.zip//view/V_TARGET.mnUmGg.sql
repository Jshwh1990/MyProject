create view V_TARGET as
  (SELECT
         qi.TRG_ID TRG_ID,
         qi.TRG_CODE TRG_CODE,
         qi.TRG_NAME TRG_NAME,
         qi.APPLY_TYPE APPLY_TYPE,
         qi.TRG_TYPE TYPE,
         qi.ORG_NO ORG_NO,
         qi.trg_category_id trg_category_id
 FROM OP_TRG_QTY_INFO qi
 where qi.DEL_FLAG = 0
 UNION ALL
 SELECT
        pi.TRG_ID TRG_ID,
        pi.TRG_CODE TRG_CODE,
        pi.TRG_NAME TRG_NAME,
        pi.APPLY_TYPE APPLY_TYPE,
        'P' TYPE,
        pi.org_no org_no,
        9 trg_category_id
  FROM OP_TRG_PROP_INFO pi
  where pi.DEL_FLAG = 0
)
/

