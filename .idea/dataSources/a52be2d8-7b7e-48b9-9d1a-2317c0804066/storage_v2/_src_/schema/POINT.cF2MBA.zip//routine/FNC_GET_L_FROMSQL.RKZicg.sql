create FUNCTION FNC_GET_L_FROMSQL(P_TABLE     VARCHAR
                                            ,P_INS_TABLE VARCHAR
                                            ,P_RECALC    INT
                                            , --计算类型：10为当日业绩计算,20为外部回算,30为内部回算
                                             P_SDAT      VARCHAR
                                            ,P_EDAT      VARCHAR)
/* 过程、函数简要描述信息
  **********************************************************
  *  存储过程名:  查询语句生成函数
  *  建立日期  :  2013-03-20
  *  作者      :  linyd
  *  模块      :
  *  功能描述  :
  *  输入参数  ： P_TABLE 来源表 ,P_INS_TABLE 目标表,P_SDAT 处理日期,P_EDAT 处理结束日期
  *               P_RECALC 计算类型：10为当日业绩计算,20为外部回算,30为内部回算
  *  输出参数  ： RETCODE 0为正确1为错误, RETMSG错误信息
  *  来源表    ： OP_AS_AR_CO_CUST  对公客户分配表
  *  目标表    :   对公客户分配规则明细表
  *   备注     ：
  *------------------------------------------------------------
  *  修改历史
  *  序号    日期      修改人      修改原因
  ************************************************************ */
 RETURN VARCHAR IS
  FROMSQL           VARCHAR(4000);
  GROUPSQL          VARCHAR(4000);
  ALLOCFIELD        VARCHAR(255);
  STAFF_R_ORG_TABLE VARCHAR(128);
  KEYFIELD          VARCHAR(128);
  KEY_T             VARCHAR(128);
  KEY_ALLOC_PROD    VARCHAR(128);
  KEY_FROM          VARCHAR(512); --与分配明细表匹配
  T_ALLOC_TABLE     VARCHAR(128);
  FNC_SEG           VARCHAR(128);
  S_POS             SMALLINT DEFAULT 1;
  E_POS             SMALLINT;
  R_WHERE_SQL       VARCHAR(4000);
  R_FROM_FIELD      VARCHAR(128);
  R_AD_TABLE        VARCHAR(128);
  CNT               SMALLINT;
  ORG_LEV           VARCHAR(128);
  /* CURSOR cur_sor  IS
  SELECT FROM_FIELD_CODE  FROM OP_AS_RT_DICT_FIELD WHERE FROM_TABLE_CODE =UPPER('#') AND INS_TABLE_CODE = UPPER(P_INS_TABLE) ORDER BY sno;*/
BEGIN

  --判断表是否可用
  SELECT COUNT(1)
    INTO CNT
    FROM OP_AS_RT_DICT_TABLE
   WHERE FROM_TABLE_CODE = UPPER(P_TABLE)
     AND INS_TABLE_CODE = UPPER(P_INS_TABLE)
     AND ENABLE = 1;
  IF CNT <= 0 THEN
    RETURN NULL;
  END IF;

  SELECT ALLOCATE_TABLE
    INTO T_ALLOC_TABLE
    FROM OP_AS_RT_DICT_TABLE
   WHERE FROM_TABLE_CODE = UPPER(P_TABLE)
     AND INS_TABLE_CODE = UPPER(P_INS_TABLE)
     AND ENABLE = 1;
  --取分段函数
  SELECT NVL(FNC_SEG, '')
    INTO FNC_SEG
    FROM OP_AS_RT_DICT_TABLE
   WHERE INS_TABLE_CODE = UPPER(P_INS_TABLE)
     AND ENABLE = 1;
  FROMSQL  := 'SELECT ';
  GROUPSQL := 'GROUP BY ';
  KEYFIELD := '@';
  KEY_FROM := '@';
  --首先判断是不是占位符,即分入ID。占位符字段不属于计算列,不属于汇总列及平均值列
  SELECT COUNT(1)
    INTO CNT
    FROM OP_AS_RT_DICT_FIELD
   WHERE FROM_TABLE_CODE = UPPER('#')
     AND INS_ENABLE = 1
     AND INS_TABLE_CODE = UPPER(P_INS_TABLE)
     AND IS_PRIMARY_KEY = 1;
  IF CNT > 0 THEN
    SELECT FROM_FIELD_CODE
      INTO ALLOCFIELD
      FROM OP_AS_RT_DICT_FIELD
     WHERE FROM_TABLE_CODE = UPPER('#')
       AND INS_TABLE_CODE = UPPER(P_INS_TABLE)
       AND IS_PRIMARY_KEY = 1;
    ALLOCFIELD := 'T1.' || ALLOCFIELD;
    GROUPSQL   := GROUPSQL || ALLOCFIELD;
    FROMSQL    := FROMSQL || ALLOCFIELD;
  ELSE
    RETURN NULL;
  END IF;

  IF (INSTR(UPPER(P_INS_TABLE), 'PI_I2') > 0 AND
     INSTR(UPPER(P_TABLE), 'PI_I3') > 0) THEN
    STAFF_R_ORG_TABLE := 'JOIN V_CRM_STAFF T2 ON T2.CODE =' || ALLOCFIELD ||
                         ' AND T2.ORG_CODE = T0.ORG_CODE ';
    KEY_ALLOC_PROD    := ' ';
  ELSE
    STAFF_R_ORG_TABLE := ' ';
    KEY_ALLOC_PROD    := ' ';
  END IF;

  --对客户分配可以在多个机构进行分配,所以需要特殊处理,只计算客户在总行级的分配
  IF (INSTR(UPPER(P_INS_TABLE), 'CUST') > 0) THEN
    ORG_LEV := ' AND nvl(t1.org_lev,0) < 2 ';
  ELSE
    ORG_LEV := ' ';
  END IF;

  --其次找到关键,即业务主键
  SELECT COUNT(1)
    INTO CNT
    FROM OP_AS_RT_DICT_FIELD
   WHERE INS_TABLE_CODE = UPPER(P_INS_TABLE)
     AND INS_ENABLE = 1
     AND IS_KEY = 1;
  IF CNT > 0 THEN
    SELECT MAX(IS_KEY)
      INTO E_POS
      FROM OP_AS_RT_DICT_FIELD
     WHERE INS_TABLE_CODE = UPPER(P_INS_TABLE)
       AND INS_ENABLE = 1
       AND IS_KEY > 0;
    IF E_POS > 1 THEN
      E_POS := 1;
    END IF;
    WHILE (S_POS <= E_POS) LOOP
      SELECT 'T0.' || FROM_FIELD_CODE
        INTO KEY_T
        FROM OP_AS_RT_DICT_FIELD
       WHERE INS_TABLE_CODE = UPPER(P_INS_TABLE)
         AND INS_ENABLE = 1
         AND IS_KEY = S_POS;
      KEYFIELD := KEYFIELD || KEY_T;
      KEY_FROM := KEY_FROM || KEY_T;
      IF (S_POS < E_POS) THEN
        KEYFIELD := KEYFIELD || ',';
      END IF;
      GROUPSQL := GROUPSQL || ',' || KEY_T;
      FROMSQL  := FROMSQL || ',' || KEY_T;
      S_POS    := S_POS + 1;
    END LOOP;
    KEYFIELD := REPLACE(KEYFIELD, '@', '');
    KEY_FROM := REPLACE(KEY_FROM, '@', '');
    GROUPSQL := REPLACE(GROUPSQL, '@', '');
    FROMSQL  := REPLACE(FROMSQL, '@', '');
  ELSE
    RETURN NULL;
  END IF;
  SELECT MAX(SNO)
    INTO E_POS
    FROM OP_AS_RT_DICT_FIELD
   WHERE INS_TABLE_CODE = UPPER(P_INS_TABLE);
  S_POS := 1;
  WHILE (S_POS <= E_POS) LOOP
    --处理如果不是占位符,则按正常方式去处理
    SELECT COUNT(1)
      INTO CNT
      FROM OP_AS_RT_DICT_FIELD
     WHERE INS_TABLE_CODE = UPPER(P_INS_TABLE)
       AND SNO = S_POS
       AND INS_ENABLE = 1
       AND IS_KEY = 0
       AND FROM_TABLE_CODE <> '#'
       AND IS_SUM = 0;
    IF CNT > 0 THEN
      SELECT FROMSQL || ',' || CASE
               WHEN IS_CALC = 0 THEN
                'T0.' || FROM_FIELD_CODE
               WHEN IS_CALC = 1 AND (FNC_SEG <> ' ' AND LENGTH(FNC_SEG) > 0) THEN
                'SUM(' || FNC_SEG || '(T0.BAL,T0.' || FROM_FIELD_CODE ||
                ',T1.START_AMT,T1.END_AMT,T1.AL_RATE,T1.AL_WAY,' ||
                DECODE(FROM_FIELD_CODE, 'BAL', 1, 0) || ')/100.0)'
               WHEN IS_CALC = 1 AND NOT (FNC_SEG <> ' ' AND LENGTH(FNC_SEG) > 0) THEN
                'SUM( NVL(T1.AL_RATE,100) * T0.' || FROM_FIELD_CODE || '/100.0)'
             END
        INTO FROMSQL
        FROM OP_AS_RT_DICT_FIELD
       WHERE INS_TABLE_CODE = UPPER(P_INS_TABLE)
         AND SNO = S_POS;
      --处理GROUP BY语句
      SELECT COUNT(1)
        INTO CNT
        FROM OP_AS_RT_DICT_FIELD
       WHERE INS_TABLE_CODE = UPPER(P_INS_TABLE)
         AND SNO = S_POS
         AND IS_CALC = 0;
      IF CNT > 0 THEN
        SELECT GROUPSQL || ',T0.' || FROM_FIELD_CODE
          INTO GROUPSQL
          FROM OP_AS_RT_DICT_FIELD
         WHERE INS_TABLE_CODE = UPPER(P_INS_TABLE)
           AND SNO = S_POS
           AND IS_CALC = 0;
      END IF;
    END IF;
    S_POS := S_POS + 1;
  END LOOP;

  --拼FROM语句,如果基础数据表中有历史表的,那么直接取历史表,没有历史表的,那么该表中必有一个指标日期字段,即TAR_DATE
  SELECT COUNT(1)
    INTO CNT
    FROM OP_AS_RT_DICT_TABLE
   WHERE INS_TABLE_CODE = UPPER(P_INS_TABLE)
     AND ENABLE = 1
     AND FROM_IS_HIS = 1;
  IF CNT > 0 THEN
    FROMSQL  := FROMSQL || ',T0.HIS_START_DATE,SUM(T1.AL_RATE)';
    GROUPSQL := GROUPSQL || ',T0.HIS_START_DATE';
    FROMSQL  := FROMSQL || ' FROM ' || UPPER(P_TABLE) || '_HIS T0 JOIN ' ||
                T_ALLOC_TABLE || ' T1 ON T1.RES_ID=' || KEY_FROM;
    FROMSQL  := FROMSQL || STAFF_R_ORG_TABLE;
    FROMSQL  := FROMSQL || 'WHERE  HIS_START_DATE =''' || P_SDAT || '''' ||
                ORG_LEV;
  ELSE
    FROMSQL  := FROMSQL || ',T0.TAR_DATE,SUM(T1.AL_RATE)';
    GROUPSQL := GROUPSQL || ',T0.TAR_DATE';
    FROMSQL  := FROMSQL || ' FROM ' || UPPER(P_TABLE) || ' T0 JOIN ' ||
                T_ALLOC_TABLE || '  T1 ON T1.RES_ID=' || KEY_FROM;
    FROMSQL  := FROMSQL || STAFF_R_ORG_TABLE;
    FROMSQL  := FROMSQL || 'WHERE TAR_DATE = ''' || P_SDAT || '''' ||
                ORG_LEV;
  END IF;
  --处理关联表
  SELECT COUNT(1)
    INTO CNT
    FROM OP_AS_RT_DICT_TABLE
   WHERE INSTR(RE_AD_TABLE, 'AD') > 0
     AND INS_TABLE_CODE = UPPER(P_INS_TABLE)
     AND ENABLE = 1;
  IF CNT > 0 THEN
    SELECT RE_AD_TABLE
      INTO R_AD_TABLE
      FROM OP_AS_RT_DICT_TABLE
     WHERE INSTR(RE_AD_TABLE, 'AD') > 0
       AND INS_TABLE_CODE = UPPER(P_INS_TABLE)
       AND ENABLE = 1;
    SELECT RE_FROM_FIELD
      INTO R_FROM_FIELD
      FROM OP_AS_RT_DICT_TABLE
     WHERE INSTR(RE_AD_TABLE, 'AD') > 0
       AND INS_TABLE_CODE = UPPER(P_INS_TABLE)
       AND ENABLE = 1;
    R_WHERE_SQL := ' AND EXISTS(SELECT 1 FROM ' || R_AD_TABLE ||
                   ' N0 WHERE T0.' || R_FROM_FIELD || '=N0.RES_ID)';
    FROMSQL     := FROMSQL || R_WHERE_SQL;
  END IF;
  FROMSQL := FROMSQL || ' ' || GROUPSQL;
  RETURN FROMSQL;
END;

/

