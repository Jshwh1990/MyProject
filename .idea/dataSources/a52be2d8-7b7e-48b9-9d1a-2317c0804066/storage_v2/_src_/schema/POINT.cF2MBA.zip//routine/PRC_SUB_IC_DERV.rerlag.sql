create PROCEDURE PRC_SUB_IC_DERV
(
	IV_DATE     VARCHAR,
	IV_TRG_CODE VARCHAR,
	OI_RETURN   OUT INTEGER,
	OV_RETMSG   OUT VARCHAR
) IS
	/***************************************************************************
    功能模块：派生指标数据堆积(包括基础同比环比类、派生指标、派生同比环比类指标计算)
    目标表  ：PI_ORG_QTY(机构指标表） PI_CM_QTY（客户指标表）
    过程名  ：prc_sub_ic_derv.prc
    参数    ：@Iv_date 数据日期（yyyymmdd) @iv_trg_code 指标编码 @oi_return 输出参数，为0表示程序功能正常
    程序逻辑：先计算出派生指标的依赖关系再拼接sql语句顺序执行，将数据插入目标表；
    编写人  ：Lihl
    编写日期：2013-3-21
    更新日期：2013-4-9
  ****************************************************************************/
	VV_PROC_NAME  VARCHAR(30) := 'PRC_SUB_IC_DERV';
	VD_DATE       DATE := TO_DATE(IV_DATE, 'yyyymmdd'); --输入日期date型
	VV_TAR_DATE   VARCHAR(1000); --插入到目标表数据日期，根据汇总周期：D-当天，M-当月最后一天,Q Y 同理
	VV_EXEC_SQL   VARCHAR(32767); --最后执行sql
	VV_RULE_ORIG  VARCHAR(2000); --计算规则原始串
	VV_RULE_EXEC  VARCHAR(2000); --计算规则执行串
	VV_COL_DEL    VARCHAR(10) := 'T('''; --规则串中基础指标分隔符T('xxx')
	VV_PAR_DEL    CHAR(2) := 'P('; --规则串中基础指标分隔符T('xxx')
	VI_START_POS  INTEGER; --特殊字符开始位置
	VI_END_POS    INTEGER; --特殊结束开始位置
	VV_SUB_OBJ    VARCHAR(30); --开始到结束位置截取的内容
	VV_TAR_TABLE  VARCHAR(30); --目标表名
	VV_DIM_COL    VARCHAR(30); --维度字段名（manager_no,org_no）
	VC_APPLY_TYPE CHAR(1); --指标考核类型（1-机构；0-人员；2-机构和人员）
	VC_PERIOD     CHAR(1); --汇总周期 D M Q Y
	VV_EXEC_SQL2  VARCHAR(32767); --机构和人员类型计算sql2
	VV_SUM_SQL    VARCHAR(2000); --接拼sql中sum(case when target_code)...部分
	VV_CON_SQL    VARCHAR(2000); --接拼sql中target_code in(...)部分
	VI_IDX_ORDER  INTEGER; --指标在公式中的序号
	VV_PAR_GRP_CD VARCHAR(32); --参数中配置的组编码
	VV_PAR_GRP_TP VARCHAR(20); --参数组类别,0-自定义，1-机构，2-人员
	VV_PAR_ITM_CD VARCHAR(32); --参数中配置中项编码
	VI_SUB_RETURN INTEGER;
	VV_SUFFIX_OBJ VARCHAR(20); --上期或指定日期限定关键字
	VV_SUFFIX_DT  VARCHAR(8); --上期或指定日期限定关键字对应的日期
	VV_TEMP_STR   VARCHAR(2000);
BEGIN
	/*判断是否为同比环比类指标，如果是则调用子过程计算，否则按普通派生指标拼sql计算*/
	IF SUBSTR(IV_TRG_CODE, -2) <> '00' THEN
		PRC_SUB_IC_COMP(IV_DATE, IV_TRG_CODE, VI_SUB_RETURN, OV_RETMSG);
		IF VI_SUB_RETURN <> 0 THEN
			OI_RETURN := VI_SUB_RETURN;
			RETURN;
		END IF;
	ELSE
		PRC_IDX_WRITE_LOG(IV_DATE, IV_TRG_CODE, VV_PROC_NAME, 0, '', ''); --write log
		EXECUTE IMMEDIATE 'Truncate Table pi_tmp_kpi_derv';
		EXECUTE IMMEDIATE 'Truncate Table pi_tmp_kpi_period';
		FOR REC IN (SELECT A.TRG_CODE, B.RULE_RESOLVE
									FROM OP_TRG_QTY_INFO A,
											 (SELECT T.*,
															 ROW_NUMBER() OVER(PARTITION BY T.TRG_ID ORDER BY T.ENABLE_DATE DESC) RNK
													FROM OP_TRG_QTY_BASE T
												 WHERE VD_DATE >= T.ENABLE_DATE) B
								 WHERE A.TRG_ID = B.TRG_ID
									 AND A.STATUS = '1'
									 AND A.DEL_FLAG = '0'
									 AND B.RNK = 1
									 AND A.TRG_TYPE = 'D'
									 AND A.TRG_ATTRIBUTE = '00'
									 AND A.TRG_CODE = IV_TRG_CODE)
		LOOP
			VV_RULE_ORIG := REC.RULE_RESOLVE;
			WHILE LENGTH(VV_RULE_ORIG) > 0
			LOOP
				IF INSTR(VV_RULE_ORIG, VV_COL_DEL) <= 0 THEN
					EXIT;
				END IF; --T('B000000039000','LASTM') 1 8 18  25
				VI_START_POS := INSTR(VV_RULE_ORIG, VV_COL_DEL);
				VI_END_POS   := INSTR(VV_RULE_ORIG, '''', VI_START_POS + 3);
				VV_SUB_OBJ   := SUBSTR(VV_RULE_ORIG,
															 VI_START_POS + 3,
															 VI_END_POS - VI_START_POS - 3);
				INSERT INTO PI_TMP_KPI_DERV VALUES (REC.TRG_CODE, VV_SUB_OBJ);
				VV_RULE_ORIG := TRIM(SUBSTR(VV_RULE_ORIG, VI_END_POS + 1));
				/*判断指标是否为上期或指定日期指标T('D000000034100')[LASTD][,LASTM,LASTQ,LASTH,LASTY,20130720]*/
				--modify by lihailiang on 2013-8-1
				IF SUBSTR(TRIM(VV_RULE_ORIG), 1, 1) = ',' THEN
					VI_END_POS    := INSTR(VV_RULE_ORIG, '''', 1, 2);
					VV_SUFFIX_OBJ := TRIM(SUBSTR(VV_RULE_ORIG, 3, VI_END_POS - 3));
					IF VV_SUFFIX_OBJ = 'LASTD' THEN
						VV_SUFFIX_DT := TO_CHAR(VD_DATE - 1, 'yyyymmdd');
					ELSIF VV_SUFFIX_OBJ = 'LASTM' THEN
						VV_SUFFIX_DT := TO_CHAR(TRUNC(VD_DATE, 'mm') - 1, 'yyyymmdd');
					ELSIF VV_SUFFIX_OBJ = 'LASTQ' THEN
						VV_SUFFIX_DT := TO_CHAR(TRUNC(VD_DATE, 'Q') - 1, 'yyyymmdd');
					ELSIF VV_SUFFIX_OBJ = 'LASTH' THEN
						VV_SUFFIX_DT := CASE
															WHEN TO_CHAR(VD_DATE, 'mm') >= 7 THEN
															 TO_CHAR(VD_DATE, 'yyyy') || '0630'
															ELSE
															 TO_CHAR(TRUNC(VD_DATE, 'yyyy') - 1, 'yyyymmdd')
														END;
					ELSIF VV_SUFFIX_OBJ = 'LASTY' THEN
						VV_SUFFIX_DT := TO_CHAR(TRUNC(VD_DATE, 'yyyy') - 1, 'yyyymmdd');
					ELSE
						VV_SUFFIX_DT := TO_CHAR(TO_DATE(VV_SUFFIX_OBJ, 'yyyymmdd'), 'yyyymmdd');
					END IF;
				ELSE
					SELECT NVL(PERIOD, 'D')
						INTO VC_PERIOD
						FROM OP_TRG_QTY_INFO
					 WHERE TRG_CODE = VV_SUB_OBJ;
					IF VC_PERIOD = 'D' THEN
						VV_SUFFIX_DT := IV_DATE;
					ELSIF VC_PERIOD = 'M' THEN
						VV_SUFFIX_DT := TO_CHAR(LAST_DAY(VD_DATE), 'yyyymmdd'); --本月最后一天
					ELSIF VC_PERIOD = 'Q' THEN
						VV_SUFFIX_DT := TO_CHAR(ADD_MONTHS(TRUNC(VD_DATE, 'Q'), 3) - 1,
																		'yyyymmdd'); --本季最后一天
					ELSIF VC_PERIOD = 'Y' THEN
						VV_SUFFIX_DT := TO_CHAR(ADD_MONTHS(TRUNC(VD_DATE, 'yyyy'), 12) - 1,
																		'yyyymmdd'); --本年最后一天
					ELSE
						VV_SUFFIX_DT := IV_DATE;
					END IF;
				END IF;
				--插入临时表记录该指标数据日期
				INSERT INTO PI_TMP_KPI_PERIOD
					SELECT *
						FROM (SELECT VV_SUB_OBJ BASE_CODE, VV_SUFFIX_DT BASE_DATE FROM DUAL) A
					 WHERE NOT EXISTS (SELECT 1
										FROM PI_TMP_KPI_PERIOD B
									 WHERE A.BASE_CODE = B.TRG_CODE
										 AND A.BASE_DATE = B.PERIOD);
			END LOOP;
		END LOOP;
		--考核类型和规则
		SELECT A.APPLY_TYPE, B.RULE_RESOLVE
			INTO VC_APPLY_TYPE, VV_RULE_EXEC
			FROM OP_TRG_QTY_INFO A,
					 (SELECT T.*,
									 ROW_NUMBER() OVER(PARTITION BY T.TRG_ID ORDER BY T.ENABLE_DATE DESC) RNK
							FROM OP_TRG_QTY_BASE T
						 WHERE VD_DATE >= T.ENABLE_DATE) B
		 WHERE A.TRG_CODE = IV_TRG_CODE
			 AND A.TRG_ID = B.TRG_ID
			 AND B.RNK = 1;
		/*    Begin
      Select period
        Into vc_period
        From pi_tmp_kpi_period
       Where trg_code = (Select Min(base_code)
                           From pi_tmp_kpi_derv
                          Where derv_code = iv_trg_code);
    Exception
      When no_Data_found Then
        vc_period := 'D';
    End;
    --纪录汇总周期
    Merge Into pi_tmp_kpi_period a
    Using (Select iv_trg_code derv_code, vc_period period From dual) b
    On (a.trg_code = b.derv_code)
    When Matched Then
      Update Set period = b.period
    When Not Matched Then
      Insert Values (b.derv_code, b.period);*/
		/*初始化变量*/
		VV_EXEC_SQL  := '';
		VV_SUM_SQL   := '';
		VV_CON_SQL   := '';
		VV_TAR_DATE  := '';
		VV_RULE_ORIG := VV_RULE_EXEC;
		--vv_rule_exec := '';
		IF VC_APPLY_TYPE IN ('0', '2') THEN
			VV_TAR_TABLE := 'pi_cm_qty';
			VV_DIM_COL   := 'manager_no';

		ELSIF VC_APPLY_TYPE = '1' THEN
			VV_TAR_TABLE := 'pi_org_qty';
			VV_DIM_COL   := 'org_no';
		END IF;
		/*根据数据汇总周期清理目标表数据*/
		/*    If vc_period = 'D' Then
      vv_tar_date := iv_date;
    Elsif vc_period = 'M' Then
      vv_tar_date := to_char(last_day(vd_date), 'yyyymmdd'); --本月最后一天
    Elsif vc_period = 'Q' Then
      vv_tar_date := to_char(add_months(trunc(vd_date, 'Q'), 3) - 1, 'yyyymmdd'); --本季最后一天
    Elsif vc_period = 'Y' Then
      vv_tar_date := to_char(add_months(trunc(vd_date, 'yyyy'), 12) - 1, 'yyyymmdd'); --本年最后一天
    Else
      vv_tar_date := iv_date;
    End If;*/
		EXECUTE IMMEDIATE 'Delete from ' || VV_TAR_TABLE || ' where target_date = ''' ||
											IV_DATE || ''' and target_code=''' || IV_TRG_CODE || '''';
		/**************************************
        开始拼接执行sql:
    Insert Into target
    Select manager_no,
           area_no,
           target_date,
           'ZZZ',
           nvl(idx_value_1,0) / (case when nvl(idx_value_2,0)=0 then null else idx_value_2 end),
           trunc(Sysdate, 'yyyymmdd')
      From (select manager_no,area_no,
            sum(case when target_code='XXX' then target_value end) idx_value_1,
            sum(case when target_code='YYY' then target_value end) idx_value_2
            from target
            where target_date='20130415' And target_code in('XXX','YYY')
            group by manager_no,area_no)
      ***************************************/
		/*替换规则串中的参数P('GROUP_CODE1','ITEM_CODE1')*/
		WHILE LENGTH(VV_RULE_ORIG) > 0
		LOOP
			IF INSTR(VV_RULE_ORIG, VV_PAR_DEL) <= 0 THEN
				EXIT;
			END IF;
			VI_START_POS  := INSTR(VV_RULE_ORIG, VV_PAR_DEL);
			VI_END_POS    := INSTR(VV_RULE_ORIG, ''')', VI_START_POS);
			VV_SUB_OBJ    := TRIM(SUBSTR(VV_RULE_ORIG,
																	 VI_START_POS + 3,
																	 VI_END_POS - VI_START_POS - 3));
			VV_PAR_GRP_CD := SUBSTR(VV_SUB_OBJ, 1, INSTR(VV_SUB_OBJ, ''',''') - 1);
			VV_PAR_ITM_CD := SUBSTR(VV_SUB_OBJ, INSTR(VV_SUB_OBJ, ''',''') + 3);
			SELECT G.PARAM_TYPE_CODE
				INTO VV_PAR_GRP_TP
				FROM OP_PAR_GROUP G
			 WHERE G.PARAM_GROUP_CODE = VV_PAR_GRP_CD;
			--自定义参数
			IF VV_PAR_GRP_TP = 0 THEN
				--判断是否被除数
				IF SUBSTR(RTRIM(SUBSTR(VV_RULE_ORIG, 1, VI_START_POS - 1)), -1) = '/' THEN
					VV_RULE_EXEC := REPLACE(VV_RULE_EXEC,
																	VV_PAR_DEL || '''' || VV_SUB_OBJ || ''')', --P('xxxx')
																	'(Case When ' ||
																	TO_CHAR(FNC_GET_IC_PARAM(VV_PAR_GRP_CD,
																													 VV_PAR_ITM_CD,
																													 IV_DATE)) ||
																	'=0 Then Null Else ' ||
																	TO_CHAR(FNC_GET_IC_PARAM(VV_PAR_GRP_CD,
																													 VV_PAR_ITM_CD,
																													 IV_DATE)) || ' End)');
				ELSE
					VV_RULE_EXEC := REPLACE(VV_RULE_EXEC,
																	VV_PAR_DEL || '''' || VV_SUB_OBJ || ''')', --P('xxxx')
																	TO_CHAR(FNC_GET_IC_PARAM(VV_PAR_GRP_CD,
																													 VV_PAR_ITM_CD,
																													 IV_DATE)));
				END IF;
			ELSE
				--判断是否被除数
				IF SUBSTR(RTRIM(SUBSTR(VV_RULE_ORIG, 1, VI_START_POS - 1)), -1) = '/' THEN
					VV_RULE_EXEC := REPLACE(VV_RULE_EXEC,
																	VV_PAR_DEL || '''' || VV_SUB_OBJ || ''')', --P('xxxx')
																	'(Case When fnc_get_ic_param(''' || VV_PAR_GRP_CD ||
																	''',' || VV_DIM_COL || ',''' || IV_DATE ||
																	''')=0 Then Null Else ' || 'fnc_get_ic_param(''' ||
																	VV_PAR_GRP_CD || ''',' || VV_DIM_COL || ',''' ||
																	IV_DATE || ''') End)');
				ELSE
					VV_RULE_EXEC := REPLACE(VV_RULE_EXEC,
																	VV_PAR_DEL || '''' || VV_SUB_OBJ || ''')', --P('xxxx')
																	'fnc_get_ic_param(''' || VV_PAR_GRP_CD || ''',' ||
																	VV_DIM_COL || ',''' || IV_DATE || ''')');
				END IF;
			END IF;
			VV_RULE_ORIG := SUBSTR(VV_RULE_ORIG, VI_END_POS + 1);
		END LOOP;
		/*替换规则内容为规则别名及除数特殊处理*/
		WHILE LENGTH(VV_RULE_EXEC) > 0
		LOOP
			IF INSTR(VV_RULE_EXEC, VV_COL_DEL) <= 0 THEN
				EXIT;
			END IF;
			VI_START_POS := INSTR(VV_RULE_EXEC, VV_COL_DEL);
			VI_END_POS   := INSTR(VV_RULE_EXEC, '''', VI_START_POS + 3);
			VV_SUB_OBJ   := SUBSTR(VV_RULE_EXEC,
														 VI_START_POS + 3,
														 VI_END_POS - VI_START_POS - 3);
			/*判断指标是否为上期或指定日期指标T('D000000034100')[LASTD][,LASTM,LASTQ,LASTH,LASTY,20130720]*/
			VV_TEMP_STR := TRIM(SUBSTR(VV_RULE_EXEC, VI_END_POS + 1));
			VI_END_POS  := 0;
			IF SUBSTR(TRIM(VV_TEMP_STR), 1, 1) = ',' THEN
				VI_END_POS    := INSTR(VV_TEMP_STR, '''', 1, 2);
				VV_SUFFIX_OBJ := TRIM(SUBSTR(VV_TEMP_STR, 3, VI_END_POS - 3));
				IF VV_SUFFIX_OBJ = 'LASTD' THEN
					VV_SUFFIX_DT := TO_CHAR(VD_DATE - 1, 'yyyymmdd');
				ELSIF VV_SUFFIX_OBJ = 'LASTM' THEN
					VV_SUFFIX_DT := TO_CHAR(TRUNC(VD_DATE, 'mm') - 1, 'yyyymmdd');
				ELSIF VV_SUFFIX_OBJ = 'LASTQ' THEN
					VV_SUFFIX_DT := TO_CHAR(TRUNC(VD_DATE, 'Q') - 1, 'yyyymmdd');
				ELSIF VV_SUFFIX_OBJ = 'LASTH' THEN
					VV_SUFFIX_DT := CASE
														WHEN TO_CHAR(VD_DATE, 'mm') >= 7 THEN
														 TO_CHAR(VD_DATE, 'yyyy') || '0630'
														ELSE
														 TO_CHAR(TRUNC(VD_DATE, 'yyyy') - 1, 'yyyymmdd')
													END;
				ELSIF VV_SUFFIX_OBJ = 'LASTY' THEN
					VV_SUFFIX_DT := TO_CHAR(TRUNC(VD_DATE, 'yyyy') - 1, 'yyyymmdd');
				ELSE
					VV_SUFFIX_DT := TO_CHAR(TO_DATE(VV_SUFFIX_OBJ, 'yyyymmdd'), 'yyyymmdd');
				END IF;
			ELSE
				SELECT NVL(PERIOD, 'D')
					INTO VC_PERIOD
					FROM OP_TRG_QTY_INFO
				 WHERE TRG_CODE = VV_SUB_OBJ;
				IF VC_PERIOD = 'D' THEN
					VV_SUFFIX_DT := IV_DATE;
				ELSIF VC_PERIOD = 'M' THEN
					VV_SUFFIX_DT := TO_CHAR(LAST_DAY(VD_DATE), 'yyyymmdd'); --本月最后一天
				ELSIF VC_PERIOD = 'Q' THEN
					VV_SUFFIX_DT := TO_CHAR(ADD_MONTHS(TRUNC(VD_DATE, 'Q'), 3) - 1, 'yyyymmdd'); --本季最后一天
				ELSIF VC_PERIOD = 'Y' THEN
					VV_SUFFIX_DT := TO_CHAR(ADD_MONTHS(TRUNC(VD_DATE, 'yyyy'), 12) - 1,
																	'yyyymmdd'); --本年最后一天
				ELSE
					VV_SUFFIX_DT := IV_DATE;
				END IF;
			END IF;
			SELECT ORDER_ID
				INTO VI_IDX_ORDER
				FROM (SELECT T.*, ROWNUM ORDER_ID
								FROM (SELECT TRG_CODE, PERIOD
												FROM PI_TMP_KPI_PERIOD
											 ORDER BY TRG_CODE, PERIOD) T)
			 WHERE TRG_CODE = VV_SUB_OBJ
				 AND PERIOD = VV_SUFFIX_DT;
			--判断是否被除数
			IF SUBSTR(RTRIM(SUBSTR(VV_RULE_EXEC, 1, VI_START_POS - 1)), -1) = '/' THEN
				VV_RULE_EXEC := SUBSTR(VV_RULE_EXEC, 1, VI_START_POS - 1) ||
												'(Case When Nvl(idx_value_' || VI_IDX_ORDER ||
												',0)=0 Then Null Else idx_value_' || VI_IDX_ORDER || ' End)' ||
												SUBSTR(VV_TEMP_STR, VI_END_POS + 2);
			ELSE
				VV_RULE_EXEC := SUBSTR(VV_RULE_EXEC, 1, VI_START_POS - 1) ||
												'Nvl(idx_value_' || VI_IDX_ORDER || ',0)' ||
												SUBSTR(VV_TEMP_STR, VI_END_POS + 2);
			END IF;
		END LOOP;
		/*生成sum部分及条件中拼接部分*/
		FOR REC IN (SELECT T.*, ROWNUM ORDER_ID
									FROM (SELECT TRG_CODE, PERIOD
													FROM PI_TMP_KPI_PERIOD
												 ORDER BY TRG_CODE, PERIOD) T)
		LOOP

			VV_SUM_SQL := VV_SUM_SQL || 'Sum(Case When target_code=''' || REC.TRG_CODE ||
										''' And target_date = ''' || REC.PERIOD ||
										''' Then target_value End) idx_value_' || REC.ORDER_ID || ',';
		END LOOP;
		/*生成指标条件列表*/
		FOR REC IN (SELECT DISTINCT TRG_CODE FROM PI_TMP_KPI_PERIOD)
		LOOP
			VV_CON_SQL := VV_CON_SQL || '''' || REC.TRG_CODE || ''',';
		END LOOP;
		/*生成日期列表*/
		FOR REC IN (SELECT DISTINCT PERIOD FROM PI_TMP_KPI_PERIOD)
		LOOP
			VV_TAR_DATE := VV_TAR_DATE || '''' || REC.PERIOD || ''',';
		END LOOP;
		--结尾处理
		VV_SUM_SQL  := SUBSTR(VV_SUM_SQL, 1, LENGTH(VV_SUM_SQL) - 1);
		VV_TAR_DATE := '(' || SUBSTR(VV_TAR_DATE, 1, LENGTH(VV_TAR_DATE) - 1) || ')';
		VV_CON_SQL  := 'target_code In (' ||
									 SUBSTR(VV_CON_SQL, 1, LENGTH(VV_CON_SQL) - 1) || ')';
		VV_EXEC_SQL := 'Insert Into ' || VV_TAR_TABLE || ' Select ' || VV_DIM_COL ||
									 ',area_no,''' || IV_DATE || ''',''' || IV_TRG_CODE || ''',' ||
									 VV_RULE_EXEC || ',to_char(sysdate,''yyyymmdd'') From (Select ' ||
									 VV_DIM_COL || ',area_no,' || VV_SUM_SQL || ' From ' ||
									 VV_TAR_TABLE || ' Where target_date in ' || VV_TAR_DATE ||
									 ' And ' || VV_CON_SQL || ' Group By ' || VV_DIM_COL ||
									 ',area_no)';
		/*执行sql，将结果写入目标表*/
		EXECUTE IMMEDIATE VV_EXEC_SQL;
		COMMIT;
		IF VC_APPLY_TYPE = '2' THEN
			VV_EXEC_SQL2 := REPLACE(VV_EXEC_SQL, 'manager_no', 'org_no');
			VV_EXEC_SQL2 := REPLACE(VV_EXEC_SQL2, 'pi_cm_qty', 'pi_org_qty');
			EXECUTE IMMEDIATE 'Delete from pi_org_qty where target_date = ''' || IV_DATE ||
												''' and target_code=''' || IV_TRG_CODE || '''';
			EXECUTE IMMEDIATE VV_EXEC_SQL2;
			COMMIT;
			PRC_IDX_WRITE_LOG(IV_DATE,
												IV_TRG_CODE,
												VV_PROC_NAME,
												1,
												'',
												VV_EXEC_SQL || ';' || VV_EXEC_SQL2); --wirte log
		ELSE
			PRC_IDX_WRITE_LOG(IV_DATE, IV_TRG_CODE, VV_PROC_NAME, 1, '', VV_EXEC_SQL); --write log
		END IF;
	END IF;
	COMMIT;
	OI_RETURN := 0;
	OV_RETMSG := '完成';
EXCEPTION
	WHEN OTHERS THEN
		OI_RETURN := SQLCODE;
		OV_RETMSG := SUBSTR(SQLERRM, 1, 200);
		PRC_IDX_WRITE_LOG(IV_DATE,
											IV_TRG_CODE,
											VV_PROC_NAME,
											-1,
											SUBSTR(SQLERRM, 1, 200),
											VV_EXEC_SQL || ';' || VV_EXEC_SQL2); --wirte log
		ROLLBACK;
END;

/

