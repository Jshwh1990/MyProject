create PROCEDURE PRC_SAL_COUNT
(
	S_DATE  VARCHAR,
	E_DATE  VARCHAR,
	RETCODE OUT INT,
	RETMSG  OUT VARCHAR
)
/* 过程、函数简要描述信息
  **********************************************************
  *  存储过程名:  机构和人员薪酬计算
  *  建立日期  :  2015-01-17
  *  作者      :  zhouxb
  *  模块      :  绩效考核管理
  *  功能描述  :
  *  输入参数  ：
  *  输出参数  ： RETCODE 0为正确1为错误， RETMSG错误信息
  *  来源表    ： sys_organization 机构表
  *   备注     ：存储过程名 PRC_SAL_COUNT
  *------------------------------------------------------------
  *  修改历史
  *  序号    日期      修改人      修改原因
  ************************************************************ */
 IS
	FLOW_ID      VARCHAR2(32);
	STEP_ID      VARCHAR2(30);
	RECORD_TIME  TIMESTAMP;
	V_WORK_DATE  VARCHAR2(8);
	TO_WORK_DATE DATE;
	S0           NUMBER(20, 2);
	S3           NUMBER(20, 2);
	S12          NUMBER(20, 2);
	S_NE         NUMBER(20, 2);
	P_SAL_ID     VARCHAR2(32);
	P_SEG_CODE   VARCHAR2(30);
	P_EMP_NO     VARCHAR2(32);
	P_ORG_ID     VARCHAR2(32);

	CURSOR SAL_P_CUR IS
		SELECT I0.SAL_ID, I0.SEG_CODE, I0.EMP_NO, I0.SAL S0, I3.SAL S3, I12.SAL S12
			FROM (SELECT * FROM SAL_CM WHERE TARGET_CODE = 'D000016392500') I0,
					 (SELECT * FROM SAL_CM WHERE TARGET_CODE = 'D000016392600') I3,
					 (SELECT * FROM SAL_CM WHERE TARGET_CODE = 'D000016392700') I12
		 WHERE I0.EMP_NO = I3.EMP_NO
			 AND I0.EMP_NO = I12.EMP_NO;
	CURSOR SAL_O_CUR IS
		SELECT I0.SAL_ID, I0.SEG_CODE, I0.ORG_ID, I0.SAL S0, I3.SAL S3, I12.SAL S12
			FROM (SELECT * FROM SAL_ORG WHERE TARGET_CODE = 'D000016392500') I0,
					 (SELECT * FROM SAL_ORG WHERE TARGET_CODE = 'D000016392600') I3,
					 (SELECT * FROM SAL_ORG WHERE TARGET_CODE = 'D000016392700') I12
		 WHERE I0.ORG_ID = I3.ORG_ID
			 AND I0.ORG_ID = I12.ORG_ID
			 AND EXISTS (SELECT 1
							FROM SAL_SCHEME_NEW A, MO_PT_ORG B
						 WHERE A.SONORG_WAY_ID = B.WAY_ID
							 AND B.ORG_ID = I0.ORG_ID);

BEGIN
	SELECT WORK_DATE INTO V_WORK_DATE FROM SYS_PARA_DATE_NEW;
	TO_WORK_DATE := TO_DATE(V_WORK_DATE, 'yyyymmdd');

	FLOW_ID     := FNC_GEN_FLOW_ID();
	STEP_ID     := 'ZXB_30_SAL_CNT';
	RECORD_TIME := SYSDATE;
	--**************************************************************************************************
	--支行特殊薪酬计算**********************************************************************************
	--************************************做支行特殊薪酬分段等关联值************************************
	EXECUTE IMMEDIATE 'truncate table FORPRC_SAL_WAY_CYC';
	COMMIT;
	INSERT INTO FORPRC_SAL_WAY_CYC
		(SAL_ID,
		 SAL_CYC,
		 SEG_CODE,
		 CM_WAY_ID,
		 ORG_WAY_ID,
		 SONORG_WAY_ID,
		 SAL_PER,
		 CHG_PER)
		SELECT A.SAL_ID,
					 CASE
						 WHEN B.SEG_CODE IS NULL THEN
							A.SAL_CYC
						 ELSE
							B.CYC_CODE
					 END SAL_CYC,
					 B.SEG_CODE,
					 A.CM_WAY_ID,
					 A.ORG_WAY_ID,
					 A.SONORG_WAY_ID,
					 CASE
						 WHEN B.SEG_CODE LIKE '%Q1' THEN
							1 / 4
						 WHEN B.SEG_CODE LIKE '%Q2' THEN
							2 / 4
						 WHEN B.SEG_CODE LIKE '%Q3' THEN
							3 / 4
						 WHEN B.SEG_CODE LIKE '%HF1' THEN
							1 / 2
						 WHEN B.SEG_CODE LIKE '%M1' THEN
							1 / 12
						 WHEN B.SEG_CODE LIKE '%M2' THEN
							2 / 12
						 WHEN B.SEG_CODE LIKE '%M3' THEN
							3 / 12
						 WHEN B.SEG_CODE LIKE '%M4' THEN
							4 / 12
						 WHEN B.SEG_CODE LIKE '%M5' THEN
							5 / 12
						 WHEN B.SEG_CODE LIKE '%M6' THEN
							6 / 12
						 WHEN B.SEG_CODE LIKE '%M7' THEN
							7 / 12
						 WHEN B.SEG_CODE LIKE '%M8' THEN
							8 / 12
						 WHEN B.SEG_CODE LIKE '%M9' THEN
							9 / 12
						 WHEN B.SEG_CODE LIKE '%M10' THEN
							10 / 12
						 WHEN B.SEG_CODE LIKE '%M11' THEN
							11 / 12
						 ELSE
							1
					 END SAL_PER,
					 NVL(CHG_PER, 1) CHG_PER
			FROM SAL_SCHEME_NEW A
			LEFT JOIN SAL_SCHEME_SEG_NEW B
				ON A.SAL_ID = B.SAL_ID
		 WHERE (NVL(B.END_DAT, A.END_DAT) >= TO_WORK_DATE AND
					 NVL(B.START_DAT, A.START_DAT) <= TO_WORK_DATE)
			 AND A.SCHEME_TYPE = 'branch';
	COMMIT;
	--***************************计算一级机构下属二级机构和员工的完成值************************************
	EXECUTE IMMEDIATE 'truncate table FORPRC_SAL_2ORG_EMP_SUM';
	COMMIT;
	INSERT INTO FORPRC_SAL_2ORG_EMP_SUM
		(SAL_ID, --薪酬方案ID
		 SEG_CODE, --薪酬阶段
		 ORG_ID,
		 TARGET_CODE, --指标代码
		 PT_VALUE,
		 FS_VALUE,
		 CALC_SCORE,
		 SUM_C_SCORE,
		 SUM_O2_SCORE)
		SELECT E.SAL_ID, --薪酬方案ID
					 E.SEG_CODE, --薪酬阶段
					 ET.ORG_ID,
					 ET.TARGET_CODE, --指标代码
					 NVL(ET.PT_VALUE, 0),
					 NVL(ET.FS_VALUE, 0),
					 NVL(EC.CALC_SCORE, 0),
					 PC.CALC_SCORE,
					 EC2.CALC_SCORE
			FROM FORPRC_SAL_WAY_CYC E
			LEFT JOIN MO_PT_ORG ET
				ON E.ORG_WAY_ID = ET.WAY_ID
			 AND E.SEG_CODE = ET.SEG_CODE --一级机构目标
			LEFT JOIN MO_EWM_ORG_DT EC
				ON E.ORG_WAY_ID = EC.WAY_ID
			 AND NVL(E.SEG_CODE, ' ') = EC.SEG_CODE
			 AND ET.TARGET_CODE = EC.TARGET_CODE
			 AND ET.ORG_ID = EC.ORG_ID --一级机构得分
			LEFT JOIN (SELECT EC2.WAY_ID,
												EC2.SEG_CODE,
												EC2.TARGET_CODE,
												O2.PARENT_ORG_NO ORG_ID,
												SUM(EC2.CALC_SCORE) CALC_SCORE
									 FROM SYS_ORGANIZATION O2, MO_EWM_ORG_DT EC2
									WHERE O2.ORG_NO = EC2.ORG_ID
									GROUP BY EC2.WAY_ID,
													 EC2.SEG_CODE,
													 EC2.TARGET_CODE,
													 O2.PARENT_ORG_NO) EC2
				ON E.SONORG_WAY_ID = EC2.WAY_ID
			 AND E.SEG_CODE = EC2.SEG_CODE
			 AND ET.TARGET_CODE = EC2.TARGET_CODE
			 AND ET.ORG_ID = EC2.ORG_ID --取二级机构得分
			LEFT JOIN (SELECT PC.WAY_ID,
												PC.SEG_CODE,
												PC.TARGET_CODE,
												O.ORG_NO,
												SUM(PC.CALC_SCORE) CALC_SCORE
									 FROM SYS_EMPLOYEE O, MO_EWM_CM_DT PC
									WHERE O.EMP_NO = PC.STAFF_ID
									GROUP BY PC.WAY_ID, PC.SEG_CODE, PC.TARGET_CODE, O.ORG_NO) PC
				ON E.CM_WAY_ID = PC.WAY_ID
			 AND NVL(E.SEG_CODE, ' ') = PC.SEG_CODE
			 AND ET.TARGET_CODE = PC.TARGET_CODE
			 AND ET.ORG_ID = PC.ORG_NO --个人得分
		;
	COMMIT;
	--*************************************一级机构计算*****************************************************
	/*清空目标表的数据*/
	DELETE FROM SAL_ORG A
	 WHERE EXISTS (SELECT 1
						FROM SAL_SCHEME_NEW B
					 WHERE A.SAL_ID = B.SAL_ID
						 AND B.END_DAT >= TO_WORK_DATE
						 AND B.START_DAT <= TO_WORK_DATE);
	COMMIT;
	--加载数据
	INSERT INTO SAL_ORG
		(SAL_ID, --薪酬方案ID
		 SAL_CYC, --薪酬周期
		 SEG_CODE, --薪酬阶段
		 ORG_ID, --机构号
		 TARGET_CODE, --指标代码
		 PT_VALUE, --任务值
		 FS_VALUE, --完成值
		 FS_PER, --完成率
		 SCORE, --得分
		 SAL, --薪酬
		 RANK_ID --薪酬排名
		 )
		SELECT E.SAL_ID, --薪酬方案ID
					 E.SAL_CYC, --薪酬周期
					 E.SEG_CODE, --薪酬阶段
					 C.ORG_ID, --机构号
					 C.TARGET_CODE, --指标代码
					 C.PT_VALUE, --任务值
					 C.FS_VALUE, --完成值
					 CASE
						 WHEN NVL(C.PT_VALUE, 0) = 0 THEN
							0
						 ELSE
							100 * C.FS_VALUE / C.PT_VALUE
					 END, --完成率
					 D.CALC_SCORE, --得分
					 E.CHG_PER * E.SAL_PER * (CASE
						 WHEN (T.TRG_NAME NOT LIKE '%直营%' AND T.TRG_NAME NOT LIKE '%小微%') THEN
							NVL(ORG.SUM_C_SCORE, 0) + NVL(ORG.SUM_O2_SCORE, 0)
						 ELSE
							D.CALC_SCORE
					 END) SAL, --薪酬
					 RANK() OVER(PARTITION BY E.SAL_ID, E.SAL_CYC, E.SEG_CODE, C.TARGET_CODE ORDER BY E.CHG_PER * E.SAL_PER * (CASE
						 WHEN (T.TRG_NAME NOT LIKE
									'%直营%' AND
									T.TRG_NAME NOT LIKE
									'%小微%') THEN
							ORG.SUM_C_SCORE +
							ORG.SUM_O2_SCORE
						 ELSE
							D.CALC_SCORE
					 END) DESC) RANK_ID
			FROM FORPRC_SAL_WAY_CYC E
			LEFT JOIN MO_PT_ORG C
				ON E.ORG_WAY_ID = C.WAY_ID
			 AND E.SEG_CODE = C.SEG_CODE
			LEFT JOIN MO_EWM_ORG_DT D
				ON E.ORG_WAY_ID = D.WAY_ID
			 AND NVL(E.SEG_CODE, ' ') = D.SEG_CODE
			 AND C.TARGET_CODE = D.TARGET_CODE
			 AND C.ORG_ID = D.ORG_ID
			LEFT JOIN OP_TRG_QTY_INFO T
				ON C.TARGET_CODE = T.TRG_CODE
			LEFT JOIN FORPRC_SAL_2ORG_EMP_SUM ORG
				ON E.SAL_ID = ORG.SAL_ID
			 AND E.SEG_CODE = ORG.SEG_CODE
			 AND C.ORG_ID = ORG.ORG_ID
			 AND C.TARGET_CODE = ORG.TARGET_CODE
		 WHERE C.ORG_ID IS NOT NULL;
	COMMIT;
	--*************************************二级机构计算*****************************************
	INSERT INTO SAL_ORG
		(SAL_ID, --薪酬方案ID
		 SAL_CYC, --薪酬周期
		 SEG_CODE, --薪酬阶段
		 ORG_ID, --机构号
		 TARGET_CODE, --指标代码
		 PT_VALUE, --任务值
		 FS_VALUE, --完成值
		 FS_PER, --完成率
		 SCORE, --得分
		 SAL, --薪酬
		 RANK_ID --薪酬排名
		 )
		SELECT SAL_ID,
					 SAL_CYC,
					 SEG_CODE,
					 ORG_ID,
					 TARGET_CODE,
					 PT_VALUE,
					 FS_VALUE,
					 FS_PER,
					 CALC_SCORE,
					 SAL,
					 RANK() OVER(PARTITION BY SAL_ID, SAL_CYC, SEG_CODE, TARGET_CODE ORDER BY SAL DESC) RANK_ID
			FROM (SELECT E.SAL_ID, --薪酬方案ID
									 E.SAL_CYC, --薪酬周期
									 E.SEG_CODE, --薪酬阶段
									 PT.ORG_ID ORG_ID, --二级机构号
									 PT.TARGET_CODE, --指标代码
									 PT.PT_VALUE, --任务值
									 PT.FS_VALUE, --完成值
									 CASE
										 WHEN NVL(PT.PT_VALUE, 0) = 0 THEN
											0
										 ELSE
											100 * PT.FS_VALUE / PT.PT_VALUE
									 END FS_PER, --完成率
									 PC.CALC_SCORE, --得分
									 E.CHG_PER * E.SAL_PER * (CASE
										 WHEN (T.TRG_NAME LIKE '%小微%' OR T.TRG_NAME LIKE '%直营%')
													AND NVL(ORG.FS_VALUE, 0) >= NVL(ORG.PT_VALUE, 0)
													AND (NVL(SUM_C_SCORE, 0) + NVL(SUM_O2_SCORE, 0)) <> 0 THEN
											ORG.CALC_SCORE * PC.CALC_SCORE /
											(NVL(SUM_C_SCORE, 0) + NVL(SUM_O2_SCORE, 0))
										 WHEN (T.TRG_NAME NOT LIKE '%直营%' AND T.TRG_NAME NOT LIKE '%小微%') THEN
											PC.CALC_SCORE
										 ELSE
											0
									 END) SAL --薪酬
							FROM FORPRC_SAL_WAY_CYC E
							LEFT JOIN MO_PT_ORG PT
								ON E.SONORG_WAY_ID = PT.WAY_ID
							 AND E.SEG_CODE = PT.SEG_CODE --目标
							LEFT JOIN MO_EWM_ORG_DT PC
								ON E.SONORG_WAY_ID = PC.WAY_ID
							 AND NVL(E.SEG_CODE, ' ') = PC.SEG_CODE
							 AND PT.TARGET_CODE = PC.TARGET_CODE
							 AND PT.ORG_ID = PC.ORG_ID --得分
							LEFT JOIN SYS_ORGANIZATION O
								ON PT.ORG_ID = O.ORG_NO --关联机构表取对应机构号
							LEFT JOIN OP_TRG_QTY_INFO T
								ON PC.TARGET_CODE = T.TRG_CODE
							LEFT JOIN FORPRC_SAL_2ORG_EMP_SUM ORG
								ON E.SAL_ID = ORG.SAL_ID
							 AND E.SEG_CODE = ORG.SEG_CODE
							 AND O.PARENT_ORG_NO = ORG.ORG_ID
							 AND PT.TARGET_CODE = ORG.TARGET_CODE
						 WHERE PT.ORG_ID IS NOT NULL) AL;
	COMMIT;
	--*************************************人员计算*****************************************************
	/*清空目标表的数据*/
	DELETE FROM SAL_CM A
	 WHERE EXISTS (SELECT 1
						FROM SAL_SCHEME_NEW B
					 WHERE A.SAL_ID = B.SAL_ID
						 AND B.END_DAT >= TO_WORK_DATE
						 AND B.START_DAT <= TO_WORK_DATE);
	COMMIT;
	--加载数据
	INSERT INTO SAL_CM
		(SAL_ID, --薪酬方案ID
		 SAL_CYC, --薪酬周期
		 SEG_CODE, --薪酬阶段
		 EMP_NO, --员工号
		 TARGET_CODE, --指标代码
		 PT_VALUE, --任务值
		 FS_VALUE, --完成值
		 FS_PER, --完成率
		 SCORE, --得分
		 SAL, --薪酬
		 RANK_ID --薪酬排名
		 )
		SELECT SAL_ID,
					 SAL_CYC,
					 SEG_CODE,
					 EMP_NO,
					 TARGET_CODE,
					 PT_VALUE,
					 FS_VALUE,
					 FS_PER,
					 CALC_SCORE,
					 SAL,
					 RANK() OVER(PARTITION BY SAL_ID, SAL_CYC, SEG_CODE, TARGET_CODE ORDER BY SAL DESC) RANK_ID
			FROM (SELECT E.SAL_ID, --薪酬方案ID
									 E.SAL_CYC, --薪酬周期
									 E.SEG_CODE, --薪酬阶段
									 PT.PT_SCOPE_ID EMP_NO, --员工号
									 PT.TARGET_CODE, --指标代码
									 PT.PT_VALUE, --任务值
									 PT.FS_VALUE, --完成值
									 CASE
										 WHEN NVL(PT.PT_VALUE, 0) = 0 THEN
											0
										 ELSE
											100 * PT.FS_VALUE / PT.PT_VALUE
									 END FS_PER, --完成率
									 PC.CALC_SCORE, --得分
									 E.CHG_PER * E.SAL_PER * (CASE
										 WHEN (T.TRG_NAME LIKE '%小微%' OR T.TRG_NAME LIKE '%直营%')
													AND NVL(ORG.FS_VALUE, 0) >= NVL(ORG.PT_VALUE, 0)
													AND (NVL(SUM_C_SCORE, 0) + NVL(SUM_O2_SCORE, 0)) <> 0 THEN
											ORG.CALC_SCORE * PC.CALC_SCORE /
											(NVL(SUM_C_SCORE, 0) + NVL(SUM_O2_SCORE, 0))
										 WHEN (T.TRG_NAME NOT LIKE '%直营%' AND T.TRG_NAME NOT LIKE '%小微%') THEN
											PC.CALC_SCORE
										 ELSE
											0
									 END) SAL --薪酬
							FROM FORPRC_SAL_WAY_CYC E
							LEFT JOIN MO_PT_CM PT
								ON E.CM_WAY_ID = PT.WAY_ID
							 AND E.SEG_CODE = PT.SEG_CODE --个人目标
							LEFT JOIN MO_EWM_CM_DT PC
								ON E.CM_WAY_ID = PC.WAY_ID
							 AND NVL(E.SEG_CODE, ' ') = PC.SEG_CODE
							 AND PT.TARGET_CODE = PC.TARGET_CODE
							 AND PT.PT_SCOPE_ID = PC.STAFF_ID --个人得分
							LEFT JOIN SYS_EMPLOYEE O
								ON PT.PT_SCOPE_ID = O.EMP_NO --关联机构表取对应机构号
							LEFT JOIN OP_TRG_QTY_INFO T
								ON PC.TARGET_CODE = T.TRG_CODE
							LEFT JOIN FORPRC_SAL_2ORG_EMP_SUM ORG
								ON E.SAL_ID = ORG.SAL_ID
							 AND E.SEG_CODE = ORG.SEG_CODE
							 AND O.ORG_NO = ORG.ORG_ID
							 AND PT.TARGET_CODE = ORG.TARGET_CODE
						 WHERE PT.PT_SCOPE_ID IS NOT NULL);
	COMMIT;

	--**************************************************************************************************
	--机构标准、奖励基本薪酬薪酬计算**************************************************************************
	INSERT INTO SAL_ORG
		(SAL_ID, --薪酬方案ID
		 SAL_CYC, --薪酬周期
		 SEG_CODE, --薪酬阶段
		 ORG_ID, --机构号
		 TARGET_CODE, --指标代码
		 PT_VALUE, --任务值
		 FS_VALUE, --完成值
		 FS_PER, --完成率
		 SCORE, --得分
		 SAL, --薪酬
		 RANK_ID --薪酬排名
		 )
		SELECT SAL_ID,
					 SAL_CYC,
					 SEG_CODE,
					 ORG_ID,
					 TARGET_CODE,
					 PT_VALUE,
					 FS_VALUE,
					 FS_PER,
					 CALC_SCORE,
					 SAL,
					 RANK() OVER(PARTITION BY SAL_ID, SAL_CYC, SEG_CODE, TARGET_CODE ORDER BY SAL DESC) RANK_ID
			FROM (SELECT E.SAL_ID, --薪酬方案ID
									 E.SAL_CYC, --薪酬周期
									 E.SEG_CODE, --薪酬阶段
									 C.ORG_ID, --机构号
									 C.TARGET_CODE, --指标代码
									 C.PT_VALUE, --任务值
									 C.FS_VALUE, --完成值
									 CASE
										 WHEN NVL(C.PT_VALUE, 0) = 0 THEN
											0
										 ELSE
											100 * C.FS_VALUE / C.PT_VALUE
									 END FS_PER, --完成率
									 D.CALC_SCORE, --得分
									 D.CALC_SCORE * E.CHG_PER SAL --薪资

							FROM (SELECT A.SAL_ID,
													 CASE
														 WHEN B.SEG_CODE IS NULL THEN
															A.SAL_CYC
														 ELSE
															B.CYC_CODE
													 END SAL_CYC,
													 B.SEG_CODE,
													 A.ORG_WAY_ID,
													 CASE
														 WHEN A.SCHEME_TYPE = 'orgbase' THEN
															NVL(A.SCHEME_ARG1, 1) * NVL(A.SCHEME_ARG2, 1) *
															NVL(A.SCHEME_ARG3, 1) * NVL(A.SCHEME_ARG4, 1) *
															NVL(A.SCHEME_ARG5, 1) / 1000
														 ELSE
															NVL(A.SCHEME_ARG1, 1) * NVL(A.SCHEME_ARG2, 1) *
															NVL(A.SCHEME_ARG3, 1) * NVL(A.SCHEME_ARG4, 1) *
															NVL(A.SCHEME_ARG5, 1) * (CASE
																												 WHEN B.SEG_CODE LIKE '%Q1' THEN
																													1 / 4
																												 WHEN B.SEG_CODE LIKE '%Q2' THEN
																													2 / 4
																												 WHEN B.SEG_CODE LIKE '%Q3' THEN
																													3 / 4
																												 WHEN B.SEG_CODE LIKE '%HF1' THEN
																													1 / 2
																												 WHEN B.SEG_CODE LIKE '%M1' THEN
																													1 / 12
																												 WHEN B.SEG_CODE LIKE '%M2' THEN
																													2 / 12
																												 WHEN B.SEG_CODE LIKE '%M3' THEN
																													3 / 12
																												 WHEN B.SEG_CODE LIKE '%M4' THEN
																													4 / 12
																												 WHEN B.SEG_CODE LIKE '%M5' THEN
																													5 / 12
																												 WHEN B.SEG_CODE LIKE '%M6' THEN
																													6 / 12
																												 WHEN B.SEG_CODE LIKE '%M7' THEN
																													7 / 12
																												 WHEN B.SEG_CODE LIKE '%M8' THEN
																													8 / 12
																												 WHEN B.SEG_CODE LIKE '%M9' THEN
																													9 / 12
																												 WHEN B.SEG_CODE LIKE '%M10' THEN
																													10 / 12
																												 WHEN B.SEG_CODE LIKE '%M11' THEN
																													11 / 12
																												 ELSE
																													1
																											 END)
													 END * NVL(A.CHG_PER, 1) CHG_PER
											FROM SAL_SCHEME_NEW A
											LEFT JOIN SAL_SCHEME_SEG_NEW B
												ON A.SAL_ID = B.SAL_ID
										 WHERE (NVL(B.END_DAT, A.END_DAT) >= TO_WORK_DATE AND
													 NVL(B.START_DAT, A.START_DAT) <= TO_WORK_DATE)
											 AND (A.SCHEME_TYPE = 'orgbase' OR A.SCHEME_TYPE = 'orgaward')) E
							LEFT JOIN MO_PT_ORG C
								ON E.ORG_WAY_ID = C.WAY_ID
							 AND E.SEG_CODE = C.SEG_CODE
							LEFT JOIN MO_EWM_ORG_DT D
								ON E.ORG_WAY_ID = D.WAY_ID
							 AND NVL(E.SEG_CODE, ' ') = D.SEG_CODE
							 AND C.TARGET_CODE = D.TARGET_CODE
							 AND C.ORG_ID = D.ORG_ID
						 WHERE C.ORG_ID IS NOT NULL) AL;
	COMMIT;
	--**************************************************************************************************
	--员工标准、奖励基本薪酬薪酬计算**************************************************************************
	INSERT INTO SAL_CM
		(SAL_ID, --薪酬方案ID
		 SAL_CYC, --薪酬周期
		 SEG_CODE, --薪酬阶段
		 EMP_NO, --员工号
		 TARGET_CODE, --指标代码
		 PT_VALUE, --任务值
		 FS_VALUE, --完成值
		 FS_PER, --完成率
		 SCORE, --得分
		 SAL, --薪酬
		 RANK_ID --薪酬排名
		 )
		SELECT SAL_ID,
					 SAL_CYC,
					 SEG_CODE,
					 EMP_NO,
					 TARGET_CODE,
					 PT_VALUE,
					 FS_VALUE,
					 FS_PER,
					 CALC_SCORE,
					 SAL,
					 RANK() OVER(PARTITION BY SAL_ID, SAL_CYC, SEG_CODE, TARGET_CODE ORDER BY SAL DESC) RANK_ID
			FROM (SELECT E.SAL_ID, --薪酬方案ID
									 E.SAL_CYC, --薪酬周期
									 E.SEG_CODE, --薪酬阶段
									 C.PT_SCOPE_ID EMP_NO, --机构号
									 C.TARGET_CODE, --指标代码
									 C.PT_VALUE, --任务值
									 C.FS_VALUE, --完成值
									 CASE
										 WHEN NVL(C.PT_VALUE, 0) = 0 THEN
											0
										 ELSE
											100 * C.FS_VALUE / C.PT_VALUE
									 END FS_PER, --完成率
									 D.CALC_SCORE, --得分
									 D.CALC_SCORE * E.CHG_PER SAL --薪资

							FROM (SELECT A.SAL_ID,
													 CASE
														 WHEN B.SEG_CODE IS NULL THEN
															A.SAL_CYC
														 ELSE
															B.CYC_CODE
													 END SAL_CYC,
													 B.SEG_CODE,
													 A.CM_WAY_ID,
													 CASE
														 WHEN A.SCHEME_TYPE = 'empbase' THEN
															NVL(A.SCHEME_ARG1, 1) * NVL(A.SCHEME_ARG2, 1) *
															NVL(A.SCHEME_ARG3, 1) * NVL(A.SCHEME_ARG4, 1) *
															NVL(A.SCHEME_ARG5, 1) / 1000
														 ELSE
															NVL(A.SCHEME_ARG1, 1) * NVL(A.SCHEME_ARG2, 1) *
															NVL(A.SCHEME_ARG3, 1) * NVL(A.SCHEME_ARG4, 1) *
															NVL(A.SCHEME_ARG5, 1) * (CASE
																												 WHEN B.SEG_CODE LIKE '%Q1' THEN
																													1 / 4
																												 WHEN B.SEG_CODE LIKE '%Q2' THEN
																													2 / 4
																												 WHEN B.SEG_CODE LIKE '%Q3' THEN
																													3 / 4
																												 WHEN B.SEG_CODE LIKE '%HF1' THEN
																													1 / 2
																												 WHEN B.SEG_CODE LIKE '%M1' THEN
																													1 / 12
																												 WHEN B.SEG_CODE LIKE '%M2' THEN
																													2 / 12
																												 WHEN B.SEG_CODE LIKE '%M3' THEN
																													3 / 12
																												 WHEN B.SEG_CODE LIKE '%M4' THEN
																													4 / 12
																												 WHEN B.SEG_CODE LIKE '%M5' THEN
																													5 / 12
																												 WHEN B.SEG_CODE LIKE '%M6' THEN
																													6 / 12
																												 WHEN B.SEG_CODE LIKE '%M7' THEN
																													7 / 12
																												 WHEN B.SEG_CODE LIKE '%M8' THEN
																													8 / 12
																												 WHEN B.SEG_CODE LIKE '%M9' THEN
																													9 / 12
																												 WHEN B.SEG_CODE LIKE '%M10' THEN
																													10 / 12
																												 WHEN B.SEG_CODE LIKE '%M11' THEN
																													11 / 12
																												 ELSE
																													1
																											 END)
													 END * NVL(A.CHG_PER, 1) CHG_PER
											FROM SAL_SCHEME_NEW A
											LEFT JOIN SAL_SCHEME_SEG_NEW B
												ON A.SAL_ID = B.SAL_ID
										 WHERE (NVL(B.END_DAT, A.END_DAT) >= TO_WORK_DATE AND
													 NVL(B.START_DAT, A.START_DAT) <= TO_WORK_DATE)
											 AND (A.SCHEME_TYPE = 'empbase' OR A.SCHEME_TYPE = 'empaward')) E
							LEFT JOIN MO_PT_CM C
								ON E.CM_WAY_ID = C.WAY_ID
							 AND E.SEG_CODE = C.SEG_CODE --个人目标
							LEFT JOIN MO_EWM_CM_DT D
								ON E.CM_WAY_ID = D.WAY_ID
							 AND NVL(E.SEG_CODE, ' ') = D.SEG_CODE
							 AND C.TARGET_CODE = D.TARGET_CODE
							 AND C.PT_SCOPE_ID = D.STAFF_ID --个人得分
						 WHERE C.PT_SCOPE_ID IS NOT NULL) AL;
	COMMIT;

	--********************************活期三月一年期净增指标薪酬调整*************************
	--员工调整
	OPEN SAL_P_CUR;
	LOOP
		FETCH SAL_P_CUR
			INTO P_SAL_ID, P_SEG_CODE, P_EMP_NO, S0, S3, S12;
		EXIT WHEN SAL_P_CUR % NOTFOUND;
		S_NE := 0;
		IF S0 < 0 THEN
			S_NE := S0 + S_NE;
			S0   := 0;
		END IF;
		IF S3 < 0 THEN
			S_NE := S3 + S_NE;
			S3   := 0;
		END IF;
		IF S12 < 0 THEN
			S_NE := S12 + S_NE;
			S12  := 0;
		END IF;

		IF S_NE < 0 THEN
			S0 := S0 + S_NE;
			IF S0 < 0 THEN
				S3 := S3 + S0;
				S0 := 0;
				IF S3 < 0 THEN
					S12 := S12 + S3;
					S3  := 0;
					IF S12 < 0 THEN
						S12 := 0;
					END IF;
				END IF;
			END IF;
		END IF;
		UPDATE SAL_CM A
			 SET SAL = S0
		 WHERE A.SAL_ID = P_SAL_ID
			 AND A.SEG_CODE = P_SEG_CODE
			 AND A.EMP_NO = P_EMP_NO
			 AND A.TARGET_CODE = 'D000016392500';
		COMMIT;
		UPDATE SAL_CM A
			 SET SAL = S3
		 WHERE A.SAL_ID = P_SAL_ID
			 AND A.SEG_CODE = P_SEG_CODE
			 AND A.EMP_NO = P_EMP_NO
			 AND A.TARGET_CODE = 'D000016392600';
		COMMIT;
		UPDATE SAL_CM A
			 SET SAL = S12
		 WHERE A.SAL_ID = P_SAL_ID
			 AND A.SEG_CODE = P_SEG_CODE
			 AND A.EMP_NO = P_EMP_NO
			 AND A.TARGET_CODE = 'D000016392700';
		COMMIT;
	END LOOP;
	CLOSE SAL_P_CUR;
	--二级机构调整
	OPEN SAL_O_CUR;
	LOOP
		FETCH SAL_O_CUR
			INTO P_SAL_ID, P_SEG_CODE, P_ORG_ID, S0, S3, S12;
		EXIT WHEN SAL_O_CUR % NOTFOUND;
		S_NE := 0;
		IF S0 < 0 THEN
			S_NE := S0 + S_NE;
			S0   := 0;
		END IF;
		IF S3 < 0 THEN
			S_NE := S3 + S_NE;
			S3   := 0;
		END IF;
		IF S12 < 0 THEN
			S_NE := S12 + S_NE;
			S12  := 0;
		END IF;

		IF S_NE < 0 THEN
			S0 := S0 + S_NE;
			IF S0 < 0 THEN
				S3 := S3 + S0;
				S0 := 0;
				IF S3 < 0 THEN
					S12 := S12 + S3;
					S3  := 0;
					IF S12 < 0 THEN
						S12 := 0;
					END IF;
				END IF;
			END IF;
		END IF;
		UPDATE SAL_ORG A
			 SET SAL = S0
		 WHERE A.SAL_ID = P_SAL_ID
			 AND A.SEG_CODE = P_SEG_CODE
			 AND A.ORG_ID = P_ORG_ID
			 AND A.TARGET_CODE = 'D000016392500';
		COMMIT;
		UPDATE SAL_ORG A
			 SET SAL = S3
		 WHERE A.SAL_ID = P_SAL_ID
			 AND A.SEG_CODE = P_SEG_CODE
			 AND A.ORG_ID = P_ORG_ID
			 AND A.TARGET_CODE = 'D000016392600';
		COMMIT;
		UPDATE SAL_ORG A
			 SET SAL = S12
		 WHERE A.SAL_ID = P_SAL_ID
			 AND A.SEG_CODE = P_SEG_CODE
			 AND A.ORG_ID = P_ORG_ID
			 AND A.TARGET_CODE = 'D000016392700';
		COMMIT;
	END LOOP;
	CLOSE SAL_O_CUR;
	--一级机构调整
	UPDATE SAL_ORG A
		 SET SAL =
				 (SELECT SUM(NVL(B.SAL, 0))
						FROM SAL_ORG B, SYS_ORGANIZATION C
					 WHERE A.ORG_ID = C.PARENT_ORG_NO
						 AND C.ORG_NO = B.ORG_ID
						 AND A.SAL_ID = B.SAL_ID
						 AND A.SEG_CODE = B.SEG_CODE
						 AND A.TARGET_CODE = B.TARGET_CODE) +
				 (SELECT SUM(NVL(E.SAL, 0))
						FROM SAL_CM E, SYS_EMPLOYEE F
					 WHERE A.ORG_ID = F.ORG_NO
						 AND F.EMP_NO = E.EMP_NO
						 AND A.SAL_ID = E.SAL_ID
						 AND A.SEG_CODE = E.SEG_CODE
						 AND A.TARGET_CODE = E.TARGET_CODE)
	 WHERE A.TARGET_CODE IN ('D000016392500', 'D000016392600', 'D000016392700');
	COMMIT;

	RETCODE := 0;
	RETMSG  := '机构和人员薪资计算执行结束';
	PRC_SYS_MONITOR_LOG(FLOW_ID,
											S_DATE,
											E_DATE,
											STEP_ID,
											RECORD_TIME,
											'PRC_EWM_AUTO_COUNT',
											1,
											RETMSG,
											'',
											RECORD_TIME,
											1);

	/*异常处理*/
EXCEPTION
	WHEN OTHERS THEN
		RETMSG  := 'SQLCODE:' || '机构和人员薪资计算' || SUBSTR(SQLERRM, 1, 500);
		RETCODE := SQLCODE;
		ROLLBACK;
		PRC_SYS_MONITOR_LOG(FLOW_ID,
												S_DATE,
												E_DATE,
												STEP_ID,
												RECORD_TIME,
												'PRC_EWM_AUTO_COUNT',
												4,
												RETMSG,
												'',
												RECORD_TIME,
												1);
		RETURN;
END PRC_SAL_COUNT;

/

