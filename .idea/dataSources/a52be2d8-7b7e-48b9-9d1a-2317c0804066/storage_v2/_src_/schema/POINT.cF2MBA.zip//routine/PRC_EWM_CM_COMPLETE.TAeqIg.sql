create PROCEDURE PRC_EWM_CM_COMPLETE(P_WAYID    IN VARCHAR,
                                                P_WAYCODE  IN VARCHAR,
                                                P_SEGCODES IN VARCHAR,
                                                RETCODE    OUT INT,
                                                ERRMSG     OUT VARCHAR) IS
  /* 过程、函数简要描述信息
  **********************************************************
  *  存储过程名: 员工成绩完成率计算
  *  建立日期  : 2018-04-15
  *  作者      : 贾军鹏
  *  模块      : 绩效考核管理
  *  功能描述  : 员工成绩完成率计算
  *  输入参数  ：P_WAYID 方案ID P_WAYCODE 方案代码, P_SEGCODES 方案阶段代码
  *  输出参数  ：RETCODE 成功为0 ,ERRMSG 错误信息
  *   备注     :
  *------------------------------------------------------------
  *  修改历史
  *  序号    日期      修改人      修改原因
  ************************************************************ */
  MYSQL           VARCHAR(2000);
  T_TARGETCODE    VARCHAR(30);
  SQLEXP          VARCHAR(2000);
  T_COMPCODE      VARCHAR(30);
  TDAYS           INT;
  P_SEGCODE       VARCHAR(30);
  V_TRG_COLL_CODE VARCHAR(100);
  T_TRG_COLL_CODE VARCHAR(100);
  V_IF_RATE       VARCHAR(100);

  CURSOR CUR IS
    SELECT TARGET_CODE, UPPER(SQL_EXP), TRG_COLL_CODE
      FROM MO_EWM_CM_TRG_RATE
     WHERE WAY_CODE = P_WAYCODE
       AND (SQL_EXP IS NOT NULL OR LENGTH(SQL_EXP) > 0)
     ORDER BY TARGET_CODE;
BEGIN
  P_SEGCODE := NVL(P_SEGCODES, ' ');

  SELECT IF_RATE, TRG_COLL_CODE
    INTO V_IF_RATE, V_TRG_COLL_CODE
    FROM MO_EWM_CM T
   WHERE T.WAY_CODE = P_WAYCODE
   and t.way_id = P_WAYID
   and t.way_code = P_WAYCODE;

  --清空方案计算日志
  DELETE FROM SYS_EWM_LOG WHERE WAY_CODE = P_WAYID;
  COMMIT;

  --无任务值指标补充任务值为空
  INSERT INTO MO_PT_CM
    (WAY_ID,
     SEG_CODE,
     PT_ID,
     TARGET_CODE,
     PT_SCOPE_ID,
     CYC_CODE,
     START_DAT,
     END_DAT,
     PT_VALUE)
    SELECT L3.WAY_ID,
           L3.SEG_CODE,
           SYS_GUID(),
           L2.TARGET_CODE,
           L1.STAFF_ID,
           L3.CYC_CODE,
           L3.START_DAT,
           L3.END_DAT,
           ''
      FROM MO_EWM_FIT_STAFF L1,
           MO_EWM_CM_TRG_RATE L2,
           (SELECT WAY_ID,
                   ' ' SEG_CODE,
                   WAY_CYC AS CYC_CODE,
                   START_DAT,
                   END_DAT
              FROM MO_EWM_CM
             WHERE SEG_FLAG = '0' --不分段
            UNION
            SELECT WAY_ID, SEG_CODE, CYC_CODE, START_DAT, END_DAT
              FROM MO_EWM_CM_SEG) L3
     WHERE L1.WAY_CODE = L2.WAY_CODE
       AND L1.WAY_CODE = P_WAYCODE
       AND NVL(L1.SEG_CODE, ' ') = P_SEGCODE
       AND L3.WAY_ID = P_WAYID
       AND NVL(L3.SEG_CODE, ' ') = P_SEGCODE
       AND NOT EXISTS
     (SELECT 1
              FROM MO_PT_CM L3
             WHERE L3.WAY_ID = P_WAYID
               AND NVL(L3.SEG_CODE, ' ') = NVL(L1.SEG_CODE, ' ')
               AND L3.TARGET_CODE = L2.TARGET_CODE
               AND L3.PT_SCOPE_ID = L1.STAFF_ID);
  COMMIT;

  --更新员工任务表完成值
  UPDATE MO_PT_CM D1
     SET FS_VALUE =
         (SELECT NVL(FUN_CM_FSVALUE(L2.START_DAT,
                                    L2.END_DAT,
                                    L1.PT_SCOPE_ID,
                                    L1.TARGET_CODE),
                     0)
            FROM MO_PT_CM L1,
                 (SELECT WAY_ID,
                         ' ' SEG_CODE,
                         WAY_CYC AS CYC_CODE,
                         START_DAT,
                         END_DAT
                    FROM MO_EWM_CM
                   WHERE SEG_FLAG = '0' --不分段
                  UNION
                  SELECT WAY_ID, SEG_CODE, CYC_CODE, START_DAT, END_DAT
                    FROM MO_EWM_CM_SEG) L2
           WHERE L1.WAY_ID = L2.WAY_ID
             AND NVL(L1.SEG_CODE, ' ') = NVL(L2.SEG_CODE, ' ')
             AND L1.WAY_ID = P_WAYID
             AND NVL(L2.SEG_CODE, ' ') = P_SEGCODE
             AND L1.PT_ID = D1.PT_ID)
   WHERE EXISTS
   (SELECT 1
            FROM MO_PT_CM L1,
                 (SELECT WAY_ID,
                         ' ' SEG_CODE,
                         WAY_CYC AS CYC_CODE,
                         START_DAT,
                         END_DAT
                    FROM MO_EWM_CM
                   WHERE SEG_FLAG = '0' --不分段
                  UNION
                  SELECT WAY_ID, SEG_CODE, CYC_CODE, START_DAT, END_DAT
                    FROM MO_EWM_CM_SEG) L2
           WHERE L1.WAY_ID = L2.WAY_ID
             AND NVL(L1.SEG_CODE, ' ') = NVL(L2.SEG_CODE, ' ')
             AND L1.WAY_ID = P_WAYID
             AND NVL(L2.SEG_CODE, ' ') = P_SEGCODE
             AND L1.PT_ID = D1.PT_ID);
  COMMIT;

  IF V_IF_RATE = 'Y' THEN

    --删除员工明细成绩表
    DELETE FROM MO_EWM_CM_DT
     WHERE WAY_ID = P_WAYID
       AND NVL(SEG_CODE, ' ') = P_SEGCODE;
    COMMIT;

    OPEN CUR;
    LOOP
      FETCH CUR
        INTO T_TARGETCODE, SQLEXP, T_TRG_COLL_CODE;
      EXIT WHEN CUR % NOTFOUND;
      IF LENGTH(SQLEXP) > 0 OR SQLEXP IS NOT NULL THEN
        SQLEXP := REPLACE(SQLEXP, '|', '''');
        MYSQL  := 'INSERT INTO MO_EWM_CM_DT(DT_ID,WAY_ID,SEG_CODE,STAFF_ID,TARGET_CODE,CALC_SCORE,ADJ_EFF_FLAG) ';
        MYSQL  := MYSQL ||
                  ' SELECT sys_guid(),WAY_ID,SEG_CODE,PT_SCOPE_ID, TARGET_CODE, ' ||
                  SQLEXP || ', ''0'' FROM (';
        MYSQL  := MYSQL ||
                  'SELECT WAY_ID,SEG_CODE,PT_SCOPE_ID,TARGET_CODE,FS_VALUE,PT_VALUE';
        MYSQL  := MYSQL || ' FROM MO_PT_CM  A  ';
        MYSQL  := MYSQL || ' WHERE  WAY_ID = ''' || P_WAYID ||
                  ''' AND nvl(SEG_CODE,'' '') = ''' || P_SEGCODE ||
                  ''' AND TARGET_CODE = ''' || T_TARGETCODE || '''';
        MYSQL  := MYSQL || ' ) ';
        EXECUTE IMMEDIATE MYSQL;



        --插入计算sql
        RETCODE := 0;
        ERRMSG  := T_TARGETCODE || ':计算成功';
        PRC_SYS_EWM_LOG(P_WAYID,
                        P_SEGCODE,
                        T_TARGETCODE,
                        MYSQL,
                        RETCODE,
                        ERRMSG);
      END IF;
    END LOOP;
    CLOSE CUR;
    COMMIT;

    --计算一级指标得分
    DELETE FROM MO_PT_CM_DT_COMPLETE
     WHERE WAY_ID = P_WAYID
       AND NVL(SEG_CODE, ' ') = P_SEGCODE;
    COMMIT;

    INSERT INTO MO_PT_CM_DT_COMPLETE
      (dt_id,
       way_id,
       seg_code,
       target_code,
       STAFF_ID,
       calc_score,
       PARAM_VALUE,
       CALC_COEFF)
      select sys_guid(),
             way_id,
             seg_code,
             trg_coll_code,
             STAFF_ID,
             calc_score,
             SCR_SCORE_PARAM_VALUE(calc_score, '0'),
             calc_coeff--SCR_SCORE_PARAM_VALUE(calc_coeff, '0')
        from (select sys_guid(),
                     way_id,
                     seg_code,
                     STAFF_ID,
                     trg_coll_code,
                     sum(calc_score) calc_score,
                     sum(calc_coeff) calc_coeff
                from (select way_id,
                             seg_code,
                             STAFF_ID,
                             trg_two_code,
                             trg_coll_code,
                             trg_two_rate,
                             sum(nvl(calc_score, 0)) * trg_two_rate calc_score,
                             sum(nvl(calc_coeff, 0)) * trg_two_rate calc_coeff
                        from (select a.way_id,
                                     a.seg_code,
                                     a.STAFF_ID,
                                     nvl(a.calc_score, 0) * b.trg_three_rate calc_score,
                                     SCR_SCORE_PARAM_VALUE(a.calc_score, '0') *
                                     b.trg_three_rate calc_coeff,
                                     b.trg_two_rate,
                                     a.target_code,
                                     b.trg_two_code,
                                     b.trg_coll_code
                                from MO_EWM_CM_DT a, mo_trg_three_info b
                               where a.target_code = b.trg_three_code
                                 and WAY_ID = P_WAYID
                                 AND nvl(SEG_CODE, ' ') = P_SEGCODE
                                 and b.trg_coll_code = V_TRG_COLL_CODE)
                       group by way_id,
                                seg_code,
                                STAFF_ID,
                                trg_two_code,
                                trg_coll_code,
                                trg_two_rate) a
               group by way_id, seg_code, STAFF_ID, trg_coll_code) a;

    COMMIT;

    delete from MO_EWM_CM_DT_SS
     where way_id = P_WAYID
       and nvl(SEG_CODE, '') = P_SEGCODE;

    insert into MO_EWM_CM_DT_SS
      (dt_id, way_id, seg_code, STAFF_ID, calc_score, param_value)
      select sys_guid(),
             a.way_id,
             a.seg_code,
             a.STAFF_ID,
             a.calc_score,
             --SCR_SCORE_PARAM_VALUE(a.calc_score, '0') --总区间系数
             calc_coeff
        from (select sys_guid(),
                     way_id,
                     seg_code,
                     STAFF_ID,
                     sum(calc_score) calc_score,
                     sum(calc_coeff) calc_coeff
                from MO_PT_CM_DT_COMPLETE t
               where t.way_id = P_WAYID
                 and nvl(SEG_CODE, ' ') = P_SEGCODE
                 and t.target_code = V_TRG_COLL_CODE
               group by way_id, seg_code, STAFF_ID) a
        join (select a.way_id,
                     a.seg_code,
                     a.STAFF_ID,
                     sum(a.calc_score) calc_score
                from MO_EWM_CM_DT a, mo_trg_three_info b
               where a.target_code = b.trg_three_code
                 and WAY_ID = P_WAYID
                 AND nvl(SEG_CODE, ' ') = P_SEGCODE
                 and b.trg_coll_code = V_TRG_COLL_CODE
               group by WAY_ID, seg_code, STAFF_ID) b
          on a.way_id = b.way_id
         and a.seg_code = b.seg_code
         and a.STAFF_ID = b.STAFF_ID;

    commit;

  ELSE

    --删除员工明细成绩表
    DELETE FROM MO_EWM_CM_DT
     WHERE WAY_ID = P_WAYID
       AND NVL(SEG_CODE, ' ') = P_SEGCODE;
    COMMIT;

    OPEN CUR;
    LOOP
      FETCH CUR
        INTO T_TARGETCODE, SQLEXP, T_TRG_COLL_CODE;
      EXIT WHEN CUR % NOTFOUND;
      IF LENGTH(SQLEXP) > 0 OR SQLEXP IS NOT NULL THEN
        SQLEXP := REPLACE(SQLEXP, '|', '''');
        MYSQL  := 'INSERT INTO MO_EWM_CM_DT(DT_ID,WAY_ID,SEG_CODE,STAFF_ID,TARGET_CODE,CALC_SCORE,ADJ_EFF_FLAG) ';
        MYSQL  := MYSQL ||
                  ' SELECT sys_guid(),WAY_ID,SEG_CODE,PT_SCOPE_ID, TARGET_CODE, ' ||
                  SQLEXP || ', ''0'' FROM (';
        MYSQL  := MYSQL ||
                  'SELECT WAY_ID,SEG_CODE,PT_SCOPE_ID,TARGET_CODE,FS_VALUE,PT_VALUE';
        MYSQL  := MYSQL || ' FROM MO_PT_CM ';
        MYSQL  := MYSQL || ' WHERE WAY_ID = ''' || P_WAYID ||
                  ''' AND nvl(SEG_CODE,'' '') = ''' || P_SEGCODE ||
                  ''' AND TARGET_CODE = ''' || T_TARGETCODE || '''';
        MYSQL  := MYSQL || ' ) ';
        EXECUTE IMMEDIATE MYSQL;

        --插入计算sql
        RETCODE := 0;
        ERRMSG  := T_TARGETCODE || ':计算成功';
        PRC_SYS_EWM_LOG(P_WAYID,
                        P_SEGCODE,
                        T_TARGETCODE,
                        MYSQL,
                        RETCODE,
                        ERRMSG);
      END IF;
    END LOOP;
    CLOSE CUR;
    COMMIT;
    --调整计算汇总得分
    PRC_EWM_CM_DT_SS(P_WAYID, P_SEGCODE, 0, RETCODE, ERRMSG);
    IF RETCODE <> 0 THEN
      --插入计算sql日志
      ERRMSG := P_WAYID || ':计算汇总得分失败';
      PRC_SYS_EWM_LOG(P_WAYID, P_SEGCODE, NULL, MYSQL, RETCODE, ERRMSG);
      RETURN;
    ELSE
      --插入计算sql日志
      ERRMSG := P_WAYID || ':计算汇总得分成功';
      PRC_SYS_EWM_LOG(P_WAYID, P_SEGCODE, NULL, MYSQL, RETCODE, ERRMSG);
    END IF;

  END IF;

  RETCODE := 0;

EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    RETCODE := SQLCODE;
    ERRMSG  := SUBSTR(SQLERRM, 1, 200);
    PRC_SYS_EWM_LOG(P_WAYID,
                    P_SEGCODE,
                    T_TARGETCODE,
                    MYSQL,
                    RETCODE,
                    ERRMSG);
END;

/

