create FUNCTION CSCR_CUMULATIONY(FS_VALUE    NUMBER
                                           ,UNIT_VALUE  NUMBER
                                           ,SCORE_VALUE NUMBER
                                           ,H_SCORE     NUMBER)
  RETURN NUMBER IS
  /* 过程、函数简要描述信息
  **********************************************************
  *  存储过程名:  客户等级积分评分法
  *  建立日期  :  2013-03-20
  *  作者      :  zhuy
  *  模块      :  评分模型
  *  功能描述  :  积分法
  *  输入参数  ：
  *  输出参数  ：
  *  来源表    ：
  *  目标表    :
  *   备注     ：1、 每   (元) ;  得       分；

  *------------------------------------------------------------
  *  修改历史
  *  序号    日期      修改人      修改原因
  ************************************************************ */
  O_VAL NUMBER(20, 2);
BEGIN
  IF ((FS_VALUE IS NOT NULL) AND (UNIT_VALUE <> 0 AND SCORE_VALUE <> 0) AND
     (UNIT_VALUE * SCORE_VALUE) IS NOT NULL) THEN
    IF (ABS(FS_VALUE / UNIT_VALUE * SCORE_VALUE) > ABS(H_SCORE)) THEN
      O_VAL := H_SCORE;
    ELSE
      O_VAL := (FS_VALUE / UNIT_VALUE) * SCORE_VALUE;
    END IF;
  ELSE
    O_VAL := NULL;
  END IF;
  RETURN O_VAL;
END;

/

