create PROCEDURE SP_SYS_PUB_PRODUCT(IV_JOBID  IN VARCHAR2,
                                               IV_OPERID IN VARCHAR2,
                                               ON_RESULT OUT NUMBER)
--*******************************************************************************
  -- CopyRight (c) 2018, 融丰银行                                               *
  -- All rights reserved.                                                       *
  --                                                                            *
  -- 文件名称 : SYS_PUB_PRODUCT.prc                                          *
  -- 摘    要 : A03_产品表                                              *
  -- 工程模块 : crmapp.04_27                                                    *
  -- 当前版本 : V1.0.0                                                          *
  -- 作    者 : LYH                                                            *
  -- 完成日期 : 2018/01/24                                                      *
  -- 错误码段 : 40270 - 40279                                                   *
  --*****************************************************************************
 IS
  V_WORK_DATE  VARCHAR2(8);
  V_RETCODE    VARCHAR2(6) := '000000'; --程序/日志返回码
  V_MSG        VARCHAR2(1000); --程序执行信息
  V_TABNAME    VARCHAR2(100); --表名
  V_RETERRFLG  VARCHAR2(1); --日志标志 I(information) W(waring) E(error)
  V_ERRCODE    VARCHAR2(10) := '40279'; --程序执行出错返回码
  V_RETSUBCODE VARCHAR2(3); --程序子返回码
  --V_TABLEEXIST NUMBER; --是否存在表名
BEGIN

  /*获得业务时间*/
  SELECT WORK_DATE INTO V_WORK_DATE FROM SYS_PARA_DATE_NEW;

  V_RETCODE    := '40270';
  V_RETSUBCODE := '001';
  V_RETERRFLG  := 'I';
  V_MSG        := '程序执行开始';
  SP_WRITEDETAILLOG(V_WORK_DATE,
                    IV_JOBID,
                    IV_OPERID,
                    V_MSG,
                    V_RETCODE,
                    V_RETSUBCODE,
                    V_RETERRFLG);

  V_RETCODE    := '40271';
  V_TABNAME    := 'SYS_PUB_PRODUCT';
  V_RETERRFLG  := 'I';
  V_RETSUBCODE := '001';
  /*清空产品表*/
  EXECUTE IMMEDIATE 'TRUNCATE TABLE SYS_PUB_PRODUCT';
  /*写日志*/
  V_MSG := V_TABNAME || '表记录成功清除';
  SP_WRITEDETAILLOG(V_WORK_DATE,
                    IV_JOBID,
                    IV_OPERID,
                    V_MSG,
                    V_RETCODE,
                    V_RETSUBCODE,
                    V_RETERRFLG);

  V_RETCODE := '40272';
  /*加载数据到产品表*/
  --加载核心活期存款产品
  INSERT INTO SYS_PUB_PRODUCT
    (prd_code, --产品编号
     prd_name, --产品名称
     start_publish_date, --产品开始发行时间
     end_publish_date, --产品结束发行时间
     prd_object, --产品对象
     prd_desc, -- 产品描述
     up_cd, --  父产品
     PRD_LEVEL,
     prd_seq --产品序列
     )
    SELECT PRDT_NO,
           TITLE, --  产品描述
           TO_CHAR(BEG_DATE), -- 启用日期
           TO_CHAR(END_DATE) END_DATE, --止用日期
           '核心活期',
           TITLE, --产品描述
           'HXHQ',
           '1',
           PRDT_NO
      FROM A_CBS_DD_PARM T
    /*WHERE TO_CHAR(T.BEG_DATE) <= V_WORK_DATE
    AND TO_CHAR(T.END_DATE) >= V_WORK_DATE*/
    ;

  --加载核心定期存款产品
  INSERT INTO SYS_PUB_PRODUCT
    (prd_code, --产品编号
     prd_name, --产品名称
     start_publish_date, --产品开始发行时间
     end_publish_date, --产品结束发行时间
     prd_object, --产品对象
     prd_desc, -- 产品描述
     up_cd, --  父产品
     PRD_LEVEL,
     prd_seq --产品序列
     )
    SELECT PRDT_NO,
           TITLE, --  产品描述
           TO_CHAR(BEG_DATE), -- 启用日期
           TO_CHAR(END_DATE) END_DATE, --止用日期
           '核心定期',
           TITLE, --产品描述
           'HXDQ',
           '1',
           PRDT_NO
      FROM A_CBS_TD_PARM T
    /*WHERE TO_CHAR(T.BEG_DATE) <= V_WORK_DATE
    AND TO_CHAR(T.END_DATE) >= V_WORK_DATE*/
    ;
  --加载信贷产品
  INSERT INTO SYS_PUB_PRODUCT
    (prd_code, --产品编号
     prd_name, --产品名称
     prd_subdivision_type, --产品细分类型
     start_publish_date, -- 产品开始发行时间
     end_publish_date, -- 产品结束发行时间
     prd_object, --产品对象
     prd_status, --产品状态
     prd_desc, --产品描述
     up_cd, --父产品
     PRD_LEVEL,
     prd_seq) --产品序列
    SELECT PRD_NO, --产品编号
           PRD_NAME, --产品名称
           PRD_TYPE, --产品类别
           TO_DATE(TO_CHAR(BEG_DATE), 'YYYYMMDD'), -- 起始日期
           (CASE
             WHEN END_DATE = 99999999 THEN
              TO_DATE('99991231', 'YYYYMMDD')
             ELSE
              TO_DATE(TO_CHAR(END_DATE), 'YYYYMMDD')
           END) END_DATE, --到期日期
           '信贷',
           USER_FLAG, --是否有效
           PRD_NAME, --产品名称
           'XD', --产品编号
           '1',
           PRD_NO --产品编号
      FROM A_CMS_PRD_BASE T
    /* WHERE TO_CHAR(T.BEG_DATE) <= V_WORK_DATE
    AND TO_CHAR(T.END_DATE) >= V_WORK_DATE*/
    ;
  commit;
  /*--加载供应链产品
   INSERT INTO SYS_PUB_PRODUCT
     (prd_code, --产品编号
      prd_name, --产品名称
      prd_subdivision_type, --产品细分类型
      start_publish_date, -- 产品开始发行时间
      end_publish_date, -- 产品结束发行时间
      prd_object, --产品对象
      prd_status, --产品状态
      prd_desc, --产品描述
      up_cd, --父产品
       PRD_LEVEL,
      prd_seq) --产品序列
     SELECT T.KIND_NO, --产品编号
            T.KIND_NAME, --产品名称
            '', --产品类别
            '', -- 起始日期
            '', --到期日期
            '供应链',
            '', --是否有效
            T.KIND_NAME, --产品名称
            'GYL', --产品编号
            '1',
            T.KIND_NO --产品编号
       FROM A_GYL_MF_SYS_KIND T
     \* WHERE TO_CHAR(T.BEG_DATE) <= V_WORK_DATE
        AND TO_CHAR(T.END_DATE) >= V_WORK_DATE*\;
  commit;*/
  --加载手机银行产品
  INSERT INTO SYS_PUB_PRODUCT
    (prd_code, --产品编号
     prd_name, --产品名称
     prd_subdivision_type, --产品细分类型
     start_publish_date, -- 产品开始发行时间
     end_publish_date, -- 产品结束发行时间
     prd_object, --产品对象
     prd_status, --产品状态
     prd_desc, --产品描述
     up_cd, --父产品
     PRD_LEVEL,
     prd_seq) --产品序列
    SELECT MM.PRDT_NO, --产品编号
           MM.PRDT_NAME, --产品名称
           '', --产品类别
           TO_DATE(TO_CHAR(MM.PRDT_DATE), 'YYYYMMDD'), -- 起始日期
           TO_DATE('99991231', 'YYYYMMDD') END_DATE, --到期日期
           '手机银行',
           MM.PRDT_STS, --是否有效
           MM.PRDT_NAME, --产品名称
           'SJYH', --产品编号
           '1',
           MM.PRDT_NO --产品编号
      FROM (SELECT T.PRDT_NO,
                   T.PRDT_NAME,
                   T.PRDT_DATE,
                   T.PRDT_STS,
                   ROW_NUMBER() OVER(PARTITION BY T.PRDT_NO ORDER BY T.PRDT_NO ASC) ROWN
              FROM A_IFP2_PRDT_BASE_INFO T) MM
     WHERE MM.ROWN = 1
    
    ;
  COMMIT;

  --处理父产品
  INSERT INTO SYS_PUB_PRODUCT
    (prd_code, --产品编号
     prd_name, --产品名称
     prd_object, --产品对象
     up_cd, --  父产品
     PRD_LEVEL,
     prd_seq --产品序列
     )
  values
    ('HXHQ', '核心活期', '核心活期', '', '0', 'HXHQ');
  INSERT INTO SYS_PUB_PRODUCT
    (prd_code, --产品编号
     prd_name, --产品名称
     prd_object, --产品对象
     up_cd, --  父产品
     PRD_LEVEL,
     prd_seq --产品序列
     )
  values
    ('HXDQ', '核心定期', '核心定期', '', '0', 'HXDQ');
  INSERT INTO SYS_PUB_PRODUCT
    (prd_code, --产品编号
     prd_name, --产品名称
     prd_object, --产品对象
     up_cd, --  父产品
     PRD_LEVEL,
     prd_seq --产品序列
     )
  values
    ('XD', '信贷', '信贷', '', '0', 'XD');
  /*INSERT INTO SYS_PUB_PRODUCT
    (prd_code, --产品编号
     prd_name, --产品名称
     prd_object, --产品对象
     up_cd, --  父产品
      PRD_LEVEL,
     prd_seq --产品序列
     )
  values
    ('GYL', '供应链', '供应链', '', '0','GYL');*/
  INSERT INTO SYS_PUB_PRODUCT
    (prd_code, --产品编号
     prd_name, --产品名称
     prd_object, --产品对象
     up_cd, --  父产品
     PRD_LEVEL,
     prd_seq --产品序列
     )
  values
    ('SJYH', '手机银行', '手机银行', '', '0', 'SJYH');
  commit;
  V_MSG := V_TABNAME || '成功写入' || SQL%ROWCOUNT || '条记录';
  COMMIT;

  /*写日志*/
  SP_WRITEDETAILLOG(V_WORK_DATE,
                    IV_JOBID,
                    IV_OPERID,
                    V_MSG,
                    V_RETCODE,
                    V_RETSUBCODE,
                    V_RETERRFLG);

  V_RETCODE := '40274';
  V_TABNAME := 'SYS_PUB_PRODUCT';
  V_MSG     := V_TABNAME || '表成功写入数据';

  ON_RESULT := 0;

  /*异常处理*/
EXCEPTION
  WHEN OTHERS THEN
    V_RETERRFLG := 'E';
    V_RETCODE   := V_ERRCODE;
    V_MSG       := 'SQLCODE:' || V_TABNAME || '表' ||
                   SUBSTR(SQLERRM, 1, 500);
    ON_RESULT   := SQLCODE;
    ROLLBACK;
    SP_WRITEDETAILLOG(V_WORK_DATE,
                      IV_JOBID,
                      IV_OPERID,
                      V_MSG,
                      V_RETCODE,
                      V_RETSUBCODE,
                      V_RETERRFLG);
    RETURN;
END;
/

