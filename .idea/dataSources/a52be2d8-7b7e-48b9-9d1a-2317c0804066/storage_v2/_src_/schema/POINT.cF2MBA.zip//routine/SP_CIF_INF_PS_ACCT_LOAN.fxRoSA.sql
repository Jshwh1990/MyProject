create PROCEDURE SP_CIF_INF_PS_ACCT_LOAN(IV_JOBID  IN VARCHAR2,
                                                    IV_OPERID IN VARCHAR2,
                                                    ON_RESULT OUT NUMBER)
--*******************************************************************************
  -- CopyRight (c) 2018, 融丰银行                                               *
  -- All rights reserved.                                                       *
  --                                                                            *
  -- 文件名称 : SP_CIF_INF_PS_ACCT_LOAN.prc                                          *
  -- 摘    要 : 个人贷款信息表数据加工                                          *
  -- 工程模块 : crmapp.04_27                                                    *
  -- 当前版本 : V1.0.0                                                          *
  -- 作    者 : lyh                                                           *
  -- 完成日期 : 2018/03/15                                                     *
  -- 错误码段 : 40270 - 40279                                                   *
  --*****************************************************************************
 IS
  V_WORK_DATE  VARCHAR2(8);
  V_RETCODE    VARCHAR2(6) := '000000'; --程序/日志返回码
  V_MSG        VARCHAR2(1000); --程序执行信息
  V_TABNAME    VARCHAR2(100); --表名
  V_RETERRFLG  VARCHAR2(1); --日志标志 I(information) W(waring) E(error)
  V_ERRCODE    VARCHAR2(10) := '40279'; --程序执行出错返回码
  V_RETSUBCODE VARCHAR2(3); --程序子返回码
  V_JOBID      VARCHAR2(50) := IV_JOBID;
  V_OPERID     VARCHAR2(50) := IV_OPERID;
  V_TABLEEXIST NUMBER; --是否存在表名
BEGIN
  /*判断个人贷款临时表数据是否存在, 若不存在，则插入个人贷款数据*/
  SELECT COUNT(1) INTO V_TABLEEXIST FROM TEMP_CIF_INF_PS_ACCT_LOAN;
  IF V_TABLEEXIST = 0 THEN
    INSERT /*+APPEND*/
    INTO TEMP_CIF_INF_PS_ACCT_LOAN NOLOGGING
      SELECT * FROM CIF_INF_PS_ACCT_LOAN;
    COMMIT;
  END IF;
  /*获得业务时间*/
  SELECT WORK_DATE INTO V_WORK_DATE FROM SYS_PARA_DATE_NEW;
  --把日期处理成年初
  --V_YEAR_FIRST := TO_DATE(FNC_GET_DATE(V_WORK_DATE, 'YB'), 'YYYYMMDD');

  ----记录日志
  V_RETCODE    := '40270';
  V_RETSUBCODE := '001';
  V_RETERRFLG  := 'I';
  V_MSG        := '程序执行开始';
  SP_WRITEDETAILLOG(V_WORK_DATE,
                    V_JOBID,
                    V_OPERID,
                    V_MSG,
                    V_RETCODE,
                    V_RETSUBCODE,
                    V_RETERRFLG);

  V_RETCODE    := '40271';
  V_TABNAME    := 'CIF_INF_PS_ACCT_LOAN';
  V_RETERRFLG  := 'I';
  V_RETSUBCODE := '001';
  /*清空个人贷款信息表*/
  EXECUTE IMMEDIATE 'TRUNCATE TABLE CIF_INF_PS_ACCT_LOAN';
  /*写日志*/
  V_MSG := V_TABNAME || '表记录成功清除';
  SP_WRITEDETAILLOG(V_WORK_DATE,
                    V_JOBID,
                    V_OPERID,
                    V_MSG,
                    V_RETCODE,
                    V_RETSUBCODE,
                    V_RETERRFLG);

  V_RETCODE := '40272';
  /*加载数据到个人贷款信息表*/
--加载信贷数据
  INSERT /*+APPEND*/
  INTO CIF_INF_PS_ACCT_LOAN NOLOGGING
    (acct_no, --账号
     area_no, --区域号
     main_acct_no, --主账号
     cust_no, --客户号
     cust_name, --客户名称
     currency, --币种
     term, --期限
     prd_code, --产品代码
     open_date, --开户日期
     open_org, --开户机构
     end_date, --到期日期
     belong_org, --归属机构
     bal, --余额
     accrual_delay, --拖欠利息
     accrual_fact_a, --累积实收利息
     manager_no, --客户经理编号
     state, --分配状态
     modify_date, --更新日期
     acct_state, --账户状态
     is_small_co, --是否小微客户
     belong_type, --客户归属机构类型：1.前台更改，0：后台自动每日更新
     fin_br_no, --财务机构号
     RATE,
     LOAN_TYPE
     )
    SELECT A.BILL_NO, --借据号
           100,
           NVL(A.LOAN_AC_NO, A.BILL_NO), --贷款帐号
           nvl(A.CIF_NO,0), --客户号
           A.CIF_NAME, --客户名称
           (CASE
             WHEN A.CUR_TYPE = 'CNY' THEN
              '01'
           END) CUR_TYPE, --币种(CUR_NO),
           A.TERM_DAY, --期限日
           A.PRD_NO, --产品号
           A.LOAN_START_DATE, --贷款起始日
           A.FINA_BR_NO, --         账务机构
           A.LOAN_END_DATE, --贷款终止日
           A.FINA_BR_NO, --         账务机构
           A.LOAN_BAL, --借据余额
           A.IN_INTST + A.OUT_INTST, --"表内欠息+表外欠息"
           A.ADD_PAY_INTST, --累计还息金额
           A.MANG_NO, --客户经理
           '0' STATE, --分配状态
           TO_DATE(V_WORK_DATE, 'YYYYMMDD'),
           A.ACCOUNT_STATUS, --   台帐状态(ACC_STATUS)
           'N',
           NVL(TMP.BELONG_TYPE, '0') BELONG_TYPE, --客户归属机构类型：1.前台更改，0：后台自动每日更新
           A.FINA_BR_NO ,--         账务机构
           A.BASE_RATE/100,
           '信贷'
      FROM A_CMS_DUE_LOAN_ACC A /*
          LEFT JOIN A_CBS_CIF_BASIC_INF B
          ON A.CIF_NO=B.CIF_NO
          AND B.TYPE='1'--1 个人*/
      LEFT JOIN TEMP_CIF_INF_PS_ACCT_LOAN TMP --备份表
        ON A.BILL_NO = TMP.ACCT_NO
     WHERE A.CIF_TYPE = '2'; --2个人，1公司
 COMMIT;
/*--加载供应链数据
  INSERT \*+APPEND*\
  INTO CIF_INF_PS_ACCT_LOAN NOLOGGING
    (acct_no, --账号
     area_no, --区域号
     main_acct_no, --主账号
     cust_no, --客户号
     cust_name, --客户名称
     currency, --币种
     term, --期限
     prd_code, --产品代码
     open_date, --开户日期
     open_org, --开户机构
     end_date, --到期日期
     belong_org, --归属机构
     bal, --余额
     accrual_delay, --拖欠利息
     accrual_fact_a, --累积实收利息
     manager_no, --客户经理编号
     state, --分配状态
     modify_date, --更新日期
     acct_state, --账户状态
     is_small_co, --是否小微客户
     belong_type, --客户归属机构类型：1.前台更改，0：后台自动每日更新
     fin_br_no, --财务机构号
     rate,
     LOAN_TYPE)
    SELECT A.BILL_NO, --供应链系统借据号
           '100', --
           A.BILL_NO, --供应链系统借据号
           nvl(C.CIF_NO,0), --核心客户号
           C.NAME, --客户名称
           '01'  CURRENCY, --币种（人民币）
           A.TERM_MON||'月', --期限月
           A.PROD_NO, --产品代码
           A.OPEN_DATE, --借据开始日
           '600001', --开户机构(前郭县阳光村镇银行)  --600001
           A.END_DATE, --到期日期
           '600001', --开户机构(前郭县阳光村镇银行)  --600001
           A.BAL, --借据余额
           A.ACCRUAL_DELAY, --拖欠利息(截止当前日期逾期的利息之和，包含逾期的正常利息、逾期本金产生的利息和逾期正常利息产生的复利利息)
           A.ACCRUAL_FACT_A, --累积实收利息(截止上报日之前所有已经归还的所有利息之和，含正常利息、逾期利息、复利利息)
           A.EMP_NO, --客户经理编号
           '0' STATE, --分配状态
           TO_DATE(V_WORK_DATE,'YYYYMMDD'), --
           A.ACT_STS, --账户状态（5放款已复核6已还款未复核7完结）
           'N', --
           NVL(TMP.BELONG_TYPE, '0') BELONG_TYPE, --客户归属机构类型：1.前台更改，0：后台自动每日更新
           A.FIN_BR_NO, --财务机构号(600001)
           A.RATE/100,
           '供应链'
      from A_GYL_LOANINFORMATION A
      LEFT JOIN TEMP_CIF_INF_PS_ACCT_LOAN TMP --备份表
        ON A.BILL_NO = TMP.ACCT_NO
        LEFT JOIN A_CBS_CIF_ID_CODE_REL C--根据证件号码关联取核心客户号
      ON A.ID_NO = C.ID_NO
      and c.id_type='1'--取身份证
     WHERE A.CIF_TYPE = '2'; --1.企业，2个人*/
  COMMIT;
  V_TABNAME := 'CIF_INF_PS_ACCT_LOAN';
  V_MSG     := V_TABNAME || '成功写入' || SQL%ROWCOUNT || '条记录';
  COMMIT;

  /*更新分配状态*/
  UPDATE CIF_INF_PS_ACCT_LOAN T
     SET T.STATE = '1'
   WHERE T.STATE = '0'
     AND EXISTS
   (SELECT 1 FROM OP_AS_AR_SA_LOAN B WHERE T.ACCT_NO = B.RES_ID);
  COMMIT;
  UPDATE CIF_INF_PS_ACCT_LOAN T
     SET T.STATE = '0'
   WHERE T.STATE = '1'
     AND NOT EXISTS
   (SELECT 1 FROM OP_AS_AR_SA_LOAN B WHERE T.ACCT_NO = B.RES_ID);
  COMMIT;
  /*写日志*/
  SP_WRITEDETAILLOG(V_WORK_DATE,
                    V_JOBID,
                    V_OPERID,
                    V_MSG,
                    V_RETCODE,
                    V_RETSUBCODE,
                    V_RETERRFLG);

  V_RETCODE := '40274';
  V_TABNAME := 'CIF_INF_PS_ACCT_LOAN';
  V_MSG     := V_TABNAME || '表成功写入数据';
  /*写日志*/
  V_RETSUBCODE := '001';
  SP_WRITEDETAILLOG(V_WORK_DATE,
                    V_JOBID,
                    V_OPERID,
                    V_MSG,
                    V_RETCODE,
                    V_RETSUBCODE,
                    V_RETERRFLG);

  V_RETCODE    := '40275';
  V_RETSUBCODE := '001';
  V_RETERRFLG  := 'I';
  V_MSG        := '程序执行结束';
  SP_WRITEDETAILLOG(V_WORK_DATE,
                    V_JOBID,
                    V_OPERID,
                    V_MSG,
                    V_RETCODE,
                    V_RETSUBCODE,
                    V_RETERRFLG);

  ON_RESULT := 0;

  /*异常处理*/
EXCEPTION
  WHEN OTHERS THEN
    V_RETERRFLG := 'E';
    V_RETCODE   := V_ERRCODE;
    V_MSG       := 'SQLCODE:' || V_TABNAME || '表' ||
                   SUBSTR(SQLERRM, 1, 500);
    ON_RESULT   := SQLCODE;
    ROLLBACK;
    SP_WRITEDETAILLOG(V_WORK_DATE,
                      V_JOBID,
                      V_OPERID,
                      V_MSG,
                      V_RETCODE,
                      V_RETSUBCODE,
                      V_RETERRFLG);
    RETURN;
END;

/

