create PROCEDURE PRC_04_IC
(
	S_DATE    VARCHAR,
	E_DATE    VARCHAR,
	CALC_TYPE INT,
	RETCODE   OUT INT,
	RETMSG    OUT VARCHAR
)
/* 过程、函数简要描述信息
  **********************************************************
  *  存储过程名:  指标计算
  *  建立日期  :  2013-03-20
  *  作者      :  linyd
  *  模块      :  指标计算
  *  功能描述  :  指标计算存储过程集合
  *  输入参数  ： s_date 处理日期,e_date 处理结束日期,flow_id流水
  *               calc_type 计算类型：10为当日业绩计算，20为外部回算，30为内部回算
  *  输出参数  ： RETCODE 0为正确1为错误， RETMSG错误信息
  *  来源表    ：
  *  目标表    :
  *   备注     ：存储过程名 PRC_01_AD
  *------------------------------------------------------------
  *  修改历史
  *  序号    日期      修改人      修改原因
  ************************************************************ */
 IS
	RECORD_TIME TIMESTAMP;
	FLOW_ID     VARCHAR2(32);
	P_STEP_ID   VARCHAR2(30);
	STEP_ID     VARCHAR2(30);
BEGIN
	FLOW_ID := FNC_GEN_FLOW_ID();
	STEP_ID := 'LYD_04_IC_';

	--指标计算存储过程集合
	RECORD_TIME := SYSDATE;
	P_STEP_ID   := STEP_ID || '01';
	PRC_20_IC_CTL(S_DATE, E_DATE, 0, RETCODE, RETMSG);
	IF RETCODE <> 0
		 OR RETCODE IS NULL THEN
		RETMSG := '指标计算存储过程集合-执行出错';
		PRC_SYS_MONITOR_LOG(FLOW_ID,
												S_DATE,
												E_DATE,
												P_STEP_ID,
												RECORD_TIME,
												'prc_20_ic_ctl',
												4,
												RETMSG,
												'',
												RECORD_TIME,
												1);
		ROLLBACK;
		RETURN;
	ELSE
		RETMSG := '指标计算存储过程集合-执行成功';
		PRC_SYS_MONITOR_LOG(FLOW_ID,
												S_DATE,
												E_DATE,
												P_STEP_ID,
												RECORD_TIME,
												'prc_20_ic_ctl',
												1,
												RETMSG,
												'',
												RECORD_TIME,
												1);
	END IF;

EXCEPTION
	WHEN OTHERS THEN
		ROLLBACK;
		RETCODE := -1;
		RETMSG  := '指标计算存储过程集合-执行错误-' || SQLERRM;
		PRC_SYS_MONITOR_LOG(FLOW_ID,
												S_DATE,
												E_DATE,
												P_STEP_ID,
												RECORD_TIME,
												'PRC_04_IC',
												4,
												RETMSG,
												'',
												RECORD_TIME,
												1);
END;

/

