create FUNCTION FNC_INS_RE_I4 (P_TABLE VARCHAR)
/* 过程、函数简要描述信息
  **********************************************************
  *  存储过程名:  插入语句生成函数
  *  建立日期  :  2013-03-20
  *  作者      :  linyd
  *  模块      :
  *  功能描述  :
  *  输入参数  ： P_TABLE 来源表
  *               P_RECALC 计算类型：10为当日业绩计算，20为外部回算，30为内部回算
  *  输出参数  ： RETCODE 0为正确1为错误， RETMSG错误信息
  *  来源表    ： OP_AS_RT_DICT_FIELD  OP_AS_RT_DICT_TABLE
  *  目标表    :
  *   备注     ：
  *------------------------------------------------------------
  *  修改历史
  *  序号    日期      修改人      修改原因
  ************************************************************ */
RETURN VARCHAR IS
INSSQL VARCHAR(4000) ;
S_POS SMALLINT DEFAULT 1;
E_POS SMALLINT ;
CNT INT;
BEGIN
  --判断表是否可用
  SELECT COUNT(1) INTO CNT FROM OP_AS_RT_DICT_TABLE WHERE INS_TABLE_CODE=UPPER(P_TABLE) AND ENABLE = 1;
  IF CNT <=0 THEN
    RETURN NULL;
  END IF ;

  SELECT MAX(SNO) INTO E_POS FROM OP_AS_RT_DICT_FIELD WHERE INS_TABLE_CODE=UPPER(P_TABLE) AND IS_SUM=0;
  INSSQL := '#';
  WHILE(S_POS<=E_POS) LOOP
   SELECT COUNT(1) INTO CNT FROM OP_AS_RT_DICT_FIELD WHERE INS_TABLE_CODE=UPPER(P_TABLE) AND SNO = S_POS AND INS_ENABLE = 1 AND IS_SUM=0;
    IF CNT > 0 THEN
      SELECT INSSQL||','||INS_FIELD_CODE INTO INSSQL FROM OP_AS_RT_DICT_FIELD WHERE INS_TABLE_CODE =UPPER(P_TABLE) AND SNO = S_POS;
    END IF;
    S_POS := S_POS + 1;
  END LOOP;
  INSSQL := REPLACE(INSSQL,'#,','');
  INSSQL :='INSERT /*+APPEND*/ INTO RE_'||UPPER(P_TABLE)||' NOLOGGING (' ||INSSQL;
  INSSQL := INSSQL || ',TAR_DATE) ';
  RETURN INSSQL;
END
;

/

