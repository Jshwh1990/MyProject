create PROCEDURE SP_OP_AS_AR_SA_FLOW(IV_JOBID  IN VARCHAR2,
                                                IV_OPERID IN VARCHAR2,
                                                ON_RESULT OUT NUMBER)
--*******************************************************************************
  -- CopyRight (c) 2018, 融丰银行                                               *
  -- All rights reserved.                                                       *
  --                                                                            *
  -- 文件名称 : SP_OP_AS_AR_SA_FLOW.prc                                     *
  -- 摘    要 : A03_个人流水分配表表加载                                          *
  -- 工程模块 : crmapp.04_27                                                    *
  -- 当前版本 : V1.0.0                                                          *
  -- 作    者 :  lyh                                                            *
  -- 完成日期 : 2018/01/25                                                      *
  -- 错误码段 : 40270 - 40279                                                   *
  --*****************************************************************************
 IS
  V_WORK_DATE  VARCHAR2(8);
  V_RETCODE    VARCHAR2(6) := '000000'; --程序/日志返回码
  V_MSG        VARCHAR2(1000); --程序执行信息
  V_TABNAME    VARCHAR2(100); --表名
  V_RETERRFLG  VARCHAR2(1); --日志标志 I(information) W(waring) E(error)
  V_ERRCODE    VARCHAR2(10) := '40279'; --程序执行出错返回码
  V_RETSUBCODE VARCHAR2(3); --程序子返回码
BEGIN

  /*获得业务时间及相关参数*/
  SELECT WORK_DATE INTO V_WORK_DATE FROM SYS_PARA_DATE_NEW;

  V_RETCODE    := '40270';
  V_RETSUBCODE := '001';
  V_RETERRFLG  := 'I';
  V_MSG        := '程序执行开始';
  SP_WRITEDETAILLOG(V_WORK_DATE,
                    IV_JOBID,
                    IV_OPERID,
                    V_MSG,
                    V_RETCODE,
                    V_RETSUBCODE,
                    V_RETERRFLG);

  V_RETCODE    := '40271';
  V_TABNAME    := 'OP_AS_AR_SA_FLOW';
  V_RETERRFLG  := 'I';
  V_RETSUBCODE := '001';
  /*清空个人流水分配表表*/
  /*清空表分区*/
  DELETE FROM OP_AS_AR_SA_FLOW T
   WHERE T.OP_TYPE = '0'
     --and t.start_date = to_date(V_WORK_DATE, 'yyyymmdd')
     ;
  COMMIT;
  /*写日志*/
  V_MSG := V_TABNAME || '表记录成功清除';
  SP_WRITEDETAILLOG(V_WORK_DATE,
                    IV_JOBID,
                    IV_OPERID,
                    V_MSG,
                    V_RETCODE,
                    V_RETSUBCODE,
                    V_RETERRFLG);

  V_RETCODE := '40272';
  /*加载数据到个人流水分配表表*/
  INSERT /*+APPEND*/
  INTO OP_AS_AR_SA_FLOW NOLOGGING
    (id, --分配序号                            
     res_id, --分配资源id                          
     area_no, --区域号                              
     res_name, --资源名称                            
     res_org, --资源机构号                          
     res_prd, --资源产品                            
     cust_no, --客户号                              
     cust_name, --客户名称                            
     open_org, --开户机构                            
     al_way, --分配方式: 1按比例分配 2按金额分配   
     al_in, --分配对象                            
     start_date, --开始日期                            
     end_date, --结束日期                            
     al_rate, --分配比率                            
     start_amt, --开始额度                            
     end_amt, --结束额度                            
     status, --生效状态                            
     orderby, --顺序号                              
     modify_date, --修改日期                            
     operator, --修改操作员                          
     al_row_rate, --原始分配比例                        
     al_factor, --分配系数                            
     is_small_co, --是否小微客户                        
     op_type --分配类型：0批量跑进去的，1：手工分配 
     )
  
    SELECT SYS_GUID(),
           t.SERIALID,
           100,
           '',
           t.BRANCH,
           '',
           '',
           '',
           t.BRANCH,
           1,
           t.TELLER,
           to_date(substr(t.STARTTIME, 1, 8), 'yyyymmdd'),
           to_date('99991231', 'yyyymmdd'),
           100,
           0,
           0,
           1,
           1,
           to_date(t.BUSINESSDATE, 'yyyymmdd'),
           t.TELLER,
           100,
           1,
           'N',
           '0'
      FROM A_CNT_TWFT_TRADERECORDS t
      JOIN SYS_EMPLOYEE B
        ON t.teller = B.EMP_NO --因为表A_CMS_TBL_ORG_USER中的部分JOB_NUMBER与员工表中的EMP_NO对应不起来，所以找不到员工所在的机构，导致I3层数据比I4层金额多
    --现在只取可以关联到的员工
      JOIN SYS_ORGANIZATION C --因为人员所在的机构比机构表中的机构多，会造成I3层数据比I4层金额多
    --现在只取可以关联到机构的员工
        ON B.ORG_NO = C.ORG_NO
     --where t.businessdate = V_WORK_DATE
     ;

  COMMIT;
  V_MSG := V_TABNAME || '成功写入' || SQL%ROWCOUNT || '条记录';
  COMMIT;

  /*写日志*/
  SP_WRITEDETAILLOG(V_WORK_DATE,
                    IV_JOBID,
                    IV_OPERID,
                    V_MSG,
                    V_RETCODE,
                    V_RETSUBCODE,
                    V_RETERRFLG);

  V_RETCODE    := '40275';
  V_RETSUBCODE := '001';
  V_RETERRFLG  := 'I';
  V_MSG        := '程序执行结束';
  SP_WRITEDETAILLOG(V_WORK_DATE,
                    IV_JOBID,
                    IV_OPERID,
                    V_MSG,
                    V_RETCODE,
                    V_RETSUBCODE,
                    V_RETERRFLG);

  ON_RESULT := 0;
  /*异常处理*/
EXCEPTION
  WHEN OTHERS THEN
    V_RETERRFLG := 'E';
    V_RETCODE   := V_ERRCODE;
    V_MSG       := 'SQLCODE:' || V_TABNAME || '表' ||
                   SUBSTR(SQLERRM, 1, 500);
    ON_RESULT   := SQLCODE;
    ROLLBACK;
    SP_WRITEDETAILLOG(V_WORK_DATE,
                      IV_JOBID,
                      IV_OPERID,
                      V_MSG,
                      V_RETCODE,
                      V_RETSUBCODE,
                      V_RETERRFLG);
    RETURN;
END;
/

