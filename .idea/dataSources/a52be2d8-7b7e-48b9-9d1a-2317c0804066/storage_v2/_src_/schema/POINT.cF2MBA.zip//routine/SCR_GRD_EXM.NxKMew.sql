create FUNCTION SCR_GRD_EXM(L_VALUE  NUMBER
                                      ,L_SCORE  NUMBER
                                      ,H_VALUE  NUMBER
                                      ,H_SCORE  NUMBER
                                      ,P_EXPSTR VARCHAR
                                      ,P_VALUE  NUMBER) RETURN NUMBER IS
  /* 过程、函数简要描述信息
  **********************************************************
  *  存储过程名:  分级考核法
  *  建立日期  :  2013-03-20
  *  作者      :  linyd
  *  模块      :  评分模型
  *  功能描述  :  分级考核法
  *  输入参数  ：
  *  输出参数  ：
  *  来源表    ：
  *  目标表    :
  *   备注     ：
  *------------------------------------------------------------
  *  修改历史
  *  序号    日期      修改人      修改原因
  ************************************************************ */
  O_VAL       NUMBER(12, 2);
  T_EXPSTRSEG VARCHAR(4000);
  LOOP_POS    INT DEFAULT 0;
  POS         INT;
  POS_SEG_NEW INT DEFAULT 0;
  POS_SEG_OLD INT DEFAULT 1;
  START_VALUE NUMBER(20, 4);
  END_VALUE   NUMBER(20, 4);
  SCORE_VALUE NUMBER(12, 4);
  --P_EXPSTR    VARCHAR(200);
BEGIN
  IF (P_VALUE < L_VALUE) THEN
    --低于值
    O_VAL := L_SCORE;
  ELSIF (P_VALUE >= H_VALUE) THEN
    --高于值
    O_VAL := H_SCORE;
  ELSIF (P_VALUE IS NOT NULL) OR (P_EXPSTR IS NOT NULL) THEN
    --落在区间
    WHILE (LOOP_POS <= LENGTH(P_EXPSTR)) LOOP
      POS_SEG_NEW := INSTR(P_EXPSTR, ';', POS_SEG_OLD);
      IF (POS_SEG_NEW > 0) THEN
        T_EXPSTRSEG := SUBSTR(P_EXPSTR,
                              POS_SEG_OLD,
                              POS_SEG_NEW - POS_SEG_OLD);
        POS_SEG_OLD := POS_SEG_NEW + 1;
        LOOP_POS    := POS_SEG_OLD;

        START_VALUE := TO_NUMBER(SUBSTR(T_EXPSTRSEG,
                                        INSTR(T_EXPSTRSEG, ',', 1) + 1,
                                        INSTR(T_EXPSTRSEG, ',', 2) - 1));
        POS         := INSTR(T_EXPSTRSEG, ',') + 1;
        T_EXPSTRSEG := SUBSTR(T_EXPSTRSEG, POS);
        END_VALUE   := TO_NUMBER(SUBSTR(T_EXPSTRSEG,
                                        INSTR(T_EXPSTRSEG, ',', 1) + 1,
                                        INSTR(T_EXPSTRSEG, ',', 2) - 1));
        POS         := INSTR(T_EXPSTRSEG, ',') + 1;
        T_EXPSTRSEG := SUBSTR(T_EXPSTRSEG, POS);
        SCORE_VALUE := TO_NUMBER(SUBSTR(T_EXPSTRSEG,
                                        INSTR(T_EXPSTRSEG, ',', 1) + 1));
        IF (P_VALUE >= START_VALUE AND
           (P_VALUE < END_VALUE OR END_VALUE IS NULL)) THEN
          O_VAL    := SCORE_VALUE;
          LOOP_POS := LENGTH(P_EXPSTR) + 1;
        END IF;
      ELSE
        LOOP_POS := LENGTH(P_EXPSTR) + 1;
      END IF;
    END LOOP;
  ELSE
    O_VAL := NULL;
  END IF;
  RETURN O_VAL;
END;

/

