create FUNCTION SCR_SCORE_PARAM_VALUE(calc_score IN NUMBER,
                                                 APPLY_TYPE IN VARCHAR2)
  RETURN NUMBER IS
  /* 过程、函数简要描述信息
  **********************************************************
  *  存储过程名:  计算分数的区间值
  *  建立日期  :  2018-04-16
  *  作者      :  贾军鹏
  *  模块      :  评分模型
  *  功能描述  :  计算分数的区间值
  *  输入参数  ：
  *  输出参数  ：
  *  来源表    ：
  *  目标表    :
  *   备注     ：
  *------------------------------------------------------------
  *  修改历史
  *  序号    日期      修改人      修改原因
  ************************************************************ */
  O_VAL             NUMBER(12, 2);
  v_calc_score      NUMBER(12, 2) := calc_score;
  V_APPLY_TYPE      VARCHAR2(2) := APPLY_TYPE;
  V_MAX_PARAM_VALUE NUMBER(12, 2);
  V_MAX_PARAM_END   NUMBER(12, 2);
  --MO_PARAM_MANAGE  PARAM_VALUE

BEGIN
  IF (calc_score = '' OR calc_score IS NULL) THEN

    v_calc_score := 0;

  END IF;

  SELECT MAX(PARAM_END), max(PARAM_VALUE)
    into V_MAX_PARAM_END, V_MAX_PARAM_VALUE
    FROM MO_PARAM_MANAGE
   where apply_type = V_APPLY_TYPE;

  if calc_score >= V_MAX_PARAM_END then
    O_VAL := V_MAX_PARAM_VALUE;
  else
    select t.param_value
      INTO O_VAL
      from MO_PARAM_MANAGE t
     where t.apply_type = V_APPLY_TYPE
       and t.param_start <= v_calc_score
       and t.param_end > v_calc_score;
  end if;
  RETURN O_VAL;
END;

/

