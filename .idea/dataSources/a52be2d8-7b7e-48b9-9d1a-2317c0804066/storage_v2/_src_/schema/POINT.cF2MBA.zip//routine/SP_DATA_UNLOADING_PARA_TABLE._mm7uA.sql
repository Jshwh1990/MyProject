create PROCEDURE SP_DATA_UNLOADING_PARA_TABLE(IV_JOBID  IN VARCHAR2,
                                                         IV_OPERID IN VARCHAR2,
                                                         ON_RESULT OUT INT) IS
  --*****************************************************************************
  -- CopyRight (c) 2017, 泸州市商业银行                                         *
  -- All rights reserved.                                                       *
  --                                                                            *
  -- 文件名称 : SP_DATA_STORAGE                                                 *
  -- 摘    要 : 定期优化数据，数据表备份数据。                                  *
  -- 工程模块 :                                                                 *
  -- 当前版本 : V1.0.0                                                          *
  -- 作    者 : sqs                                                             *
  -- 完成日期 : 2017/04/14                                                      *
  -- 错误码段 :                                                                 *
  --*****************************************************************************
  IV_DATE    VARCHAR2(8);
  P_SQL      VARCHAR2(1000);
  V_DATENAME DATE;
  --V_NUMBER   NUMBER;
  V_MINDAY           DATE;
  V_DATECHAR         VARCHAR2(8);
  V_PARTNAME         VARCHAR2(50);
  V_LAST_PART        VARCHAR2(20);
  V_EXP_YD           VARCHAR2(200);
  ROW_DATA_UNLOADING DATA_UNLOADING_PARA_TABLE%ROWTYPE;

  CURSOR CUR_DATA_UNLOADING IS
    SELECT TABLE_NAME,
           STORAGE_TYPE,
           STORAGE_CYCLE_DAY,
           MTD_FLAG,
           STORAGE_DAY_NUM,
           BAK_TABLE_NAME,
           DATE_NAME_COLUMN,
           UPDATE_DATE,
           SX_FLAG
      FROM DATA_UNLOADING_PARA_TABLE
     WHERE SX_FLAG = 'Y'
     ORDER BY TABLE_NAME;

BEGIN
  P_SQL := NULL;

  --ON_RESULT := 0;
  --RETURN;

  SELECT A.WORK_DATE INTO IV_DATE FROM SYS_PARA_DATE_NEW A;
  --清理日志表信息
  DELETE FROM DATA_UNLOADING_CHECK A WHERE A.RUN_DATE = IV_DATE;
  COMMIT;

  V_DATECHAR := IV_DATE;
  /*  --周六时间判断，不是周六数据不处理
  IF TRIM(TO_CHAR(TO_DATE(IV_DATE, 'YYYYMMDD'), 'day')) <> '星期六' AND
     TRIM(TO_CHAR(TO_DATE(IV_DATE, 'YYYYMMDD'), 'day')) <> 'saturday' THEN
    ON_RESULT := 0;
    RETURN;
  END IF;*/

  OPEN CUR_DATA_UNLOADING;
  LOOP
    FETCH CUR_DATA_UNLOADING
      INTO ROW_DATA_UNLOADING;
    EXIT WHEN CUR_DATA_UNLOADING%NOTFOUND;
    --日志表插入数据
    INSERT INTO DATA_UNLOADING_CHECK
      (RUN_DATE, TABLE_NAME, START_TIME)
    VALUES
      (IV_DATE, ROW_DATA_UNLOADING.TABLE_NAME, SYSDATE);
    COMMIT;

    --非分区表
    IF ROW_DATA_UNLOADING.STORAGE_TYPE = 'NP' THEN

      --最大清理日期
      V_DATENAME := TO_DATE(IV_DATE, 'YYYYMMDD') -
                    ROW_DATA_UNLOADING.STORAGE_DAY_NUM;

      V_EXP_YD := NULL;
      IF ROW_DATA_UNLOADING.MTD_FLAG = 'Y' THEN
        V_EXP_YD := ' AND ' || ROW_DATA_UNLOADING.DATE_NAME_COLUMN ||
                    ' <> TO_CHAR(LAST_DAY(TO_DATE(' ||
                    ROW_DATA_UNLOADING.DATE_NAME_COLUMN ||
                    ', ''YYYYMMDD'')), ''YYYYMMDD'')';
      END IF;
      --判断表中是否存在对应日期的记录，如果存在，则删除
      LOOP
        --获取原表中最小日期
        P_SQL := 'SELECT TO_DATE(MIN(' ||
                 ROW_DATA_UNLOADING.DATE_NAME_COLUMN ||
                 ' ),''YYYYMMDD'') FROM ' || ROW_DATA_UNLOADING.TABLE_NAME ||
                 ' WHERE ' || ROW_DATA_UNLOADING.DATE_NAME_COLUMN ||
                 ' < ''' || TO_CHAR(V_DATENAME, 'YYYYMMDD') || '''' ||
                 V_EXP_YD;
        EXECUTE IMMEDIATE P_SQL
          INTO V_MINDAY;
        EXIT WHEN V_MINDAY >= V_DATENAME OR V_MINDAY IS NULL;

        V_DATECHAR := TO_CHAR(V_MINDAY, 'YYYYMMDD');

        --判断是否保留月末数据且最小日期小于清理日期
        IF ((ROW_DATA_UNLOADING.MTD_FLAG = 'Y' AND
           V_DATECHAR <> TO_CHAR(LAST_DAY(V_MINDAY), 'YYYYMMDD')) OR
           ROW_DATA_UNLOADING.MTD_FLAG = 'N') AND V_MINDAY < V_DATENAME THEN
          --删除数据
          P_SQL := 'DELETE FROM ' || ROW_DATA_UNLOADING.TABLE_NAME ||
                   ' WHERE ' || ROW_DATA_UNLOADING.DATE_NAME_COLUMN ||
                   ' = ''' || V_DATECHAR || '''';
          --日志表操作记录更新
          UPDATE DATA_UNLOADING_CHECK
             SET REMARK = P_SQL
           WHERE RUN_DATE = IV_DATE
             AND TABLE_NAME = ROW_DATA_UNLOADING.TABLE_NAME;
          COMMIT;

          EXECUTE IMMEDIATE P_SQL;
          COMMIT;
        END IF;
      END LOOP;

      ON_RESULT := 0;

      --分区表
    ELSIF ROW_DATA_UNLOADING.STORAGE_TYPE = 'YP' THEN

      --获取分区表的分区名称，存储空间名称
      P_SQL := 'SELECT DISTINCT SUBSTR(A.PARTITION_NAME, 1, LENGTH(A.PARTITION_NAME)-8)' ||
               ' FROM USER_TAB_PARTITIONS A WHERE A.TABLE_NAME = UPPER(''' ||
               ROW_DATA_UNLOADING.TABLE_NAME || ''')';
      EXECUTE IMMEDIATE P_SQL
        INTO V_PARTNAME;

      --最大清理日期
      V_DATENAME  := TO_DATE(IV_DATE, 'YYYYMMDD') -
                     ROW_DATA_UNLOADING.STORAGE_DAY_NUM;
      V_LAST_PART := V_PARTNAME || TO_CHAR(V_DATENAME, 'YYYYMMDD');

      V_EXP_YD := NULL;
      IF ROW_DATA_UNLOADING.MTD_FLAG = 'Y' THEN
        V_EXP_YD := ' AND SUBSTR(PARTITION_NAME, 3) <> TO_CHAR(LAST_DAY(TO_DATE(SUBSTR(PARTITION_NAME, 3), ''YYYYMMDD'')), ''YYYYMMDD'')';
      END IF;
      --获取数据表中最小业务日期
      P_SQL := 'SELECT TO_DATE(MIN(SUBSTR(PARTITION_NAME, 3)), ''YYYYMMDD'') FROM USER_TAB_PARTITIONS WHERE TABLE_NAME = UPPER(''' ||
               ROW_DATA_UNLOADING.TABLE_NAME ||
               ''') AND PARTITION_NAME < ''' || V_LAST_PART || '''' ||
               V_EXP_YD;
      EXECUTE IMMEDIATE P_SQL
        INTO V_MINDAY;

      LOOP
        EXIT WHEN V_MINDAY >= V_DATENAME OR V_MINDAY IS NULL;
        V_DATECHAR  := TO_CHAR(V_MINDAY, 'YYYYMMDD');
        V_LAST_PART := V_PARTNAME || V_DATECHAR;
        --判断是否保留月末数据且最小日期小于清理日期
        IF ((ROW_DATA_UNLOADING.MTD_FLAG = 'Y' AND
           V_DATECHAR <> TO_CHAR(LAST_DAY(V_MINDAY), 'YYYYMMDD')) OR
           ROW_DATA_UNLOADING.MTD_FLAG = 'N') AND V_MINDAY < V_DATENAME THEN
          P_SQL := 'ALTER TABLE ' || ROW_DATA_UNLOADING.TABLE_NAME ||
                   ' DROP PARTITION ' || V_PARTNAME || V_DATECHAR;
          --日志表操作记录更新
          UPDATE DATA_UNLOADING_CHECK
             SET REMARK = P_SQL
           WHERE RUN_DATE = IV_DATE
             AND TABLE_NAME = ROW_DATA_UNLOADING.TABLE_NAME;
          COMMIT;
          EXECUTE IMMEDIATE P_SQL;
        END IF;

        --获取数据表中最小业务日期
        P_SQL := 'SELECT TO_DATE(MIN(SUBSTR(PARTITION_NAME, 3)), ''YYYYMMDD'') FROM USER_TAB_PARTITIONS WHERE TABLE_NAME = UPPER(''' ||
                 ROW_DATA_UNLOADING.TABLE_NAME ||
                 ''') AND PARTITION_NAME > ''' || V_LAST_PART || '''' ||
                 V_EXP_YD;
        EXECUTE IMMEDIATE P_SQL
          INTO V_MINDAY;
      END LOOP;

    END IF;
    --日志表结束时间更新
    UPDATE DATA_UNLOADING_CHECK
       SET END_TIME = SYSDATE
     WHERE RUN_DATE = IV_DATE
       AND TABLE_NAME = ROW_DATA_UNLOADING.TABLE_NAME;
    COMMIT;
  END LOOP;
  CLOSE CUR_DATA_UNLOADING;

  ON_RESULT := 0;

EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    ON_RESULT := '' || SQLCODE;
    ON_RESULT := SQLERRM;
    SP_WRITEDETAILLOG(V_DATECHAR,
                      IV_JOBID,
                      IV_OPERID,
                      P_SQL,
                      ON_RESULT,
                      '1',
                      '1');
    RETURN;
END;

/

