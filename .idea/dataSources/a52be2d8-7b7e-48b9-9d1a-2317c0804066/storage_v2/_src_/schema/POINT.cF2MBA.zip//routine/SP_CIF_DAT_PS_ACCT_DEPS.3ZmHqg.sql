create PROCEDURE SP_CIF_DAT_PS_ACCT_DEPS(IV_JOBID  IN VARCHAR2,
                                                    IV_OPERID IN VARCHAR2,
                                                    ON_RESULT OUT NUMBER)
--*******************************************************************************
  -- CopyRight (c) 2018, 融丰银行                                               *
  -- All rights reserved.                                                       *
  --                                                                            *
  -- 文件名称 : SP_NEW_CIF_DAT_PS_ACCT_DEPS.prc                                 *
  -- 摘    要 : A03_个人存款数据表加载                                          *
  -- 工程模块 : crmapp.04_27                                                    *
  -- 当前版本 : V1.0.0                                                          *
  -- 作    者 :                                                              *
  -- 完成日期 : 2018/1/24                                                       *
  -- 错误码段 : 40270 - 40279                                                   *
  --*****************************************************************************
 IS
  V_WORK_DATE VARCHAR2(8);
  --TO_WORK_DATE DATE;
  V_RETCODE    VARCHAR2(6) := '000000'; --程序/日志返回码
  V_MSG        VARCHAR2(1000); --程序执行信息
  V_TABNAME    VARCHAR2(100); --表名
  V_RETERRFLG  VARCHAR2(1); --日志标志 I(information) W(waring) E(error)
  V_ERRCODE    VARCHAR2(10) := '40279'; --程序执行出错返回码
  V_RETSUBCODE VARCHAR2(3); --程序子返回码
BEGIN

  /*获得业务时间及相关参数*/
  SELECT WORK_DATE INTO V_WORK_DATE FROM SYS_PARA_DATE_NEW;
  --TO_WORK_DATE := TO_DATE(V_WORK_DATE, 'YYYYMMDD');

  V_RETCODE    := '40270';
  V_RETSUBCODE := '001';
  V_RETERRFLG  := 'I';
  V_MSG        := '程序执行开始';
  SP_WRITEDETAILLOG(V_WORK_DATE,
                    IV_JOBID,
                    IV_OPERID,
                    V_MSG,
                    V_RETCODE,
                    V_RETSUBCODE,
                    V_RETERRFLG);

  V_RETCODE    := '40271';
  V_TABNAME    := 'CIF_DAT_PS_ACCT_DEPS';
  V_RETERRFLG  := 'I';
  V_RETSUBCODE := '001';
  /*清空个人存款数据表*/
  EXECUTE IMMEDIATE 'TRUNCATE TABLE CIF_DAT_PS_ACCT_DEPS';

  /*写日志*/
  V_MSG := V_TABNAME || '表记录成功清除';
  SP_WRITEDETAILLOG(V_WORK_DATE,
                    IV_JOBID,
                    IV_OPERID,
                    V_MSG,
                    V_RETCODE,
                    V_RETSUBCODE,
                    V_RETERRFLG);

  V_RETCODE := '40272';
  /*加载数据到个人存款数据表*/
  --加载核心活期
  INSERT /*+APPEND*/
  INTO CIF_DAT_PS_ACCT_DEPS NOLOGGING
    (ACCT_NO, --账号
     MAIN_ACCT_NO, --主账号
     AC_SEQ,
     TAR_DATE, --指标日期
     AREA_NO, --区域号
     BIZ_CUST_NO, --原业务系统客户号
     ACCT_NAME, --户名
     ACCT_TYPE, --账户类型
     ACCT_STATE, --账户状态
     CURRENCY, --币种
     TERM, --存期
     SUBJ_CODE, --科目
     PRD_CODE, --产品代码
     OPEN_DATE, --开户日期
     OPEN_ORG, --开户机构
     END_DATE, --到期日期
     LAST_TRD_DATE, --上笔业务活动日期
     BAL, --余额
     BAL_AVG_M, --月日均余额
     BAL_LAST, --昨日余额
     BAL_AVG_Y, --年日均余额
     BAL_M_H, --当月最高余额
     BAL_STATIC_Y, --当年存量余额
     BAL_ADD_Y, --当年增量余额
     BAL_LAST_Y, --上年末余额
     BAL_LAST_AVG_Y, --上年末日均
     RATE, --利率
     RATE_FTP, --FTP价格
     BAL_PROFIT, --模拟利润
     BAL_FEE, --营销费用
     AMT_D_Y, --借方发生额(年)
     AMT_C_Y, --贷方发生额(年)
     STAT_TIME, --统计日期
     IS_NEW, --是否新增客户数
     CUST_LVL, --客户级别
     IS_SMALL_CO, --是否小微企业
     WHE_SPEC_LINE, --特殊标志
     YA_INT_EPS_AMT, --年累计利息支出
     SUB_ACCT_NO, --子账户序号
     CD_INT_EPS_AMT, --当日利息支出
     DEPS_TYPE)
    SELECT A.AC_ID || A.AC_SEQN acct_no, --账号
           NVL(REL.AC_NO, REL_NEW.AC_NO) MAIN_ACCT_NO, --主账号（主卡为空的时候取副卡）
           A.AC_SEQN,
           V_WORK_DATE tar_date, --指标日期
           100 area_no, --区域号
           A.CIF_NO biz_cust_no, --原业务系统客户号
           B.NAME acct_name, --户名
           A.AC_TYPE acct_type, --账户类型
           A.AC_STS acct_state, --账户状态
           A.CUR_NO currency, --币种
           0 term, --存期
           d.acc_no subj_code, --科目
           A.PRDT_NO prd_code, --产品代码
           (CASE
             WHEN A.OPN_DATE = 0 THEN
              '19001231'
             WHEN A.OPN_DATE = 99999999 THEN
              '99991231'
             ELSE
              TO_CHAR(A.OPN_DATE)
           END) open_date, --开户日期
           A.OPN_BR_NO open_org, --开户机构
           (CASE
             WHEN A.VAL_DATE = 0 THEN
              '99991231'
             WHEN A.VAL_DATE = 99999999 THEN
              '99991231'
             ELSE
              TO_CHAR(A.VAL_DATE)
           END) end_date, --到期日期
           TO_CHAR(A.LST_DATE) last_trd_date, --上笔业务活动日期
           A.BAL bal, --余额
           0 BAL_AVG_M, --月日均余额
           A.YS_BAL bal_last, --昨日余额
           0 bal_avg_y, --年日均余额
           0 bal_m_h, --当月最高余额
           0 bal_static_y, --当年存量余额
           0 bal_add_y, --当年增量余额
           0 bal_last_y, --上年末余额
           0 bal_last_avg_y, --上年末日均
           A. RATE rate, --利率
           0 rate_ftp, --ftp价格
           0 bal_profit, --模拟利润
           0 bal_fee, --营销费用
           0 amt_d_y, --借方发生额(年)
           0 amt_c_y, --贷方发生额(年)
           TO_DATE(V_WORK_DATE, 'YYYYMMDD') stat_time, --统计日期
           CUST.IS_NEW is_new, --是否当年新增客户
           NVL(B.CIF_LVL, 0) cust_lvl, --客户等级
           'N' is_small_co, --是否小微客户
           'N', --转存标志
           0 ya_int_eps_amt, --年累计利息支出
           A.AC_SEQN sub_acct_no, --子账户序号
           0 cd_int_eps_amt, --   当日利息支出
           '核心活期存款' DEPS_TYPE
      FROM A_CBS_DD_MST A --活期存款主文件（核心）
      LEFT JOIN A_CBS_CIF_BASIC_INF B
        ON A.CIF_NO = B.CIF_NO
      LEFT JOIN (SELECT T.AC_NO, T.AC_ID, T.AC_SEQN, T.NAME
                   FROM A_CBS_MDM_AC_REL T
                  WHERE T.MAIN_IND = '1' --主卡
                    AND (T.NOTE_STS = '0' or t.note_sts = '1' or
                        t.note_sts = '#' or t.note_sts = '*'
                        )) REL
        ON A.AC_ID = REL.AC_ID
      LEFT JOIN (SELECT T.AC_NO, T.AC_ID, T.AC_SEQN, T.NAME
                   FROM A_CBS_MDM_AC_REL T
                  WHERE T.MAIN_IND = '2' --副卡
                    AND (T.NOTE_STS = '0' or t.note_sts = '1' or
                        t.note_sts = '#'  )) REL_NEW
        ON A.AC_ID = REL_NEW.AC_ID
      LEFT JOIN v_subj_prodt D--取核心科目
        ON A.PRDT_NO = D.PRDT_NO
      LEFT JOIN CIF_DAT_PS_CUST CUST
        ON A.CIF_NO = CUST.CUST_NO
     WHERE A.CIF_NO LIKE '1%'
       and a.ac_sts <> '*' 
        and a.ac_sts <> '#' --计息结束和销户的数据余额均为0，不加载进来
    -- and a.opn_date <= V_WORK_DATE
    ;
  --客户号以‘1’开头即为个人存款，以其他数字开头即为对公存款
  commit;
  --加载核心定期
  INSERT /*+APPEND*/
  INTO CIF_DAT_PS_ACCT_DEPS NOLOGGING
    (ACCT_NO, --账号
     MAIN_ACCT_NO, --主账号
     AC_SEQ,
     TAR_DATE, --指标日期
     AREA_NO, --区域号
     BIZ_CUST_NO, --原业务系统客户号
     ACCT_NAME, --户名
     ACCT_TYPE, --账户类型
     ACCT_STATE, --账户状态
     CURRENCY, --币种
     TERM, --存期
     SUBJ_CODE, --科目
     PRD_CODE, --产品代码
     OPEN_DATE, --开户日期
     OPEN_ORG, --开户机构
     END_DATE, --到期日期
     LAST_TRD_DATE, --上笔业务活动日期
     BAL, --余额
     BAL_AVG_M, --月日均余额
     BAL_LAST, --昨日余额
     BAL_AVG_Y, --年日均余额
     BAL_M_H, --当月最高余额
     BAL_STATIC_Y, --当年存量余额
     BAL_ADD_Y, --当年增量余额
     BAL_LAST_Y, --上年末余额
     BAL_LAST_AVG_Y, --上年末日均
     RATE, --利率
     RATE_FTP, --FTP价格
     BAL_PROFIT, --模拟利润
     BAL_FEE, --营销费用
     AMT_D_Y, --借方发生额(年)
     AMT_C_Y, --贷方发生额(年)
     STAT_TIME, --统计日期
     IS_NEW, --是否新增客户数
     CUST_LVL, --客户级别
     IS_SMALL_CO, --是否小微企业
     WHE_SPEC_LINE, --特殊标志
     YA_INT_EPS_AMT, --年累计利息支出
     SUB_ACCT_NO, --子账户序号
     CD_INT_EPS_AMT, --当日利息支出
     DEPS_TYPE)
    SELECT A.AC_ID || A.AC_SEQN acct_no, --账号
           NVL(REL.AC_NO, REL_NEW.AC_NO) MAIN_ACCT_NO, --主账号（主卡为空的时候取副卡）
           A.AC_SEQN,
           V_WORK_DATE tar_date, --指标日期
           100 area_no, --区域号
           A.CIF_NO biz_cust_no, --原业务系统客户号
           C.NAME acct_name, --户名
           '1' acct_type, --账户类型
           A.AC_STS acct_state, --账户状态
           A.CUR_NO currency, --币种
           (CASE
             WHEN B.TERM_TYPE = 'Y' THEN
              B.TERM * 365
             WHEN B.TERM_TYPE = 'M' THEN
              B.TERM * 30
             ELSE
              NVL(B.TERM, 0)
           END) term, --存期
           d.acc_no subj_code, --科目
           A.PRDT_NO prd_code, --产品代码
           (CASE
             WHEN A.OPN_DATE = 0 THEN
              '19001231'
             WHEN A.OPN_DATE = 99999999 THEN
              '99991231'
             ELSE
              TO_CHAR(A.OPN_DATE)
           END) open_date, --开户日期
           A.OPN_BR_NO open_org, --开户机构
           (CASE
             WHEN A.MTR_DATE = 0 THEN
              '99991231'
             WHEN A.MTR_DATE = 99999999 THEN
              '99991231'
             ELSE
              TO_CHAR(A.MTR_DATE)
           END) end_date, --到期日期
           TO_CHAR(A.LST_DATE) last_trd_date, --上笔业务活动日期
           A.BAL bal, --余额
           0 al_avg_m, --月日均余额
           A.YS_BAL bal_last, --昨日余额
           0 bal_avg_y, --年日均余额
           0 bal_m_h, --当月最高余额
           0 bal_static_y, --当年存量余额
           0 bal_add_y, --当年增量余额
           0 bal_last_y, --上年末余额
           0 bal_last_avg_y, --上年末日均
           A.RATE rate, --利率
           0 rate_ftp, --ftp价格
           0 bal_profit, --模拟利润
           0 bal_fee, --营销费用
           0 amt_d_y, --借方发生额(年)
           0 amt_c_y, --贷方发生额(年)
           TO_DATE(V_WORK_DATE, 'YYYYMMDD') stat_time, --统计日期
           cust.is_new is_new, --是否新增客户
           NVL(C.CIF_LVL, 0) cust_lvl, --客户等级
           'N' is_small_co, --是否小微客户
           NVL(a.tfr_ind, 'N'), --转存标志
           0 ya_int_eps_amt, --年累计利息支出
           A.AC_SEQN sub_acct_no, --子账户序号
           0 cd_int_eps_amt, --   当日利息支出
           '核心定期存款' DEPS_TYPE
      FROM A_CBS_TD_MST A --定期存款主文件（核心）
      LEFT JOIN A_CBS_TD_PARM B
        ON A.PRDT_NO = B.PRDT_NO
      LEFT JOIN A_CBS_CIF_BASIC_INF C
        ON A.CIF_NO = C.CIF_NO
      LEFT JOIN (SELECT T.AC_NO, T.AC_ID, T.AC_SEQN, T.NAME
                   FROM A_CBS_MDM_AC_REL T
                  WHERE T.MAIN_IND = '1' --主卡
                    AND (T.NOTE_STS = '0' or t.note_sts = '1' or
                        t.note_sts = '#' or t.note_sts = '*'
                        )) REL
        ON A.AC_ID = REL.AC_ID
      LEFT JOIN (SELECT T.AC_NO, T.AC_ID, T.AC_SEQN, T.NAME
                   FROM A_CBS_MDM_AC_REL T
                  WHERE T.MAIN_IND = '2' --副卡
                    AND (T.NOTE_STS = '0' or t.note_sts = '1' or
                        t.note_sts = '#')) REL_NEW
        ON A.AC_ID = REL_NEW.AC_ID
      LEFT JOIN CIF_DAT_PS_CUST CUST
        ON A.CIF_NO = CUST.CUST_NO
      LEFT JOIN v_subj_prodt D --取核心科目
        ON A.PRDT_NO = D.PRDT_NO
     WHERE A.CIF_NO LIKE '1%'
       and a.ac_sts <> '*' 
    --and a.opn_date <= V_WORK_DATE
    ;
  --客户号以‘1’开头即为个人存款，以其他数字开头即为对公存款
  commit;

  V_TABNAME := 'CIF_DAT_PS_ACCT_DEPS';
  V_MSG     := V_TABNAME || '成功写入' || SQL%ROWCOUNT || '条记录';
  COMMIT;
  V_MSG := V_TABNAME || '成功写入' || SQL%ROWCOUNT || '条记录';
  COMMIT;

  /*写日志*/
  SP_WRITEDETAILLOG(V_WORK_DATE,
                    IV_JOBID,
                    IV_OPERID,
                    V_MSG,
                    V_RETCODE,
                    V_RETSUBCODE,
                    V_RETERRFLG);

  V_RETCODE := '40274';
  V_MSG     := V_TABNAME || '表成功写入数据';
  /*写日志*/
  V_RETSUBCODE := '001';
  SP_WRITEDETAILLOG(V_WORK_DATE,
                    IV_JOBID,
                    IV_OPERID,
                    V_MSG,
                    V_RETCODE,
                    V_RETSUBCODE,
                    V_RETERRFLG);

  V_RETCODE    := '40275';
  V_RETSUBCODE := '001';
  V_RETERRFLG  := 'I';
  V_MSG        := '程序执行结束';
  SP_WRITEDETAILLOG(V_WORK_DATE,
                    IV_JOBID,
                    IV_OPERID,
                    V_MSG,
                    V_RETCODE,
                    V_RETSUBCODE,
                    V_RETERRFLG);

  ON_RESULT := 0;
  /*异常处理*/
EXCEPTION
  WHEN OTHERS THEN
    V_RETERRFLG := 'E';
    V_RETCODE   := V_ERRCODE;
    V_MSG       := 'SQLCODE:' || V_TABNAME || '表' ||
                   SUBSTR(SQLERRM, 1, 500);
    ON_RESULT   := SQLCODE;
    ROLLBACK;
    SP_WRITEDETAILLOG(V_WORK_DATE,
                      IV_JOBID,
                      IV_OPERID,
                      V_MSG,
                      V_RETCODE,
                      V_RETSUBCODE,
                      V_RETERRFLG);
    RETURN;
END;
/

