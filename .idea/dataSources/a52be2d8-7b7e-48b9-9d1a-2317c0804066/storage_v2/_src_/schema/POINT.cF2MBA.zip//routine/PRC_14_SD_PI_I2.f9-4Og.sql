create PROCEDURE PRC_14_SD_PI_I2
(
  S_DATE    VARCHAR,
  E_DATE    VARCHAR,
  CALC_TYPE INT,
  RETCODE   OUT INT,
  RETMSG    OUT VARCHAR
)
/* 过程、函数简要描述信息
  **********************************************************
  *  存储过程名:  零售存款人员账户数据表生成
  *  建立日期  :  2013-03-20
  *  作者      :  linyd
  *  模块      :  业绩计算
  *  功能描述  :  业绩计算人员数据生成
  *  输入参数  ： s_date 处理日期,e_date 处理结束日期,flow_id流水
  *               calc_type 计算类型：10为当日业绩计算，20为外部回算，30为内部回算
  *  输出参数  ： RETCODE 0为正确1为错误， RETMSG错误信息
  *  来源表    ： OP_AS_AD_SA_DEPS 零售存款分配规则明细表， CIF_DAT_PS_ACCT_DEPS 零售存款数据表
  *  目标表    :  PI_I2_PS_DEPS 零售存款人员账户数据表
  *   备注     ：存储过程名 PRC_14_SD_PI_I2 里的14为跑批号，SD第1个S为零售，第2个D为存款业务类型号
  *------------------------------------------------------------
  *  修改历史
  *  序号    日期      修改人      修改原因
  ************************************************************ */
 IS
  P_SQL       LONG;
  STEP_ID     VARCHAR2(30);
  RECORD_TIME TIMESTAMP;
  P_STEP_ID   VARCHAR2(30);
  FLOW_ID     VARCHAR2(32);
  P_CNT       INT;
BEGIN
  FLOW_ID := FNC_GEN_FLOW_ID();
  STEP_ID := 'LYD_14_PI_I2_PS_DEPS_';

  --分配不足100的数据处理给虚拟客户经理
  RECORD_TIME := SYSDATE;
  RETMSG      := '分配不足100的数据处理-出错误';
  P_STEP_ID   := STEP_ID || '1_1';
  P_SQL       := 'MERGE INTO OP_AS_AD_SA_DEPS L1 ';
  P_SQL       := P_SQL ||
                 'USING (SELECT T1.RES_ID,T1.AREA_NO,T1.AL_TYPE,''PFM_'' || RES_ORG AL_IN,T1.START_DATE,T1.END_DATE, T1.AL_WAY,(100 - SUM(T1.AL_RATE)) AL_RATE,T1.START_AMT,T1.END_AMT,';
  P_SQL       := P_SQL || 'T1.RES_ORG ,T1.DEPS_TYPE,T1.MAIN_ACCT_NO,T1.AC_SEQ  FROM OP_AS_AD_SA_DEPS T1 ';
  P_SQL       := P_SQL ||
                 'GROUP BY T1.RES_ID,T1.AREA_NO,T1.AL_TYPE,T1.START_DATE,T1.END_DATE,T1.AL_WAY, T1.START_AMT, T1.END_AMT,T1.RES_ORG,T1.DEPS_TYPE,T1.MAIN_ACCT_NO,T1.AC_SEQ  HAVING SUM(T1.AL_RATE) < 100) L2';
  P_SQL       := P_SQL ||
                 ' ON (L1.RES_ID = L2.RES_ID AND L1.AL_IN =L2.AL_IN AND NVL(L1.START_AMT,0) = NVL(L2.START_AMT,0) AND NVL(L1.END_AMT,0) = NVL(L2.END_AMT,0) )';
  P_SQL       := P_SQL ||
                 ' WHEN MATCHED THEN UPDATE SET L1.AL_RATE =(NVL(L1.AL_RATE, 0) + NVL(L2.AL_RATE, 0)) WHEN NOT MATCHED THEN ';
  P_SQL       := P_SQL ||
                 'INSERT VALUES (SYS_GUID(),L2.RES_ID, L2.AREA_NO,L2.AL_TYPE,L2.AL_IN,L2.START_DATE,L2.END_DATE,L2.AL_WAY,L2.AL_RATE,L2.START_AMT,L2.END_AMT, L2.RES_ORG,L2.DEPS_TYPE,L2.MAIN_ACCT_NO,L2.AC_SEQ)';
  EXECUTE IMMEDIATE P_SQL;
  PRC_SYS_MONITOR_LOG(FLOW_ID,
                      S_DATE,
                      E_DATE,
                      P_STEP_ID,
                      RECORD_TIME,
                      'PRC_14_SD_PI_I2',
                      1,
                      '分配不足100的数据处理.[OP_AS_AD_SA_DEPS]',
                      P_SQL,
                      RECORD_TIME,
                      1);

  --分配规则明细表唯一性检查
  RECORD_TIME := SYSDATE;
  RETMSG      := '分配规则明细表唯一性检查-出错误';
  P_STEP_ID   := STEP_ID || '2_1';
  P_SQL       := 'SELECT COUNT(1) FROM (SELECT a.res_id,a.al_in,a.start_amt,a.end_amt FROM OP_AS_AD_SA_DEPS a GROUP BY a.res_id,a.al_in,a.start_amt,a.end_amt HAVING COUNT(1)>1) T';
  EXECUTE IMMEDIATE P_SQL
    INTO P_CNT;
  IF P_CNT > 0 THEN
    RETCODE := -1;
    PRC_SYS_MONITOR_LOG(FLOW_ID,
                        S_DATE,
                        E_DATE,
                        P_STEP_ID,
                        RECORD_TIME,
                        'PRC_14_SD_PI_I2',
                        4,
                        RETMSG,
                        P_SQL,
                        RECORD_TIME,
                        1);
    RETURN;
  END IF;
  PRC_SYS_MONITOR_LOG(FLOW_ID,
                      S_DATE,
                      E_DATE,
                      P_STEP_ID,
                      RECORD_TIME,
                      'PRC_14_SD_PI_I2',
                      1,
                      '分配规则明细表唯一性检查.[OP_AS_AD_SA_DEPS]',
                      P_SQL,
                      RECORD_TIME,
                      1);

  --来源表数据唯一性检查
  RECORD_TIME := SYSDATE;
  RETMSG      := '来源表数据唯一性检查-出错误';
  P_STEP_ID   := STEP_ID || '2_2';
  P_SQL       := 'SELECT COUNT(1) FROM (SELECT a.acct_no FROM CIF_DAT_PS_ACCT_DEPS a GROUP BY a.acct_no HAVING COUNT(1)>1) T';
  EXECUTE IMMEDIATE P_SQL
    INTO P_CNT;
  IF P_CNT > 0 THEN
    RETCODE := -1;
    PRC_SYS_MONITOR_LOG(FLOW_ID,
                        S_DATE,
                        E_DATE,
                        P_STEP_ID,
                        RECORD_TIME,
                        'PRC_14_SD_PI_I2',
                        4,
                        RETMSG,
                        P_SQL,
                        RECORD_TIME,
                        1);
    RETURN;
  END IF;
  PRC_SYS_MONITOR_LOG(FLOW_ID,
                      S_DATE,
                      E_DATE,
                      P_STEP_ID,
                      RECORD_TIME,
                      'PRC_14_SD_PI_I2',
                      1,
                      '来源表数据唯一性检查.[CIF_DAT_PS_ACCT_DEPS]',
                      P_SQL,
                      RECORD_TIME,
                      1);

  --删除已经存在的临时表
  RECORD_TIME := SYSDATE;
  RETMSG      := '删除已经存在的临时表-出错误';
  P_STEP_ID   := STEP_ID || '3_1';
  SELECT COUNT(1) INTO P_CNT FROM COLS WHERE UPPER(TABLE_NAME) = 'RE_PI_I2_PS_DEPS';
  IF P_CNT > 0 THEN
    P_SQL := 'DROP TABLE RE_PI_I2_PS_DEPS';
    EXECUTE IMMEDIATE P_SQL;
  END IF;
  PRC_SYS_MONITOR_LOG(FLOW_ID,
                      S_DATE,
                      E_DATE,
                      P_STEP_ID,
                      RECORD_TIME,
                      'PRC_14_SD_PI_I2',
                      1,
                      '删除已经存在的临时表.[RE_PI_I2_PS_DEPS]',
                      P_SQL,
                      RECORD_TIME,
                      1);

  --创建临时表
  RECORD_TIME := SYSDATE;
  RETMSG      := '创建临时表-出错误';
  P_STEP_ID   := STEP_ID || '3_2';
  P_SQL       := FNC_GET_TBLSQL('PI_I2_PS_DEPS', 'RE_PI_I2_PS_DEPS');
  EXECUTE IMMEDIATE P_SQL;
  PRC_SYS_MONITOR_LOG(FLOW_ID,
                      S_DATE,
                      E_DATE,
                      P_STEP_ID,
                      RECORD_TIME,
                      'PRC_14_SD_PI_I2',
                      1,
                      '创建临时表.[RE_PI_I2_PS_DEPS]',
                      P_SQL,
                      RECORD_TIME,
                      1);

  --数据加工到临时表
  RECORD_TIME := SYSDATE;
  RETMSG      := '数据加工到临时表-出错误';
  P_STEP_ID   := STEP_ID || '3_3';
  P_SQL       := FNC_GET_L_FROMSQL('CIF_DAT_PS_ACCT_DEPS',
                                   'PI_I2_PS_DEPS',
                                   CALC_TYPE,
                                   S_DATE,
                                   E_DATE);
  P_SQL       := 'INSERT /*+APPEND*/ INTO RE_PI_I2_PS_DEPS NOLOGGING ' || P_SQL;
  EXECUTE IMMEDIATE P_SQL;
  PRC_SYS_MONITOR_LOG(FLOW_ID,
                      S_DATE,
                      E_DATE,
                      P_STEP_ID,
                      RECORD_TIME,
                      'PRC_14_SD_PI_I2',
                      1,
                      '数据加工到临时表.[RE_PI_I2_PS_DEPS]',
                      P_SQL,
                      RECORD_TIME,
                      1);

  --没有分配的资源默认分配给开户机构对应的虚拟客户经理（PFM_机构号）,此处可以按机构汇总，但机构汇总就不能支持单一指标回算
  RECORD_TIME := SYSDATE;
  RETMSG      := '没有分配的数据补录到临时表-出错误';
  P_STEP_ID   := STEP_ID || '3_4';
  P_SQL       := FNC_GET_D_FROMSQL('CIF_DAT_PS_ACCT_DEPS',
                                   'PI_I2_PS_DEPS',
                                   CALC_TYPE,
                                   S_DATE,
                                   E_DATE);
  P_SQL       := 'INSERT /*+APPEND*/ INTO RE_PI_I2_PS_DEPS NOLOGGING ' || P_SQL;
  EXECUTE IMMEDIATE P_SQL;
  PRC_SYS_MONITOR_LOG(FLOW_ID,
                      S_DATE,
                      E_DATE,
                      P_STEP_ID,
                      RECORD_TIME,
                      'PRC_14_SD_PI_I2',
                      1,
                      '没有分配的数据补录到临时表.[RE_PI_I2_PS_DEPS]',
                      P_SQL,
                      RECORD_TIME,
                      1);

  --清空当前人员数据表
  RECORD_TIME := SYSDATE;
  RETMSG      := '清空当前人员数据表-出错误';
  P_STEP_ID   := STEP_ID || '4_1';
  P_SQL       := 'TRUNCATE TABLE PI_I2_PS_DEPS';
  EXECUTE IMMEDIATE P_SQL;
  PRC_SYS_MONITOR_LOG(FLOW_ID,
                      S_DATE,
                      E_DATE,
                      P_STEP_ID,
                      RECORD_TIME,
                      'PRC_14_SD_PI_I2',
                      1,
                      '清空当前人员数据表.[PI_I2_PS_DEPS]',
                      P_SQL,
                      RECORD_TIME,
                      1);

  --数据加工到当前人员数据表
  RECORD_TIME := SYSDATE;
  RETMSG      := '数据加工到当前人员数据表-出错误';
  P_STEP_ID   := STEP_ID || '4_2';
  P_SQL       := FNC_GET_INSSQL('PI_I2_PS_DEPS');
  P_SQL       := P_SQL || FNC_GET_FROMSQL('CIF_DAT_PS_ACCT_DEPS',
                                          'PI_I2_PS_DEPS',
                                          'RE_PI_I2_PS_DEPS',
                                          CALC_TYPE,
                                          S_DATE,
                                          E_DATE);
  EXECUTE IMMEDIATE P_SQL;
  PRC_SYS_MONITOR_LOG(FLOW_ID,
                      S_DATE,
                      E_DATE,
                      P_STEP_ID,
                      RECORD_TIME,
                      'PRC_14_SD_PI_I2',
                      1,
                      '数据加工到当前人员数据表.[PI_I2_PS_DEPS]',
                      P_SQL,
                      RECORD_TIME,
                      1);
  --
  --清空历史数据表
  RECORD_TIME := SYSDATE;
  RETMSG      := '清空历史数据表-出错误';
  P_STEP_ID   := STEP_ID || '5_1';
  P_SQL       := 'ALTER TABLE PI_I2_PS_DEPS_HIS TRUNCATE PARTITION P_' || S_DATE;
  EXECUTE IMMEDIATE P_SQL;
  PRC_SYS_MONITOR_LOG(FLOW_ID,
                      S_DATE,
                      E_DATE,
                      P_STEP_ID,
                      RECORD_TIME,
                      'PRC_14_SD_PI_I2',
                      1,
                      '清空历史数据表.[PI_I2_PS_DEPS_HIS]',
                      P_SQL,
                      RECORD_TIME,
                      1);

  --人员数据备份到历史表
  RECORD_TIME := SYSDATE;
  RETMSG      := '人员数据备份到历史表-出错误';
  P_STEP_ID   := STEP_ID || '5_2';
  P_SQL       := 'INSERT /*+APPEND*/ INTO PI_I2_PS_DEPS_HIS NOLOGGING (' ||
                 FNC_GET_FIELDSQL('PI_I2_PS_DEPS') ||
                 ',AL_RATE,HIS_START_DATE,HIS_END_DATE) ';
  P_SQL       := P_SQL || 'SELECT ' || FNC_GET_FIELDSQL('PI_I2_PS_DEPS') ||
                 ',AL_RATE,TAR_DATE,TAR_DATE FROM PI_I2_PS_DEPS';
  EXECUTE IMMEDIATE P_SQL;
  PRC_SYS_MONITOR_LOG(FLOW_ID,
                      S_DATE,
                      E_DATE,
                      P_STEP_ID,
                      RECORD_TIME,
                      'PRC_14_SD_PI_I2',
                      1,
                      '人员数据备份到历史表.[PI_I2_PS_DEPS_HIS]',
                      P_SQL,
                      RECORD_TIME,
                      1);

  --清空人员产品层数据
  RECORD_TIME := SYSDATE;
  RETMSG      := '清空人员产品层数据-出错误';
  P_STEP_ID   := STEP_ID || '6_1';
  P_SQL       := 'ALTER TABLE PI_I3_PS_DEPS TRUNCATE PARTITION P_' || S_DATE;
  EXECUTE IMMEDIATE P_SQL;
  PRC_SYS_MONITOR_LOG(FLOW_ID,
                      S_DATE,
                      E_DATE,
                      P_STEP_ID,
                      RECORD_TIME,
                      'PRC_14_SD_PI_I2',
                      1,
                      '清空人员产品层数据.[PI_I3_PS_DEPS]',
                      P_SQL,
                      RECORD_TIME,
                      1);

  --人员清单数据汇总到人员产品
  RECORD_TIME := SYSDATE;
  RETMSG      := '人员清单数据汇总到人员产品-出错误';
  P_STEP_ID   := STEP_ID || '6_2';
  P_SQL       := FNC_INS_I2_TO_I3('PI_I3_PS_DEPS');
  P_SQL       := P_SQL || FNC_SEL_I2_TO_I3('PI_I2_PS_DEPS',
                                           'PI_I3_PS_DEPS',
                                           CALC_TYPE,
                                           S_DATE,
                                           E_DATE);
  EXECUTE IMMEDIATE P_SQL;
  PRC_SYS_MONITOR_LOG(FLOW_ID,
                      S_DATE,
                      E_DATE,
                      P_STEP_ID,
                      RECORD_TIME,
                      'PRC_14_SD_PI_I2',
                      1,
                      '人员清单数据汇总到人员产品.[PI_I3_PS_DEPS]',
                      P_SQL,
                      RECORD_TIME,
                      1);

  --删除机构产品临时表
  RECORD_TIME := SYSDATE;
  RETMSG      := '删除机构产品临时表-出错误';
  P_STEP_ID   := STEP_ID || '7_1';
  SELECT COUNT(1) INTO P_CNT FROM COLS WHERE UPPER(TABLE_NAME) = 'RE_PI_I4_PS_DEPS';
  IF P_CNT > 0 THEN
    P_SQL := 'DROP TABLE RE_PI_I4_PS_DEPS';
    EXECUTE IMMEDIATE P_SQL;
  END IF;
  PRC_SYS_MONITOR_LOG(FLOW_ID,
                      S_DATE,
                      E_DATE,
                      P_STEP_ID,
                      RECORD_TIME,
                      'PRC_14_SD_PI_I2',
                      1,
                      '删除机构产品临时表.[RE_PI_I4_PS_DEPS]',
                      P_SQL,
                      RECORD_TIME,
                      1);

  --创建机构产品临时表
  RECORD_TIME := SYSDATE;
  RETMSG      := '创建机构产品临时表-出错误';
  P_STEP_ID   := STEP_ID || '7_2';
  P_SQL       := FNC_GET_I4_TBLSQL('PI_I4_PS_DEPS', 'RE_PI_I4_PS_DEPS');
  EXECUTE IMMEDIATE P_SQL;
  PRC_SYS_MONITOR_LOG(FLOW_ID,
                      S_DATE,
                      E_DATE,
                      P_STEP_ID,
                      RECORD_TIME,
                      'PRC_14_SD_PI_I2',
                      1,
                      '创建机构产品临时表.[RE_PI_I4_PS_DEPS]',
                      P_SQL,
                      RECORD_TIME,
                      1);

  --人员产品数据到机构产品临时表
  RECORD_TIME := SYSDATE;
  RETMSG      := '人员产品数据到机构产品临时表-出错误';
  P_STEP_ID   := STEP_ID || '7_3';
  P_SQL       := FNC_INS_RE_I4('PI_I4_PS_DEPS');
  P_SQL       := P_SQL || FNC_GET_I4_REFROMSQL('PI_I3_PS_DEPS',
                                               'PI_I4_PS_DEPS',
                                               CALC_TYPE,
                                               S_DATE,
                                               E_DATE);
  EXECUTE IMMEDIATE P_SQL;
  PRC_SYS_MONITOR_LOG(FLOW_ID,
                      S_DATE,
                      E_DATE,
                      P_STEP_ID,
                      RECORD_TIME,
                      'PRC_14_SD_PI_I2',
                      1,
                      '人员产品数据到机构产品临时表.[RE_PI_I4_PS_DEPS]',
                      P_SQL,
                      RECORD_TIME,
                      1);

  --删除层级机构产品临时表
  RECORD_TIME := SYSDATE;
  RETMSG      := '删除层级机构产品临时表-出错误';
  P_STEP_ID   := STEP_ID || '7_4';
  SELECT COUNT(1)
    INTO P_CNT
    FROM COLS
   WHERE UPPER(TABLE_NAME) = 'NEW_PI_I4_PS_DEPS';
  IF P_CNT > 0 THEN
    P_SQL := 'DROP TABLE NEW_PI_I4_PS_DEPS';
    EXECUTE IMMEDIATE P_SQL;
  END IF;
  PRC_SYS_MONITOR_LOG(FLOW_ID,
                      S_DATE,
                      E_DATE,
                      P_STEP_ID,
                      RECORD_TIME,
                      'PRC_14_SD_PI_I2',
                      1,
                      '删除层级机构产品临时表.[NEW_PI_I4_PS_DEPS]',
                      P_SQL,
                      RECORD_TIME,
                      1);

  --创建层级机构产品临时表
  RECORD_TIME := SYSDATE;
  RETMSG      := '创建层级机构产品临时表-出错误';
  P_STEP_ID   := STEP_ID || '7_5';
  P_SQL       := FNC_GET_I4_TBLSQL('PI_I4_PS_DEPS', 'NEW_PI_I4_PS_DEPS');
  EXECUTE IMMEDIATE P_SQL;
  PRC_SYS_MONITOR_LOG(FLOW_ID,
                      S_DATE,
                      E_DATE,
                      P_STEP_ID,
                      RECORD_TIME,
                      'PRC_14_SD_PI_I2',
                      1,
                      '创建层级机构产品临时表.[NEW_PI_I4_PS_DEPS]',
                      P_SQL,
                      RECORD_TIME,
                      1);

  --临时层机构产品数据层层汇总
  RECORD_TIME := SYSDATE;
  RETMSG      := '临时层机构产品数据层层汇总-出错误';
  P_STEP_ID   := STEP_ID || '7_6';
  P_SQL       := FNC_INS_NEW_I4('PI_I4_PS_DEPS');
  P_SQL       := P_SQL || FNC_GET_NEW_I4('PI_I4_PS_DEPS', CALC_TYPE, S_DATE, E_DATE);
  EXECUTE IMMEDIATE P_SQL;
  PRC_SYS_MONITOR_LOG(FLOW_ID,
                      S_DATE,
                      E_DATE,
                      P_STEP_ID,
                      RECORD_TIME,
                      'PRC_14_SD_PI_I2',
                      1,
                      '临时层机构产品数据层层汇总.[NEW_PI_I4_PS_DEPS]',
                      P_SQL,
                      RECORD_TIME,
                      1);

  --清空机构产品表数据
  RECORD_TIME := SYSDATE;
  RETMSG      := '清空机构产品层数据-出错误';
  P_STEP_ID   := STEP_ID || '7_7';
  P_SQL       := 'ALTER TABLE PI_I4_PS_DEPS TRUNCATE PARTITION P_' || S_DATE;
  EXECUTE IMMEDIATE P_SQL;
  PRC_SYS_MONITOR_LOG(FLOW_ID,
                      S_DATE,
                      E_DATE,
                      P_STEP_ID,
                      RECORD_TIME,
                      'PRC_14_SD_PI_I2',
                      1,
                      '清空机构产品层数据.[PI_I4_PS_DEPS]',
                      P_SQL,
                      RECORD_TIME,
                      1);

  --机构产品临时表到机构产品表
  RECORD_TIME := SYSDATE;
  RETMSG      := '机构产品临时表到机构产品表-出错误';
  P_STEP_ID   := STEP_ID || '7_8';
  P_SQL       := FNC_GET_I4_ORGINSSQL('PI_I4_PS_DEPS');
  P_SQL       := P_SQL || FNC_GET_I4_NEWFROMSQL('PI_I4_PS_DEPS',
                                                'NEW_PI_I4_PS_DEPS',
                                                CALC_TYPE,
                                                S_DATE,
                                                E_DATE);
  EXECUTE IMMEDIATE P_SQL;
  PRC_SYS_MONITOR_LOG(FLOW_ID,
                      S_DATE,
                      E_DATE,
                      P_STEP_ID,
                      RECORD_TIME,
                      'PRC_14_SD_PI_I2',
                      1,
                      '机构产品临时表到机构产品表.[PI_I4_PS_DEPS]',
                      P_SQL,
                      RECORD_TIME,
                      1);

  COMMIT;
  RETCODE := 0;
  RETMSG  := '完成';
EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    RETCODE := SQLCODE;
    RETMSG  := '人员数据表-执行错误[' || SQLERRM || ']. ' || RETMSG;
    PRC_SYS_MONITOR_LOG(FLOW_ID,
                        S_DATE,
                        E_DATE,
                        P_STEP_ID,
                        RECORD_TIME,
                        'PRC_14_SD_PI_I2',
                        4,
                        RETMSG,
                        P_SQL,
                        RECORD_TIME,
                        1);
END;

/

