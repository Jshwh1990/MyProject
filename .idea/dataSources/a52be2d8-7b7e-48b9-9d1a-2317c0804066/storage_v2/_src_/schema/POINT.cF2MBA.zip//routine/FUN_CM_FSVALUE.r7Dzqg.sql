create FUNCTION FUN_CM_FSVALUE(DATE_S       DATE,
                                          DATE_E       DATE,
                                          P_CUSTMG     VARCHAR,
                                          P_TARGETCODE VARCHAR)
  RETURN NUMBER IS
  /* 过程、函数简要描述信息
  **********************************************************
  *  存储过程名:  取指标值
  *  建立日期  :  2013-03-20
  *  作者      :  linyd
  *  模块      :  考核方案
  *  功能描述  :  根据周期，人员，指标代码来取指标值
  *  输入参数  ：P_CYCCODE 周期，P_CUSTMG 人员，P_TARGETCODE 指标代码
  *  输出参数  ： 指标值
  *  来源表    ：
  *  目标表    :
  *   备注     ：
  *------------------------------------------------------------
  *  修改历史
  *  序号    日期      修改人      修改原因
  ************************************************************ */
  IND_VALUE NUMBER(20, 4);
 /* DATE_S    DATE := CYC_CODE_SDAT(P_CYCCODE);
  DATE_E    DATE := CYC_CODE_EDAT(P_CYCCODE);*/
BEGIN
  --获取指定周期的起始日期
  SELECT TARGET_VALUE
    INTO IND_VALUE
    FROM (SELECT *
            FROM (SELECT TARGET_VALUE, TARGET_DATE, MANAGER_NO, TARGET_CODE
                    FROM PI_CM_QTY
                  UNION ALL
                  SELECT TARGET_VALUE, TARGET_DATE, MANAGER_NO, TARGET_CODE
                    FROM PI_CM_QTY_HAND) A00
           WHERE A00.TARGET_DATE BETWEEN TO_CHAR(DATE_S, 'YYYYMMDD') AND
                 TO_CHAR(DATE_E, 'YYYYMMDD')
             AND A00.MANAGER_NO = P_CUSTMG
             AND A00.TARGET_CODE = P_TARGETCODE
           ORDER BY TARGET_DATE DESC) A
   WHERE ROWNUM <= 1;
  RETURN IND_VALUE;
END;

/

