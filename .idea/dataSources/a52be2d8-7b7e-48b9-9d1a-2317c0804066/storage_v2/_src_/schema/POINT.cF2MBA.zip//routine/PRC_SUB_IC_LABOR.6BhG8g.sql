create PROCEDURE PRC_SUB_IC_LABOR
(
	IV_DATE     VARCHAR,
	IV_TRG_CODE VARCHAR,
	OI_RETURN   OUT INTEGER,
	OV_RETMSG   OUT VARCHAR
) IS
	/***************************************************************************
    功能模块：劳动竞赛指标数据堆积
    目标表  ：PI_ORG_QTY(机构指标表） PI_CM_QTY（客户指标表）
    过程名  ：prc_sub_ic_labor.prc
    参数    ：@Iv_date 数据日期（yyyymmdd) @trg_code 比较指标编码 @oi_return 输出参数，为0表示程序功能正常
    程序逻辑：根据劳动竞赛开始结束日期，进行指标计算，将数据插入目标表；
    编写人  ：Lihl
    编写日期：2013-4-1
    更新日期：2013-4-1
  ****************************************************************************/
	VV_PROC_NAME VARCHAR(30) := 'PRC_SUB_IC_LABOR';
	VD_DATE      DATE := TO_DATE(IV_DATE, 'yyyymmdd'); --输入日期date型
	VV_TRG_CODE  VARCHAR(32);
	VV_TAR_DATE  VARCHAR(8); --插入到目标表数据日期，根据汇总周期：D-当天，M-当月最后一天,Q Y 同理
	VV_EXEC_SQL  VARCHAR(32767); --最后执行sql
	VV_RULE_ORIG VARCHAR(2000); --计算规则原始串
	VV_RULE_EXEC VARCHAR(2000); --计算规则执行串
	VV_COL_DEL   CHAR(1) := '#'; --字段分隔符
	--vv_par_del     Char(1) := '$'; --参数分隔符
	VI_START_POS INTEGER; --特殊字符开始位置
	VI_END_POS   INTEGER; --特殊结束开始位置
	VV_SUB_OBJ   VARCHAR(30); --开始到结束位置截取的内容
	VV_TAR_TABLE VARCHAR(30); --目标表名
	VV_DIM_COL   VARCHAR(30); --维度字段名（manager_no,org_no）
	VI_SWITCH    INTEGER; --机构和人员类型计算方式
	VV_TWO_SQL   VARCHAR(32767); --机构和人员的执行sql合并
	VV_SRC_TAB   VARCHAR(30); --源表名；查找op_trg_data_src_tab中table_name
	VV_JOIN_SQL  VARCHAR(2000); --劳动竞赛指标多年份时的join部份
	VV_COND_SQL  VARCHAR(2000); --劳动竞赛指标where部份
BEGIN
	/*劳动竞赛指标*/
	FOR REC IN (SELECT A.TRG_ID,
										 A.TRG_CODE,
										 A.AREA_NO,
										 A.DATA_SRC,
										 A.APPLY_TYPE, --指标考核类型（1-机构；0-人员；2-机构和人员）
										 A.START_DATE,
										 A.END_DATE,
										 A.SUM_TYPE,
										 B.RULE_RESOLVE,
										 B.RULE_CONDITION,
										 A.CAL_TYPE
								FROM OP_TRG_QTY_INFO A,
										 (SELECT T.*,
														 ROW_NUMBER() OVER(PARTITION BY T.TRG_ID ORDER BY T.ENABLE_DATE DESC) RNK
												FROM OP_TRG_QTY_BASE T
											 WHERE VD_DATE >= T.ENABLE_DATE) B
							 WHERE A.TRG_ID = B.TRG_ID
								 AND A.STATUS = '1'
								 AND A.DEL_FLAG = '0'
								 AND B.RNK = 1
								 AND A.END_DATE >= VD_DATE --超过结束日期则不计算
								 AND A.START_DATE <= VD_DATE --小于开始日期则不计算
								 AND A.TRG_TYPE = 'L'
								 AND A.TRG_CODE = IV_TRG_CODE)
	LOOP
		VV_TRG_CODE := REC.TRG_CODE;
		PRC_IDX_WRITE_LOG(IV_DATE, REC.TRG_CODE, VV_PROC_NAME, 0, '', ''); --write log
		/*初始化变量*/
		VI_SWITCH  := 2;
		VV_TWO_SQL := '';
		--添加main标签，用于适用类型为人员和机构的goto回算
		<<MAIN>>
		VV_EXEC_SQL := '';
		VV_JOIN_SQL := '';
		--vv_rule_exec := '';
		IF REC.APPLY_TYPE = '0'
			 OR (REC.APPLY_TYPE = 2 AND VI_SWITCH = 2) THEN
			VV_TAR_TABLE := 'pi_cm_qty';
			VV_DIM_COL   := 'manager_no';
			--根据适用类型找出源表名
			SELECT TABLE_NAME
				INTO VV_SRC_TAB
				FROM OP_TRG_DATA_SRC_TAB
			 WHERE DATA_SRC = REC.DATA_SRC
				 AND APPLY_TYPE = '0';
		ELSIF REC.APPLY_TYPE = '1'
					OR (REC.APPLY_TYPE = 2 AND VI_SWITCH = 1) THEN
			VV_TAR_TABLE := 'pi_org_qty';
			VV_DIM_COL   := 'org_no';
			--根据适用类型找出源表名
			SELECT TABLE_NAME
				INTO VV_SRC_TAB
				FROM OP_TRG_DATA_SRC_TAB
			 WHERE DATA_SRC = REC.DATA_SRC
				 AND APPLY_TYPE = '1';
		END IF;
		VV_TAR_DATE := IV_DATE;
		/*根据数据汇总周期清理目标表数据*/
		EXECUTE IMMEDIATE 'Delete from ' || VV_TAR_TABLE || ' where target_date = ''' ||
											VV_TAR_DATE || ''' and target_code=''' || REC.TRG_CODE || '''';
		/*计算规则串处理*/
		VV_RULE_ORIG := REPLACE(REPLACE(REPLACE(REPLACE(REC.RULE_RESOLVE,
																										'$mdays$',
																										TO_NUMBER(SUBSTR(IV_DATE, 7, 2))),
																						'$sdays$',
																						VD_DATE - TRUNC(VD_DATE, 'Q') + 1),
																		'$ydays$',
																		VD_DATE - TRUNC(VD_DATE, 'yyyy') + 1),
														'$months$',
														TO_NUMBER(SUBSTR(IV_DATE, 5, 2)));
		--vv_rule_orig := Replace(vv_rule_orig, vv_col_del, ''); --#bal#
		--判断是sum或count计算类型
		IF REC.CAL_TYPE = '1' THEN
			WHILE LENGTH(VV_RULE_ORIG) > 0
			LOOP
				IF INSTR(VV_RULE_ORIG, VV_COL_DEL) <= 0 THEN
					EXIT;
				END IF;
				VI_START_POS := INSTR(VV_RULE_ORIG, VV_COL_DEL);
				VI_END_POS   := INSTR(VV_RULE_ORIG, VV_COL_DEL, VI_START_POS + 1);
				VV_SUB_OBJ   := TRIM(SUBSTR(VV_RULE_ORIG,
																		VI_START_POS + 1,
																		VI_END_POS - VI_START_POS - 1)); --#bal#
				--除数为0处理
				IF SUBSTR(RTRIM(SUBSTR(VV_RULE_ORIG, 1, VI_START_POS - 1)), -1) = '/' THEN
					VV_RULE_ORIG := SUBSTR(VV_RULE_ORIG, 1, VI_START_POS - 1) ||
													'(Case When Nvl(' || VV_SUB_OBJ || ',0)=0 Then Null Else ' ||
													VV_SUB_OBJ || ' End)' ||
													SUBSTR(VV_RULE_ORIG, VI_END_POS + 1);
				ELSE
					VV_RULE_ORIG := SUBSTR(VV_RULE_ORIG, 1, VI_START_POS - 1) || 'Nvl(' ||
													VV_SUB_OBJ || ',0)' ||
													SUBSTR(VV_RULE_ORIG, VI_END_POS + 1);
				END IF;
			END LOOP;
			VV_RULE_EXEC := 'Sum(Case When tar_date = ''' || IV_DATE || ''' Then ' ||
											VV_RULE_ORIG || ' Else 0 End)';
		ELSE
			VV_RULE_ORIG := REPLACE(VV_RULE_ORIG, VV_COL_DEL, '');
			VV_RULE_EXEC := 'Count(Distinct Case When tar_date = ''' || IV_DATE ||
											''' Then ' || VV_RULE_ORIG || ' End)';
		END IF;
		VV_COND_SQL := '''' || IV_DATE || '''';
		--计算规则（t1表的指标减去t2表的指标）
		--循环年数之差
		FOR I IN 1 .. (TO_CHAR(VD_DATE, 'yyyy') - TO_CHAR(REC.START_DATE, 'yyyy'))
		LOOP
			IF REC.CAL_TYPE = '1' THEN
				VV_RULE_EXEC := VV_RULE_EXEC || ' + ' || ' Sum(Case When tar_date = ''' ||
												TO_CHAR(TO_CHAR(VD_DATE, 'yyyy') - I) || '1231'' Then ' ||
												VV_RULE_ORIG || ' Else 0 End)';
			ELSE
				VV_RULE_EXEC := VV_RULE_EXEC || ' + ' ||
												' Count(Distinct Case When tar_date = ''' ||
												TO_CHAR(TO_CHAR(VD_DATE, 'yyyy') - I) || '1231'' Then ' ||
												VV_RULE_ORIG || ' End)';
			END IF;
			VV_COND_SQL := VV_COND_SQL || ',''' || TO_CHAR(TO_CHAR(VD_DATE, 'yyyy') - I) ||
										 '1231''';
		END LOOP;
		--判断开始时间是否为年初，如果为年初则不用减，否则减去开始时间上一天值
		IF SUBSTR(TO_CHAR(REC.START_DATE, 'yyyymmdd'), 5) <> '0101' THEN
			IF REC.CAL_TYPE = '1' THEN
				VV_RULE_EXEC := VV_RULE_EXEC || ' - ' || 'Sum(Case When tar_date = ''' ||
												TO_CHAR(REC.START_DATE - 1, 'yyyymmdd') || ''' Then ' ||
												VV_RULE_ORIG || ' Else 0 End)';
			ELSE
				VV_RULE_EXEC := VV_RULE_EXEC || ' - ' ||
												'Count(Distinct Case When tar_date = ''' ||
												TO_CHAR(REC.START_DATE - 1, 'yyyymmdd') || ''' Then ' ||
												VV_RULE_ORIG || ' End)';
			END IF;
			VV_COND_SQL := VV_COND_SQL || ',''' || TO_CHAR(REC.START_DATE - 1, 'yyyymmdd') || '''';
		END IF;
		--如果计算方式为为日均，则需除以间隔天数
		IF REC.SUM_TYPE = '2' THEN
			VV_RULE_EXEC := '(' || VV_RULE_EXEC || ')/' ||
											TO_CHAR(TRUNC(VD_DATE - REC.START_DATE) + 1);
		END IF;
		/**************************************
      开始拼接执行sql:
        insert into Target
        select col...,
        sum(case when tar_date='20130310' then bal_s else 0 end)+
        sum(case when tar_date='20121231' then bal_s else 0 end)+
        sum(case when tar_date='20111231' then bal_s else 0 end)+
        sum(case when tar_date='20101231' then bal_s else 0 end)-
        sum(case when tar_date='20100930' then bal_s else 0 end)
        From source
        where area_no=1 and tar_date in('20130310','20121231','20111231','20101231','20100930')
        group by col...
    ***************************************/
		--[Column_list]
		VV_EXEC_SQL := 'Insert Into ' || VV_TAR_TABLE || ' Select ' || VV_DIM_COL ||
									 ',area_no ,''' || VV_TAR_DATE || ''',''' || REC.TRG_CODE || ''',' ||
									 VV_RULE_EXEC || ',to_char(sysdate,''yyyymmdd'') From ' ||
									 VV_SRC_TAB || ' Where tar_date in (' || VV_COND_SQL || ')' || CASE
										 WHEN REC.RULE_CONDITION IS NOT NULL THEN
											' And ' || REPLACE(REC.RULE_CONDITION, VV_COL_DEL, '')
									 END || ' Group By ' || VV_DIM_COL || ',area_no';
		/*执行sql，将结果写入目标表*/
		EXECUTE IMMEDIATE VV_EXEC_SQL;
		COMMIT;
		VI_SWITCH := VI_SWITCH - 1;
		IF REC.APPLY_TYPE = 2 THEN
			VV_TWO_SQL := VV_TWO_SQL || VV_EXEC_SQL || ';';
			IF VI_SWITCH = 1 THEN
				GOTO MAIN;
			ELSE
				PRC_IDX_WRITE_LOG(IV_DATE, REC.TRG_CODE, VV_PROC_NAME, 1, '', VV_TWO_SQL); --write log
			END IF;
		ELSE
			PRC_IDX_WRITE_LOG(IV_DATE, REC.TRG_CODE, VV_PROC_NAME, 1, '', VV_EXEC_SQL); --write log
		END IF;
	END LOOP;
	OI_RETURN := 0;
	OV_RETMSG := '完成';
EXCEPTION
	WHEN OTHERS THEN
		OI_RETURN := SQLCODE;
		OV_RETMSG := SUBSTR(SQLERRM, 1, 200);
		PRC_IDX_WRITE_LOG(IV_DATE,
											VV_TRG_CODE,
											VV_PROC_NAME,
											-1,
											SUBSTR(SQLERRM, 1, 200),
											VV_EXEC_SQL); --write log
		ROLLBACK;
END;

/

