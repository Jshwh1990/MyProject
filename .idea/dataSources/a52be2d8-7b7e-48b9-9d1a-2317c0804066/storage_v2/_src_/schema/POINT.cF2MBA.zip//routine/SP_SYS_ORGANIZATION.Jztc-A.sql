create PROCEDURE SP_SYS_ORGANIZATION(IV_JOBID  IN VARCHAR2,
                                                IV_OPERID IN VARCHAR2,
                                                ON_RESULT OUT NUMBER)
--*******************************************************************************
  -- CopyRight (c) 2014, 融丰银行                                               *
  -- All rights reserved.                                                       *
  --                                                                            *
  -- 文件名称 : SP_SYS_ORGANIZATION.prc                                         *
  -- 摘    要 : 生成机构表 数据处理                                             *
  -- 工程模块 : crmapp.04_27                                                    *
  -- 当前版本 : V1.0.0                                                          *
  -- 作    者 : linyd                                                           *
  -- 完成日期 : 2014/09/12                                                      *
  -- 错误码段 :  5000 - 6000                                                  *
  --*****************************************************************************

 IS
  V_WORK_DATE  VARCHAR2(8);
  V_RETCODE    VARCHAR2(6) := '000000'; --程序/日志返回码
  V_MSG        VARCHAR2(1000); --程序执行信息
  V_TABNAME    VARCHAR2(100); --表名
  V_RETERRFLG  VARCHAR2(1); --日志标志 I(information) W(waring) E(error)
  V_ERRCODE    VARCHAR2(10) := '40279'; --程序执行出错返回码
  V_RETSUBCODE VARCHAR2(3); --程序子返回码
  V_JOBID      VARCHAR2(50) := 'SP_SYS_ORGANIZATION';
  V_OPERID     VARCHAR2(50) := 'LINYD';
  TO_WORK_DATE DATE;
  V_TABLEEXIST NUMBER; --是否存在表名
  V_SQL        VARCHAR2(4000);

BEGIN
  /*获得业务时间及相关参数*/
  SELECT WORK_DATE INTO V_WORK_DATE FROM SYS_PARA_DATE_NEW;
  TO_WORK_DATE := TO_DATE(V_WORK_DATE, 'yyyymmdd');

  /*加载机构表数据*/
  V_RETCODE    := '5005';
  V_RETSUBCODE := '001';
  V_RETERRFLG  := 'I';
  V_MSG        := 'SYS_ORGANIZATION-数据加载';
  SP_WRITEDETAILLOG(V_WORK_DATE,
                    V_JOBID,
                    V_OPERID,
                    V_MSG,
                    V_RETCODE,
                    V_RETSUBCODE,
                    V_RETERRFLG);

  INSERT INTO SYS_ORGANIZATION
    (ORG_NO, ORG_NAME, PARENT_ORG_NO, ORG_LEVEL, STATUS, ORG_TYPE)
    SELECT A.BANK_ORG_ID,
           A.BANK_ORG_NAME,
           A.PARENT_BANK_ORG_ID,
           A.BANK_ORG_LEVEL,
           A.STATUS,
           A.BANK_ORG_TYPE_CODE
      FROM A_DMD_BANK_ORGANIZATION A
     WHERE NOT EXISTS
     (SELECT 1 FROM SYS_ORGANIZATION B WHERE A.BANK_ORG_ID = B.ORG_NO);

  COMMIT;

  /*机构级别更新*/
  V_RETCODE    := '5005';
  V_RETSUBCODE := '002';
  V_RETERRFLG  := 'I';
  V_MSG        := 'SYS_ORGANIZATION-机构级别更新';
  SP_WRITEDETAILLOG(V_WORK_DATE,
                    V_JOBID,
                    V_OPERID,
                    V_MSG,
                    V_RETCODE,
                    V_RETSUBCODE,
                    V_RETERRFLG);

  UPDATE SYS_ORGANIZATION A
     SET A.ORG_LEVEL =
         (SELECT COUNT(1)
            FROM SYS_ORGANIZATION B
           START WITH ORG_NO = A.ORG_NO
          CONNECT BY PRIOR PARENT_ORG_NO = ORG_NO)
   WHERE EXISTS (SELECT 1
            FROM SYS_ORGANIZATION B
           START WITH ORG_NO = A.ORG_NO
          CONNECT BY PRIOR PARENT_ORG_NO = ORG_NO);

  COMMIT;

  /*机构org_seq更新*/
  V_RETCODE    := '5005';
  V_RETSUBCODE := '003';
  V_RETERRFLG  := 'I';
  V_MSG        := 'SYS_ORGANIZATION-机构org_seq更新';
  SP_WRITEDETAILLOG(V_WORK_DATE,
                    V_JOBID,
                    V_OPERID,
                    V_MSG,
                    V_RETCODE,
                    V_RETSUBCODE,
                    V_RETERRFLG);

  UPDATE SYS_ORGANIZATION A
     SET A.ORG_SEQ =
         (SELECT B.ORG_SEQ
            FROM (SELECT A1.ORG_NO,
                         ',' || DECODE(A5.ORG_NO, '', '', A5.ORG_NO || ',') ||
                         DECODE(A4.ORG_NO, '', '', A4.ORG_NO || ',') ||
                         DECODE(A3.ORG_NO, '', '', A3.ORG_NO || ',') ||
                         DECODE(A2.ORG_NO, '', '', A2.ORG_NO || ',') ||
                         DECODE(A1.ORG_NO, '', '', A1.ORG_NO || ',') ORG_SEQ
                    FROM SYS_ORGANIZATION A1
                    LEFT JOIN SYS_ORGANIZATION A2
                      ON A2.ORG_NO = A1.PARENT_ORG_NO
                    LEFT JOIN SYS_ORGANIZATION A3
                      ON A3.ORG_NO = A2.PARENT_ORG_NO
                    LEFT JOIN SYS_ORGANIZATION a4
                      ON A4.ORG_NO = A3.PARENT_ORG_NO
                    LEFT JOIN SYS_ORGANIZATION a5
                      ON A5.ORG_NO = A4.PARENT_ORG_NO) B
           WHERE A.ORG_NO = B.ORG_NO);

  COMMIT;

  V_RETCODE    := '5005';
  V_RETSUBCODE := '004';
  V_RETERRFLG  := 'I';
  V_MSG        := '程序执行结束';
  SP_WRITEDETAILLOG(V_WORK_DATE,
                    V_JOBID,
                    V_OPERID,
                    V_MSG,
                    V_RETCODE,
                    V_RETSUBCODE,
                    V_RETERRFLG);

  ON_RESULT := 0;
  /*异常处理*/
EXCEPTION
  WHEN OTHERS THEN
    V_RETERRFLG := 'E';
    V_RETCODE   := V_ERRCODE;
    V_MSG       := 'SQLCODE:' || V_TABNAME || '表' ||
                   SUBSTR(SQLERRM, 1, 500);
    ON_RESULT   := SQLCODE;
    ROLLBACK;
    SP_WRITEDETAILLOG(V_WORK_DATE,
                      V_JOBID,
                      V_OPERID,
                      V_MSG,
                      V_RETCODE,
                      V_RETSUBCODE,
                      V_RETERRFLG);

    RETURN;

END;

/

