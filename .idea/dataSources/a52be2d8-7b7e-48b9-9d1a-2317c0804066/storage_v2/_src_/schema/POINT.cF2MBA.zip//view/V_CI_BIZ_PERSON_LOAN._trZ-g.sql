create view V_CI_BIZ_PERSON_LOAN as
  SELECT A.ACCOUNT_NO, --账号
       CASE
				 WHEN B.CUST_NO IS NULL THEN
					 A.BIZ_CUST_SYSTEM
         ELSE
					 B.CUST_NO||'#D'
       END BIZ_CUST_SYSTEM,--业务客户号 + # + 业务系统类型
       A.CATE_CODE        ,--业务类别
       A.OPEN_ORG_NO      ,--开户机构
			 A.SUBJ_CODE, --科目号
       A.PRD_NO           ,--产品编号
       NVL(B.CUST_NO,A.BIZ_CUST_NO) BIZ_CUST_NO,--原业务系统客户号
       A.BIZ_SYSTEM_TYPE  ,--源系统类型
       A.CONTRACT_NO      ,--合同编号
       A.IOU_NO           ,--借据编号
       A.BAL              ,--余额
       A.CURRENCY         ,--币种
       A.RATE             ,--利率
       A.INTEREST_WAY     ,--计息方式
       A.REPAY_WAY        ,--还款方式
       A.TIME_LIMIT       ,--贷款期限
       A.EXPIRE_DATE      ,--到期日
       A.ASSURE_WAY       ,--担保方式
       A.FIVE_TIER        ,--五级分类
       A.ACCOUNT_STATUS   ,--账户状态
       A.OPEN_DATE        ,--开户日期
       A.PIPER_CONTRACT_NO,--纸质合同号
       A.BAL_AVG_M        ,--月日均余额
       A.BAL_AVG_Q        ,--季日均
       A.BAL_AVG_Y        ,--年日均余额
       A.ACCRUAL_SHOULD   ,--当日应收利息
       A.ACCRUAL_SHOULD_A ,--累计应收利息
       A.ACCRUAL_FACT     ,--当日实收利息
       A.ACCRUAL_FACT_A    --累计实收利息
  FROM CI_BIZ_PERSON_LOAN A
  LEFT JOIN CI_CUS_PERSON_COMBINE B
	  ON A.BIZ_CUST_NO = B.COMBINED_CUST_NO
		AND B.STATE = '1'

/

