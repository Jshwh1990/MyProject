create FUNCTION FUN_RE_BIG_ORG(P_INSTR_INIT VARCHAR)
  RETURN VARCHAR IS
  /* 过程、函数简要描述信息
  **********************************************************
  *  存储过程名:  根据入参的字符串返回大机构字符串
  *  建立日期  :  2013-03-20
  *  作者      :  linyd
  *  模块      :
  *  功能描述  :
  *  输入参数  ：
  *  输出参数  ：
  *  来源表    ：
  *  目标表    :
  *   备注     ：
  *------------------------------------------------------------
  *  修改历史
  *  序号    日期      修改人      修改原因
  ************************************************************ */
  T_OUTSTR1   VARCHAR(500);
  T_OUTSTR2   VARCHAR(500);
  T_OUTSTR3   VARCHAR(500);
  P_INSTR     VARCHAR(500);
  LOOP_POS    INT DEFAULT 0;
  POS_SEG_NEW INT DEFAULT 0;
  POS_SEG_OLD INT DEFAULT 1;
  LINYD       VARCHAR(500);
  C_NUM       INT;
BEGIN
  P_INSTR := REPLACE(P_INSTR_INIT, ',', ''',''');
  P_INSTR := ''''||P_INSTR || ''',''a''';
  WHILE (LOOP_POS <= LENGTH(P_INSTR)) LOOP
    --算出第一个‘，’在第几位
    POS_SEG_NEW := INSTR(P_INSTR, ',', POS_SEG_OLD);
    IF (POS_SEG_NEW > 0) THEN
      --截取第一个机构
      T_OUTSTR1   := SUBSTR(P_INSTR, POS_SEG_OLD, POS_SEG_NEW - POS_SEG_OLD);
      --更新开始截取数字
      POS_SEG_OLD := POS_SEG_NEW + 1;
      --在原有字符串里，把取出的机构去掉
      T_OUTSTR2   := REPLACE(P_INSTR, T_OUTSTR1, '');
      --如果字符串里第一位是‘，’，说明还需要截取
      IF substr(T_OUTSTR2, 1, 1) = ',' THEN
        T_OUTSTR2 := substr(T_OUTSTR2, 2, LENGTH(T_OUTSTR2));
      END IF;
      --字符串最后一位为','就去掉','
      IF substr(T_OUTSTR2, LENGTH(T_OUTSTR2), 1) = ',' THEN
        T_OUTSTR2 := substr(T_OUTSTR2, 1, LENGTH(T_OUTSTR2) - 1);
      END IF;
      T_OUTSTR2 := REPLACE(T_OUTSTR2, ',,', ',');
      LINYD     := 'SELECT COUNT(1) FROM SYS_ORG_SUB A WHERE A.SUB_ORG IN ('||
                   T_OUTSTR1 || ') AND A.INS_ORG IN (' || T_OUTSTR2 || ')';
       --dbms_output.put_line('LINYD====='||LINYD);
      EXECUTE IMMEDIATE LINYD
        INTO C_NUM;
      IF C_NUM = 0 THEN
        T_OUTSTR3 := T_OUTSTR3 || T_OUTSTR1 || ',';
      END IF;
      LOOP_POS := POS_SEG_OLD;
    ELSE
      LOOP_POS := LENGTH(P_INSTR) + 1;
    END IF;
  END LOOP;
  IF substr(T_OUTSTR3, LENGTH(T_OUTSTR3), 1) = ',' THEN
    T_OUTSTR3 := substr(T_OUTSTR3, 1, LENGTH(T_OUTSTR3) - 1);
  END IF;
  RETURN T_OUTSTR3;
END;

/

