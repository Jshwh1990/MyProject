create PROCEDURE PRC_11_SM_AD_SA_MAIN
(
	S_DATE    VARCHAR,
	E_DATE    VARCHAR,
	CALC_TYPE INT,
	RETCODE   OUT INT,
	RETMSG    OUT VARCHAR
)
/* 过程、函数简要描述信息
  **********************************************************
  *  存储过程名:  零售主账户分配规则明细生成
  *  建立日期  :  2013-03-20
  *  作者      :  linyd
  *  模块      :  业绩分配规模
  *  功能描述  :  业绩分配明细生成
  *  输入参数  ： s_date 处理日期,e_date 处理结束日期,flow_id流水
  *               calc_type 计算类型：10为当日业绩计算，20为外部回算，30为内部回算
  *  输出参数  ： RETCODE 0为正确1为错误， RETMSG错误信息
  *  来源表    ： OP_AS_AR_SA_MAIN  零售客户分配表
  *  目标表    :  OP_AS_AD_SA_MAIN 零售客户分配规则明细表
  *   备注     ：存储过程名 PRC_11_SM_AS_AD_SA_MAIN 里的11为跑批号，S为零售，M为主账户业务类型号
  *------------------------------------------------------------
  *  修改历史
  *  序号    日期      修改人      修改原因
  ************************************************************ */
 IS
	P_SQL       LONG;
	INS_SQL     VARCHAR2(1000);
	SEL_SQL     VARCHAR2(4000);
	GRY_SQL     VARCHAR2(500);
	STEP_ID     VARCHAR2(30);
	RECORD_TIME TIMESTAMP;
	P_STEP_ID   VARCHAR2(30);
	FLOW_ID     VARCHAR2(32);
BEGIN
	FLOW_ID     := FNC_GEN_FLOW_ID();
	STEP_ID     := 'LYD_11_OP_AS_AD_SA_MAIN_';
	RECORD_TIME := SYSDATE;
	--清空分配明细表
	RETMSG    := '清空分配明细表-出错误';
	P_STEP_ID := STEP_ID || '1';
	P_SQL     := 'TRUNCATE TABLE OP_AS_AD_SA_MAIN';
	EXECUTE IMMEDIATE P_SQL;
	PRC_SYS_MONITOR_LOG(FLOW_ID,
											S_DATE,
											E_DATE,
											P_STEP_ID,
											RECORD_TIME,
											'PRC_11_SM_AS_AD_SA_MAIN',
											1,
											'清空分配明细表.[OP_AS_AD_SA_MAIN]',
											P_SQL,
											RECORD_TIME,
											1);

	--分配明细生成
	RECORD_TIME := SYSDATE;
	RETMSG      := '生成分配明细表-出现错误';
	P_STEP_ID   := STEP_ID || '2';
	INS_SQL     := 'INSERT /*+append*/ INTO OP_AS_AD_SA_MAIN nologging (ID,RES_ID,AREA_NO,RES_ORG,AL_TYPE,AL_IN,START_DATE,END_DATE,AL_WAY,AL_RATE,START_AMT,END_AMT) ';
	SEL_SQL     := ' SELECT SYS_GUID(),HN.RES_ID,HN.AREA_NO,HN.RES_ORG,''01'',HN.AL_IN,TO_DATE(''' ||
								 S_DATE || ''',''YYYYMMDD''),TO_DATE(''' || S_DATE ||
								 ''',''YYYYMMDD''),HN.AL_WAY,SUM(HN.AL_RATE) AL_RATE,HN.START_AMT,HN.END_AMT ';
	SEL_SQL     := SEL_SQL ||
								 'FROM OP_AS_AR_SA_MAIN HN WHERE HN.STATUS = ''1'' AND TO_DATE(''' ||
								 S_DATE ||
								 ''',''YYYYMMDD'') BETWEEN HN.START_DATE AND nvl(HN.END_DATE,to_date(''29991231'',''YYYYMMDD''))';
	GRY_SQL     := ' GROUP BY HN.RES_ID,HN.AREA_NO,HN.RES_ORG,HN.AL_IN,HN.AL_WAY,HN.START_AMT,HN.END_AMT ';
	P_SQL       := INS_SQL || SEL_SQL || GRY_SQL;
	EXECUTE IMMEDIATE P_SQL;
	PRC_SYS_MONITOR_LOG(FLOW_ID,
											S_DATE,
											E_DATE,
											P_STEP_ID,
											RECORD_TIME,
											'PRC_11_SM_AS_AD_SA_MAIN',
											1,
											'分配明细完成.[OP_AS_AD_SA_MAIN]',
											P_SQL,
											RECORD_TIME,
											1);

	COMMIT;
	RETCODE := 0;
	RETMSG  := '完成';
EXCEPTION
	WHEN OTHERS THEN
		ROLLBACK;
		RETCODE := -1;
		RETMSG  := '生成分配明细-执行错误[' || SQLERRM || ']. ' || RETMSG;
		PRC_SYS_MONITOR_LOG(FLOW_ID,
												S_DATE,
												E_DATE,
												P_STEP_ID,
												RECORD_TIME,
												'PRC_11_SM_AS_AD_SA_MAIN',
												4,
												RETMSG,
												P_SQL,
												RECORD_TIME,
												1);
END;

/

