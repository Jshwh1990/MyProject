create PROCEDURE PRC_EWM_AUTO_COUNT
(
	S_DATE  VARCHAR,
	E_DATE  VARCHAR,
	RETCODE OUT INT,
	RETMSG  OUT VARCHAR
)
/* 过程、函数简要描述信息
  **********************************************************
  *  存储过程名:  机构和人员考核方案自动计算
  *  建立日期  :  2015-01-16
  *  作者      :  zhouxb
  *  模块      :  绩效考核管理
  *  功能描述  :
  *  输入参数  ： MO_EWM_ORG 机构考核方案,MO_EWM_ORG_SEG 机构考核方案阶段,
                  MO_EWM_CM 员工考核方案,MO_EWM_CM_SEG 员工考核方案阶段
  *  输出参数  ： RETCODE 0为正确1为错误， RETMSG错误信息
  *  来源表    ： sys_organization 机构表
  *  调用存储过程:  PRC_EWM_ORG 机构计算成绩过程,PRC_EWM_CM 员工计算成绩过程
  *   备注     ：存储过程名 PRC_10_ORG_SUM
  *------------------------------------------------------------
  *  修改历史
  *  序号    日期      修改人      修改原因
  ************************************************************ */
 IS
	P_WAYID      VARCHAR2(32);
	P_WAYCODE    VARCHAR2(32);
	P_SEGCODES   VARCHAR2(30);
	STEP_ID      VARCHAR2(30);
	RECORD_TIME  TIMESTAMP;
	P_STEP_ID    VARCHAR2(30);
	FLOW_ID      VARCHAR2(32);
	V_WORK_DATE  VARCHAR2(8);
	TO_WORK_DATE DATE;

	CURSOR WAY_O_CUR IS
		SELECT A.WAY_ID, A.WAY_CODE, B.SEG_CODE
			FROM MO_EWM_ORG A
			LEFT JOIN MO_EWM_ORG_SEG B
				ON A.WAY_ID = B.WAY_ID
			 AND A.SEG_FLAG = '1'
			 AND B.START_DAT <= TO_WORK_DATE
			 AND B.END_DAT >= TO_WORK_DATE;
	CURSOR WAY_C_CUR IS

		SELECT A.WAY_ID, A.WAY_CODE, B.SEG_CODE
			FROM MO_EWM_CM A
			LEFT JOIN MO_EWM_CM_SEG B
				ON A.WAY_ID = B.WAY_ID
			 AND A.SEG_FLAG = '1'
			 AND B.START_DAT <= TO_WORK_DATE
			 AND B.END_DAT >= TO_WORK_DATE;

BEGIN
	SELECT WORK_DATE INTO V_WORK_DATE FROM SYS_PARA_DATE_NEW;
	TO_WORK_DATE := TO_DATE(V_WORK_DATE, 'yyyymmdd');

	FLOW_ID     := FNC_GEN_FLOW_ID();
	STEP_ID     := 'ZXB_20_EWM_AUTO_CNT_';
	RECORD_TIME := SYSDATE;
	RETCODE     := 0;

	--*****************************机构考核方案自动计算***********************************
	P_STEP_ID := STEP_ID || '01';
	OPEN WAY_O_CUR;
	LOOP
		FETCH WAY_O_CUR
			INTO P_WAYID, P_WAYCODE, P_SEGCODES;
		EXIT WHEN WAY_O_CUR % NOTFOUND;
		PRC_EWM_ORG(P_WAYID, P_WAYCODE, P_SEGCODES, RETCODE, RETMSG);

		IF RETCODE <> 0
			 OR RETCODE IS NULL THEN
			ROLLBACK;
			RETURN;
		END IF;

	END LOOP;

	IF RETCODE <> 0
		 OR RETCODE IS NULL THEN
		RETMSG := '机构自动计算成绩过程-执行出错';
		PRC_SYS_MONITOR_LOG(FLOW_ID,
												S_DATE,
												E_DATE,
												P_STEP_ID,
												RECORD_TIME,
												'PRC_EWM_AUTO_COUNT',
												4,
												RETMSG,
												'',
												RECORD_TIME,
												1);
		ROLLBACK;
		RETURN;
	ELSE
		RETMSG := '机构自动计算成绩过程-执行成功';
		PRC_SYS_MONITOR_LOG(FLOW_ID,
												S_DATE,
												E_DATE,
												P_STEP_ID,
												RECORD_TIME,
												'PRC_EWM_AUTO_COUNT',
												1,
												RETMSG,
												'',
												RECORD_TIME,
												1);
	END IF;

	CLOSE WAY_O_CUR;

	--*****************************人员考核方案自动计算***********************************
	P_STEP_ID := STEP_ID || '02';
	OPEN WAY_C_CUR;
	LOOP
		FETCH WAY_C_CUR
			INTO P_WAYID, P_WAYCODE, P_SEGCODES;
		EXIT WHEN WAY_C_CUR % NOTFOUND;
		PRC_EWM_CM(P_WAYID, P_WAYCODE, P_SEGCODES, RETCODE, RETMSG);
		IF RETCODE <> 0
			 OR RETCODE IS NULL THEN
			ROLLBACK;
			RETURN;
		END IF;
	END LOOP;

	IF RETCODE <> 0
		 OR RETCODE IS NULL THEN
		RETMSG := '员工自动计算成绩过程-执行出错';
		PRC_SYS_MONITOR_LOG(FLOW_ID,
												S_DATE,
												E_DATE,
												P_STEP_ID,
												RECORD_TIME,
												'PRC_EWM_AUTO_COUNT',
												4,
												RETMSG,
												'',
												RECORD_TIME,
												1);
		ROLLBACK;
		RETURN;
	ELSE
		RETMSG := '员工自动计算成绩过程-执行成功';
		PRC_SYS_MONITOR_LOG(FLOW_ID,
												S_DATE,
												E_DATE,
												P_STEP_ID,
												RECORD_TIME,
												'PRC_EWM_AUTO_COUNT',
												1,
												RETMSG,
												'',
												RECORD_TIME,
												1);
	END IF;

	CLOSE WAY_C_CUR;
	--更新 机构和员工考核方案阶段表 中 方案状态字段
	UPDATE MO_EWM_ORG_SEG
		 SET WAY_STS = SUBSTR(WAY_STS, 1, 5) || '110'
	 WHERE START_DAT <= TO_WORK_DATE
		 AND END_DAT > TO_WORK_DATE;
	COMMIT;
	UPDATE MO_EWM_CM_SEG
		 SET WAY_STS = SUBSTR(WAY_STS, 1, 5) || '110'
	 WHERE START_DAT <= TO_WORK_DATE
		 AND END_DAT > TO_WORK_DATE;
	COMMIT;

	UPDATE MO_EWM_ORG_SEG
		 SET WAY_STS = SUBSTR(WAY_STS, 1, 5) || '111'
	 WHERE END_DAT = TO_WORK_DATE;
	COMMIT;
	UPDATE MO_EWM_CM_SEG
		 SET WAY_STS = SUBSTR(WAY_STS, 1, 5) || '111'
	 WHERE END_DAT = TO_WORK_DATE;
	COMMIT;

	P_STEP_ID := STEP_ID || '03';
	RETMSG    := '机构和员工自动计算成绩过程-执行成功';
	PRC_SYS_MONITOR_LOG(FLOW_ID,
											S_DATE,
											E_DATE,
											P_STEP_ID,
											RECORD_TIME,
											'PRC_EWM_AUTO_COUNT',
											1,
											RETMSG,
											'',
											RECORD_TIME,
											1);
	COMMIT;
END PRC_EWM_AUTO_COUNT;

/

