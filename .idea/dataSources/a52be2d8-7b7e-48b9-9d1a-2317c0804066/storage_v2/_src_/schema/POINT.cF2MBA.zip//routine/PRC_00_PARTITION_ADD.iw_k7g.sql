create PROCEDURE PRC_00_PARTITION_ADD
(
	S_DATE    VARCHAR,
	E_DATE    VARCHAR,
	CALC_TYPE INT,
	RETCODE   OUT INT,
	RETMSG    OUT VARCHAR
)
--***************************************************************************** *
	-- 从数据库里拿分区表及子分区数，判断当前系统日期里所有分区表是否有分区值     *
	-- 如没有就增加相应的分区，包括主分区和子分区                                 *
	-- 文件名称 : PRC_P_PARTITION.prc                                             *
	-- 摘    要 : 表分区处理                                                      *
	-- 工程模块 :                                                                 *
	-- 当前版本 : V1.0.0                                                          *
	-- 作    者 : linyd                                                           *
	-- 完成日期 : 20121217                                                        *
	-- 错误码段 : 0                                                               *
	--*****************************************************************************
 IS
	T_NAME         VARCHAR(50); --表名
	T_P_NUM        INTEGER; --子分区数,如果有子分区数说明分区是月分区，否则为天分区
	T_P_NAME       VARCHAR2(8); --分区前缀名
	T_P_TABLESPACE VARCHAR2(20); --表空间名称
	T_P_D_VALUES   VARCHAR2(8); --天分区值'20121217'
	T_P_M_VALUES   VARCHAR2(6); --月分区值'201212'
	T_SQL          VARCHAR(500);
	V_NUM          INTEGER;
	RECORD_TIME    TIMESTAMP;
	FLOW_ID        VARCHAR2(32);
	P_STEP_ID      VARCHAR2(30);
	STEP_ID        VARCHAR2(30);
	CURSOR IND_CUR IS
		SELECT A.TABLE_NAME,
					 A.SUBPARTITION_COUNT,
					 SUBSTR(A.PARTITION_NAME, 1, LENGTH(A.PARTITION_NAME) - 8),
					 A.TABLESPACE_NAME
			FROM USER_TAB_PARTITIONS A
		 WHERE A.TABLE_NAME NOT LIKE '%$%'
			 AND INSTR(TABLE_NAME, '_I5_') = 0
		 GROUP BY A.TABLE_NAME,
							A.SUBPARTITION_COUNT,
							SUBSTR(A.PARTITION_NAME, 1, LENGTH(A.PARTITION_NAME) - 8),
							A.TABLESPACE_NAME
		 ORDER BY A.TABLE_NAME;
BEGIN
	FLOW_ID := FNC_GEN_FLOW_ID();
	STEP_ID := 'LYD_00_PARTITION_ADD_';

	--清空日志表
	T_SQL := 'TRUNCATE TABLE SYS_MONITOR_LOG';
	EXECUTE IMMEDIATE T_SQL;
	/* T_SQL :='TRUNCATE TABLE PI_KPI_CALC_LOG';
  EXECUTE IMMEDIATE T_SQL;*/
	--处理分区日和月分区值
	RECORD_TIME  := SYSDATE;
	P_STEP_ID    := STEP_ID || '1';
	T_P_D_VALUES := S_DATE;
	IF TRIM(T_P_D_VALUES) IS NULL THEN
		RETCODE := -1;
		RETMSG  := '处理日期输入有问题';
		RETURN;
	ELSE
		T_P_M_VALUES := SUBSTR(T_P_D_VALUES, 1, 6);
	END IF;
	--打开游标，循环对分区表增加分区
	OPEN IND_CUR;
	LOOP
		FETCH IND_CUR
			INTO T_NAME, T_P_NUM, T_P_NAME, T_P_TABLESPACE;
		EXIT WHEN IND_CUR % NOTFOUND;
		--按天list分区,没有子分区处理
		IF T_P_NUM = 0 THEN
			T_SQL := 'SELECT COUNT(1) FROM USER_TAB_PARTITIONS WHERE TABLE_NAME=UPPER(''' ||
							 T_NAME || ''') AND PARTITION_NAME=''' || T_P_NAME || T_P_D_VALUES || '''';
			EXECUTE IMMEDIATE T_SQL
				INTO V_NUM;
			--V_NUM=0说明表没有当日分区，需要对表进行当日分区增加
			IF V_NUM = 0 THEN
				T_SQL := 'ALTER TABLE ' || T_NAME || ' ADD  PARTITION ' || T_P_NAME || '' ||
								 T_P_D_VALUES || ' VALUES (''' || T_P_D_VALUES || ''') ' ||
								 'TABLESPACE ' || T_P_TABLESPACE;
				EXECUTE IMMEDIATE T_SQL;
			END IF;
		END IF;
		--后续如果有组合分区，可以继续判断处理
	END LOOP;
	CLOSE IND_CUR;
	RETMSG := '增加表分区-执行成功';
	PRC_SYS_MONITOR_LOG(FLOW_ID,
											S_DATE,
											E_DATE,
											P_STEP_ID,
											RECORD_TIME,
											'PRC_00_PARTITION_ADD',
											1,
											RETMSG,
											'',
											RECORD_TIME,
											1);

	--机构下级机构汇总过程
	RECORD_TIME := SYSDATE;
	P_STEP_ID   := STEP_ID || '2';
	PRC_10_ORG_SUB(S_DATE, E_DATE, CALC_TYPE, RETCODE, RETMSG);
	IF RETCODE <> 0
		 OR RETCODE IS NULL THEN
		RETMSG := '机构下级机构汇总过程-执行出错';
		PRC_SYS_MONITOR_LOG(FLOW_ID,
												S_DATE,
												E_DATE,
												P_STEP_ID,
												RECORD_TIME,
												'PRC_10_ORG_SUB',
												4,
												RETMSG,
												'',
												RECORD_TIME,
												1);
		ROLLBACK;
		RETURN;
	ELSE
		RETMSG := '机构下级机构汇总过程-执行成功';
		PRC_SYS_MONITOR_LOG(FLOW_ID,
												S_DATE,
												E_DATE,
												P_STEP_ID,
												RECORD_TIME,
												'PRC_10_ORG_SUB',
												1,
												RETMSG,
												'',
												RECORD_TIME,
												1);
	END IF;

	--处理虚拟客户经理--byshi
	RECORD_TIME := SYSDATE;
	P_STEP_ID   := STEP_ID || '3';
	T_SQL       := 'merge into SYS_EMPLOYEE a using sys_organization b on (''PFM_''||b.org_no=a.emp_no AND a.job_title=''9'' AND a.status=''1'')';
	T_SQL       := T_SQL ||
								 'when matched then update set a.emp_name=b.org_name||''虚拟客户经理''';
	T_SQL       := T_SQL ||
								 'when not matched then insert (a.emp_no,a.Emp_Name,a.Org_No,a.Job_Title,a.Status) values(''PFM_''||b.org_no,b.org_name||''虚拟客户经理'',b.org_no,''9'',''1'')';
	EXECUTE IMMEDIATE T_SQL;
	--将虚拟客户经理同步到RBAC_USER
	MERGE INTO RBAC_USER A
	USING (SELECT * FROM SYS_EMPLOYEE WHERE EMP_NO LIKE 'PFM_%') B
	ON (A.LOGIN_NAME = B.EMP_NO)
	WHEN NOT MATCHED THEN
		INSERT
			(A.ID,
			 A.LOGIN_NAME,
			 A.NAME,
			 A.PASSWORD,
			 A.STATUS,
			 A.START_DATE,
			 A.END_DATE,
       A.VALID_TIME,
			 A.PASSWORD_SALT,
			 A.EMP_NO)
		VALUES
			(SEQ_RBAC_USER.NEXTVAL,
			 B.EMP_NO,
			 B.EMP_NAME,
			 '0ff13aeaad2d38f2a3e848cc1d882fcaf7096e0f',
			 '1',
			 DATE '2000-01-01',
			 DATE '2999-12-31',
       '90',
			 '00c8fb2d105bc828',
			 B.EMP_NO);
	COMMIT;
	RETMSG := '处理虚拟客户经理-执行成功';
	PRC_SYS_MONITOR_LOG(FLOW_ID,
											S_DATE,
											E_DATE,
											P_STEP_ID,
											RECORD_TIME,
											'PRC_00_PARTITION_ADD',
											1,
											RETMSG,
											'',
											RECORD_TIME,
											1);

	RETMSG  := '增加表分区-执行成功';
	RETCODE := 0;
EXCEPTION
	WHEN OTHERS THEN
		ROLLBACK;
		RETCODE := -1;
		RETMSG  := '增加表分区-执行错误-' || SQLERRM;
		PRC_SYS_MONITOR_LOG(FLOW_ID,
												S_DATE,
												E_DATE,
												P_STEP_ID,
												RECORD_TIME,
												'PRC_00_PARTITION_ADD',
												4,
												RETMSG,
												T_SQL,
												RECORD_TIME,
												1);
END;

/

