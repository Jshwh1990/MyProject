create FUNCTION CScr_YesNo(FS_VALUE    NUMBER,
                                          H_SCORE     NUMBER,
                                          L_SCORE     NUMBER) RETURN NUMBER IS
/* 过程、函数简要描述信息
  **********************************************************
  *  存储过程名:  客户等级签约积分法
  *  建立日期  :  2013-03-20
  *  作者      :  zhuy
  *  模块      :  评分模型
  *  功能描述  :  积分法
  *  输入参数  ：
  *  输出参数  ：
  *  来源表    ：
  *  目标表    :
  *   备注     ：1、  1（是）;  得           分；
                 2、 0（否）   得            分；
  *------------------------------------------------------------
  *  修改历史
  *  序号    日期      修改人      修改原因
  ************************************************************ */
  O_VAL NUMBER(12, 2);
BEGIN
  IF FS_VALUE IS NOT NULL AND H_SCORE IS NOT NULL AND L_SCORE IS NOT NULL THEN
    IF FS_VALUE = 1 THEN
      O_VAL := H_SCORE;
    ELSIF FS_VALUE = 0 THEN
      O_VAL := L_SCORE;
    ELSE
      O_VAL := NULL;
    END IF;
  ELSE
    O_VAL := NULL;
  END IF;
  RETURN O_VAL;
END;

/

