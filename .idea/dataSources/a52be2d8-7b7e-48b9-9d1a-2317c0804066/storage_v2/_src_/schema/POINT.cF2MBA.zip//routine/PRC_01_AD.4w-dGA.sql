create PROCEDURE PRC_01_AD
(
	S_DATE    VARCHAR,
	E_DATE    VARCHAR,
	CALC_TYPE INT,
	RETCODE   OUT INT,
	RETMSG    OUT VARCHAR
)
/* 过程、函数简要描述信息
  **********************************************************
  *  存储过程名:  分配规则存储过程集合
  *  建立日期  :  2013-03-20
  *  作者      :  linyd
  *  模块      :  业绩分配规模
  *  功能描述  :  分配规则存储过程集合
  *  输入参数  ： s_date 处理日期,e_date 处理结束日期,flow_id流水
  *               calc_type 计算类型：10为当日业绩计算，20为外部回算，30为内部回算
  *  输出参数  ： RETCODE 0为正确1为错误， RETMSG错误信息
  *  来源表    ：
  *  目标表    :
  *   备注     ：存储过程名 PRC_01_AD
  *------------------------------------------------------------
  *  修改历史
  *  序号    日期      修改人      修改原因
  ************************************************************ */
 IS
	RECORD_TIME TIMESTAMP;
	FLOW_ID     VARCHAR2(32);
	P_STEP_ID   VARCHAR2(30);
	STEP_ID     VARCHAR2(30);
BEGIN
	FLOW_ID := FNC_GEN_FLOW_ID();
	STEP_ID := 'LYD_01_AD_';

	--对公客户分配规则明细生成
	RECORD_TIME := SYSDATE;
	P_STEP_ID   := STEP_ID || '01';
	PRC_11_CC_AD_CO_CUST(S_DATE, E_DATE, CALC_TYPE, RETCODE, RETMSG);
	IF RETCODE <> 0
		 OR RETCODE IS NULL THEN
		RETMSG := '对公客户分配规则明细生成-执行出错';
		PRC_SYS_MONITOR_LOG(FLOW_ID,
												S_DATE,
												E_DATE,
												P_STEP_ID,
												RECORD_TIME,
												'PRC_11_CC_AD_CO_CUST',
												4,
												RETMSG,
												'',
												RECORD_TIME,
												1);
		ROLLBACK;
		RETURN;
	ELSE
		RETMSG := '对公客户分配规则明细生成-执行成功';
		PRC_SYS_MONITOR_LOG(FLOW_ID,
												S_DATE,
												E_DATE,
												P_STEP_ID,
												RECORD_TIME,
												'PRC_11_CC_AD_CO_CUST',
												1,
												RETMSG,
												'',
												RECORD_TIME,
												1);
	END IF;

	--对公存款账户分配规则明细生成
	RECORD_TIME := SYSDATE;
	P_STEP_ID   := STEP_ID || '02';
	PRC_11_CD_AD_CO_DEPS(S_DATE, E_DATE, CALC_TYPE, RETCODE, RETMSG);
	IF RETCODE <> 0
		 OR RETCODE IS NULL THEN
		RETMSG := '对公存款账户分配规则明细生成-执行出错';
		PRC_SYS_MONITOR_LOG(FLOW_ID,
												S_DATE,
												E_DATE,
												P_STEP_ID,
												RECORD_TIME,
												'PRC_11_CD_AD_CO_DEPS',
												4,
												RETMSG,
												'',
												RECORD_TIME,
												1);
		ROLLBACK;
		RETURN;
	ELSE
		RETMSG := '对公存款账户分配规则明细生成-执行成功';
		PRC_SYS_MONITOR_LOG(FLOW_ID,
												S_DATE,
												E_DATE,
												P_STEP_ID,
												RECORD_TIME,
												'PRC_11_CD_AD_CO_DEPS',
												1,
												RETMSG,
												'',
												RECORD_TIME,
												1);
	END IF;

	--对公贷款账户分配规则明细生成
	RECORD_TIME := SYSDATE;
	P_STEP_ID   := STEP_ID || '03';
	PRC_11_CL_AD_CO_LOAN(S_DATE, E_DATE, CALC_TYPE, RETCODE, RETMSG);
	IF RETCODE <> 0
		 OR RETCODE IS NULL THEN
		RETMSG := '对公贷款账户分配规则明细生成-执行出错';
		PRC_SYS_MONITOR_LOG(FLOW_ID,
												S_DATE,
												E_DATE,
												P_STEP_ID,
												RECORD_TIME,
												'PRC_11_CL_AD_CO_LOAN',
												4,
												RETMSG,
												'',
												RECORD_TIME,
												1);
		ROLLBACK;
		RETURN;
	ELSE
		RETMSG := '对公贷款账户分配规则明细生成-执行成功';
		PRC_SYS_MONITOR_LOG(FLOW_ID,
												S_DATE,
												E_DATE,
												P_STEP_ID,
												RECORD_TIME,
												'PRC_11_CL_AD_CO_LOAN',
												1,
												RETMSG,
												'',
												RECORD_TIME,
												1);
	END IF;

	--对公业务流水分配规则明细生成
	RECORD_TIME := SYSDATE;
	P_STEP_ID   := STEP_ID || '04';
	PRC_11_CF_AD_CO_FLOW(S_DATE, E_DATE, CALC_TYPE, RETCODE, RETMSG);
	IF RETCODE <> 0
		 OR RETCODE IS NULL THEN
		RETMSG := '对公业务流水分配规则明细生成-执行出错';
		PRC_SYS_MONITOR_LOG(FLOW_ID,
												S_DATE,
												E_DATE,
												P_STEP_ID,
												RECORD_TIME,
												'PRC_11_CF_AD_CO_FLOW',
												4,
												RETMSG,
												'',
												RECORD_TIME,
												1);
		ROLLBACK;
		RETURN;
	ELSE
		RETMSG := '对公业务流水分配规则明细生成-执行成功';
		PRC_SYS_MONITOR_LOG(FLOW_ID,
												S_DATE,
												E_DATE,
												P_STEP_ID,
												RECORD_TIME,
												'PRC_11_CF_AD_CO_FLOW',
												1,
												RETMSG,
												'',
												RECORD_TIME,
												1);
	END IF;

	--对公签约流水分配规则明细生成
	RECORD_TIME := SYSDATE;
	P_STEP_ID   := STEP_ID || '05';
	PRC_11_CS_AD_CO_SIGN(S_DATE, E_DATE, CALC_TYPE, RETCODE, RETMSG);
	IF RETCODE <> 0
		 OR RETCODE IS NULL THEN
		RETMSG := '对公签约流水分配规则明细生成-执行出错';
		PRC_SYS_MONITOR_LOG(FLOW_ID,
												S_DATE,
												E_DATE,
												P_STEP_ID,
												RECORD_TIME,
												'PRC_11_CS_AD_CO_SIGN',
												4,
												RETMSG,
												'',
												RECORD_TIME,
												1);
		ROLLBACK;
		RETURN;
	ELSE
		RETMSG := '对公签约流水分配规则明细生成-执行成功';
		PRC_SYS_MONITOR_LOG(FLOW_ID,
												S_DATE,
												E_DATE,
												P_STEP_ID,
												RECORD_TIME,
												'PRC_11_CS_AD_CO_SIGN',
												1,
												RETMSG,
												'',
												RECORD_TIME,
												1);
	END IF;

	--零售客户分配规则明细生成
	RECORD_TIME := SYSDATE;
	P_STEP_ID   := STEP_ID || '06';
	PRC_11_SC_AD_SA_CUST(S_DATE, E_DATE, CALC_TYPE, RETCODE, RETMSG);
	IF RETCODE <> 0
		 OR RETCODE IS NULL THEN
		RETMSG := '零售客户分配规则明细生成-执行出错';
		PRC_SYS_MONITOR_LOG(FLOW_ID,
												S_DATE,
												E_DATE,
												P_STEP_ID,
												RECORD_TIME,
												'PRC_11_SC_AD_SA_CUST',
												4,
												RETMSG,
												'',
												RECORD_TIME,
												1);
		ROLLBACK;
		RETURN;
	ELSE
		RETMSG := '零售客户分配规则明细生成-执行成功';
		PRC_SYS_MONITOR_LOG(FLOW_ID,
												S_DATE,
												E_DATE,
												P_STEP_ID,
												RECORD_TIME,
												'PRC_11_SC_AD_SA_CUST',
												1,
												RETMSG,
												'',
												RECORD_TIME,
												1);
	END IF;

	--零售主账户分配规则明细生成
	RECORD_TIME := SYSDATE;
	P_STEP_ID   := STEP_ID || '07';
	PRC_11_SM_AD_SA_MAIN(S_DATE, E_DATE, CALC_TYPE, RETCODE, RETMSG);
	IF RETCODE <> 0
		 OR RETCODE IS NULL THEN
		RETMSG := '零售主账户分配规则明细生成-执行出错';
		PRC_SYS_MONITOR_LOG(FLOW_ID,
												S_DATE,
												E_DATE,
												P_STEP_ID,
												RECORD_TIME,
												'PRC_11_SM_AD_SA_MAIN',
												4,
												RETMSG,
												'',
												RECORD_TIME,
												1);
		ROLLBACK;
		RETURN;
	ELSE
		RETMSG := '零售主账户分配规则明细生成-执行成功';
		PRC_SYS_MONITOR_LOG(FLOW_ID,
												S_DATE,
												E_DATE,
												P_STEP_ID,
												RECORD_TIME,
												'PRC_11_SM_AD_SA_MAIN',
												1,
												RETMSG,
												'',
												RECORD_TIME,
												1);
	END IF;

	--零售存款账户分配规则明细生成
	RECORD_TIME := SYSDATE;
	P_STEP_ID   := STEP_ID || '08';
	PRC_11_SD_AD_SA_DEPS(S_DATE, E_DATE, CALC_TYPE, RETCODE, RETMSG);
	IF RETCODE <> 0
		 OR RETCODE IS NULL THEN
		RETMSG := '零售存款账户分配规则明细生成-执行出错';
		PRC_SYS_MONITOR_LOG(FLOW_ID,
												S_DATE,
												E_DATE,
												P_STEP_ID,
												RECORD_TIME,
												'PRC_11_SD_AD_SA_DEPS',
												4,
												RETMSG,
												'',
												RECORD_TIME,
												1);
		ROLLBACK;
		RETURN;
	ELSE
		RETMSG := '零售存款账户分配规则明细生成-执行成功';
		PRC_SYS_MONITOR_LOG(FLOW_ID,
												S_DATE,
												E_DATE,
												P_STEP_ID,
												RECORD_TIME,
												'PRC_11_SD_AD_SA_DEPS',
												1,
												RETMSG,
												'',
												RECORD_TIME,
												1);
	END IF;

	--零售贷款账户分配规则明细生成
	RECORD_TIME := SYSDATE;
	P_STEP_ID   := STEP_ID || '09';
	PRC_11_SL_AD_SA_LOAN(S_DATE, E_DATE, CALC_TYPE, RETCODE, RETMSG);
	IF RETCODE <> 0
		 OR RETCODE IS NULL THEN
		RETMSG := '零售贷款账户分配规则明细生成-执行出错';
		PRC_SYS_MONITOR_LOG(FLOW_ID,
												S_DATE,
												E_DATE,
												P_STEP_ID,
												RECORD_TIME,
												'PRC_11_SL_AD_SA_LOAN',
												4,
												RETMSG,
												'',
												RECORD_TIME,
												1);
		ROLLBACK;
		RETURN;
	ELSE
		RETMSG := '零售贷款账户分配规则明细生成-执行成功';
		PRC_SYS_MONITOR_LOG(FLOW_ID,
												S_DATE,
												E_DATE,
												P_STEP_ID,
												RECORD_TIME,
												'PRC_11_SL_AD_SA_LOAN',
												1,
												RETMSG,
												'',
												RECORD_TIME,
												1);
	END IF;

	--零售业务流水分配规则明细生成
	RECORD_TIME := SYSDATE;
	P_STEP_ID   := STEP_ID || '10';
	PRC_11_SF_AD_SA_FLOW(S_DATE, E_DATE, CALC_TYPE, RETCODE, RETMSG);
	IF RETCODE <> 0
		 OR RETCODE IS NULL THEN
		RETMSG := '零售业务流水分配规则明细生成-执行出错';
		PRC_SYS_MONITOR_LOG(FLOW_ID,
												S_DATE,
												E_DATE,
												P_STEP_ID,
												RECORD_TIME,
												'PRC_11_SF_AD_SA_FLOW',
												4,
												RETMSG,
												'',
												RECORD_TIME,
												1);
		ROLLBACK;
		RETURN;
	ELSE
		RETMSG := '零售业务流水分配规则明细生成-执行成功';
		PRC_SYS_MONITOR_LOG(FLOW_ID,
												S_DATE,
												E_DATE,
												P_STEP_ID,
												RECORD_TIME,
												'PRC_11_SF_AD_SA_FLOW',
												1,
												RETMSG,
												'',
												RECORD_TIME,
												1);
	END IF;

	--零售签约流水分配规则明细生成
	RECORD_TIME := SYSDATE;
	P_STEP_ID   := STEP_ID || '11';
	PRC_11_SS_AD_SA_SIGN(S_DATE, E_DATE, CALC_TYPE, RETCODE, RETMSG);
	IF RETCODE <> 0
		 OR RETCODE IS NULL THEN
		RETMSG := '零售签约流水分配规则明细生成-执行出错';
		PRC_SYS_MONITOR_LOG(FLOW_ID,
												S_DATE,
												E_DATE,
												P_STEP_ID,
												RECORD_TIME,
												'PRC_11_SS_AD_SA_SIGN',
												4,
												RETMSG,
												'',
												RECORD_TIME,
												1);
		ROLLBACK;
		RETURN;
	ELSE
		RETMSG := '零售签约流水分配规则明细生成-执行成功';
		PRC_SYS_MONITOR_LOG(FLOW_ID,
												S_DATE,
												E_DATE,
												P_STEP_ID,
												RECORD_TIME,
												'PRC_11_SS_AD_SA_SIGN',
												1,
												RETMSG,
												'',
												RECORD_TIME,
												1);
	END IF;

EXCEPTION
	WHEN OTHERS THEN
		ROLLBACK;
		RETCODE := -1;
		RETMSG  := '分配规则存储过程集合-执行错误-' || SQLERRM;
		PRC_SYS_MONITOR_LOG(FLOW_ID,
												S_DATE,
												E_DATE,
												P_STEP_ID,
												RECORD_TIME,
												'PRC_01_AD',
												4,
												RETMSG,
												'',
												RECORD_TIME,
												1);
END;

/

