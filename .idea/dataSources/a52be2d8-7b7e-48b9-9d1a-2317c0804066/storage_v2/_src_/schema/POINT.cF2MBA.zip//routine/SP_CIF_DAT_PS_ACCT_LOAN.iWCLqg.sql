create PROCEDURE SP_CIF_DAT_PS_ACCT_LOAN(IV_JOBID  IN VARCHAR2,
                                                    IV_OPERID IN VARCHAR2,
                                                    ON_RESULT OUT NUMBER)
--*******************************************************************************
  -- CopyRight (c) 2018, 融丰银行                                               *
  -- All rights reserved.                                                       *
  --                                                                            *
  -- 文件名称 : SP_CIF_DAT_PS_ACCT_LOAN.prc                                          *
  -- 摘    要 : 个人贷款数据表数据加工                                          *
  -- 工程模块 : crmapp.04_27                                                    *
  -- 当前版本 : V1.0.0                                                          *
  -- 作    者 : lyh                                                           *
  -- 完成日期 : 2018/03/15                                                     *
  -- 错误码段 : 40270 - 40279                                                   *
  --*****************************************************************************
 IS
  V_WORK_DATE  VARCHAR2(8);
  V_RETCODE    VARCHAR2(6) := '000000'; --程序/日志返回码
  V_MSG        VARCHAR2(1000); --程序执行信息
  V_TABNAME    VARCHAR2(100); --表名
  V_RETERRFLG  VARCHAR2(1); --日志标志 I(information) W(waring) E(error)
  V_ERRCODE    VARCHAR2(10) := '40279'; --程序执行出错返回码
  V_RETSUBCODE VARCHAR2(3); --程序子返回码
  --V_JOBID      VARCHAR2(50) := 'SP_CIF_DAT_PS_ACCT_LOAN';
  --V_OPERID     VARCHAR2(50) := 'ZHUY';
  V_JOBID  VARCHAR2(50) := IV_JOBID;
  V_OPERID VARCHAR2(50) := IV_OPERID;
  --V_YEAR_FIRST DATE; --年初
BEGIN

  /*获得业务时间*/
  SELECT WORK_DATE INTO V_WORK_DATE FROM SYS_PARA_DATE_NEW;
  --把日期处理成年初
  --V_YEAR_FIRST := TO_DATE(FNC_GET_DATE(V_WORK_DATE, 'YB'), 'YYYYMMDD');

  ----记录日志
  V_RETCODE    := '40270';
  V_RETSUBCODE := '001';
  V_RETERRFLG  := 'I';
  V_MSG        := '程序执行开始';
  SP_WRITEDETAILLOG(V_WORK_DATE,
                    V_JOBID,
                    V_OPERID,
                    V_MSG,
                    V_RETCODE,
                    V_RETSUBCODE,
                    V_RETERRFLG);

  V_RETCODE    := '40271';
  V_TABNAME    := 'CIF_DAT_PS_ACCT_LOAN';
  V_RETERRFLG  := 'I';
  V_RETSUBCODE := '001';
  /*清空个人贷款数据表*/
  EXECUTE IMMEDIATE 'TRUNCATE TABLE CIF_DAT_PS_ACCT_LOAN';
  /*写日志*/
  V_MSG := V_TABNAME || '表记录成功清除';
  SP_WRITEDETAILLOG(V_WORK_DATE,
                    V_JOBID,
                    V_OPERID,
                    V_MSG,
                    V_RETCODE,
                    V_RETSUBCODE,
                    V_RETERRFLG);

  V_RETCODE := '40272';
  /*加载数据到个人贷款数据表*/
  --加载信贷数据
  INSERT /*+APPEND*/
  INTO CIF_DAT_PS_ACCT_LOAN NOLOGGING
    (acct_no, --账号
     tar_date, --指标日期
     area_no, --区域号
     biz_cust_no, --原业务系统客户号
     acct_name, --户名
     business_type, --业务品种
     acct_state, --账户状态
     occur_type, --发生类型
     currency, --币种
     term, --期限
     subj_code, --科目
     prd_code, --产品代码
     contract_no, --贷款合同号
     loan_way, --贷款投向
     assure_model, --担保方式
     return_type, --还款方式
     fetchdate, --还款日
     open_date, --贷款日期
     open_org, --开户机构
     end_date, --到期日期
     loan_state, --贷款形态
     level_five, --五级分类
     pay_times, --还款期次
     amt_put, --结清金额
     amt_pay, --已还本金
     amt_delay, --拖欠本金
     accrual_delay, --拖欠利息
     rate, --利率
     accrual_should, --应收利息
     accrual_fact, --利息收入（结息金额-税金）
     accrual_fact_a, --累积实收利息（结息金额）
     taxes, --税金（公式为结息金额/1.03*0.03）
     bal, --贷款余额
     ftp_rate, --贷款ftp价格
     bal_profit_s, --应收模拟利润
     bal_profit_f, --实收模拟利润
     bal_fee, --营销费用
     stat_time, --统计日期
     is_new, --是否当年新增客户
     cust_lvl, --客户等级
     is_small_co, --是否小微客户
     bal_avg_m, --月日均余额
     bal_avg_y, --年日均余额
     bal_last_y, --上年末余额
     bal_last_avg_y, --上年末日均
     base_acct_no, --原系统贷款账号
     whe_spec_line, --是否特殊条线设置
     term_day, --期限日
     term_mon, --期限月
     ya_int_eps_amt, --年累计利息支出
     cd_int_eps_amt, --当日利息支出
     fin_br_no, --财务机构号
     OVER_DAYS, --逾期天数
     ACCOUNT_PRD_NO, --核心产品号（新增）
     LOAN_TYPE,
     VOU_AMT, -- 担保合同总金额
     LOAN_AMT, --发放金额
     settl_date, --本金结清日期
     CONT_AMT, --   合同金额
     ENDORSE_AMT --  审批金额
     )
    SELECT A.BILL_NO, --借据号
           V_WORK_DATE, --
           100, --
           nvl(A.CIF_NO, 0), --客户号
           A.CIF_NAME, --客户名称
           nvl(A.PRD_USERDF_TYPE, 0), --业务品种分类
           A.ACCOUNT_STATUS, --台帐状态(ACC_STATUS)
           NVL(A.OCCUR_TYPE, 0), --发生类型(OCCUR_TYPE)
           (CASE
             WHEN A.CUR_TYPE = 'CNY' THEN
              '01'
           END) CUR_TYPE, --币种(CUR_NO)
           A.TERM_DAY, --期限日
           NVL(A.ACCOUNT_CLASS, 0), --科目号
           NVL(A.PRD_NO, 0), --产品号
           A.CONT_NO, --合同号
           A.LOAN_DIRECT_NO, --贷款投向
           nvl(A.VOU_TYPE, 0), --主担保方式(VOU_TYPE)
           A.REPAY_TYPE, --还款方式(REPAY_TYPE)
           A.REPAY_DAY, --还款日
           A.LOAN_START_DATE, --贷款起始日
           A.FINA_BR_NO, --         账务机构
           A.LOAN_END_DATE, --贷款终止日
           1, --
           NVL(A.CLA, 0), --五级分类标志(FIVE_STS
           NULL, --
           CASE
             WHEN A.LOAN_BAL = 0 THEN
              A.LOAN_AMT
           END, --结清金额
           A.ADD_PAY_BAL, --累计还本金额
           NULL, --
           A.IN_INTST + A.OUT_INTST, --表内欠息+表外欠息
           a.DUE_RATE, --行里确认取执行利率(年)
           A.RECE_INT, --应还利息
           DETAIL.SUM1 - round(NVL(DETAIL.SUM1, 0) / 1.03 * 0.03, 2), --利息收入（结息金额-税金）
           DETAIL.SUM1, --累计收息（结息金额）
           round(NVL(DETAIL.SUM1, 0) / 1.03 * 0.03, 2), --税金（公式为结息金额/1.03*0.03，四舍五入保留两位小数）
           A.LOAN_BAL, --借据余额
           NULL, --
           NULL, --
           NULL, --
           NULL, --
           TO_DATE(V_WORK_DATE, 'YYYYMMDD'), --
           'N', --
           NVL(B.CIF_LVL, 0), --
           'N',
           NULL, --
           NULL, --
           NULL, --
           NULL, --
           A.LOAN_AC_NO, --贷款帐号
           '', --
           A.TERM_DAY, --期限日
           A.TERM_MON, --期限月
           NULL, --
           NULL, --
           A.FINA_BR_NO, --账务机构
           NVL(A.OVER_DAYS, 0), --逾期天数
           A.ACCOUNT_PRD_NO, --核心产品号
           '信贷',
           nvl(c.vou_amt, 0),
           A.LOAN_AMT,
           a.settl_date,
           d.cont_amt,
           d.endorse_amt
      FROM A_CMS_DUE_LOAN_ACC A
      LEFT JOIN A_CBS_CIF_BASIC_INF B
        ON A.CIF_NO = B.CIF_NO
      left join (select rel.cont_no cont_no, sum(cont.vou_amt) vou_amt --担保合同总金额
                   from a_cms_grt_cont cont
                   left join a_cms_grt_lnp_rel rel
                     on cont.grt_cont_no = rel.grt_cont_no
                  group by rel.cont_no) c
        on a.cont_no = c.cont_no
      left join (SELECT BILL_NO, SUM(TRADE_AMOUNT) AS SUM1 --累计收息(信贷提供的规则)
                   FROM A_cms_ACC_BILL_DETAILS
                  WHERE TRADE_TYPE <> '0'
                    AND ADD_IND = '0'
                  GROUP BY BILL_NO) DETAIL
        on a.bill_no = detail.BILL_NO
      left join (select lnp.cont_no cont_no,
                        sum(lnp.cont_amt) cont_amt, --合同金额
                        sum(lnp.endorse_amt) endorse_amt --审批金额
                   from A_CMS_LNP_LOAN lnp
                  group by lnp.cont_no) d
        on a.cont_no = d.cont_no
     WHERE A.CIF_TYPE = '2'
    --AND A.LOAN_START_DATE <= V_WORK_DATE
    ;
  COMMIT;
  --2个人，1公司
  /*  --加载供应链数据
  INSERT \*+APPEND*\
  INTO CIF_DAT_PS_ACCT_LOAN NOLOGGING
    (acct_no, --账号
     tar_date, --指标日期
     area_no, --区域号
     biz_cust_no, --原业务系统客户号
     acct_name, --户名
     business_type, --业务品种
     acct_state, --账户状态
     occur_type, --发生类型
     currency, --币种
     term, --期限
     subj_code, --科目
     prd_code, --产品代码
     contract_no, --贷款合同号
     loan_way, --贷款投向
     assure_model, --担保方式
     return_type, --还款方式
     fetchdate, --还款日
     open_date, --贷款日期
     open_org, --开户机构
     end_date, --到期日期
     loan_state, --贷款形态
     level_five, --五级分类
     pay_times, --还款期次
     amt_put, --发放金额
     amt_pay, --已还本金
     amt_delay, --拖欠本金
     accrual_delay, --拖欠利息
     rate, --利率
     accrual_should, --应收利息
     accrual_fact, --实收利息
     accrual_fact_a, --累积实收利息
     bal, --贷款余额
     ftp_rate, --贷款ftp价格
     bal_profit_s, --应收模拟利润
     bal_profit_f, --实收模拟利润
     bal_fee, --营销费用
     stat_time, --统计日期
     is_new, --是否当年新增客户
     cust_lvl, --客户等级
     is_small_co, --是否小微客户
     bal_avg_m, --月日均余额
     bal_avg_y, --年日均余额
     bal_last_y, --上年末余额
     bal_last_avg_y, --上年末日均
     base_acct_no, --原系统贷款账号
     whe_spec_line, --是否特殊条线设置
     term_day, --期限日
     term_mon, --期限月
     ya_int_eps_amt, --年累计利息支出
     cd_int_eps_amt, --当日利息支出
     fin_br_no, --财务机构号
     OVER_DAYS, --逾期天数
     ACCOUNT_PRD_NO, --核心产品号（新增）
     LOAN_TYPE)
    SELECT A.BILL_NO, --供应链系统借据号
         V_WORK_DATE, --报文数据日期
         '100', --
         nvl(B.CIF_NO,0), --核心客户号
         B.NAME, --客户名称
         A.BUSSINESS_TYPE, --业务品种(产品名称)
         A.ACT_STS, --账户状态（5放款已复核6已还款未复核7完结）
         nvl(A.OCCUR_TYPE,0), --贷款发生类型
         '01' CURRENCY, --币种（人民币）
         A.TERM_MON||'月', --期限月
         A.PROD_NO, --
         A.PROD_NO, --产品代码
         A.CONCAT_NO, --供应链系统合同号
         A.LOAN_WAY, --贷款投向
         A.ASSURE_MODEL, --担保方式(1 信用,2 保证,3 抵押,4 质押,5 转让)
         A.RETURN_TYPE, --还款方式1等额本息2等额本金3利随本清4到期还本按月结息5到期还本按季结息6按计划
         A.FETCHDATE, --还款日(如果是固定还款日，取还款日；如果是随贷款发放日，取日)
         A.OPEN_DATE, --借据开始日
         '600001', --开户机构均为前郭县阳光村镇银行
         A.END_DATE, --到期日期
         A.LOAN_STATE, --贷款形态(0-2不良，3-5正常，6展期)
         A.LEVEL_FIVE, --五级分类(1 正常,2 关注,3 次级,4 可疑,5 损失)
         A.PAY_TIMES, --还款期次(已还的还款计划期数 )
         A.DUE_AMT, --借据金额
         A.AMT_PAY, --已还本金(截止当前日期已还的本金之和)
         A.AMT_DELAY, --拖欠本金(截止当前日期逾期的本金之和)
         A.ACCRUAL_DELAY, --拖欠利息(截止当前日期逾期的利息之和，包含逾期的正常利息、逾期本金产生的利息和逾期正常利息产生的复利利息)
         A.RATE/100, --利率(借据利率，月利率)
         A.ACCRUAL_SHOULD, --应收利息(还款计划中正常利息之和)
         A.ACCRUAL_FACT, --实收利息(上报日归还的利息之和，含正常利息、逾期利息、复利利息)
         A.ACCRUAL_FACT_A, --累积实收利息(截止上报日之前所有已经归还的所有利息之和，含正常利息、逾期利息、复利利息)
         A.BAL, --借据余额
         NULL, --
         NULL, --
         NULL, --
         NULL, --
         TO_DATE(V_WORK_DATE, 'YYYYMMDD'),
         A.IS_NEW, --是否当年新增客户(1.是新增，2不是当年新增)
         NVL(C.CIF_LVL, 0),
         'N',
         NULL, --
         NULL, --
         A.BAL_LAST_Y, --上年末余额(如果借据跨年，取上年年末余额，否则为0)
         '', --
         '', --
         '', --
         A.TERM_DAY, --期限日
         A.TERM_MON, --期限月
         NULL, --
         NULL, --
         A.FIN_BR_NO, --财务机构号(600001)
         A.OVER_DAYS, --逾期天数(借据还款计划中最早逾期的那一期的逾期天数)
         '',
         '供应链'
    FROM A_GYL_LOANINFORMATION A
    LEFT JOIN A_CBS_CIF_ID_CODE_REL B --根据证件号码关联取核心客户号
      ON A.ID_NO = B.ID_NO
      and B.id_type='1'--取身份证
    LEFT JOIN A_CBS_CIF_BASIC_INF C
      ON B.CIF_NO = C.CIF_NO
   WHERE A.CIF_TYPE = '2';*/
  --2个人，1公司
  commit;
  V_TABNAME := 'CIF_DAT_PS_ACCT_LOAN';
  V_MSG     := V_TABNAME || '成功写入' || SQL%ROWCOUNT || '条记录';
  COMMIT;

  /*写日志*/
  SP_WRITEDETAILLOG(V_WORK_DATE,
                    V_JOBID,
                    V_OPERID,
                    V_MSG,
                    V_RETCODE,
                    V_RETSUBCODE,
                    V_RETERRFLG);

  V_RETCODE := '40274';
  V_TABNAME := 'CIF_DAT_PS_ACCT_LOAN';
  V_MSG     := V_TABNAME || '表成功写入数据';
  /*写日志*/
  V_RETSUBCODE := '001';
  SP_WRITEDETAILLOG(V_WORK_DATE,
                    V_JOBID,
                    V_OPERID,
                    V_MSG,
                    V_RETCODE,
                    V_RETSUBCODE,
                    V_RETERRFLG);

  V_RETCODE    := '40275';
  V_RETSUBCODE := '001';
  V_RETERRFLG  := 'I';
  V_MSG        := '程序执行结束';
  SP_WRITEDETAILLOG(V_WORK_DATE,
                    V_JOBID,
                    V_OPERID,
                    V_MSG,
                    V_RETCODE,
                    V_RETSUBCODE,
                    V_RETERRFLG);

  ON_RESULT := 0;

  /*异常处理*/
EXCEPTION
  WHEN OTHERS THEN
    V_RETERRFLG := 'E';
    V_RETCODE   := V_ERRCODE;
    V_MSG       := 'SQLCODE:' || V_TABNAME || '表' ||
                   SUBSTR(SQLERRM, 1, 500);
    ON_RESULT   := SQLCODE;
    ROLLBACK;
    SP_WRITEDETAILLOG(V_WORK_DATE,
                      V_JOBID,
                      V_OPERID,
                      V_MSG,
                      V_RETCODE,
                      V_RETSUBCODE,
                      V_RETERRFLG);
    RETURN;
END;
/

