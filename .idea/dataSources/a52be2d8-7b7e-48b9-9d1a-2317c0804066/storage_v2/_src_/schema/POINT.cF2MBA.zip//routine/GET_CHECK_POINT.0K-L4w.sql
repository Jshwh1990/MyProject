create FUNCTION Get_Check_Point(Pi_Identifyno VARCHAR2) RETURN VARCHAR2 IS
      --检查身份证号的校验位
      l_Identifyno17 VARCHAR2(18);
      l_Loopvl       PLS_INTEGER;
      l_Smryvl       PLS_INTEGER;
      l_Tempin       PLS_INTEGER;
      l_Tempch       CHAR(1);
   BEGIN

      --转化为十七位身份证(没有校验位)
      l_Identifyno17 := Ltrim(Rtrim(Pi_Identifyno));

      IF Length(l_Identifyno17) = 18 THEN
         l_Identifyno17 := Substr(l_Identifyno17,
                                  1,
                                  17);
      END IF;

      --计算校验位数值
      l_Loopvl := 17;
      l_Smryvl := 0;

      WHILE l_Loopvl > 0 LOOP
         l_Tempin := 19 - l_Loopvl;
         CASE l_Tempin
            WHEN 1 THEN
               l_Tempin := 1;
            WHEN 2 THEN
               l_Tempin := 2;
            WHEN 3 THEN
               l_Tempin := 4;
            WHEN 4 THEN
               l_Tempin := 8;
            WHEN 5 THEN
               l_Tempin := 5;
            WHEN 6 THEN
               l_Tempin := 10;
            WHEN 7 THEN
               l_Tempin := 9;
            WHEN 8 THEN
               l_Tempin := 7;
            WHEN 9 THEN
               l_Tempin := 3;
            WHEN 10 THEN
               l_Tempin := 6;
            WHEN 11 THEN
               l_Tempin := 1;
            WHEN 12 THEN
               l_Tempin := 2;
            WHEN 13 THEN
               l_Tempin := 4;
            WHEN 14 THEN
               l_Tempin := 8;
            WHEN 15 THEN
               l_Tempin := 5;
            WHEN 16 THEN
               l_Tempin := 10;
            WHEN 17 THEN
               l_Tempin := 9;
            WHEN 18 THEN
               l_Tempin := 7;
         END CASE;
         l_Smryvl := l_Smryvl + To_Number(Substr(l_Identifyno17,
                                                 l_Loopvl,
                                                 1)) * l_Tempin;
         l_Loopvl := l_Loopvl - 1;

      END LOOP;

      l_Tempin := MOD(l_Smryvl,
                      11);
      CASE l_Tempin
         WHEN 0 THEN
            l_Tempch := '1';
         WHEN 1 THEN
            l_Tempch := '0';
         WHEN 2 THEN
            l_Tempch := 'X';
         WHEN 3 THEN
            l_Tempch := '9';
         WHEN 4 THEN
            l_Tempch := '8';
         WHEN 5 THEN
            l_Tempch := '7';
         WHEN 6 THEN
            l_Tempch := '6';
         WHEN 7 THEN
            l_Tempch := '5';
         WHEN 8 THEN
            l_Tempch := '4';
         WHEN 9 THEN
            l_Tempch := '3';
         WHEN 10 THEN
            l_Tempch := '2';
         ELSE
            l_Tempch := '@';
      END CASE;

      RETURN l_Tempch;

   END Get_Check_Point;

/

