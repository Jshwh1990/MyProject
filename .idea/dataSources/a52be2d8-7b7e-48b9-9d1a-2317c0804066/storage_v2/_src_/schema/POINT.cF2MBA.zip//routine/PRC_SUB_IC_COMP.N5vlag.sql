create PROCEDURE PRC_SUB_IC_COMP
(
	IV_DATE     VARCHAR,
	IV_TRG_CODE VARCHAR,
	OI_RETURN   OUT INTEGER,
	OV_RETMSG   OUT VARCHAR
) IS
	/***************************************************************************
    功能模块：所有其他指标数据堆积(attribute<>00 同比，环比等)
    目标表  ：PI_ORG_QTY(机构指标表） PI_CM_QTY（客户指标表）
    过程名  ：prc_sub_ic_comp.prc
    参数    ：@Iv_date 数据日期（yyyymmdd) @trg_code 比较指标编码@oi_return 输出参数，为0表示程序功能正常
    程序逻辑：通过查找主指标进行运算；
    编写人  ：Lihl
    编写日期：2013-3-21
    更新日期：2013-4-9
  ****************************************************************************/
	VV_PROC_NAME   VARCHAR(30) := 'PRC_SUB_IC_COMP';
	VD_DATE        DATE := TO_DATE(IV_DATE, 'yyyymmdd'); --输入日期date型
	VV_TAR_DATE    VARCHAR(8); --插入到目标表数据日期，根据汇总周期：D-当天，M-当月最后一天,Q Y 同理
	VV_COMP_DATE   VARCHAR(8); --需要作比较的目标日期，如同比取去年同一天
	VV_EXEC_SQL    VARCHAR(32767); --最后执行sql
	VV_TAR_TABLE   VARCHAR(30); --目标表名
	VV_DIM_COL     VARCHAR(30); --维度字段名（manager_no,org_no）
	VV_MAIN_TRG    VARCHAR(32); --对应的主指标code
	VC_MAIN_PERIOD CHAR(1); --主指标的汇总周期
	VV_CALC_COL    VARCHAR(2000); --计算指标的公式
	--vi_cnt         Integer;
	VV_EXEC_SQL2  VARCHAR(32767); --机构和人员类型计算sql2
	VV_AREA_NO    VARCHAR(10);
	VV_TRG_ATTR   VARCHAR(2); --指标属性
	VC_APPLY_TYPE CHAR(1); --适用类型
BEGIN
	/*其他指标（同比，环比...）*/
	SELECT A.AREA_NO, A.TRG_ATTRIBUTE, A.APPLY_TYPE
		INTO VV_AREA_NO, VV_TRG_ATTR, VC_APPLY_TYPE
		FROM OP_TRG_QTY_INFO A
	 WHERE A.STATUS = '1'
		 AND A.DEL_FLAG = '0'
		 AND A.TRG_CODE = IV_TRG_CODE;
	/*输入指标不是同比环比类指标*/
	IF VV_TRG_ATTR NOT IN
		 ('01', '02', '03', '04', '05', '06', '07', '08', '09', '10', '11', '12') THEN
		PRC_IDX_WRITE_LOG(IV_DATE,
											IV_TRG_CODE,
											VV_PROC_NAME,
											-1,
											'输入指标不是同比环比类指标',
											'');
		OI_RETURN := -1;
		RETURN;
	END IF;

	/*初始化变量*/
	PRC_IDX_WRITE_LOG(IV_DATE, IV_TRG_CODE, VV_PROC_NAME, 0, '', '');
	VV_MAIN_TRG := SUBSTR(IV_TRG_CODE, 1, LENGTH(IV_TRG_CODE) - 2) || '00';
	/*主指标没有成功执行*/
	/*Select Count(*)
    Into vi_cnt
    From pi_kpi_calc_log
   Where dta_date = iv_date
     And trg_code = vv_main_trg
     And status = 1;
  If vi_cnt = 0 Then
    prc_idx_write_log(iv_date, iv_trg_code, vv_proc_name, -1, '主指标：' ||
                       vv_main_trg ||
                       '未成功执行', '');
    oi_return := -1;
    Return;
  End If;*/
	IF VC_APPLY_TYPE IN ('0', '2') THEN
		VV_TAR_TABLE := 'pi_cm_qty';
		VV_DIM_COL   := 'manager_no';
	ELSIF VC_APPLY_TYPE = '1' THEN
		VV_TAR_TABLE := 'pi_org_qty';
		VV_DIM_COL   := 'org_no';
	END IF;
	SELECT NVL(PERIOD, 'D')
		INTO VC_MAIN_PERIOD
		FROM OP_TRG_QTY_INFO A
	 WHERE A.TRG_CODE = IV_TRG_CODE;
	/*根据数据汇总周期清理目标表数据*/
	IF VC_MAIN_PERIOD = 'D' THEN
		VV_TAR_DATE := IV_DATE;
	ELSIF VC_MAIN_PERIOD = 'M' THEN
		VV_TAR_DATE := TO_CHAR(LAST_DAY(VD_DATE), 'yyyymmdd'); --本月最后一天
	ELSIF VC_MAIN_PERIOD = 'Q' THEN
		VV_TAR_DATE := TO_CHAR(ADD_MONTHS(TRUNC(VD_DATE, 'Q'), 3) - 1, 'yyyymmdd'); --本季最后一天
	ELSIF VC_MAIN_PERIOD = 'Y' THEN
		VV_TAR_DATE := TO_CHAR(ADD_MONTHS(TRUNC(VD_DATE, 'yyyy'), 12) - 1, 'yyyymmdd'); --本年最后一天
	END IF;
	EXECUTE IMMEDIATE 'Delete from ' || VV_TAR_TABLE || ' where target_date = ''' ||
										VV_TAR_DATE || ''' and target_code=''' || IV_TRG_CODE || '''';
	/*计算指标的公式
  00-主指标 01-同比 02-季环比 03-月环比 04-较月初增长量 05-较季初增长量 06-较年初增长量
  07-较月初增长率 08-较季初增长率 09-较年初增长率 10-完成比例 11-较目标增长量 12-同比增长量
  ***********************************************************/
	IF VV_TRG_ATTR IN ('01', '12') THEN
		VV_COMP_DATE := TO_CHAR(ADD_MONTHS(TO_DATE(VV_TAR_DATE, 'yyyymmdd'), -12),
														'yyyymmdd');
	ELSIF VV_TRG_ATTR = '02' THEN
		VV_COMP_DATE := TO_CHAR(ADD_MONTHS(TO_DATE(VV_TAR_DATE, 'yyyymmdd'), -3),
														'yyyymmdd');
	ELSIF VV_TRG_ATTR = '03' THEN
		VV_COMP_DATE := TO_CHAR(ADD_MONTHS(TO_DATE(VV_TAR_DATE, 'yyyymmdd'), -1),
														'yyyymmdd');
	ELSIF VV_TRG_ATTR IN ('04', '07') THEN
		VV_COMP_DATE := TO_CHAR(TRUNC(TO_DATE(VV_TAR_DATE, 'yyyymmdd'), 'mm') - 1,
														'yyyymmdd');
	ELSIF VV_TRG_ATTR IN ('05', '08') THEN
		VV_COMP_DATE := TO_CHAR(TRUNC(TO_DATE(VV_TAR_DATE, 'yyyymmdd'), 'q') - 1,
														'yyyymmdd');
	ELSIF VV_TRG_ATTR IN ('06', '09') THEN
		VV_COMP_DATE := TO_CHAR(TRUNC(TO_DATE(VV_TAR_DATE, 'yyyymmdd'), 'yyyy') - 1,
														'yyyymmdd');
	END IF;
	IF VV_TRG_ATTR IN ('01', '02', '03', '10') THEN
		--比值
		VV_CALC_COL := 'case when b.target_value is null or b.target_value=0 then NULL else a.target_value/b.target_value end';
	ELSIF VV_TRG_ATTR IN ('04', '05', '06', '11', '12') THEN
		--增长量
		VV_CALC_COL := 'a.target_value-nvl(b.target_value,0)';
		--增长率
	ELSIF VV_TRG_ATTR IN ('07', '08', '09') THEN
		VV_CALC_COL := 'case when b.target_value is null or b.target_value=0 then NULL else (a.target_value-b.target_value)/b.target_value end';
	END IF;
	/**************************************
        开始拼接执行sql:
  Insert Into target
  Select a.obj_no,
         'X',
         a.target_date,
         'YYY',
         a.target_value / b.target_value,
         trunc(Sysdate, 'yyyymmdd')
    From target a
    Left Join target b
      On a.obj_no = b.obj_no
     And b.target_code = 'XXX'
     And b.target_date = '20120301'
     And b.area_no = 'X'
   Where a.target_code = 'XXX'
     And a.target_date = '20130301'
     And a.area_no = 'X'
      ***************************************/
	VV_EXEC_SQL := 'Insert Into ' || VV_TAR_TABLE || ' Select a.' || VV_DIM_COL ||
								 ',a.area_no ,''' || VV_TAR_DATE || ''',''' || IV_TRG_CODE || ''',' ||
								 VV_CALC_COL || ',to_char(sysdate,''yyyymmdd'') From ' ||
								 VV_TAR_TABLE || ' a Left Join ' || VV_TAR_TABLE || ' b On (a.' ||
								 VV_DIM_COL || ' = ' || 'b.' || VV_DIM_COL ||
								 ' And a.area_no = b.area_no And b.target_code = ''' || VV_MAIN_TRG ||
								 ''' And b.target_date = ''' || VV_COMP_DATE ||
								 ''') Where a.target_code = ''' || VV_MAIN_TRG ||
								 ''' And a.target_date = ''' || VV_TAR_DATE || '''';

	/*执行sql，将结果写入目标表*/
	EXECUTE IMMEDIATE VV_EXEC_SQL;
	COMMIT;
	IF VC_APPLY_TYPE = '2' THEN
		VV_EXEC_SQL2 := REPLACE(VV_EXEC_SQL, 'manager_no', 'org_no');
		VV_EXEC_SQL2 := REPLACE(VV_EXEC_SQL2, 'pi_cm_qty', 'pi_org_qty');
		EXECUTE IMMEDIATE 'Delete from pi_org_qty where target_date = ''' || VV_TAR_DATE ||
											''' and target_code=''' || IV_TRG_CODE || '''';
		EXECUTE IMMEDIATE VV_EXEC_SQL2;
		COMMIT;
		PRC_IDX_WRITE_LOG(IV_DATE,
											IV_TRG_CODE,
											VV_PROC_NAME,
											1,
											'',
											VV_EXEC_SQL || ';' || VV_EXEC_SQL2); --wirte log
	ELSE
		PRC_IDX_WRITE_LOG(IV_DATE, IV_TRG_CODE, VV_PROC_NAME, 1, '', VV_EXEC_SQL); --write log
	END IF;
	OI_RETURN := 0;
	OV_RETMSG := '完成';
EXCEPTION
	WHEN OTHERS THEN
		OI_RETURN := SQLCODE;
		OV_RETMSG := SUBSTR(SQLERRM, 1, 200);
		PRC_IDX_WRITE_LOG(IV_DATE,
											IV_TRG_CODE,
											VV_PROC_NAME,
											-1,
											SUBSTR(SQLERRM, 1, 200),
											VV_EXEC_SQL || ';' || VV_EXEC_SQL2);
		ROLLBACK;
END;

/

