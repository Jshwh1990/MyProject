create view V_RELATION_OBJECT as
  SELECT R.ID,
       R.CUST_NO,
       R.CUST_NAME,
       R.CUST_TYPE,
       R.RELA_TYPE,
       R.RELA_NAME,
       R.CREATE_EMP_NO
  FROM (SELECT MB.ID,
               MB.CUST_NO,
               MB.CUST_NAME,
               MB.CUST_TYPE,
               'BO' RELA_TYPE,
               MB.OPPO_NAME RELA_NAME,
               MB.CREATE_EMP_NO
          FROM OP_MKT_BUSINESS_OPPORTUNITY MB
        UNION ALL
        SELECT MC.ID,
               MC.CUST_NO,
               MC.CUST_NAME,
               MC.CUST_TYPE,
               'CP' RELA_TYPE,
               MC.CUST_NAME || RD.NAME RELA_NAME,
               MC.CREATE_EMP_NO
          FROM OP_MKT_COMPLAINTS MC
          LEFT JOIN RBAC_DICTIONARY RD
            ON RD.VALUE = MC.COMP_TYPE
         WHERE RD.NICK_NAME = 'COMPLAINTS_TYPE') R
/

