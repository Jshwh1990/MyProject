create view V_EMPLOYEE as
  SELECT u.id user_id,
       e.EMP_NO,
       e.EMP_NAME,
       e.ORG_NO,
       e.STATUS
FROM SYS_EMPLOYEE e
left join rbac_user u
on e.emp_no=u.emp_no
/

