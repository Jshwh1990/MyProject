create FUNCTION SCR_FSRATE_AUTO_RATE(PT_VALUE   IN NUMBER
                                               ,FS_VALUE   IN NUMBER
                                               ,BASE_SCORE IN NUMBER)
  RETURN NUMBER IS
  /* 过程、函数简要描述信息
  **********************************************************
  *  存储过程名:  完成率自动增减法
  *  建立日期  :  2013-03-20
  *  作者      :  ZHUY
  *  模块      :  评分模型
  *  功能描述  :  完成率自动增减法
  *  输入参数  ：
  *  输出参数  ：
  *  来源表    ：
  *  目标表    :
  *   备注     ：1、 任务完成,得基本分；
                 2、 未加分 = 超额值 /（目标值 + 超额值）× 基础分 ；
                 3、 扣分 = 差额值 /（目标值 - 差额值）× 基础分 扣分不超过基础分；
                 6、PT_VALUE 任务值 FS_VALUE 完成值 BASE_SCORE 基本分
                 7、任务值为空时成绩为0
  *------------------------------------------------------------
  *  修改历史
  *  序号    日期      修改人      修改原因
  ************************************************************ */
  O_VAL    NUMBER(12, 2);
  OVER_VAL NUMBER(20, 6);
BEGIN
  IF (PT_VALUE = '' OR PT_VALUE IS NULL) THEN
    O_VAL := 0;
    RETURN O_VAL;
  END IF;
  IF (PT_VALUE = 0) THEN
    O_VAL := BASE_SCORE;
    RETURN O_VAL;
  END IF;

  IF (FS_VALUE = '' OR FS_VALUE IS NULL) THEN
    O_VAL := 0;
    RETURN O_VAL;
  END IF;
  IF (FS_VALUE = 0) THEN
    O_VAL := 0;
    RETURN O_VAL;
  END IF;

  OVER_VAL := (FS_VALUE - PT_VALUE) / FS_VALUE * BASE_SCORE;

  IF OVER_VAL < BASE_SCORE * (-1) THEN
    OVER_VAL := BASE_SCORE * (-1);
  END IF;

  O_VAL := BASE_SCORE + OVER_VAL;

  RETURN O_VAL;
END;

/

