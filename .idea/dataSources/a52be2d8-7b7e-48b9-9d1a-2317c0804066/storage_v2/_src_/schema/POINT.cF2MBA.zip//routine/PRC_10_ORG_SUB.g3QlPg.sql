create PROCEDURE PRC_10_ORG_SUB
(
	S_DATE    VARCHAR,
	E_DATE    VARCHAR,
	CALC_TYPE INT,
	RETCODE   OUT INT,
	RETMSG    OUT VARCHAR
)
/* 过程、函数简要描述信息
  **********************************************************
  *  存储过程名:  机构下级机构汇总
  *  建立日期  :  2013-03-20
  *  作者      :  linyd
  *  模块      :  机构下级机构汇总
  *  功能描述  :
  *  输入参数  ： s_date 处理日期,e_date 处理结束日期,flow_id流水
  *               calc_type 计算类型：10为当日业绩计算，20为外部回算，30为内部回算
  *  输出参数  ： RETCODE 0为正确1为错误， RETMSG错误信息
  *  来源表    ： sys_organization 机构表
  *  目标表    :  SYS_ORG_SUB 下级机构汇总表
  *   备注     ：存储过程名 PRC_10_ORG_SUM
  *------------------------------------------------------------
  *  修改历史
  *  序号    日期      修改人      修改原因
  ************************************************************ */
 IS
	P_SQL       LONG;
	STEP_ID     VARCHAR2(30);
	RECORD_TIME TIMESTAMP;
	P_STEP_ID   VARCHAR2(30);
	FLOW_ID     VARCHAR2(32);
	F_ORG       VARCHAR2(32);
	ORG_LEV     NUMBER(2);

	CURSOR IND_CUR IS
		SELECT A.ORG_NO, A.ORG_LEVEL FROM SYS_ORGANIZATION A ORDER BY A.ORG_NO;

BEGIN
	FLOW_ID := FNC_GEN_FLOW_ID();
	STEP_ID := 'LYD_10_ORG_SUM_';

	--清空下级机构汇总表
	RECORD_TIME := SYSDATE;
	RETMSG      := '清空下级机构汇总表-出错误';
	P_STEP_ID   := STEP_ID || '1';
	P_SQL       := 'TRUNCATE TABLE SYS_ORG_SUB';
	EXECUTE IMMEDIATE P_SQL;
	PRC_SYS_MONITOR_LOG(FLOW_ID,
											S_DATE,
											E_DATE,
											P_STEP_ID,
											RECORD_TIME,
											'PRC_10_ORG_SUB',
											1,
											'清空下级机构汇总表.[SYS_ORG_SUB]',
											P_SQL,
											RECORD_TIME,
											1);

	--根据机构上下级关系，取出机构所有下级机构
	RECORD_TIME := SYSDATE;
	RETMSG      := '生成机构所有下级机构-出错误';
	P_STEP_ID   := STEP_ID || '2';
	OPEN IND_CUR;
	LOOP
		FETCH IND_CUR
			INTO F_ORG, ORG_LEV;
		EXIT WHEN IND_CUR % NOTFOUND;
		P_SQL := 'INSERT INTO SYS_ORG_SUB(INS_ORG,INS_LEV,SUB_ORG)';
		P_SQL := P_SQL || ' SELECT ''' || F_ORG || ''' INS_ORG,' || ORG_LEV ||
						 ' INS_LEV,A.ORG_NO SUB_ORG FROM sys_organization A START WITH org_no = ''' ||
						 F_ORG || ''' CONNECT BY PRIOR org_no = PARENT_ORG_NO';
		EXECUTE IMMEDIATE P_SQL;
	END LOOP;
	PRC_SYS_MONITOR_LOG(FLOW_ID,
											S_DATE,
											E_DATE,
											P_STEP_ID,
											RECORD_TIME,
											'PRC_10_ORG_SUB',
											1,
											'生成机构所有下级机构.[SYS_ORG_SUB]',
											P_SQL,
											RECORD_TIME,
											1);
	CLOSE IND_CUR;

	COMMIT;
	RETCODE := 0;
	RETMSG  := '完成';
EXCEPTION
	WHEN OTHERS THEN
		ROLLBACK;
		RETCODE := -1;
		RETMSG  := '生成机构所有下级机构-执行错误[' || SQLERRM || ']. ' || RETMSG;
		PRC_SYS_MONITOR_LOG(FLOW_ID,
												S_DATE,
												E_DATE,
												P_STEP_ID,
												RECORD_TIME,
												'PRC_10_ORG_SUB',
												4,
												RETMSG,
												P_SQL,
												RECORD_TIME,
												1);
END;

/

