create PROCEDURE SP_CIF_MANAGER_PERFOEMANCE(IV_JOBID  IN VARCHAR2,
                                                       IV_OPERID IN VARCHAR2,
                                                       ON_RESULT OUT NUMBER)
--*******************************************************************************
  -- CopyRight (c) 2018, 融丰银行                                               *
  -- All rights reserved.                                                       *
  --                                                                            *
  -- 文件名称 : SP_CIF_MANAGER_PERFOEMANCE.prc                                          *
  -- 摘    要 : A03_手机银行存款绩效明细表加载                                          *
  -- 工程模块 : crmapp.04_27                                                    *
  -- 当前版本 : V1.0.0                                                          *
  -- 作    者 :                                                              *
  -- 完成日期 : 2018/02/01                                                     *
  -- 错误码段 : 40270 - 40279                                                   *
  --*****************************************************************************
 IS
  V_WORK_DATE  VARCHAR2(8);
  V_RETCODE    VARCHAR2(6) := '000000'; --程序/日志返回码
  V_MSG        VARCHAR2(1000); --程序执行信息
  V_TABNAME    VARCHAR2(100); --表名
  V_RETERRFLG  VARCHAR2(1); --日志标志 I(information) W(waring) E(error)
  V_ERRCODE    VARCHAR2(10) := '40279'; --程序执行出错返回码
  V_RETSUBCODE VARCHAR2(3); --程序子返回码 
  V_JOBID      VARCHAR2(50) := IV_JOBID;
  V_OPERID     VARCHAR2(50) := IV_OPERID;
  V_LAST_DAY   VARCHAR2(8); --当前业务日期的上一天日期
  TO_WORK_DATE DATE;
BEGIN

  /*获得业务时间*/
  SELECT WORK_DATE INTO V_WORK_DATE FROM SYS_PARA_DATE_NEW;
  TO_WORK_DATE := TO_DATE(V_WORK_DATE, 'YYYYMMDD');
  V_LAST_DAY   := TO_CHAR(TO_WORK_DATE - 1, 'YYYYMMDD'); --当前业务日期的上一天日期

  ----记录日志
  V_RETCODE    := '40270';
  V_RETSUBCODE := '001';
  V_RETERRFLG  := 'I';
  V_MSG        := '程序执行开始';
  SP_WRITEDETAILLOG(V_WORK_DATE,
                    V_JOBID,
                    V_OPERID,
                    V_MSG,
                    V_RETCODE,
                    V_RETSUBCODE,
                    V_RETERRFLG);

  V_RETCODE    := '40271';
  V_TABNAME    := 'CIF_MANAGER_PERFOEMANCE';
  V_RETERRFLG  := 'I';
  V_RETSUBCODE := '001';
  /*清空手机银行存款绩效表*/
  EXECUTE IMMEDIATE 'ALTER TABLE CIF_MANAGER_PERFOEMANCE TRUNCATE PARTITION P_' ||
                    V_WORK_DATE;
  /*清空手机银行存款绩效临时表*/
   EXECUTE IMMEDIATE 'TRUNCATE TABLE CIF_MANAGER_PERFOEMANCE_TP';
  /*写日志*/
  V_MSG := V_TABNAME || '表记录成功清除';
  SP_WRITEDETAILLOG(V_WORK_DATE,
                    V_JOBID,
                    V_OPERID,
                    V_MSG,
                    V_RETCODE,
                    V_RETSUBCODE,
                    V_RETERRFLG);

  V_RETCODE := '40272';
  /*加载数据到手机银行存款绩效临时表表*/
  INSERT /*+APPEND*/
  INTO CIF_MANAGER_PERFOEMANCE_TP NOLOGGING
    (ac_no, --帐号
     ac_id, --帐户id
     ac_seqn, --帐户序号
     mang, --经理代码（存款关联人）
     mang_name, --经理（存款关联人）名称
     mang_inviter, --存款关联人的邀请人
     mang_inviter_name, --存款关联人的邀请人名称
     super_no, --inviter上级(存款关联人的邀请人上级)
     super_no_name, --存款关联人的邀请人上级名称
     cif_no, --客户代码
     performance_no, --业绩归属人
     performance_name, --业绩归属人名称
     -- performance_mang, --存款关联人绩效
     -- performance_mang_inviter, --存款关联人的邀请人绩效
     name, --户名
     prdt_no, --产品编号
     prdt_name, --产品名称
     de_rate, --收益率
     bal_last_y, --年初余额
     bal, --当前余额
     bal_avg_m, --月日均余额
     M_BAL_S, -- 月累计
     BAL_AVG_Y, --年日均余额
     Y_BAL_S, -- 年累计
     crt_date, --购买日期
     canl_date, --到期日期
     performance_no_org, --业绩归属人部门
     work_date, --数据日期
     MDM_STS,
     OPEN_ORG,
     MANG_CIF_NO,
     INVITER_CIF_NO)
    SELECT B.AG_ACC_NO AS ac_no,
           NVL(B.ACC_ID, A.AC_ID) AS AC_ID,
           B.ACC_SEQN,
           A.mang,
           A.MANG_NAME,
           A.mang_inviter,
           A.MANG_INVITER_NAME,
           A.super_no,
           A. SUPER_NO_NAME,
           b.de_cif_no AS cif_no,
           (CASE
             WHEN A.performance_no LIKE '6%' THEN
              a.performance_no
             ELSE
              NULL --业绩归属人都是行内员工,不是行内员工的为空
           END) performance_no,
           (CASE
             WHEN A.performance_no LIKE '6%' THEN
              A.Performance_Name
             ELSE
              NULL --业绩归属人都是行内员工,不是行内员工的为空
           END) PERFORMANCE_NAME,
           /*(CASE
             WHEN A.MANG is not null and a.mang like '6%' THEN
              (NVL(B.DE_BAL, 0) / 10000) * (5 / 360) --存款关联人为6位工号的(客户经理和直销客户经理)绩效按照5元/万元/年来计算（20190104修改）
             WHEN A.MANG is not null and a.mang not like '8%' THEN
              (NVL(B.DE_BAL, 0) / 10000) * (15 / 360) --,存款关联人为12位工号（银行家）的不做改变，仍为15元/万元/年（20180702修改）。
             ELSE
              0
           END) PERFORMANCE_MANG,
           (CASE
             WHEN A.MANG_CIF_NO <> A.INVITER_CIF_NO AND
                  A.MANG_INVITER IS NOT NULL THEN --存款关联人的邀请人不为空并且存款关联人和存款关联人的邀请人不是同一个人则给2元
              (NVL(B.DE_BAL, 0) / 10000) * (2 / 360)
             ELSE
              0
           end) PERFORMANCE_MANG_INVITER,*/
           cif.NAME,
           B.PRDT_NO,
           D.PRDT_NAME,
           B.DE_RATE,
           NVL(C.BAL, 0), --上年末余额
           NVL(B.DE_BAL, 0) as bal,
           (CASE
             WHEN SUBSTR(V_WORK_DATE, 7, 2) = '01' THEN
              B.DE_BAL
             ELSE
              (B.DE_BAL + NVL(F.M_BAL_S, 0)) /
              (TO_NUMBER(SUBSTR(V_WORK_DATE, 7, 2)))
           END) BAL_AVG_M, --月日均余额
           (CASE
             WHEN SUBSTR(V_WORK_DATE, 7, 2) = '01' THEN
              B.DE_BAL
             ELSE
              (B.DE_BAL + NVL(F.M_BAL_S, 0))
           END) M_BAL_S, --月累计
           (CASE
             WHEN TO_CHAR(TO_DATE(V_WORK_DATE, 'YYYYMMDD'), 'DDD') = '001' THEN
              B.DE_BAL
             ELSE
              (B.DE_BAL + NVL(F.Y_BAL_S, 0)) /
              (TO_NUMBER(TO_CHAR(TO_DATE(V_WORK_DATE, 'YYYYMMDD'), 'DDD')))
           END) BAL_AVG_Y, --年日均余额
           (CASE
             WHEN TO_CHAR(TO_DATE(V_WORK_DATE, 'YYYYMMDD'), 'DDD') = '001' THEN
              B.DE_BAL
             ELSE
              (B.DE_BAL + NVL(F.Y_BAL_S, 0))
           END) Y_BAL_S, --年累计
           B.DE_OPN_DATE,
           B.DE_MTR_DATE,
           emp.org_no,
           V_WORK_DATE,
           B.DE_ACC_STS,
           B.OPN_BR_NO,
           A.MANG_CIF_NO,
           A.INVITER_CIF_NO
      FROM A_IFP2_DE_MST B
      LEFT JOIN B_OP_IFP2_MANAGER A
        ON A.AC_ID || A.AC_SEQN = B.ACC_ID || B.ACC_SEQN
      LEFT JOIN CIF_MANAGER_PERFOEMANCE C
        ON B.ACC_ID || B.ACC_SEQN = C.AC_ID || C.AC_SEQN
       AND C.WORK_DATE =
           TO_CHAR(TRUNC(TO_WORK_DATE, 'YYYY') - 1, 'YYYYMMDD') --上年末
      LEFT JOIN A_IFP2_PRDT_BASE_INFO D --PRD_NAME
        ON B.PRDT_NO = D.PRDT_NO
      LEFT JOIN CIF_MANAGER_PERFOEMANCE F
        ON B.ACC_ID || B.ACC_SEQN = F.AC_ID || F.AC_SEQN
       AND F.WORK_DATE = V_LAST_DAY --业务日期前一天
      LEFT JOIN SYS_EMPLOYEE emp
        ON a.performance_no = emp.emp_no --取业绩归属人所在的部门
      LEFT JOIN (select eci.cif_clino cif_no, eci.user_real_name name
                   from a_ifp2_eci_cif_register_bak eci
                  group by cif_clino, user_real_name) cif --20181008 关联客户号取户名
        ON B.DE_CIF_NO = cif.cif_no;
  COMMIT;
  /*加载数据到手机银行存款绩效表*/
  INSERT /*+APPEND*/
  INTO CIF_MANAGER_PERFOEMANCE NOLOGGING
    (ac_no, --帐号
     ac_id, --帐户id
     ac_seqn, --帐户序号
     mang, --经理代码（存款关联人）
     mang_name, --经理（存款关联人）名称
     mang_inviter, --存款关联人的邀请人
     mang_inviter_name, --存款关联人的邀请人名称
     super_no, --inviter上级(存款关联人的邀请人上级)
     super_no_name, --存款关联人的邀请人上级名称
     cif_no, --客户代码
     performance_no, --业绩归属人
     performance_name, --业绩归属人名称
     performance_mang, --存款关联人绩效
     performance_mang_inviter, --存款关联人的邀请人绩效
     name, --户名
     prdt_no, --产品编号
     prdt_name, --产品名称
     de_rate, --收益率
     bal_last_y, --年初余额
     bal, --当前余额
     bal_avg_m, --月日均余额
     M_BAL_S, -- 月累计
     BAL_AVG_Y, --年日均余额
     Y_BAL_S, -- 年累计
     crt_date, --购买日期
     canl_date, --到期日期
     performance_no_org, --业绩归属人部门
     work_date, --数据日期
     MDM_STS,
     OPEN_ORG,
     MANG_CIF_NO,
     INVITER_CIF_NO)
    select temp.ac_no, --帐号
           temp.ac_id, --帐户id
           temp.ac_seqn, --帐户序号
           temp.mang, --经理代码（存款关联人）
           temp.mang_name, --经理（存款关联人）名称
           temp.mang_inviter, --存款关联人的邀请人
           temp.mang_inviter_name, --存款关联人的邀请人名称
           temp.super_no, --inviter上级(存款关联人的邀请人上级)
           temp.super_no_name, --存款关联人的邀请人上级名称
           temp.cif_no, --客户代码
           temp.performance_no, --业绩归属人
           temp.performance_name, --业绩归属人名称
           (CASE
             WHEN temp.prdt_no in ('DE1130011',
                                   'DE1130012',
                                   'DE1130013',
                                   'DE1130014',
                                   'DE1130018',
                                   'DE1130016',
                                   'DE1130017') and temp.MANG is not null and
                  temp.mang like '6%' THEN
              (NVL(temp.bal_avg_m, 0) / 10000) * (5 / 360) --存款关联人为6位工号的(客户经理和直销客户经理)绩效按照5元/万元/年来计算
             WHEN temp.prdt_no in ('DE1130011',
                                   'DE1130012',
                                   'DE1130013',
                                   'DE1130014',
                                   'DE1130018',
                                   'DE1130016',
                                   'DE1130017') and temp.MANG is not null and
                  temp.mang not like '6%' THEN
              (NVL(temp.bal_avg_m, 0) / 10000) * (15 / 360) --,存款关联人为12位工号（银行家）的为15元/万元/年 。
             ELSE
              0
           END) PERFORMANCE_MANG,
           (CASE
             WHEN temp.prdt_no in ('DE1130011',
                                   'DE1130012',
                                   'DE1130013',
                                   'DE1130014',
                                   'DE1130018',
                                   'DE1130016',
                                   'DE1130017') and
                  temp.MANG_CIF_NO <> temp.INVITER_CIF_NO AND
                  temp.MANG_INVITER IS NOT NULL THEN --存款关联人的邀请人不为空并且存款关联人和存款关联人的邀请人不是同一个人则给2元
              (NVL(temp.bal_avg_m, 0) / 10000) * (2 / 360)
             ELSE
              0
           end) PERFORMANCE_MANG_INVITER,
           temp.name, --户名
           temp.prdt_no, --产品编号
           temp.prdt_name, --产品名称
           temp.de_rate, --收益率
           temp.bal_last_y, --年初余额
           temp.bal, --当前余额
           temp.bal_avg_m, --月日均余额
           temp.M_BAL_S, -- 月累计
           temp.BAL_AVG_Y, --年日均余额
           temp.Y_BAL_S, -- 年累计
           temp.crt_date, --购买日期
           temp.canl_date, --到期日期
           temp.performance_no_org, --业绩归属人部门
           temp.work_date, --数据日期
           temp.MDM_STS,
           temp.OPEN_ORG,
           temp.MANG_CIF_NO,
           temp.INVITER_CIF_NO
      from CIF_MANAGER_PERFOEMANCE_TP temp;
  COMMIT;

  V_TABNAME := 'CIF_MANAGER_PERFOEMANCE';
  V_MSG     := V_TABNAME || '成功写入' || SQL%ROWCOUNT || '条记录';
  COMMIT;

  /*写日志*/
  SP_WRITEDETAILLOG(V_WORK_DATE,
                    V_JOBID,
                    V_OPERID,
                    V_MSG,
                    V_RETCODE,
                    V_RETSUBCODE,
                    V_RETERRFLG);

  V_RETCODE := '40274';
  V_TABNAME := 'CIF_MANAGER_PERFOEMANCE';
  V_MSG     := V_TABNAME || '表成功写入数据';
  /*写日志*/
  V_RETSUBCODE := '001';
  SP_WRITEDETAILLOG(V_WORK_DATE,
                    V_JOBID,
                    V_OPERID,
                    V_MSG,
                    V_RETCODE,
                    V_RETSUBCODE,
                    V_RETERRFLG);

  V_RETCODE    := '40275';
  V_RETSUBCODE := '001';
  V_RETERRFLG  := 'I';
  V_MSG        := '程序执行结束';
  SP_WRITEDETAILLOG(V_WORK_DATE,
                    V_JOBID,
                    V_OPERID,
                    V_MSG,
                    V_RETCODE,
                    V_RETSUBCODE,
                    V_RETERRFLG);

  ON_RESULT := 0;

  /*异常处理*/
EXCEPTION
  WHEN OTHERS THEN
    V_RETERRFLG := 'E';
    V_RETCODE   := V_ERRCODE;
    V_MSG       := 'SQLCODE:' || V_TABNAME || '表' ||
                   SUBSTR(SQLERRM, 1, 500);
    ON_RESULT   := SQLCODE;
    ROLLBACK;
    SP_WRITEDETAILLOG(V_WORK_DATE,
                      V_JOBID,
                      V_OPERID,
                      V_MSG,
                      V_RETCODE,
                      V_RETSUBCODE,
                      V_RETERRFLG);
    RETURN;
END;
/

