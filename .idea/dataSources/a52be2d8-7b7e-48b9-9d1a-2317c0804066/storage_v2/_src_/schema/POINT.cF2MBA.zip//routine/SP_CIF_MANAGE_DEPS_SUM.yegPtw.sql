create PROCEDURE SP_CIF_MANAGE_DEPS_SUM(IV_JOBID  IN VARCHAR2,
                                                   IV_OPERID IN VARCHAR2,
                                                   ON_RESULT OUT NUMBER)
--*******************************************************************************
  -- CopyRight (c) 2018, 融丰银行                                               *
  -- All rights reserved.                                                       *
  --                                                                            *
  -- 文件名称 : SP_CIF_MANAGE_DEPS_SUM.prc                                          *
  -- 摘    要 : A03_手机银行存款业绩汇总                                          *
  -- 工程模块 : crmapp.04_27                                                    *
  -- 当前版本 : V1.0.0                                                          *
  -- 作    者 :                                                              *
  -- 完成日期 : 2018/02/01                                                     *
  -- 错误码段 : 40270 - 40279                                                   *
  --*****************************************************************************
 IS
  V_WORK_DATE  VARCHAR2(8);
  V_RETCODE    VARCHAR2(6) := '000000'; --程序/日志返回码
  V_MSG        VARCHAR2(1000); --程序执行信息
  V_TABNAME    VARCHAR2(100); --表名
  V_RETERRFLG  VARCHAR2(1); --日志标志 I(information) W(waring) E(error)
  V_ERRCODE    VARCHAR2(10) := '40279'; --程序执行出错返回码
  V_RETSUBCODE VARCHAR2(3); --程序子返回码
  V_JOBID      VARCHAR2(50) := IV_JOBID;
  V_OPERID     VARCHAR2(50) := IV_OPERID;
BEGIN

  /*获得业务时间*/
  SELECT WORK_DATE INTO V_WORK_DATE FROM SYS_PARA_DATE_NEW;

  ----记录日志
  V_RETCODE    := '40270';
  V_RETSUBCODE := '001';
  V_RETERRFLG  := 'I';
  V_MSG        := '程序执行开始';
  SP_WRITEDETAILLOG(V_WORK_DATE,
                    V_JOBID,
                    V_OPERID,
                    V_MSG,
                    V_RETCODE,
                    V_RETSUBCODE,
                    V_RETERRFLG);

  V_RETCODE    := '40271';
  V_TABNAME    := 'CIF_MANAGE_DEPS_SUM';
  V_RETERRFLG  := 'I';
  V_RETSUBCODE := '001';
  /*清空手机银行存款绩效表*/
  EXECUTE IMMEDIATE 'ALTER TABLE CIF_MANAGE_DEPS_SUM TRUNCATE PARTITION P_' ||
                    V_WORK_DATE;
  /*写日志*/
  V_MSG := V_TABNAME || '表记录成功清除';
  SP_WRITEDETAILLOG(V_WORK_DATE,
                    V_JOBID,
                    V_OPERID,
                    V_MSG,
                    V_RETCODE,
                    V_RETSUBCODE,
                    V_RETERRFLG);

  V_RETCODE := '40272';
  /*加载数据到手机银行存款绩效表*/
  INSERT /*+APPEND*/
  INTO CIF_MANAGE_DEPS_SUM NOLOGGING
    (emp_no, --员工号
     emp_name, --客户经理名称
     prdt_no, --产品编号
     prdt_name, --产品名称
     bal_last_y, --年初余额
     bal, --当前余额
     work_date --数据日期
     )
    select tmp.emp_no,
           tmp.emp_name,
           tmp.PRDT_NO,
           tmp.PRDT_NAME,
           sum(tmp.BAL_LAST_Y),
           sum(tmp.BAL),
           tmp.WORK_DATE
      from (SELECT T.Mang emp_no,
                   T.Mang_Name emp_name,
                   T.PRDT_NO,
                   T.PRDT_NAME,
                   SUM(T.BAL_LAST_Y) BAL_LAST_Y,
                   SUM(T.BAL) BAL,
                   V_WORK_DATE WORK_DATE
              FROM CIF_MANAGER_PERFOEMANCE T
             WHERE T.WORK_DATE = V_WORK_DATE --存款关联人
               AND t.mang like '6%'
             GROUP BY t.mang, t.mang_name, T.PRDT_NO, T.PRDT_NAME
            union all
            SELECT T.Mang_Inviter emp_no,
                   T.Mang_Inviter_Name emp_name,
                   T.PRDT_NO,
                   T.PRDT_NAME,
                   SUM(T.BAL_LAST_Y) BAL_LAST_Y,
                   SUM(T.BAL) BAL,
                   V_WORK_DATE WORK_DATE
              FROM CIF_MANAGER_PERFOEMANCE T
             WHERE T.WORK_DATE = V_WORK_DATE
               AND t.mang_inviter like '6%' --存款关联人的邀请人
               and t.mang_cif_no <> t.inviter_cif_no --存款关联人的邀请人不是存款关联人本身
             GROUP BY T.Mang_Inviter,
                      T.Mang_Inviter_Name,
                      T.PRDT_NO,
                      T.PRDT_NAME
            union all
            SELECT T.PERFORMANCE_NO emp_no,
                   T.PERFORMANCE_NAME emp_name,
                   T.PRDT_NO,
                   T.PRDT_NAME,
                   SUM(T.BAL_LAST_Y) BAL_LAST_Y,
                   SUM(T.BAL) BAL,
                   V_WORK_DATE WORK_DATE
              FROM CIF_MANAGER_PERFOEMANCE T
             WHERE T.WORK_DATE = V_WORK_DATE
               AND T.PERFORMANCE_NO IS NOT NULL --业绩归属人
               and t.performance_no <> t.mang
               and t.performance_no <> t.mang_inviter
             GROUP BY T.PERFORMANCE_NO,
                      T.PERFORMANCE_NAME,
                      T.PRDT_NO,
                      T.PRDT_NAME) tmp
     group by tmp.emp_no,
              tmp.emp_name,
              tmp.PRDT_NO,
              tmp.PRDT_NAME,
              tmp.WORK_DATE;

  V_TABNAME := 'CIF_MANAGE_DEPS_SUM';
  V_MSG     := V_TABNAME || '成功写入' || SQL%ROWCOUNT || '条记录';
  COMMIT;

  /*写日志*/
  SP_WRITEDETAILLOG(V_WORK_DATE,
                    V_JOBID,
                    V_OPERID,
                    V_MSG,
                    V_RETCODE,
                    V_RETSUBCODE,
                    V_RETERRFLG);

  V_RETCODE := '40274';
  V_TABNAME := 'CIF_MANAGE_DEPS_SUM';
  V_MSG     := V_TABNAME || '表成功写入数据';
  /*写日志*/
  V_RETSUBCODE := '001';
  SP_WRITEDETAILLOG(V_WORK_DATE,
                    V_JOBID,
                    V_OPERID,
                    V_MSG,
                    V_RETCODE,
                    V_RETSUBCODE,
                    V_RETERRFLG);

  V_RETCODE    := '40275';
  V_RETSUBCODE := '001';
  V_RETERRFLG  := 'I';
  V_MSG        := '程序执行结束';
  SP_WRITEDETAILLOG(V_WORK_DATE,
                    V_JOBID,
                    V_OPERID,
                    V_MSG,
                    V_RETCODE,
                    V_RETSUBCODE,
                    V_RETERRFLG);

  ON_RESULT := 0;

  /*异常处理*/
EXCEPTION
  WHEN OTHERS THEN
    V_RETERRFLG := 'E';
    V_RETCODE   := V_ERRCODE;
    V_MSG       := 'SQLCODE:' || V_TABNAME || '表' ||
                   SUBSTR(SQLERRM, 1, 500);
    ON_RESULT   := SQLCODE;
    ROLLBACK;
    SP_WRITEDETAILLOG(V_WORK_DATE,
                      V_JOBID,
                      V_OPERID,
                      V_MSG,
                      V_RETCODE,
                      V_RETSUBCODE,
                      V_RETERRFLG);
    RETURN;
END;
/

