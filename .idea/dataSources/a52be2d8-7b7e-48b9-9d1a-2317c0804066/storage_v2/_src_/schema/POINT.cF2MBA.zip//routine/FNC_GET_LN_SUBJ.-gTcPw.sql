create FUNCTION FNC_GET_LN_SUBJ
(
	PRD_NO  IN VARCHAR2, --产品号
	IF_UNIT IN VARCHAR2, --对公客户标志
	DUE_STS IN VARCHAR2, --借据状态
	LN_TERM IN INTEGER, --贷款期限: 月
	IF_GD   IN VARCHAR2, --是否固定资产贷款
	IF_PRJ  IN VARCHAR2, --是否项目贷款
	LN_JYXZ IN VARCHAR2 --贷款经营性质
) RETURN VARCHAR2 IS
	/*
   *******************
   信贷产品转科目函数
   *******************
  */
  RESULT  VARCHAR2(15);
  IS_UNIT VARCHAR2(1);
  IS_GD   VARCHAR2(1);
  IS_PRJ  VARCHAR2(1);
BEGIN
  IS_UNIT := IF_UNIT;
  IS_GD   := NVL(IF_GD, '0');
  IS_PRJ  := NVL(IF_PRJ, '0');
  IF PRD_NO IN ('50', '5001') THEN
    RESULT := '125101'; --贴现
  ELSIF PRD_NO IN ('48', '4801', '4802', '4803') THEN
    RESULT := '125102'; --转贴现
  ELSIF PRD_NO IN ('56', '5601') THEN
    RESULT := '700101'; --承兑汇票
  ELSIF PRD_NO = '95' THEN
    RESULT := '13210101'; --公积金委托贷款(个人)
  ELSIF PRD_NO = '55' THEN
    RESULT := '13210103'; --个人委托贷款
  ELSIF PRD_NO = '5501' THEN
    RESULT := '13210102'; --对公委托贷款
  ELSIF PRD_NO = '5602' THEN
    RESULT := '13010402'; --承兑垫款
    /*--暂无信用证垫款
    ELSIF PRD_NO = '信用证垫款' THEN
      RESULT := '13010403'; --信用证垫款*/
  ELSIF PRD_NO = '53' THEN
    RESULT := '700201'; --开出保函
  ELSIF PRD_NO = '5302' THEN
    RESULT := '13010404'; --保函垫款
    /*--暂无保理垫款
    ELSIF PRD_NO = '保理垫款' THEN
      RESULT := '13010405'; --保理垫款*/
  ELSIF PRD_NO = '04' THEN
    RESULT := '130105'; --信贷资产转让
    --贷款状态: 逾期/部分逾期/呆滞/呆账, 排除委托贷款、公积金贷款
  ELSIF DUE_STS IN ('3', '4', '5', '6')
        AND PRD_NO NOT IN ('95', '55', '5501') THEN
    IF IF_UNIT = '1'
       AND LN_TERM <= 12 THEN
      RESULT := '1301010105'; --单位逾期短期贷款
    ELSIF IF_UNIT = '1'
          AND LN_TERM > 12 THEN
      RESULT := '1301020105'; --单位逾期中长期贷款
    ELSIF IF_UNIT = '0'
          AND LN_TERM <= 12 THEN
      RESULT := '1301010204'; --个人逾期短期贷款
    ELSIF IF_UNIT = '0'
          AND LN_TERM > 12 THEN
      RESULT := '1301020204'; --个人逾期中长期贷款
    END IF;
    --单位流动资金贷款
  ELSIF PRD_NO IN ('01', '2201', '6701', '2301', '6101')
        OR (PRD_NO IN ('2501', '1801', '1901') AND IS_GD = '0' AND IS_PRJ = '0') THEN
    IF LN_TERM <= 12 THEN
      RESULT := '1301010101'; --单位短期流动资金贷款
    ELSIF LN_TERM > 12
          AND LN_TERM <= 24 THEN
      RESULT := '130102010101'; --一至二年流动资金贷款
    ELSIF LN_TERM > 24
          AND LN_TERM <= 36 THEN
      RESULT := '130102010102'; -- 二至三年流动资金贷款
    END IF;
    --单位固定资产贷款
  ELSIF (PRD_NO = '02' AND IS_PRJ = '0')
        OR (PRD_NO IN ('2501', '1801', '1901') AND IS_GD = '1' AND IS_PRJ = '0') THEN
    IF LN_TERM <= 12 THEN
      RESULT := '1301010102'; --单位短期固定资产贷款
    ELSIF LN_TERM > 12
          AND LN_TERM <= 24 THEN
      RESULT := '130102010201'; --一至二年固定资产贷款
    ELSIF LN_TERM > 24
          AND LN_TERM <= 36 THEN
      RESULT := '130102010202'; --二至三年固定资产贷款
    ELSIF LN_TERM > 36
          AND LN_TERM <= 48 THEN
      RESULT := '130102010203'; --三至四年固定资产贷款
    ELSIF LN_TERM > 48
          AND LN_TERM <= 60 THEN
      RESULT := '130102010204'; --四至五年固定资产贷款
    ELSIF LN_TERM > 60 THEN
      RESULT := '130102010205'; --五年以上固定资产贷款
    END IF;
    --单位项目融资贷款
  ELSIF PRD_NO IN ('81', '80')
        OR (PRD_NO IN ('02', '2501', '1801', '1901') AND IS_PRJ = '1') THEN
    IF LN_TERM <= 12 THEN
      RESULT := '1301010103'; --单位短期项目融资贷款
    ELSIF LN_TERM > 12
          AND LN_TERM <= 24 THEN
      RESULT := '130102010301'; --一至二年项目融资贷款
    ELSIF LN_TERM > 24
          AND LN_TERM <= 36 THEN
      RESULT := '130102010302'; --二至三年项目融资贷款
    ELSIF LN_TERM > 36
          AND LN_TERM <= 48 THEN
      RESULT := '130102010303'; --三至四年项目融资贷款
    ELSIF LN_TERM > 48
          AND LN_TERM <= 60 THEN
      RESULT := '130102010304'; --四至五年项目融资贷款
    ELSIF LN_TERM > 60 THEN
      RESULT := '130102010305'; --五年以上项目融资贷款
    END IF;
    --个人经营性贷款
  ELSIF IS_UNIT = '0'
        AND LN_JYXZ IN ('3', '4', '5')
        AND PRD_NO NOT IN ('95', '55', '5501') THEN
    IF LN_TERM <= 12 THEN
      RESULT := '1301010201'; --个人短期经营性贷款
    ELSIF LN_TERM > 12
          AND LN_TERM <= 24 THEN
      RESULT := '130102020101'; --一至二年经营性贷款
    ELSIF LN_TERM > 24
          AND LN_TERM <= 36 THEN
      RESULT := '130102020102'; --二至三年项目经营性贷款
    ELSIF LN_TERM > 36
          AND LN_TERM <= 48 THEN
      RESULT := '130102020103'; --三至四年经营性贷款
    ELSIF LN_TERM > 48
          AND LN_TERM <= 60 THEN
      RESULT := '130102020104'; --四至五年经营性贷款
    ELSIF LN_TERM > 60 THEN
      RESULT := '130102020105'; --五年以上经营性贷款
    END IF;
    --个人消费贷款
  ELSIF IS_UNIT = '0'
        AND LN_JYXZ = '1'
        AND PRD_NO NOT IN ('95', '55', '5501') THEN
    IF LN_TERM <= 12 THEN
      RESULT := '1301010202'; --个人短期消费贷款
    ELSIF LN_TERM > 12
          AND LN_TERM <= 24 THEN
      RESULT := '130102020201'; --一至二年消费贷款
    ELSIF LN_TERM > 24
          AND LN_TERM <= 36 THEN
      RESULT := '130102020202'; --二至三年消费贷款
    ELSIF LN_TERM > 36
          AND LN_TERM <= 48 THEN
      RESULT := '130102020203'; --三至四年消费贷款
    ELSIF LN_TERM > 48
          AND LN_TERM <= 60 THEN
      RESULT := '130102020204'; --四至五年消费贷款
    ELSIF LN_TERM > 60 THEN
      RESULT := '130102020205'; --五年以上消费贷款
    END IF;
  ELSE
    IF IS_UNIT = '1' THEN
      IF LN_TERM <= 12 THEN
        RESULT := '1301010104'; --单位其他短期贷款
      ELSIF LN_TERM > 12
            AND LN_TERM <= 24 THEN
        RESULT := '130102010401'; --单位其他一至二年贷款
      ELSIF LN_TERM > 24
            AND LN_TERM <= 36 THEN
        RESULT := '130102010402'; --单位其他二至三年贷款
      ELSIF LN_TERM > 36
            AND LN_TERM <= 48 THEN
        RESULT := '130102010403'; --单位其他三至四年贷款
      ELSIF LN_TERM > 48
            AND LN_TERM <= 60 THEN
        RESULT := '130102010404'; --单位其他四至五年贷款
      ELSIF LN_TERM > 60 THEN
        RESULT := '130102010405'; --单位其他五年以上贷款
      END IF;
      --个人其他贷款
    ELSIF IS_UNIT = '0' THEN
      IF LN_TERM <= 12 THEN
        RESULT := '1301010203'; --个人其他短期贷款
      ELSIF LN_TERM > 12
            AND LN_TERM <= 24 THEN
        RESULT := '130102020301'; --个人其他一至二年贷款
      ELSIF LN_TERM > 24
            AND LN_TERM <= 36 THEN
        RESULT := '130102020302'; --个人其他二至三年贷款
      ELSIF LN_TERM > 36
            AND LN_TERM <= 48 THEN
        RESULT := '130102020303'; --个人其他三至四年贷款
      ELSIF LN_TERM > 48
            AND LN_TERM <= 60 THEN
        RESULT := '130102020304'; --个人其他四至五年贷款
      ELSIF LN_TERM > 60 THEN
        RESULT := '130102020305'; --个人其他五年以上贷款
      END IF;
    END IF;
  END IF;
  IF RESULT IS NULL THEN
    RESULT := '99';
  END IF;
  RETURN(RESULT);
END;

/

