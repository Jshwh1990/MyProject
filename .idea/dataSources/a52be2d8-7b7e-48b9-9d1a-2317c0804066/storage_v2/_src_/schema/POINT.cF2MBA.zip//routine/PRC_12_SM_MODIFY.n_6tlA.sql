create PROCEDURE PRC_12_SM_MODIFY
(
	S_DATE    VARCHAR,
	E_DATE    VARCHAR,
	CALC_TYPE INT,
	RETCODE   OUT INT,
	RETMSG    OUT VARCHAR
)
/* 过程、函数简要描述信息
  **********************************************************
  *  存储过程名:  零售主账户修正
  *  建立日期  :  2013-03-20
  *  作者      :  linyd
  *  模块      :  业绩分配规模
  *  功能描述  :  根据主账户分配修正账户分配规则
  *  输入参数  ： s_date 处理日期,e_date 处理结束日期,flow_id流水
  *               calc_type 计算类型：10为当日业绩计算，20为外部回算，30为内部回算
  *  输出参数  ： RETCODE 0为正确1为错误， RETMSG错误信息
  *  来源表    ： OP_AS_AD_SA_MAIN 零售主账户规则明细表，CIF_INF_PS_ACCT_DEPS 零售存款账户信息表，CIF_INF_PS_ACCT_LOAN 零售贷款账户信息表，
  *  目标表    :  OP_AS_AD_SA_DEPS 零售存款账户分配规则明细表,OP_AS_AD_SA_LOAN 零售贷款账户分配规则明细表
  *   备注     ：存储过程名 PRC_12_SM_MODIFY 里的12为跑批号，SM第1个S为零售，第2个M为主账户业务类型号
  *------------------------------------------------------------
  *  修改历史
  *  序号    日期      修改人      修改原因
  ************************************************************ */
 IS
	P_SQL       LONG;
	INS_SQL     VARCHAR2(1000);
	SEL_SQL     VARCHAR2(4000);
	WHE_SQL     VARCHAR2(500);
	STEP_ID     VARCHAR2(30);
	RECORD_TIME TIMESTAMP;
	P_STEP_ID   VARCHAR2(30);
	FLOW_ID     VARCHAR2(32);
BEGIN
	FLOW_ID := FNC_GEN_FLOW_ID();
	STEP_ID := 'LYD_12_SM_MODIFY_';

	--个人存款账户分配修正个人流水业务
	RECORD_TIME := SYSDATE;
	RETMSG      := '个人存款账户分配修正个人流水业务-出现错误_';
	P_STEP_ID   := STEP_ID || '1';
	INS_SQL     := 'INSERT /*+append*/ INTO OP_AS_AD_SA_FLOW nologging (ID, res_id,area_no,al_type,al_in,start_date,end_date,al_way,al_rate,start_amt,end_amt,RES_ORG)';
	SEL_SQL     := ' SELECT sys_guid(),l1.flow_id,l1.area_no,l2.al_type,l2.al_in,l2.start_date,l2.end_date,l2.al_way,l2.al_rate,l2.start_amt,l2.end_amt,l1.OPEN_ORG';
	SEL_SQL     := SEL_SQL || ' FROM CIF_DAT_PS_FLOW l1,OP_AS_AD_SA_DEPS l2';
	WHE_SQL     := ' WHERE l1.acct_no=l2.res_id and l2.al_way=''1'' AND l1.tar_date=''' ||
								 S_DATE || '''';
	WHE_SQL     := WHE_SQL ||
								 ' AND NOT EXISTS (SELECT 1 FROM OP_AS_AD_SA_FLOW l3 WHERE l3.res_id=l1.flow_id)';
	P_SQL       := INS_SQL || SEL_SQL || WHE_SQL;
	EXECUTE IMMEDIATE P_SQL;
	PRC_SYS_MONITOR_LOG(FLOW_ID,
											S_DATE,
											E_DATE,
											P_STEP_ID,
											RECORD_TIME,
											'PRC_13_CC_MODIFY',
											1,
											'个人存款账户分配修正个人流水业务.[OP_AS_AD_SA_FLOW]',
											P_SQL,
											RECORD_TIME,
											1);

	--个人存款账户分配修正个人流水签约
	RECORD_TIME := SYSDATE;
	RETMSG      := '个人存款账户分配修正个人流水签约-出现错误_';
	P_STEP_ID   := STEP_ID || '2';
	INS_SQL     := 'INSERT /*+append*/ INTO OP_AS_AD_SA_SIGN nologging (ID, res_id,area_no,al_type,al_in,start_date,end_date,al_way,al_rate,start_amt,end_amt,RES_ORG)';
	SEL_SQL     := ' SELECT sys_guid(),l1.flow_id,l1.area_no,l2.al_type,l2.al_in,l2.start_date,l2.end_date,l2.al_way,l2.al_rate,l2.start_amt,l2.end_amt,l1.OPEN_ORG';
	SEL_SQL     := SEL_SQL || ' FROM CIF_DAT_PS_SIGN_FLOW l1,OP_AS_AD_SA_DEPS l2';
	WHE_SQL     := ' WHERE l1.acct_no=l2.res_id and l2.al_way=''1'' AND l1.tar_date=''' ||
								 S_DATE || '''';
	WHE_SQL     := WHE_SQL ||
								 ' AND NOT EXISTS (SELECT 1 FROM OP_AS_AD_SA_SIGN l3 WHERE l3.res_id=l1.flow_id)';
	P_SQL       := INS_SQL || SEL_SQL || WHE_SQL;
	EXECUTE IMMEDIATE P_SQL;
	PRC_SYS_MONITOR_LOG(FLOW_ID,
											S_DATE,
											E_DATE,
											P_STEP_ID,
											RECORD_TIME,
											'PRC_13_CC_MODIFY',
											1,
											'个人存款账户分配修正个人流水签约.[OP_AS_AD_SA_SIGN]',
											P_SQL,
											RECORD_TIME,
											1);

	--个人贷款账户分配修正个人流水业务
	RECORD_TIME := SYSDATE;
	RETMSG      := '个人贷款账户分配修正个人流水业务-出现错误_';
	P_STEP_ID   := STEP_ID || '3';
	INS_SQL     := 'INSERT /*+append*/ INTO OP_AS_AD_SA_FLOW nologging (ID, res_id,area_no,al_type,al_in,start_date,end_date,al_way,al_rate,start_amt,end_amt,RES_ORG)';
	SEL_SQL     := ' SELECT sys_guid(),l1.flow_id,l1.area_no,l2.al_type,l2.al_in,l2.start_date,l2.end_date,l2.al_way,l2.al_rate,l2.start_amt,l2.end_amt,l1.OPEN_ORG';
	SEL_SQL     := SEL_SQL || ' FROM CIF_DAT_PS_FLOW l1,OP_AS_AD_SA_LOAN l2';
	WHE_SQL     := ' WHERE l1.acct_no=l2.res_id and l2.al_way=''1'' AND l1.tar_date=''' ||
								 S_DATE || '''';
	WHE_SQL     := WHE_SQL ||
								 ' AND NOT EXISTS (SELECT 1 FROM OP_AS_AD_SA_FLOW l3 WHERE l3.res_id=l1.flow_id)';
	P_SQL       := INS_SQL || SEL_SQL || WHE_SQL;
	EXECUTE IMMEDIATE P_SQL;
	PRC_SYS_MONITOR_LOG(FLOW_ID,
											S_DATE,
											E_DATE,
											P_STEP_ID,
											RECORD_TIME,
											'PRC_13_CC_MODIFY',
											1,
											'个人贷款账户分配修正个人流水业务.[OP_AS_AD_SA_FLOW]',
											P_SQL,
											RECORD_TIME,
											1);

	--个人贷款账户分配修正个人流水签约
	RECORD_TIME := SYSDATE;
	RETMSG      := '个人贷款账户分配修正个人流水签约-出现错误_';
	P_STEP_ID   := STEP_ID || '4';
	INS_SQL     := 'INSERT /*+append*/ INTO OP_AS_AD_SA_SIGN nologging (ID, res_id,area_no,al_type,al_in,start_date,end_date,al_way,al_rate,start_amt,end_amt,RES_ORG)';
	SEL_SQL     := ' SELECT sys_guid(),l1.flow_id,l1.area_no,l2.al_type,l2.al_in,l2.start_date,l2.end_date,l2.al_way,l2.al_rate,l2.start_amt,l2.end_amt,l1.OPEN_ORG';
	SEL_SQL     := SEL_SQL || ' FROM CIF_DAT_PS_SIGN_FLOW l1,OP_AS_AD_SA_LOAN l2';
	WHE_SQL     := ' WHERE l1.acct_no=l2.res_id and l2.al_way=''1'' AND l1.tar_date=''' ||
								 S_DATE || '''';
	WHE_SQL     := WHE_SQL ||
								 ' AND NOT EXISTS (SELECT 1 FROM OP_AS_AD_SA_SIGN l3 WHERE l3.res_id=l1.flow_id)';
	P_SQL       := INS_SQL || SEL_SQL || WHE_SQL;
	EXECUTE IMMEDIATE P_SQL;
	PRC_SYS_MONITOR_LOG(FLOW_ID,
											S_DATE,
											E_DATE,
											P_STEP_ID,
											RECORD_TIME,
											'PRC_13_CC_MODIFY',
											1,
											'个人贷款账户分配修正个人流水签约.[OP_AS_AD_SA_SIGN]',
											P_SQL,
											RECORD_TIME,
											1);

	--对公存款账户分配修正对公流水业务
	RECORD_TIME := SYSDATE;
	RETMSG      := '对公存款账户分配修正对公流水业务-出现错误_';
	P_STEP_ID   := STEP_ID || '5';
	INS_SQL     := 'INSERT /*+append*/ INTO OP_AS_AD_CO_FLOW nologging (ID, res_id,area_no,al_type,al_in,start_date,end_date,al_way,al_rate,start_amt,end_amt,RES_ORG)';
	SEL_SQL     := ' SELECT sys_guid(),l1.flow_id,l1.area_no,l2.al_type,l2.al_in,l2.start_date,l2.end_date,l2.al_way,l2.al_rate,l2.start_amt,l2.end_amt,l1.OPEN_ORG';
	SEL_SQL     := SEL_SQL || ' FROM CIF_DAT_CO_FLOW l1,OP_AS_AD_CO_DEPS l2';
	WHE_SQL     := ' WHERE l1.acct_no=l2.res_id and l2.al_way=''1'' AND l1.tar_date=''' ||
								 S_DATE || '''';
	WHE_SQL     := WHE_SQL ||
								 ' AND NOT EXISTS (SELECT 1 FROM OP_AS_AD_CO_FLOW l3 WHERE l3.res_id=l1.flow_id)';
	P_SQL       := INS_SQL || SEL_SQL || WHE_SQL;
	EXECUTE IMMEDIATE P_SQL;
	PRC_SYS_MONITOR_LOG(FLOW_ID,
											S_DATE,
											E_DATE,
											P_STEP_ID,
											RECORD_TIME,
											'PRC_13_CC_MODIFY',
											1,
											'对公存款账户分配修正对公流水业务.[OP_AS_AD_CO_FLOW]',
											P_SQL,
											RECORD_TIME,
											1);

	--对公存款账户分配修正对公流水签约
	RECORD_TIME := SYSDATE;
	RETMSG      := '对公存款账户分配修正对公流水签约-出现错误_';
	P_STEP_ID   := STEP_ID || '6';
	INS_SQL     := 'INSERT /*+append*/ INTO OP_AS_AD_CO_SIGN nologging (ID, res_id,area_no,al_type,al_in,start_date,end_date,al_way,al_rate,start_amt,end_amt,RES_ORG)';
	SEL_SQL     := ' SELECT sys_guid(),l1.flow_id,l1.area_no,l2.al_type,l2.al_in,l2.start_date,l2.end_date,l2.al_way,l2.al_rate,l2.start_amt,l2.end_amt,l1.OPEN_ORG';
	SEL_SQL     := SEL_SQL || ' FROM CIF_DAT_CO_SIGN_FLOW l1,OP_AS_AD_CO_DEPS l2';
	WHE_SQL     := ' WHERE l1.acct_no=l2.res_id and l2.al_way=''1'' AND l1.tar_date=''' ||
								 S_DATE || '''';
	WHE_SQL     := WHE_SQL ||
								 ' AND NOT EXISTS (SELECT 1 FROM OP_AS_AD_CO_SIGN l3 WHERE l3.res_id=l1.flow_id)';
	P_SQL       := INS_SQL || SEL_SQL || WHE_SQL;
	EXECUTE IMMEDIATE P_SQL;
	PRC_SYS_MONITOR_LOG(FLOW_ID,
											S_DATE,
											E_DATE,
											P_STEP_ID,
											RECORD_TIME,
											'PRC_13_CC_MODIFY',
											1,
											'对公存款账户分配修正对公流水签约.[OP_AS_AD_CO_SIGN]',
											P_SQL,
											RECORD_TIME,
											1);

	--对公贷款账户分配修正对公流水业务
	RECORD_TIME := SYSDATE;
	RETMSG      := '对公贷款账户分配修正对公流水业务-出现错误_';
	P_STEP_ID   := STEP_ID || '7';
	INS_SQL     := 'INSERT /*+append*/ INTO OP_AS_AD_CO_FLOW nologging (ID, res_id,area_no,al_type,al_in,start_date,end_date,al_way,al_rate,start_amt,end_amt,RES_ORG)';
	SEL_SQL     := ' SELECT sys_guid(),l1.flow_id,l1.area_no,l2.al_type,l2.al_in,l2.start_date,l2.end_date,l2.al_way,l2.al_rate,l2.start_amt,l2.end_amt,l1.OPEN_ORG';
	SEL_SQL     := SEL_SQL || ' FROM CIF_DAT_CO_FLOW l1,OP_AS_AD_CO_LOAN l2';
	WHE_SQL     := ' WHERE l1.acct_no=l2.res_id and l2.al_way=''1'' AND l1.tar_date=''' ||
								 S_DATE || '''';
	WHE_SQL     := WHE_SQL ||
								 ' AND NOT EXISTS (SELECT 1 FROM OP_AS_AD_CO_FLOW l3 WHERE l3.res_id=l1.flow_id)';
	P_SQL       := INS_SQL || SEL_SQL || WHE_SQL;
	EXECUTE IMMEDIATE P_SQL;
	PRC_SYS_MONITOR_LOG(FLOW_ID,
											S_DATE,
											E_DATE,
											P_STEP_ID,
											RECORD_TIME,
											'PRC_13_CC_MODIFY',
											1,
											'对公贷款账户分配修正对公流水业务.[OP_AS_AD_CO_FLOW]',
											P_SQL,
											RECORD_TIME,
											1);

	--对公贷款账户分配修正对公流水签约
	RECORD_TIME := SYSDATE;
	RETMSG      := '对公贷款账户分配修正对公流水签约-出现错误_';
	P_STEP_ID   := STEP_ID || '8';
	INS_SQL     := 'INSERT /*+append*/ INTO OP_AS_AD_CO_SIGN nologging (ID, res_id,area_no,al_type,al_in,start_date,end_date,al_way,al_rate,start_amt,end_amt,RES_ORG)';
	SEL_SQL     := ' SELECT sys_guid(),l1.flow_id,l1.area_no,l2.al_type,l2.al_in,l2.start_date,l2.end_date,l2.al_way,l2.al_rate,l2.start_amt,l2.end_amt,l1.OPEN_ORG';
	SEL_SQL     := SEL_SQL || ' FROM CIF_DAT_CO_SIGN_FLOW l1,OP_AS_AD_CO_LOAN l2';
	WHE_SQL     := ' WHERE l1.acct_no=l2.res_id and l2.al_way=''1'' AND l1.tar_date=''' ||
								 S_DATE || '''';
	WHE_SQL     := WHE_SQL ||
								 ' AND NOT EXISTS (SELECT 1 FROM OP_AS_AD_CO_SIGN l3 WHERE l3.res_id=l1.flow_id)';
	P_SQL       := INS_SQL || SEL_SQL || WHE_SQL;
	EXECUTE IMMEDIATE P_SQL;
	PRC_SYS_MONITOR_LOG(FLOW_ID,
											S_DATE,
											E_DATE,
											P_STEP_ID,
											RECORD_TIME,
											'PRC_13_CC_MODIFY',
											1,
											'对公贷款账户分配修正对公流水签约.[OP_AS_AD_CO_SIGN]',
											P_SQL,
											RECORD_TIME,
											1);

	----------------------
	--修正存款账户分配
	RECORD_TIME := SYSDATE;
	RETMSG      := '主账户分配修正存款账户分配-出现错误_';
	P_STEP_ID   := STEP_ID || '9';
	INS_SQL     := 'INSERT /*+append*/ INTO OP_AS_AD_SA_DEPS nologging (ID, res_id,area_no,al_type,al_in,start_date,end_date,al_way,al_rate,start_amt,end_amt,RES_ORG)';
	SEL_SQL     := ' SELECT sys_guid(),l1.acct_no,l1.area_no,l2.al_type,l2.al_in,l2.start_date,l2.end_date,l2.al_way,l2.al_rate,l2.start_amt,l2.end_amt,l1.OPEN_ORG';
	SEL_SQL     := SEL_SQL || ' FROM CIF_INF_PS_ACCT_DEPS l1,OP_AS_AD_SA_MAIN l2';
	WHE_SQL     := ' WHERE l1.main_acct_no=l2.res_id';
	WHE_SQL     := WHE_SQL ||
								 ' AND NOT EXISTS (SELECT 1 FROM OP_AS_AD_SA_DEPS l3 WHERE l3.res_id=l1.acct_no)';
	P_SQL       := INS_SQL || SEL_SQL || WHE_SQL;
	EXECUTE IMMEDIATE P_SQL;
	PRC_SYS_MONITOR_LOG(FLOW_ID,
											S_DATE,
											E_DATE,
											P_STEP_ID,
											RECORD_TIME,
											'PRC_12_SM_MODIFY',
											1,
											'主账户分配修正存款账户分配表.[OP_AS_AD_SA_DEPS]',
											P_SQL,
											RECORD_TIME,
											1);

	--修正贷款账户分配
	RECORD_TIME := SYSDATE;
	RETMSG      := '主账户分配修正贷款账户分配-出现错误_';
	P_STEP_ID   := STEP_ID || '10';
	INS_SQL     := 'INSERT /*+append*/ INTO OP_AS_AD_SA_LOAN nologging (ID, res_id,area_no,al_type,al_in,start_date,end_date,al_way,al_rate,start_amt,end_amt,RES_ORG)';
	SEL_SQL     := ' SELECT sys_guid(),l1.acct_no,l1.area_no,l2.al_type,l2.al_in,l2.start_date,l2.end_date,l2.al_way,l2.al_rate,l2.start_amt,l2.end_amt,l1.OPEN_ORG';
	SEL_SQL     := SEL_SQL || ' FROM CIF_INF_PS_ACCT_LOAN l1,OP_AS_AD_SA_MAIN l2';
	WHE_SQL     := ' WHERE l1.main_acct_no=l2.res_id';
	WHE_SQL     := WHE_SQL ||
								 ' AND NOT EXISTS (SELECT 1 FROM OP_AS_AD_SA_LOAN l3 WHERE l3.res_id=l1.acct_no)';
	P_SQL       := INS_SQL || SEL_SQL || WHE_SQL;
	EXECUTE IMMEDIATE P_SQL;
	PRC_SYS_MONITOR_LOG(FLOW_ID,
											S_DATE,
											E_DATE,
											P_STEP_ID,
											RECORD_TIME,
											'PRC_12_SM_MODIFY',
											1,
											'主账户分配修正贷款账户分配表.[OP_AS_AD_SA_LOAN]',
											P_SQL,
											RECORD_TIME,
											1);

	--修正业务流水分配
	RECORD_TIME := SYSDATE;
	RETMSG      := '个人主账户分配修正业务流水分配-出现错误_';
	P_STEP_ID   := STEP_ID || '11';
	INS_SQL     := 'INSERT /*+append*/ INTO OP_AS_AD_SA_FLOW nologging (ID, res_id,area_no,al_type,al_in,start_date,end_date,al_way,al_rate,start_amt,end_amt,RES_ORG)';
	SEL_SQL     := ' SELECT sys_guid(),l1.flow_id,l1.area_no,l2.al_type,l2.al_in,l2.start_date,l2.end_date,l2.al_way,l2.al_rate,l2.start_amt,l2.end_amt,l1.OPEN_ORG';
	SEL_SQL     := SEL_SQL || ' FROM CIF_DAT_PS_FLOW l1,OP_AS_AD_SA_MAIN l2';
	WHE_SQL     := ' WHERE l1.main_acct_no=l2.res_id AND l1.tar_date=''' || S_DATE || '''';
	WHE_SQL     := WHE_SQL ||
								 ' AND NOT EXISTS (SELECT 1 FROM OP_AS_AD_SA_FLOW l3 WHERE l3.res_id=l1.flow_id)';
	P_SQL       := INS_SQL || SEL_SQL || WHE_SQL;
	EXECUTE IMMEDIATE P_SQL;
	PRC_SYS_MONITOR_LOG(FLOW_ID,
											S_DATE,
											E_DATE,
											P_STEP_ID,
											RECORD_TIME,
											'PRC_13_CC_MODIFY',
											1,
											'个人主账户分配修正业务流水分配表.[OP_AS_AD_SA_FLOW]',
											P_SQL,
											RECORD_TIME,
											1);

	--修正签约流水分配
	RECORD_TIME := SYSDATE;
	RETMSG      := '个人主账户分配修正签约流水分配-出现错误_';
	P_STEP_ID   := STEP_ID || '12';
	INS_SQL     := 'INSERT /*+append*/ INTO OP_AS_AD_SA_SIGN nologging (ID, res_id,area_no,al_type,al_in,start_date,end_date,al_way,al_rate,start_amt,end_amt,RES_ORG)';
	SEL_SQL     := ' SELECT sys_guid(),l1.flow_id,l1.area_no,l2.al_type,l2.al_in,l2.start_date,l2.end_date,l2.al_way,l2.al_rate,l2.start_amt,l2.end_amt,l1.OPEN_ORG';
	SEL_SQL     := SEL_SQL || ' FROM CIF_DAT_PS_SIGN_FLOW l1,OP_AS_AD_SA_MAIN l2';
	WHE_SQL     := ' WHERE l1.main_acct_no=l2.res_id AND l1.tar_date=''' || S_DATE || '''';
	WHE_SQL     := WHE_SQL ||
								 ' AND NOT EXISTS (SELECT 1 FROM OP_AS_AD_SA_SIGN l3 WHERE l3.res_id=l1.flow_id)';
	P_SQL       := INS_SQL || SEL_SQL || WHE_SQL;
	EXECUTE IMMEDIATE P_SQL;
	PRC_SYS_MONITOR_LOG(FLOW_ID,
											S_DATE,
											E_DATE,
											P_STEP_ID,
											RECORD_TIME,
											'PRC_13_CC_MODIFY',
											1,
											'个人主账户分配修正签约流水分配表.[OP_AS_AD_SA_SIGN]',
											P_SQL,
											RECORD_TIME,
											1);

	COMMIT;
	RETCODE := 0;
	RETMSG  := '完成';
EXCEPTION
	WHEN OTHERS THEN
		ROLLBACK;
		RETCODE := -1;
		RETMSG  := '主账户分配修正明细-执行错误[' || SQLERRM || ']. ' || RETMSG;
		PRC_SYS_MONITOR_LOG(FLOW_ID,
												S_DATE,
												E_DATE,
												P_STEP_ID,
												RECORD_TIME,
												'PRC_12_SM_MODIFY',
												4,
												RETMSG,
												P_SQL,
												RECORD_TIME,
												1);
END;

/

