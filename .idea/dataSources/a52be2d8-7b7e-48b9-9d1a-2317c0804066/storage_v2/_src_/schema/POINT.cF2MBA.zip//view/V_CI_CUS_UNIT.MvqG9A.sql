create view V_CI_CUS_UNIT as
  select A.CUST_NO,                          --客户编码
       A.CUST_NAME,                        --客户中文名
       A.CIFRE_NAME,                       --客户曾用名
       A.ENG_NAME,                         --客户英文名
       A.CERT_TYPE,                        --证件类型
       A.CERT_NO,                          --证件号
       A.CIF_AREA,                         --行政区划
       A.CO_SIZE,                          --企业规模
       A.CO_TYPE,                          --企业性质
       A.BELONG_WAY,                       --行业分类
       A.WAY_AREA,                         --经营范围
       A.MAIN_OPER,                        --主营业务
       A.RGST_DT,                          --注册日期
       A.BSN_LCN_MAT_DT,                   --营业执照到期日
       A.BASE_BR,                          --基本开户行
       A.BASE_NO,                          --基本账户
       A.WHE_MARKET,                       --是否上市
       A.MARKET_ADDR,                      --上市地
       A.OPERATION_RAPPORT,                --与我行业务往来关系
       A.RELATION_FLAG,                    --是否本行关联企业
       A.IFME_PARTNER,                     --是否我行股东
       A.WHE_GROUP,                        --是否集团客户
       A.MAIN_PROD,                        --主要产品情况
       A.MANA_AREA,                        --经营场地面积平米
       A.AREA_OWNER,                       --经营场地所有权
       A.ASS_TOT,                          --总资产
       A.ASS_NET,                          --净资产
       A.CRED_DEG,                         --信誉度
       A.CRTL_WAY,                         --控股方式
       A.WHE_ASSURANCE,                    --是否保险公司
       A.SML_CLT_F,                        --小微客户标志
       A.OPN_OU_IP_ID,                     --开户机构
       A.DEPS_BAL,                         --存款余额
       A.DEPS_BAL_AVG_M,                   --存款月日均
       A.DEPS_BAL_AVG_Y,                   --存款年日均
       A.LOAN_BAL,                         --贷款余额
       A.FINANCES_BAL,                     --理财余额
       A.CUST_LEVEL,                       --客户等级
       A.CUST_STATUS,                      --客户状态
       A.ASN_STATUS,                       --分配状态
       A.BELONG_ORG_NO,                    --归属机构
       A.BELONG_EMP_NO,                    --归属人员
       A.CREATE_EMP_NO,                    --创建人
       A.CREATE_TIME,                      --创建时间
       A.MODIFY_EMP_NO,                    --修改人
       A.MODIFY_TIME,                      --修改时间
       A.WHE_CREDIT,                       --是否授信客户
       A.WHE_NET_BANKING,                  --是否网银客户
       A.MODIFY_ORG_NO,                    --修改机构
       A.CREATE_ORG_NO,                    --创建机构
       A.LOAN_BAL_M,                       --贷款月日均
       A.LOAN_BAL_Y,                       --贷款年日均
       A.WHE_NOTE,                         --是否短信签约
       A.EFF_CST_DT,                       --开始成为客户日期
       A.CUST_STAGE,                       --客户阶段
       A.CUST_CRM_STATUS,                  --客户在crm状态
       A.DP_ACCT_CNT,                      --存款账户数
       A.LN_ACCT_CNT,                      --贷款账户数
       A.ALL_ACCT_CNT,                     --存款和贷款账户数之和
       A.CUST_LINE,                        --客户条线
       A.UNIT_TYPE,                        --单位类型
       A.BILL_BAL,                         --承兑汇票余额
       A.BILL_AVG_M,                       --承兑汇票月日均
       A.BILL_AVG_Q,                       --承兑汇票季日均
       A.BILL_AVG_Y,                       --承兑汇票年日均
       A.CD_INT_EPS_AMT,                   --当日利息支出
       A.MA_INT_EPS_AMT,                   --月累计利息支出
       A.QA_INT_EPS_AMT,                   --季累计利息支出
       A.YA_INT_EPS_AMT,                   --年累计利息支出
       A.ACCRUAL_SHOULD,                   --当日应收利息
       A.ACCRUAL_SHOULD_A,                 --累计应收利息
       A.ACCRUAL_FACT,                     --当日实收利息
       A.ACCRUAL_FACT_A                    --累计实收利息
  from CI_CUS_UNIT A
 where not exists (select 1 from CI_CUS_UNIT_COMBINE B where (A.CUST_NO=B.CUST_NO or A.CUST_NO=B.COMBINED_CUST_NO) and B.STATE='1')
union all
select M.CUST_NO,                          --客户编码
       M.CUST_NAME,                        --客户中文名
       M.CIFRE_NAME,                       --客户曾用名
       M.ENG_NAME,                         --客户英文名
       M.CERT_TYPE,                        --证件类型
       M.CERT_NO,                          --证件号
       M.CIF_AREA,                         --行政区划
       M.CO_SIZE,                          --企业规模
       M.CO_TYPE,                          --企业性质
       M.BELONG_WAY,                       --行业分类
       M.WAY_AREA,                         --经营范围
       M.MAIN_OPER,                        --主营业务
       M.RGST_DT,                          --注册日期
       M.BSN_LCN_MAT_DT,                   --营业执照到期日
       M.BASE_BR,                          --基本开户行
       M.BASE_NO,                          --基本账户
       M.WHE_MARKET,                       --是否上市
       M.MARKET_ADDR,                      --上市地
       M.OPERATION_RAPPORT,                --与我行业务往来关系
       M.RELATION_FLAG,                    --是否本行关联企业
       M.IFME_PARTNER,                     --是否我行股东
       M.WHE_GROUP,                        --是否集团客户
       M.MAIN_PROD,                        --主要产品情况
       M.MANA_AREA,                        --经营场地面积平米
       M.AREA_OWNER,                       --经营场地所有权
       N.ASS_TOT,                          --总资产
       N.ASS_NET,                          --净资产
       M.CRED_DEG,                         --信誉度
       M.CRTL_WAY,                         --控股方式
       M.WHE_ASSURANCE,                    --是否保险公司
       M.SML_CLT_F,                        --小微客户标志
       M.OPN_OU_IP_ID,                     --开户机构
       sum(nvl(N.DEPS_BAL,0)),                         --存款余额
       sum(nvl(N.DEPS_BAL_AVG_M,0)),                   --存款月日均
       sum(nvl(N.DEPS_BAL_AVG_Y,0)),                   --存款年日均
       sum(nvl(N.LOAN_BAL,0)),                         --贷款余额
       sum(nvl(N.FINANCES_BAL,0)),                     --理财余额
       M.CUST_LEVEL,                       --客户等级
       M.CUST_STATUS,                      --客户状态
       M.ASN_STATUS,                       --分配状态
       M.BELONG_ORG_NO,                    --归属机构
       M.BELONG_EMP_NO,                    --归属人员
       M.CREATE_EMP_NO,                    --创建人
       M.CREATE_TIME,                      --创建时间
       M.MODIFY_EMP_NO,                    --修改人
       M.MODIFY_TIME,                      --修改时间
       M.WHE_CREDIT,                       --是否授信客户
       M.WHE_NET_BANKING,                  --是否网银客户
       M.MODIFY_ORG_NO,                    --修改机构
       M.CREATE_ORG_NO,                    --创建机构
       sum(nvl(N.LOAN_BAL_M,0)),                       --贷款月日均
       sum(nvl(N.LOAN_BAL_Y,0)),                       --贷款年日均
       M.WHE_NOTE,                         --是否短信签约
       M.EFF_CST_DT,                       --开始成为客户日期
       M.CUST_STAGE,                       --客户阶段
       M.CUST_CRM_STATUS,                  --客户在crm状态
       sum(nvl(N.DP_ACCT_CNT,0)),                      --存款账户数
       sum(nvl(N.LN_ACCT_CNT,0)),                      --贷款账户数
       sum(nvl(N.ALL_ACCT_CNT,0)),                     --存款和贷款账户数之和
       M.CUST_LINE,                        --客户条线
       M.UNIT_TYPE,                        --单位类型
       sum(nvl(N.BILL_BAL,0)),                         --承兑汇票余额
       sum(nvl(N.BILL_AVG_M,0)),                       --承兑汇票月日均
       sum(nvl(N.BILL_AVG_Q,0)),                       --承兑汇票季日均
       sum(nvl(N.BILL_AVG_Y,0)),                       --承兑汇票年日均
       sum(nvl(N.CD_INT_EPS_AMT,0)),                   --当日利息支出
       sum(nvl(N.MA_INT_EPS_AMT,0)),                   --月累计利息支出
       sum(nvl(N.QA_INT_EPS_AMT,0)),                   --季累计利息支出
       sum(nvl(N.YA_INT_EPS_AMT,0)),                   --年累计利息支出
       sum(nvl(N.ACCRUAL_SHOULD,0)),                   --当日应收利息
       sum(nvl(N.ACCRUAL_SHOULD_A,0)),                 --累计应收利息
       sum(nvl(N.ACCRUAL_FACT,0)),                     --当日实收利息
       sum(nvl(N.ACCRUAL_FACT_A,0))                    --累计实收利息
  from
       (select * from CI_CUS_UNIT I
        where exists (select 1 from CI_CUS_UNIT_COMBINE K where I.CUST_NO=K.CUST_NO and K.STATE='1')) M
left join
       (select * from CI_CUS_UNIT J
        where exists (select 1 from CI_CUS_UNIT_COMBINE L where (J.CUST_NO=L.CUST_NO or J.CUST_NO=L.COMBINED_CUST_NO) and L.STATE='1')) N
       on M.CUST_NO=N.CUST_NO
group by M.CUST_NO,
         M.CUST_NAME,
         M.CIFRE_NAME,
         M.ENG_NAME,
         M.CERT_TYPE,
         M.CERT_NO,
         M.CIF_AREA,
         M.CO_SIZE,
         M.CO_TYPE,
         M.BELONG_WAY,
         M.WAY_AREA,
         M.MAIN_OPER,
         M.RGST_DT,
         M.BSN_LCN_MAT_DT,
         M.BASE_BR,
         M.BASE_NO,
         M.WHE_MARKET,
         M.MARKET_ADDR,
         M.OPERATION_RAPPORT,
         M.RELATION_FLAG,
         M.IFME_PARTNER,
         M.WHE_GROUP,
         M.MAIN_PROD,
         M.MANA_AREA,
         M.AREA_OWNER,
         N.ASS_TOT,
         N.ASS_NET,
         M.CRED_DEG,
         M.CRTL_WAY,
         M.WHE_ASSURANCE,
         M.SML_CLT_F,
         M.OPN_OU_IP_ID,
         M.CUST_LEVEL,
         M.CUST_STATUS,
         M.ASN_STATUS,
         M.BELONG_ORG_NO,
         M.BELONG_EMP_NO,
         M.CREATE_EMP_NO,
         M.CREATE_TIME,
         M.MODIFY_EMP_NO,
         M.MODIFY_TIME,
         M.WHE_CREDIT,
         M.WHE_NET_BANKING,
         M.MODIFY_ORG_NO,
         M.CREATE_ORG_NO,
         M.WHE_NOTE,
         M.EFF_CST_DT,
         M.CUST_STAGE,
         M.CUST_CRM_STATUS,
         M.CUST_LINE,
         M.UNIT_TYPE

/

