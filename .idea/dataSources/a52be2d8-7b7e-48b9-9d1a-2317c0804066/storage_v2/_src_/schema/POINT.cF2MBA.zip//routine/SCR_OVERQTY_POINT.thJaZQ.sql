create FUNCTION SCR_OVERQTY_POINT(BASE_SCORE   IN NUMBER,
                                             LPT_VALUE    IN NUMBER,
                                             FS_VALUE     IN NUMBER,
                                             HPT_VALUE    IN NUMBER,
                                             ADD_VALUE    IN NUMBER,
                                             ADD_SCORE    IN NUMBER,
                                             HIGH_SCORE   IN NUMBER,
                                             REDUCE_VALUE IN NUMBER,
                                             REDUCE_SCORE IN NUMBER,
                                             LOW_SCORE    IN NUMBER)
  RETURN NUMBER IS
/* 过程、函数简要描述信息
  **********************************************************
  *  存储过程名:  超范围按量扣分法
  *  建立日期  :  2013-03-20
  *  作者      :  linyd
  *  模块      :  评分模型
  *  功能描述  :  超范围按量扣分法
  *  输入参数  ：
  *  输出参数  ：
  *  来源表    ：
  *  目标表    :
  *   备注     ：1、 指标在  (元)   到   (元) 之间得满分！
                 2、 每超出上限   （元），  扣分  ，   扣分不超过   分 ；
                 3、 每低于下限   （元），  扣分  ，   扣分不超过   分 ；
  *------------------------------------------------------------
  *  修改历史
  *  序号    日期      修改人      修改原因
  ************************************************************ */
  O_VAL NUMBER(12, 2);
BEGIN
  IF ((LPT_VALUE IS NOT NULL) OR (HPT_VALUE IS NOT NULL) OR
     (FS_VALUE IS NOT NULL) OR (ADD_VALUE IS NOT NULL) OR
     (REDUCE_VALUE IS NOT NULL)) AND (HPT_VALUE >= LPT_VALUE) THEN
    IF (FS_VALUE >= LPT_VALUE AND FS_VALUE <= HPT_VALUE) THEN
      O_VAL := BASE_SCORE;
    ELSIF (FS_VALUE > HPT_VALUE) THEN
      O_VAL := TRUNC((FS_VALUE - HPT_VALUE) / ADD_VALUE) * ADD_SCORE;
      IF O_VAL > HIGH_SCORE THEN
        O_VAL := BASE_SCORE - HIGH_SCORE;
      ELSE
        O_VAL := BASE_SCORE - O_VAL;
      END IF;
    ELSIF (FS_VALUE < LPT_VALUE) THEN
      O_VAL := TRUNC((LPT_VALUE - FS_VALUE) / REDUCE_VALUE) * REDUCE_SCORE;
      IF O_VAL > LOW_SCORE THEN
        O_VAL := BASE_SCORE - LOW_SCORE;
      ELSE
        O_VAL := BASE_SCORE - O_VAL;
      END IF;
    END IF;
  ELSE
    O_VAL := NULL;
  END IF;
  RETURN O_VAL;
END;

/

