create PROCEDURE SP_CIF_DAT_PS_CUST(IV_JOBID  IN VARCHAR2,
                                               IV_OPERID IN VARCHAR2,
                                               ON_RESULT OUT NUMBER)
--*******************************************************************************
  -- CopyRight (c) 2017, 融丰银行                                         *
  -- All rights reserved.                                                       *
  --                                                                            *
  -- 文件名称 : SP_CIF_DAT_PS_CUST.prc                                          *
  -- 摘    要 : A03_零售客户数据表加载                                          *
  -- 工程模块 : crmapp.04_27                                                    *
  -- 当前版本 : V1.0.0                                                          *
  -- 作    者 : WXH                                                             *
  -- 完成日期 : 2017/02/09                                                      *
  -- 错误码段 : 40270 - 40279                                                   *
  --*****************************************************************************
 IS
  V_WORK_DATE  VARCHAR2(8);
  V_RETCODE    VARCHAR2(6) := '000000'; --程序/日志返回码
  V_MSG        VARCHAR2(1000); --程序执行信息
  V_TABNAME    VARCHAR2(100); --表名
  V_RETERRFLG  VARCHAR2(1); --日志标志 I(information) W(waring) E(error)
  V_ERRCODE    VARCHAR2(10) := '40279'; --程序执行出错返回码
  V_RETSUBCODE VARCHAR2(3); --程序子返回码
  --V_JOBID      VARCHAR2(50) := 'SP_CIF_DAT_PS_CUST_LX';
  --V_OPERID     VARCHAR2(50) := 'ZHUY';
  V_JOBID  VARCHAR2(50) := IV_JOBID;
  V_OPERID VARCHAR2(50) := IV_OPERID;
  --V_YEAR_FIRST DATE; --年初
BEGIN

  /*获得业务时间*/
  SELECT WORK_DATE INTO V_WORK_DATE FROM SYS_PARA_DATE_NEW;

  --把日期处理成年初
  --V_YEAR_FIRST := TO_DATE(FNC_GET_DATE(V_WORK_DATE, 'YB'), 'YYYYMMDD');

  V_RETCODE    := '40270';
  V_RETSUBCODE := '001';
  V_RETERRFLG  := 'I';
  V_MSG        := '程序执行开始';
  SP_WRITEDETAILLOG(V_WORK_DATE,
                    V_JOBID,
                    V_OPERID,
                    V_MSG,
                    V_RETCODE,
                    V_RETSUBCODE,
                    V_RETERRFLG);

  V_RETCODE    := '40271';
  V_TABNAME    := 'CIF_DAT_PS_CUST';
  V_RETERRFLG  := 'I';
  V_RETSUBCODE := '001';
  /*清空零售客户数据表*/
  EXECUTE IMMEDIATE 'TRUNCATE TABLE CIF_DAT_PS_CUST';
  /*写日志*/
  V_MSG := V_TABNAME || '表记录成功清除';
  SP_WRITEDETAILLOG(V_WORK_DATE,
                    V_JOBID,
                    V_OPERID,
                    V_MSG,
                    V_RETCODE,
                    V_RETSUBCODE,
                    V_RETERRFLG);

  V_RETCODE := '40272';

  /*加载数据到零售客户数据表*/
  INSERT /*+APPEND*/
  INTO CIF_DAT_PS_CUST NOLOGGING
    (CUST_NO, --客户号
     TAR_DATE, --指标日期
     AREA_NO, --区域号
     OPEN_ORG, --开户机构
     HIGH_CUST_NUM, --高端客户数
     GOOD_CUST_NUM, --优质客户数
     CUST_NUM, --客户数
     STAT_TIME, --统计日期
     IS_NEW, --是否新增客户
     IS_SMALL_CO, --是否小微企业
     CUST_LVL, --客户级别
     CUST_NUM_DAY10W, --存款年日均大于等于100000
     IS_NOTE_SIGN, --是否短信签约
     IS_NET_SIGN --是否网银签约
     )
    SELECT A.CIF_NO, --客户号
           V_WORK_DATE, --指标日期
           100 AS AREA_NO, --区域号
           A.LEGAL_BR_NO, --法人机构
           NULL AS HIGH_CUST_NUM, --高端客户数
           NULL GOOD_CUST_NUM, --优质客户数
           1 CUST_NUM, --客户数
           (case
             when a.crt_date = 0 then
              to_date('19001231', 'yyyymmdd')
             else
              TO_DATE(to_char(a.crt_date), 'YYYYMMDD')
           end) crt_date, --统计日期
           (case
             when substr(a.crt_date, 1, 4) = substr(V_WORK_DATE, 1, 4) then
              1
             ELSE
              0
           END) IS_NEW, --是否新增客户
           'N' AS IS_SMALL_CO, --是否小微企业
           A.CIF_LVL CUST_LVL, --客户级别
           NULL, --存款年日均大于等于50000
           'N', --是否短信签约
           'N' --是否网银客户
      FROM A_CBS_CIF_BASIC_INF A
     WHERE A.TYPE = '1'; --客户基本信息表

  V_TABNAME := 'CIF_DAT_PS_CUST';
  V_MSG     := V_TABNAME || '成功写入' || SQL%ROWCOUNT || '条记录';
  COMMIT;

  /*写日志*/
  SP_WRITEDETAILLOG(V_WORK_DATE,
                    V_JOBID,
                    V_OPERID,
                    V_MSG,
                    V_RETCODE,
                    V_RETSUBCODE,
                    V_RETERRFLG);

  V_RETCODE := '40274';
  V_TABNAME := 'CIF_DAT_PS_CUST';
  V_MSG     := V_TABNAME || '表成功写入数据';
  /*写日志*/
  V_RETSUBCODE := '001';
  SP_WRITEDETAILLOG(V_WORK_DATE,
                    V_JOBID,
                    V_OPERID,
                    V_MSG,
                    V_RETCODE,
                    V_RETSUBCODE,
                    V_RETERRFLG);

  V_RETCODE    := '40275';
  V_RETSUBCODE := '001';
  V_RETERRFLG  := 'I';
  V_MSG        := '程序执行结束';
  SP_WRITEDETAILLOG(V_WORK_DATE,
                    V_JOBID,
                    V_OPERID,
                    V_MSG,
                    V_RETCODE,
                    V_RETSUBCODE,
                    V_RETERRFLG);

  ON_RESULT := 0;

  /*异常处理*/
EXCEPTION
  WHEN OTHERS THEN
    V_RETERRFLG := 'E';
    V_RETCODE   := V_ERRCODE;
    V_MSG       := 'SQLCODE:' || V_TABNAME || '表' ||
                   SUBSTR(SQLERRM, 1, 500);
    ON_RESULT   := SQLCODE;
    ROLLBACK;
    SP_WRITEDETAILLOG(V_WORK_DATE,
                      V_JOBID,
                      V_OPERID,
                      V_MSG,
                      V_RETCODE,
                      V_RETSUBCODE,
                      V_RETERRFLG);
    RETURN;
END;
/

