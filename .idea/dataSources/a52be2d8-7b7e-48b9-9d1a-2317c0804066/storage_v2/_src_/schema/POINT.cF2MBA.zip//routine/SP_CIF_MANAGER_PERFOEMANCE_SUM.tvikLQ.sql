create PROCEDURE SP_CIF_MANAGER_PERFOEMANCE_SUM(IV_JOBID  IN VARCHAR2,
                                                           IV_OPERID IN VARCHAR2,
                                                           ON_RESULT OUT NUMBER)
--*******************************************************************************
  -- CopyRight (c) 2018, 融丰银行                                               *
  -- All rights reserved.                                                       *
  --                                                                            *
  -- 文件名称 : SP_CIF_MANAGER_PERFOEMANCE_SUM.prc                                          *
  -- 摘    要 : A03_手机银行存款绩效和二维码绩效表加载                                          *
  -- 工程模块 : crmapp.04_27                                                    *
  -- 当前版本 : V1.0.0                                                          *
  -- 作    者 :                                                               *
  -- 完成日期 : 2018/02/01                                                     *
  -- 错误码段 : 40270 - 40279                                                   *
  --*****************************************************************************
 IS
  V_WORK_DATE  VARCHAR2(8);
  V_RETCODE    VARCHAR2(6) := '000000'; --程序/日志返回码
  V_MSG        VARCHAR2(1000); --程序执行信息
  V_TABNAME    VARCHAR2(100); --表名
  V_RETERRFLG  VARCHAR2(1); --日志标志 I(information) W(waring) E(error)
  V_ERRCODE    VARCHAR2(10) := '40279'; --程序执行出错返回码
  V_RETSUBCODE VARCHAR2(3); --程序子返回码
  V_JOBID      VARCHAR2(50) := IV_JOBID;
  V_OPERID     VARCHAR2(50) := IV_OPERID;
  -- V_YEAR_FIRST DATE; --年初
BEGIN

  /*获得业务时间*/
  SELECT WORK_DATE INTO V_WORK_DATE FROM SYS_PARA_DATE_NEW;
  --把日期处理成年初
  --V_YEAR_FIRST := TO_DATE(FNC_GET_DATE(V_WORK_DATE, 'YB'), 'YYYYMMDD');

  ----记录日志
  V_RETCODE    := '40270';
  V_RETSUBCODE := '001';
  V_RETERRFLG  := 'I';
  V_MSG        := '程序执行开始';
  SP_WRITEDETAILLOG(V_WORK_DATE,
                    V_JOBID,
                    V_OPERID,
                    V_MSG,
                    V_RETCODE,
                    V_RETSUBCODE,
                    V_RETERRFLG);

  V_RETCODE    := '40271';
  V_TABNAME    := 'CIF_MANAGER_PERFOEMANCE_SUM';
  V_RETERRFLG  := 'I';
  V_RETSUBCODE := '001';
  /*清空表分区*/
  EXECUTE IMMEDIATE 'ALTER TABLE CIF_MANAGER_PERFOEMANCE_SUM TRUNCATE PARTITION P_' ||
                    V_WORK_DATE;
  /*写日志*/
  V_MSG := V_TABNAME || '表记录成功清除';
  SP_WRITEDETAILLOG(V_WORK_DATE,
                    V_JOBID,
                    V_OPERID,
                    V_MSG,
                    V_RETCODE,
                    V_RETSUBCODE,
                    V_RETERRFLG);

  V_RETCODE := '40272';
  /*加载数据到手机银行存款绩效和二维码绩效表*/
  --加载手机银行绩效
  INSERT /*+APPEND*/
  INTO CIF_MANAGER_PERFOEMANCE_SUM NOLOGGING
    (ID,
     mang, -- 存款关联人
     mang_name, -- 存款关联人名称
     performance_mang, -- 存款关联人绩效
     acc_no, -- 电子账户
     acc_name, -- 电子账户户名
     org_no, -- 法人机构（600000）
     type, -- 业务类型（BT39）
     remark, -- 备注
     JX_SOURCE,
     work_date -- 数据日期
     )
    select SYS_GUID(),
           /* (case
             when t.mang like '8%' then
              t.mang
             else
              tt.cif_clino  --若为员工则展示员工号，若为银行家则展示12位的客户号
           end)*/
           t.mang,
           t.mang_name,
           sum(t.jx),
           nvl(tp.acc_no, tt.acc_no), --电子帐号
           nvl(tp.acc_name, tt.acc_name), --电子帐号名称
           '601000',
           'BT39',
           '融丰绩效发放',
           '手机银行存款',
           V_WORK_DATE
      from (SELECT MANG, mang_name, SUM(jx) AS jx
              FROM (SELECT --a.mang,
                    --a.mang_cif_no,
                    -- emp.emp_no,
                    --cif.cif_clino,
                     nvl(emp.emp_no, a.mang_cif_no) as mang,
                     a.mang_name mang_name,
                     sum(a.performance_mang) jx
                      FROM CIF_MANAGER_PERFOEMANCE a
                      left join a_ifp2_eci_cif_register_bak cif
                        on cif.cif_clino = a.mang_cif_no
                      left join (select emp_no, cert_no
                                  from sys_employee
                                 where status = '1') emp
                        on emp.cert_no = cif.cif_idno
                     where a.mang is not null
                       and a.WORK_DATE = V_WORK_DATE
                     group by nvl(emp.emp_no, a.mang_cif_no), a.mang_name
                    union all
                    SELECT --b.mang_inviter mang,
                    -- b.inviter_cif_no,
                    -- ep.emp_no,
                    --  cf.cif_clino,
                     nvl(ep.emp_no, b.inviter_cif_no) as mang,
                     b.mang_inviter_name mang_name,
                     sum(b.performance_mang_inviter) jx
                      FROM CIF_MANAGER_PERFOEMANCE b
                      left join a_ifp2_eci_cif_register_bak cf
                        on cf.cif_clino = b.inviter_cif_no
                      left join (select emp_no, cert_no
                                  from sys_employee
                                 where status = '1') ep
                        on ep.cert_no = cf.cif_idno
                     where b.mang_inviter is not null
                       and b.WORK_DATE = V_WORK_DATE
                     group by nvl(ep.emp_no, b.inviter_cif_no),
                              b.mang_inviter_name) TEMP
             GROUP BY MANG, mang_name) t
      left join (select emp.emp_no, rel.acc_no, rel.acc_name ----客户经理电子帐号
                   from sys_employee emp
                   left join A_IFP2_MDM_ACC_REL rel
                     on emp.cert_no = rel.cert_no
                  where rel.mdm_sts in ('MS01', 'MS00')) tp
        on t.mang = tp.emp_no
      left join (select eci.cif_no, eci.cif_clino, rel.acc_no, rel.acc_name ----银行家电子帐号
                   from A_IFP2_ECI_CIF_REGISTER_BAK eci
                   left join A_IFP2_MDM_ACC_REL rel
                     on eci.cif_idno = rel.cert_no
                  where eci.reg_sts = '1' --取电子账号是已开通的
                    and eci.ele_sts = '1'
                    and rel.mdm_sts in ('MS01', 'MS00')) tt
        on t.mang = tt.cif_clino
     group by t.mang,
              t.mang_name,
              nvl(tp.acc_no, tt.acc_no),
              nvl(tp.acc_name, tt.acc_name);
  commit;
  --加载二维码绩效
  /* INSERT \*+APPEND*\
  INTO CIF_MANAGER_PERFOEMANCE_SUM NOLOGGING
    (ID,
     mang, -- 存款关联人
     mang_name, -- 存款关联人名称
     performance_mang, -- 存款关联人绩效
     acc_no, -- 电子账户
     acc_name, -- 电子账户户名
     org_no, -- 法人机构（600000）
     type, -- 业务类型（BT39）
     remark, -- 备注
     JX_SOURCE,
     work_date -- 数据日期
     )
    SELECT SYS_GUID(),
           A.GM_ID,
           A.USER_NAME,
           SUM(A.GM_JX),
           B.ACC_NO,
           B.ACC_NAME,
           '601000',
           'BT39',
           '融丰绩效发放',
           '二维码绩效',
           V_WORK_DATE
      FROM CIF_TWO_BAR_CODES_MERCHANT A
      LEFT JOIN (select emp.emp_no, rel.acc_no, rel.acc_name ----客户经理电子帐号
                   from sys_employee emp
                   left join A_IFP2_MDM_ACC_REL rel
                     on emp.cert_no = rel.cert_no
                    and rel.mdm_sts in ('MS01', 'MS00')) B
        on A.GM_ID = B.emp_no
     WHERE A.WORK_DATE = V_WORK_DATE
     GROUP BY A.GM_ID, A.USER_NAME, B.ACC_NO, B.ACC_NAME;
  COMMIT;*/
  V_TABNAME := 'CIF_MANAGER_PERFOEMANCE_SUM';
  V_MSG     := V_TABNAME || '成功写入' || SQL%ROWCOUNT || '条记录';
  COMMIT;

  /*写日志*/
  SP_WRITEDETAILLOG(V_WORK_DATE,
                    V_JOBID,
                    V_OPERID,
                    V_MSG,
                    V_RETCODE,
                    V_RETSUBCODE,
                    V_RETERRFLG);

  V_RETCODE := '40274';
  V_TABNAME := 'CIF_MANAGER_PERFOEMANCE_SUM';
  V_MSG     := V_TABNAME || '表成功写入数据';
  /*写日志*/
  V_RETSUBCODE := '001';
  SP_WRITEDETAILLOG(V_WORK_DATE,
                    V_JOBID,
                    V_OPERID,
                    V_MSG,
                    V_RETCODE,
                    V_RETSUBCODE,
                    V_RETERRFLG);

  V_RETCODE    := '40275';
  V_RETSUBCODE := '001';
  V_RETERRFLG  := 'I';
  V_MSG        := '程序执行结束';
  SP_WRITEDETAILLOG(V_WORK_DATE,
                    V_JOBID,
                    V_OPERID,
                    V_MSG,
                    V_RETCODE,
                    V_RETSUBCODE,
                    V_RETERRFLG);

  ON_RESULT := 0;

  /*异常处理*/
EXCEPTION
  WHEN OTHERS THEN
    V_RETERRFLG := 'E';
    V_RETCODE   := V_ERRCODE;
    V_MSG       := 'SQLCODE:' || V_TABNAME || '表' ||
                   SUBSTR(SQLERRM, 1, 500);
    ON_RESULT   := SQLCODE;
    ROLLBACK;
    SP_WRITEDETAILLOG(V_WORK_DATE,
                      V_JOBID,
                      V_OPERID,
                      V_MSG,
                      V_RETCODE,
                      V_RETSUBCODE,
                      V_RETERRFLG);
    RETURN;
END;
/

