create PROCEDURE SP_CIF_TWO_BAR_CODES_MERCHANT(IV_JOBID  IN VARCHAR2,
                                                          IV_OPERID IN VARCHAR2,
                                                          ON_RESULT OUT NUMBER)
--*******************************************************************************
  -- CopyRight (c) 2018, 阳光银行                                               *
  -- All rights reserved.                                                       *
  --                                                                            *
  -- 文件名称 : SP_CIF_TWO_BAR_CODES_MERCHANT.prc                                          *
  -- 摘    要 : A03_二维码业绩统计                                          *
  -- 工程模块 : crmapp.04_27                                                    *
  -- 当前版本 : V1.0.0                                                          *
  -- 作    者 :  lyh                                                            *
  -- 完成日期 : 2018/02/01                                                     *
  -- 错误码段 : 40270 - 40279                                                   *
  --*****************************************************************************
 IS
  V_WORK_DATE  VARCHAR2(8);
  V_RETCODE    VARCHAR2(6) := '000000'; --程序/日志返回码
  V_MSG        VARCHAR2(1000); --程序执行信息
  V_TABNAME    VARCHAR2(100); --表名
  V_RETERRFLG  VARCHAR2(1); --日志标志 I(information) W(waring) E(error)
  V_ERRCODE    VARCHAR2(10) := '40279'; --程序执行出错返回码
  V_RETSUBCODE VARCHAR2(3); --程序子返回码
  V_JOBID      VARCHAR2(50) := IV_JOBID;
  V_OPERID     VARCHAR2(50) := IV_OPERID;
BEGIN

  /*获得业务时间*/
  SELECT WORK_DATE INTO V_WORK_DATE FROM SYS_PARA_DATE_NEW;

  ----记录日志
  V_RETCODE    := '40270';
  V_RETSUBCODE := '001';
  V_RETERRFLG  := 'I';
  V_MSG        := '程序执行开始';
  SP_WRITEDETAILLOG(V_WORK_DATE,
                    V_JOBID,
                    V_OPERID,
                    V_MSG,
                    V_RETCODE,
                    V_RETSUBCODE,
                    V_RETERRFLG);

  V_RETCODE    := '40271';
  V_TABNAME    := 'CIF_TWO_BAR_CODES_MERCHANT';
  V_RETERRFLG  := 'I';
  V_RETSUBCODE := '001';
  /*清空二维码业绩统计表*/
  EXECUTE IMMEDIATE 'ALTER TABLE CIF_TWO_BAR_CODES_MERCHANT TRUNCATE PARTITION P_' ||
                    V_WORK_DATE;
  /*写日志*/
  V_MSG := V_TABNAME || '表记录成功清除';
  SP_WRITEDETAILLOG(V_WORK_DATE,
                    V_JOBID,
                    V_OPERID,
                    V_MSG,
                    V_RETCODE,
                    V_RETSUBCODE,
                    V_RETERRFLG);

  V_RETCODE := '40272';
  /*加载数据到二维码业绩统计表*/
  INSERT /*+APPEND*/
  INTO CIF_TWO_BAR_CODES_MERCHANT NOLOGGING
    (mct_id, --商户号
     mct_name, --商户名称
     retail_status, --商户类型（0:商户     1:散户）
     mct_status, --商户状态（0:正式商户 1:入驻中商户  9:注销）
     phone_id, --商户电话号
     reg_time, --申请时间
     success_date, --入驻时间
     pay_cnt, --交易笔数
     is_thirty, --是否满30笔
     pay_amt, --交易金额
     is_amt_sum, --是否满100元
     settle_type, --清算方式（00：t+0      01：t+1）
     gm_id, --客户经理号
     user_name, --客户经理名称
     gm_jx, --客户经理绩效
     mct_yqm_id, --邀请码
     mct_yqm_name, --  银行家（营销人）:邀请码对应的名称
     yqm_acc_no, --银行家（营销人）电子帐号20180906
     mct_yqm_status, --邀请码状态（0：新建      1：已修改）
     mct_jx, --银行家绩效
     bank_no, --客户经理所属机构
     bank_name, --机构名称
     user_tel, --客户经理手机号
     SUCCESS_USER, --审核人
     work_date --数据日期
     )
    SELECT A.mct_id, --商户号
           A.mct_name, --商户名称
           A.retail_status, --商户类型（0:商户     1:散户）
           A.mct_status, --商户状态（0:正式商户 1:入驻中商户  9:注销）
           A.phone_id, --商户电话号
           A.reg_time, --申请时间
           A.success_date, --入驻时间
           A.pay_cnt, --交易笔数
           (CASE
             WHEN A.PAY_CNT >= 30 and d.pay_cnt < 30 /*and
                                                                                                                                                    to_date(substr(a.success_date, 1, 10), 'yyyy-mm-dd') =
                                                                                                                                                    to_date(V_WORK_DATE, 'yyyy-mm-dd')*/
              THEN
              V_WORK_DATE || '已达30笔'
             WHEN A.PAY_CNT >= 30 and
                  to_date(substr(a.success_date, 1, 10), 'yyyy-mm-dd') =
                  to_date(V_WORK_DATE, 'yyyy-mm-dd') THEN
              V_WORK_DATE || '已达30笔'
             when d.mct_id is not null and d.pay_cnt >= 30 then
              d.is_thirty
             when A.PAY_CNT >= 30 and d.pay_cnt is null THEN

              '绩效接入前已达30笔' --批量第一次跑批用，之后注释
             else
              '未达30笔'
           end) is_thirty, --是否满30笔
           A.pay_amt, --交易金额
           (CASE
             WHEN A.PAY_AMT >= 100 and d.PAY_AMT < 100 THEN
              V_WORK_DATE || '交易金额已达100'
             WHEN A.PAY_AMT >= 100 and
                  to_date(substr(a.success_date, 1, 10), 'yyyy-mm-dd') =
                  to_date(V_WORK_DATE, 'yyyy-mm-dd') THEN
              V_WORK_DATE || '交易金额已达100'
             when d.PAY_AMT >= 100 and d.is_amt_sum is not null then
              d.is_amt_sum
             when A.PAY_AMT >= 100 and
                  (d.PAY_AMT >= 100 or d.pay_amt is null) THEN
              '绩效接入前交易金额已达100' --批量第一次跑批用，之后注释
             else
              '交易金额未达100'
           end) is_amt_sum, --交易金额
           A.settle_type, --清算方式（00：t+0      01：t+1）
           A.gm_id, --客户经理号
           A.user_name, --客户经理名称
           (CASE
             WHEN A.GM_ID IS NOT NULL AND A.MCT_YQM_ID IS NULL AND
                  to_date(substr(a.success_date, 1, 10), 'yyyy-mm-dd') =
                  to_date(V_WORK_DATE, 'yyyy-mm-dd') and A.PAY_CNT < 30 THEN
              30
             WHEN A.GM_ID IS NOT NULL AND A.MCT_YQM_ID IS NULL AND
                  to_date(substr(a.success_date, 1, 10), 'yyyy-mm-dd') =
                  to_date(V_WORK_DATE, 'yyyy-mm-dd') and A.PAY_CNT >= 30 THEN
              50

             when d.mct_id is not null and a.pay_cnt >= 30 and
                  d.pay_cnt < 30 then
              20
             else
              0
           END) gm_jx, --客户经理绩效

           A.mct_yqm_id, --银行家（营销人）:也就是邀请码
           B.ACC_NAME,
           B.ACC_NO, --银行家（营销人）电子帐号
           A.mct_yqm_status, --邀请码状态（0：新建      1：已修改）
           (CASE
             WHEN A.MCT_YQM_ID IS NULL THEN
              0
             WHEN A.MCT_YQM_ID IS not NULL and A.MCT_YQM_ID = b.cif_no and
                  to_date(substr(a.success_date, 1, 10), 'yyyy-mm-dd') =
                  to_date(V_WORK_DATE, 'yyyy-mm-dd') THEN
              30
             else
              0
           END) mct_jx, -- -银行家绩效
           A.bank_no, --客户经理所属机构
           A.bank_name, --机构名称
           A.tel, --客户经理手机号
           A.SUCCESS_USER, --审核人
           V_WORK_DATE
      FROM A_KHJLJX A
      left join CIF_TWO_BAR_CODES_MERCHANT d
        on a.mct_id = d.mct_id
       and to_date(d.work_date, 'yyyymmdd') =
           to_date(V_WORK_DATE, 'yyyymmdd') - 1
      LEFT JOIN (select CIF_NO, ACC_NAME, ACC_NO --添加电子帐号20180904
                   from A_IFP2_MDM_ACC_REL
                  WHERE MDM_STS = 'MS01'
                  group by CIF_NO, ACC_NAME, ACC_NO) B --只取状态为正常的20180806
        ON A.MCT_YQM_ID = TO_CHAR(B.CIF_NO);
  V_TABNAME := 'CIF_TWO_BAR_CODES_MERCHANT';
  V_MSG     := V_TABNAME || '成功写入' || SQL%ROWCOUNT || '条记录';
  COMMIT;

  /*写日志*/
  SP_WRITEDETAILLOG(V_WORK_DATE,
                    V_JOBID,
                    V_OPERID,
                    V_MSG,
                    V_RETCODE,
                    V_RETSUBCODE,
                    V_RETERRFLG);

  V_RETCODE := '40274';
  V_TABNAME := 'CIF_TWO_BAR_CODES_MERCHANT';
  V_MSG     := V_TABNAME || '表成功写入数据';
  /*写日志*/
  V_RETSUBCODE := '001';
  SP_WRITEDETAILLOG(V_WORK_DATE,
                    V_JOBID,
                    V_OPERID,
                    V_MSG,
                    V_RETCODE,
                    V_RETSUBCODE,
                    V_RETERRFLG);

  V_RETCODE    := '40275';
  V_RETSUBCODE := '001';
  V_RETERRFLG  := 'I';
  V_MSG        := '程序执行结束';
  SP_WRITEDETAILLOG(V_WORK_DATE,
                    V_JOBID,
                    V_OPERID,
                    V_MSG,
                    V_RETCODE,
                    V_RETSUBCODE,
                    V_RETERRFLG);

  ON_RESULT := 0;

  /*异常处理*/
EXCEPTION
  WHEN OTHERS THEN
    V_RETERRFLG := 'E';
    V_RETCODE   := V_ERRCODE;
    V_MSG       := 'SQLCODE:' || V_TABNAME || '表' ||
                   SUBSTR(SQLERRM, 1, 500);
    ON_RESULT   := SQLCODE;
    ROLLBACK;
    SP_WRITEDETAILLOG(V_WORK_DATE,
                      V_JOBID,
                      V_OPERID,
                      V_MSG,
                      V_RETCODE,
                      V_RETSUBCODE,
                      V_RETERRFLG);
    RETURN;
END;
/

