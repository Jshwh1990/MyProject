create PROCEDURE SP_PI_I2_XZ_DEPS_HIS(IV_JOBID  IN VARCHAR2,
                                                 IV_OPERID IN VARCHAR2,
                                                 ON_RESULT OUT NUMBER)
--*******************************************************************************
  -- CopyRight (c) 2017, 融丰银行                                         *
  -- All rights reserved.                                                       *
  --                                                                            *
  -- 文件名称 : SP_PI_I2_XZ_DEPS_HIS.prc                                          *
  -- 摘    要 : 存款新增明细历史表数据加载                                          *
  -- 工程模块 : crmapp.04_27                                                    *
  -- 当前版本 : V1.0.0                                                          *
  -- 作    者 : lyh                                                             *
  -- 完成日期 : 20181202                                                     *
  -- 错误码段 : 40270 - 40279                                                   *
  --*****************************************************************************
 IS
  V_WORK_DATE  VARCHAR2(8);
  V_RETCODE    VARCHAR2(6) := '000000'; --程序/日志返回码
  V_MSG        VARCHAR2(1000); --程序执行信息
  V_TABNAME    VARCHAR2(100); --表名
  V_RETERRFLG  VARCHAR2(1); --日志标志 I(information) W(waring) E(error)
  V_ERRCODE    VARCHAR2(10) := '40279'; --程序执行出错返回码
  V_RETSUBCODE VARCHAR2(3); --程序子返回码
  V_JOBID      VARCHAR2(50) := IV_JOBID;
  V_OPERID     VARCHAR2(50) := IV_OPERID;
BEGIN

  /*获得业务时间*/
  SELECT WORK_DATE INTO V_WORK_DATE FROM SYS_PARA_DATE_NEW;
  --获取本月末
  /* SELECT to_char(last_day(to_date(WORK_DATE, 'yyyymmdd')), 'YYYYMMDD')
  INTO V_WORK_DATE
  FROM SYS_PARA_DATE_NEW;*/
  V_RETCODE    := '40270';
  V_RETSUBCODE := '001';
  V_RETERRFLG  := 'I';
  V_MSG        := '程序执行开始';
  SP_WRITEDETAILLOG(V_WORK_DATE,
                    V_JOBID,
                    V_OPERID,
                    V_MSG,
                    V_RETCODE,
                    V_RETSUBCODE,
                    V_RETERRFLG);

  V_RETCODE    := '40271';
  V_TABNAME    := 'PI_I2_XZ_DEPS_HIS';
  V_RETERRFLG  := 'I';
  V_RETSUBCODE := '001';
  /*清空活期存款明细历史表*/
  --如果是月末，则清空当天的数据
  -- if V_WORK_DATE = V_WORK_DATE then
  EXECUTE IMMEDIATE 'ALTER TABLE PI_I2_XZ_DEPS_HIS TRUNCATE PARTITION P_' ||
                    V_WORK_DATE;
  --EXECUTE IMMEDIATE 'TRUNCATE TABLE  PI_I2_XZ_DEPS_HIS_TEMP';
  --end if;
  /*写日志*/
  V_MSG := V_TABNAME || '表记录成功清除';
  SP_WRITEDETAILLOG(V_WORK_DATE,
                    V_JOBID,
                    V_OPERID,
                    V_MSG,
                    V_RETCODE,
                    V_RETSUBCODE,
                    V_RETERRFLG);

  V_RETCODE := '40272';

  /*加载数据到活期存款明细历史表*/
  --如果是月末加载，否则不加载
  --if V_WORK_DATE = V_WORK_DATE then
  --加载活期存款新增数据
  INSERT /*+APPEND*/
  INTO PI_I2_XZ_DEPS_HIS NOLOGGING
    (manager_no, --客户经理编号
     acct_no, --账号(pk)
     his_start_date, --历史开始日期
     his_end_date, --历史结束日期
     biz_cust_no, --原业务系统客户号
     acct_name, --户名
     acct_state, --账户状态
     currency, --交易币种
     term, --期限
     prd_code, --产品号
     open_date, --开户时间
     open_org, --开户机构号
     end_date, --到期日期(展期到期日期)
     rate, --当前执行利率
     bal, --账户余额
     al_rate, --分配比率
     deps_type, --存款类型
     ac_seq, --账户序号
     main_acct_no, --主账号
     add_ind, --增减标志(0：减少；1：增加)，提前支取标志
     tx_amt, --交易金额
     ZJ_AMT, --增加金额
     tx_date, --交易日期
     tx_br_no, --交易机构号
     sum_amt, --存款金额
     whe_spec_line, --是否转存{y：是；n：否}
     --TYPE, --类型
     brf, --  摘要
     hst_cnt --  明细笔数 {注：明细顺序号；1起}
     
     )
    select (case
             when c.manager_no is not null then
              c.manager_no
             else
              'PFM_' || a.opn_br_no
           end) manager_no,
           a.ac_id,
           V_WORK_DATE,
           V_WORK_DATE,
           b.cif_no,
           d.name,
           b.ac_sts,
           b.cur_no,
           (CASE
             WHEN e.TERM_TYPE = 'Y' THEN
              e.TERM * 365
             WHEN e.TERM_TYPE = 'M' THEN
              e.TERM * 30
             ELSE
              NVL(e.TERM, 0)
           END) term,
           a.prdt_no,
           (CASE
             WHEN b.OPN_DATE = 0 THEN
              19001231
             ELSE
              b.OPN_DATE
           END) open_date, --开户日期
           b.OPN_BR_NO open_org,
           (CASE
             WHEN b.VAL_DATE = 0 THEN
              99991231
             WHEN b.VAL_DATE = 99999999 THEN
              99991231
             ELSE
              b.VAL_DATE
           END) end_date,
           b.rate,
           a.bal,
           c.al_rate,
           '核心活期',
           a.ac_seqn,
           a.ac_no,
           a.add_ind,
           a.tx_amt,
           --增加的(add_ind=1)的交易金额TX_AMT
           a.tx_amt   ZJ_AMT,
           a.tx_date, --交易日期
           a.tx_br_no, --交易机构号
           --存款金额为HST_CNT=1时的TX_AMT
           hst.tx_amt sum_amt,
           'N',
           a.brf,
           a.hst_cnt
      from A_CBS_DD_MST_HST a
      LEFT JOIN A_CBS_DD_MST b
        ON A.AC_ID = B.AC_ID
       and a.ac_seqn = b.ac_seqn
      left join (select op.res_id  res_id,
                        op.al_in   manager_no,
                        op.al_rate al_rate
                   from op_as_ar_co_deps op
                  group by op.res_id, op.al_in, al_rate
                 union all
                 select op.res_id  res_id,
                        op.al_in   manager_no,
                        op.al_rate al_rate
                   from op_as_ar_sa_deps op
                  group by op.res_id, op.al_in, al_rate) c
        on a.ac_id || a.ac_seqn = c.res_id
      LEFT JOIN A_CBS_CIF_BASIC_INF d --客户基本信息表
        ON b.CIF_NO = d.CIF_NO
      LEFT JOIN A_CBS_TD_PARM e
        ON A.PRDT_NO = e.PRDT_NO
      left join (select ac_id ac_id, ac_seqn ac_seqn, tx_amt
                   from A_CBS_DD_MST_HST
                  where hst_cnt = 1
                  and trace_cnt = '1') hst
        on a.ac_id = hst.ac_id
       and a.ac_seqn = hst.ac_seqn
     WHERE a.tx_date = v_work_date
       and a.add_ind = '1'
    --and a.tx_date < b.mtr_date
    ;
  commit;
  --加载定期存款新增数据
  INSERT /*+APPEND*/
  INTO PI_I2_XZ_DEPS_HIS NOLOGGING
    (manager_no, --客户经理编号
     acct_no, --账号(pk)
     his_start_date, --历史开始日期
     his_end_date, --历史结束日期
     biz_cust_no, --原业务系统客户号
     acct_name, --户名
     acct_state, --账户状态
     currency, --交易币种
     term, --期限
     prd_code, --产品号
     open_date, --开户时间
     open_org, --开户机构号
     end_date, --到期日期(展期到期日期)
     rate, --当前执行利率
     bal, --账户余额
     al_rate, --分配比率
     deps_type, --存款类型
     ac_seq, --账户序号
     main_acct_no, --主账号
     add_ind, --增减标志(0：减少；1：增加)，提前支取标志
     tx_amt, --交易金额
     ZJ_AMT, --增加金额
     tx_date, --交易日期
     tx_br_no, --交易机构号
     sum_amt, --存款金额
     whe_spec_line, --是否转存{y：是；n：否}
     --TYPE, --类型
     brf, --  摘要
     hst_cnt --  明细笔数 {注：明细顺序号；1起}
     
     )
    select (case
             when c.manager_no is not null then
              c.manager_no
             else
              'PFM_' || a.opn_br_no
           end) manager_no,
           a.ac_id,
           V_WORK_DATE,
           V_WORK_DATE,
           b.cif_no,
           d.name,
           b.ac_sts,
           b.cur_no,
           (CASE
             WHEN e.TERM_TYPE = 'Y' THEN
              e.TERM * 365
             WHEN e.TERM_TYPE = 'M' THEN
              e.TERM * 30
             ELSE
              NVL(e.TERM, 0)
           END) term,
           a.prdt_no,
           (CASE
             WHEN b.OPN_DATE = 0 THEN
              19001231
             ELSE
              b.OPN_DATE
           END) open_date, --开户日期
           b.OPN_BR_NO open_org,
           (CASE
             WHEN b.MTR_DATE = 0 THEN
              99991231
             WHEN b.MTR_DATE = 99999999 THEN
              99991231
             ELSE
              b.MTR_DATE
           END) end_date,
           b.rate,
           a.bal,
           c.al_rate,
           '核心定期',
           a.ac_seqn,
           a.ac_no,
           a.add_ind,
           a.tx_amt,
           --增加的(add_ind=1)的交易金额TX_AMT
           a.tx_amt   ZJ_AMT,
           a.tx_date, --交易日期
           a.tx_br_no, --交易机构号
           --存款金额为HST_CNT=1时的TX_AMT
           hst.tx_amt sum_amt,
           b.tfr_ind,
           a.brf,
           a.hst_cnt
      from A_CBS_TD_MST_HST a
      LEFT JOIN A_CBS_TD_MST b
        ON A.AC_ID = B.AC_ID
       and a.ac_seqn = b.ac_seqn
      left join (select op.res_id  res_id,
                        op.al_in   manager_no,
                        op.al_rate al_rate
                   from op_as_ar_co_deps op
                  group by op.res_id, op.al_in, al_rate
                 union all
                 select op.res_id  res_id,
                        op.al_in   manager_no,
                        op.al_rate al_rate
                   from op_as_ar_sa_deps op
                  group by op.res_id, op.al_in, al_rate) c
        on a.ac_id || a.ac_seqn = c.res_id
      LEFT JOIN A_CBS_CIF_BASIC_INF d --客户基本信息表
        ON b.CIF_NO = d.CIF_NO
      LEFT JOIN A_CBS_TD_PARM e
        ON A.PRDT_NO = e.PRDT_NO
      left join (select ac_id ac_id, ac_seqn ac_seqn, tx_amt
                   from a_cbs_td_mst_hst
                  where hst_cnt = 1
                  and trace_cnt = '1') hst
        on a.ac_id = hst.ac_id
       and a.ac_seqn = hst.ac_seqn
     WHERE a.tx_date = v_work_date
       and a.add_ind = '1'
    --and a.tx_date < b.mtr_date
    ;
  commit;
  -- end if;
  V_TABNAME := 'PI_I2_XZ_DEPS_HIS';
  V_MSG     := V_TABNAME || '成功写入' || SQL%ROWCOUNT || '条记录';
  COMMIT;

  /*写日志*/
  V_RETSUBCODE := '001';
  SP_WRITEDETAILLOG(V_WORK_DATE,
                    V_JOBID,
                    V_OPERID,
                    V_MSG,
                    V_RETCODE,
                    V_RETSUBCODE,
                    V_RETERRFLG);

  V_RETCODE    := '40275';
  V_RETSUBCODE := '001';
  V_RETERRFLG  := 'I';
  V_MSG        := '程序执行结束';
  SP_WRITEDETAILLOG(V_WORK_DATE,
                    V_JOBID,
                    V_OPERID,
                    V_MSG,
                    V_RETCODE,
                    V_RETSUBCODE,
                    V_RETERRFLG);

  ON_RESULT := 0;

  /*异常处理*/
EXCEPTION
  WHEN OTHERS THEN
    V_RETERRFLG := 'E';
    V_RETCODE   := V_ERRCODE;
    V_MSG       := 'SQLCODE:' || V_TABNAME || '表' ||
                   SUBSTR(SQLERRM, 1, 500);
    ON_RESULT   := SQLCODE;
    ROLLBACK;
    SP_WRITEDETAILLOG(V_WORK_DATE,
                      V_JOBID,
                      V_OPERID,
                      V_MSG,
                      V_RETCODE,
                      V_RETSUBCODE,
                      V_RETERRFLG);
    RETURN;
END;
/

