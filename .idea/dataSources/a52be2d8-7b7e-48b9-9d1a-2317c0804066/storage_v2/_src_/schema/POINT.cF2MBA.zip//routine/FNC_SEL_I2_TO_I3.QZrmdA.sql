create FUNCTION FNC_SEL_I2_TO_I3
(
  F_TABLE VARCHAR,
  P_TABLE VARCHAR,        --INSTABLE
  P_RECALC INT, --计算类型：10为当日业绩计算，20为外部回算，30为内部回算
  P_SDAT VARCHAR,
  P_EDAT VARCHAR
)
/* 过程、函数简要描述信息
  **********************************************************
  *  存储过程名:  查询语句生成函数
  *  建立日期  :  2013-03-20
  *  作者      :  linyd
  *  模块      :
  *  功能描述  :
  *  输入参数  ： P_TABLE 来源表 ，P_INS_TABLE 目标表，P_SDAT 处理日期,P_EDAT 处理结束日期
  *               P_RECALC 计算类型：10为当日业绩计算，20为外部回算，30为内部回算
  *  输出参数  ： RETCODE 0为正确1为错误， RETMSG错误信息
  *  来源表    ： OP_AS_AR_CO_CUST  对公客户分配表
  *  目标表    :   对公客户分配规则明细表
  *   备注     ：
  *------------------------------------------------------------
  *  修改历史
  *  序号    日期      修改人      修改原因
  ************************************************************ */
RETURN VARCHAR IS
  FIELDSQL VARCHAR(4000) ;
  GROUPBYSQL VARCHAR(1000) ;
  S_POS SMALLINT DEFAULT 1;
  E_POS SMALLINT ;
  CNT SMALLINT;

BEGIN
  --判断表是否可用
  SELECT COUNT(1) INTO CNT FROM OP_AS_RT_DICT_TABLE WHERE INS_TABLE_CODE=UPPER(P_TABLE) AND ENABLE = 1 ;
  IF CNT <= 0 THEN
    RETURN NULL;
  END IF ;

  SELECT MAX(SNO) INTO E_POS FROM OP_AS_RT_DICT_FIELD WHERE INS_TABLE_CODE=UPPER(P_TABLE);
  FIELDSQL := '#';
  GROUPBYSQL :=' GROUP BY #';
  WHILE(S_POS<=E_POS) LOOP
    SELECT COUNT(1) INTO CNT FROM OP_AS_RT_DICT_FIELD WHERE INS_TABLE_CODE=UPPER(P_TABLE) AND SNO = S_POS AND INS_ENABLE = 1;
    IF CNT > 0 THEN
       SELECT FIELDSQL||','||CASE WHEN IS_CALC = 0 THEN  INS_FIELD_CODE
                                  WHEN IS_CALC = 1 THEN 'SUM('||FROM_FIELD_CODE||') '||INS_FIELD_CODE
                                  END INTO FIELDSQL
       FROM OP_AS_RT_DICT_FIELD
       WHERE INS_TABLE_CODE =UPPER(P_TABLE) AND SNO = S_POS;
    END IF;
    --group by
    SELECT COUNT(1) INTO CNT FROM OP_AS_RT_DICT_FIELD WHERE INS_TABLE_CODE=UPPER(P_TABLE) AND SNO = S_POS AND INS_ENABLE = 1 AND is_calc=0;
    IF CNT > 0 THEN
       SELECT GROUPBYSQL||','|| INS_FIELD_CODE  INTO GROUPBYSQL
       FROM OP_AS_RT_DICT_FIELD
       WHERE INS_TABLE_CODE =UPPER(P_TABLE) AND SNO = S_POS;
    END IF;
    S_POS := S_POS + 1;
  END LOOP;
  FIELDSQL :='select '||FIELDSQL;
  FIELDSQL := REPLACE(FIELDSQL,'#,','')||' ';
  GROUPBYSQL := REPLACE(GROUPBYSQL,'#,','')||' ';
  FIELDSQL :=FIELDSQL||',TAR_DATE FROM '||F_TABLE||' WHERE TAR_DATE ='''||P_SDAT||'''';
  FIELDSQL :=FIELDSQL||GROUPBYSQL||', TAR_DATE';
  RETURN FIELDSQL;

END
;

/

