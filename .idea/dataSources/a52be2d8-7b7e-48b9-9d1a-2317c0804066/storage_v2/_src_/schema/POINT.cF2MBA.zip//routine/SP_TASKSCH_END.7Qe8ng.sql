create PROCEDURE SP_TASKSCH_END(iv_ThisDay IN VARCHAR2,
                                           on_Result  OUT INTEGER)
--*****************************************************************************
  -- CopyRight (c) 2014, 泸州银行                                               *
  -- All rights reserved.                                                       *
  --                                                                            *
  -- 文件名称 : SP_SYS_PARA_DATE.prc                                             *
  -- 摘    要 : 设置业务日期                                                    *
  -- 工程模块 :                                                                 *
  -- 当前版本 : V1.0.0                                                          *
  -- 作    者 : zqh                                                             *
  -- 完成日期 : 2014/09/12                                                      *
  -- 错误码段 :                                                                 *
  --*****************************************************************************
  --WORK_DATE       VARCHAR2(8) Y                工作日期
  --PRE_DATE        VARCHAR2(8) Y                工作日期前一天的日期
  --AFT_DATE        VARCHAR2(8) Y                工作日期后一天的日期
  --DAY_THISYEAR    NUMBER(3)   Y                年初至本日天数
  --DAY_THISQUATER  NUMBER(3)   Y                季初至本日天数
  --DAY_THISMONTH   NUMBER(3)   Y                月初至本日天数
  --BEGINDAY_YEAR   VARCHAR2(8) Y                本年开始日期
  --BEGINDAY_QUATER VARCHAR2(8) Y                本季开始日期
  --BEGINDAY_MONTH  VARCHAR2(8) Y                本月开始日期
  --STEP            NUMBER(2)   Y                当前跑批到哪一步
  --STATUS          VARCHAR2(1) Y                跑批的状态 0-报批正常结束 1-正在跑批  2-跑批结束，但有错误
 AS
  v_WORK_DATE VARCHAR2(8);

BEGIN
  v_WORK_DATE := iv_ThisDay;

  DELETE FROM SYS_PARA_DATE WHERE WORK_DATE >= v_WORK_DATE;
  COMMIT;

  INSERT /*+APPEND*/
  INTO SYS_PARA_DATE NOLOGGING
    (WORK_DATE,
     PRE_DATE,
     AFT_DATE,
     DAY_THISYEAR,
     DAY_THISQUATER,
     DAY_THISMONTH,
     BEGINDAY_YEAR,
     BEGINDAY_QUATER,
     BEGINDAY_MONTH,
     STEP,
     STATUS)
    SELECT A.WORK_DATE,
           A.PRE_DATE,
           A.AFT_DATE,
           A.DAY_THISYEAR,
           A.DAY_THISQUATER,
           A.DAY_THISMONTH,
           A.BEGINDAY_YEAR,
           A.BEGINDAY_QUATER,
           A.BEGINDAY_MONTH,
           A.STEP,
           A.STATUS
      FROM SYS_PARA_DATE_NEW A;
  COMMIT;


/*-- 每天晚上12点扫描 MO_HP_CM 和MO_HP_ORG 表，判断未评分的考评设置数据是否过期，过期将状态设置为3（已过期）状态
--员工设置表
UPDATE MO_HP_CM HC
   SET HC.STATE = '3'
 WHERE HC.REC_DAT + TO_NUMBER(NVL(HC.PERIOD_DAY, '0')) < SYSDATE
   AND HC.STATE = '1';
 commit;

 --机构设置表
UPDATE MO_HP_ORG HO
     SET HO.STATE = '3'
   WHERE HO.REC_DAT + TO_NUMBER(NVL(HO.PERIOD_DAY, '0')) < SYSDATE
     AND HO.STATE = '1';
 commit;*/

  on_Result := 0;
  RETURN;
EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    on_Result := SQLCODE;

END;

/

