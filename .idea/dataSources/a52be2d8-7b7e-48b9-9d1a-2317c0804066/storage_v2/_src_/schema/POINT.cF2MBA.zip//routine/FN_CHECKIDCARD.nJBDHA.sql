create FUNCTION FN_CHECKIDCARD(P_IDCARD IN VARCHAR2) RETURN INT IS
  V_SUM       NUMBER;
  V_MOD       NUMBER;
  V_CHECKCODE CHAR(11) := '10X98765432';
  V_CHECKBIT  CHAR(1);
  /*11,12,13,14,15,21,22,23,31,32,33,34,35,36,37,41,42,
  43,44,45,46,50,51,52,53,54,61,62,63,64,65,71,81,82,91*/
  V_AREACODE VARCHAR2(2000) := '^(1[1-5]|2[123]|3[1-7]|4[1-6]|5[0-4]|6[1-5]|[7-9]1|82)$';
  ID_NO      VARCHAR2(50);
  NUM_YEAR   INTEGER; --身份证中的年份
  STR_DATE   VARCHAR2(8); --身份证的日期串
  ID_LEN     INTEGER; --证件号长度
  EXP_FULL   VARCHAR2(200);
  EXP_MD     VARCHAR2(200);
  RESULT     INTEGER;
BEGIN
  ID_NO  := UPPER(P_IDCARD);
  ID_LEN := LENGTHB(ID_NO);
  --证件号长度不满足身份证的要求: 15或者18位
  IF ID_LEN <> 15
     AND ID_LEN <> 18 THEN
    RETURN 0;
    --前两位不满足身份证前2位的地区号要求
  ELSIF NOT REGEXP_LIKE(SUBSTR(ID_NO, 1, 2), V_AREACODE) THEN
    RETURN 0;
    --格式不满足以下两种：15位数字、17位数字+【数字/X】
  ELSIF NOT REGEXP_LIKE(ID_NO, '^([0-9]{15}|[0-9]{17}[0-9X])$') THEN
    RETURN 0;
  END IF;

  IF ID_LEN = 15 THEN
    NUM_YEAR := 1900 + SUBSTR(ID_NO, 7, 2);
    STR_DATE := SUBSTR(ID_NO, 7, 6);
    --年份正则表达式
    EXP_FULL := '^[0-9]{2}';
  ELSE
    NUM_YEAR := SUBSTR(ID_NO, 7, 4);
    --年份正则表达式
    EXP_FULL := '^(19|20)[0-9]{2}';
    STR_DATE := SUBSTR(ID_NO, 7, 8);
  END IF;

  --月+天正则表达式
  EXP_MD := '(0[13-9]|1[012])(0[1-9]|[12][0-9]|30)|(0[13578]|1[02])31';

  --根据是否闰年拼接2月份的月+天正则表达式
  IF MOD(NUM_YEAR, 400) = 0
     OR (MOD(NUM_YEAR, 100) <> 0 AND MOD(NUM_YEAR, 4) = 0) THEN
    EXP_FULL := EXP_FULL || '(' || EXP_MD || '|02(0[1-9]|1[0-9]|2[0-9]))$';
  ELSE
    EXP_FULL := EXP_FULL || '(' || EXP_MD || '|02(0[1-9]|1[0-9]|2[0-8]))$';
  END IF;

  --开始日期匹配
  IF NOT REGEXP_LIKE(STR_DATE, EXP_FULL) THEN
    RETURN 0;
  END IF;
  --15位身份证匹配到此结束
  IF ID_LEN = 15 THEN
    RETURN 1;
  END IF;

  --继续校验18位身份证的数字和校验
  V_SUM      := (TO_NUMBER(SUBSTR(ID_NO, 1, 1)) + TO_NUMBER(SUBSTR(ID_NO, 11, 1))) * 7 +
                (TO_NUMBER(SUBSTR(ID_NO, 2, 1)) + TO_NUMBER(SUBSTR(ID_NO, 12, 1))) * 9 +
                (TO_NUMBER(SUBSTR(ID_NO, 3, 1)) + TO_NUMBER(SUBSTR(ID_NO, 13, 1))) * 10 +
                (TO_NUMBER(SUBSTR(ID_NO, 4, 1)) + TO_NUMBER(SUBSTR(ID_NO, 14, 1))) * 5 +
                (TO_NUMBER(SUBSTR(ID_NO, 5, 1)) + TO_NUMBER(SUBSTR(ID_NO, 15, 1))) * 8 +
                (TO_NUMBER(SUBSTR(ID_NO, 6, 1)) + TO_NUMBER(SUBSTR(ID_NO, 16, 1))) * 4 +
                (TO_NUMBER(SUBSTR(ID_NO, 7, 1)) + TO_NUMBER(SUBSTR(ID_NO, 17, 1))) * 2 +
                TO_NUMBER(SUBSTR(ID_NO, 8, 1)) * 1 +
                TO_NUMBER(SUBSTR(ID_NO, 9, 1)) * 6 +
                TO_NUMBER(SUBSTR(ID_NO, 10, 1)) * 3;
  V_MOD      := MOD(V_SUM, 11);
  V_CHECKBIT := SUBSTR(V_CHECKCODE, V_MOD + 1, 1);

  IF V_CHECKBIT = UPPER(SUBSTR(P_IDCARD, 18, 1)) THEN
    RETURN 1;
  END IF;

  RETURN 0;

EXCEPTION
  WHEN OTHERS THEN
    RETURN 0;
    RETURN(RESULT);
END;

/

