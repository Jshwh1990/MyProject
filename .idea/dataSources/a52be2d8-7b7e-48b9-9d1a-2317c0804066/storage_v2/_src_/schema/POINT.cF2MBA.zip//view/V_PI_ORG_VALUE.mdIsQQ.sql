create view V_PI_ORG_VALUE as
  (select distinct ORG_NO ,
  area_no,
  TARGET_DATE ,
  TARGET_CODE ,
  TARGET_VALUE from (
 select ORG_NO ,
  nvl(area_no,'100') area_no,
  TARGET_DATE ,
  TARGET_CODE ,
  TARGET_VALUE from pi_org_qty_hand
  union all
 select   ORG_NO ,
  nvl(area_no,'100') area_no,
  TARGET_DATE ,
  TARGET_CODE ,
  TARGET_VALUE from pi_org_qty))
/

