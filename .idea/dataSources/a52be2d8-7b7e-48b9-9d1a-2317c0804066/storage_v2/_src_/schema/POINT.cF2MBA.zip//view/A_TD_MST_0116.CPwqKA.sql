create view A_TD_MST_0116 as
  select ac_no, ac_id, ac_seqn, tx_date, bal
  from a_cbs_td_mst_hst
 where ac_id || ac_seqn || tx_date || trace_no || trace_cnt in
       (select ac_id || ac_seqn || tx_date || trace_no || max(trace_cnt)
          from a_cbs_td_mst_hst
         where ac_id || ac_seqn || tx_date || trace_no in
               (select ac_id || ac_seqn || tx_date || max(trace_no)
                  from a_cbs_td_mst_hst
                 where  tx_date <= 20181116
                 group by ac_id, ac_seqn, tx_date)
         group by ac_id, ac_seqn, tx_date, trace_no)
          order by ac_id, ac_seqn, tx_date
/

