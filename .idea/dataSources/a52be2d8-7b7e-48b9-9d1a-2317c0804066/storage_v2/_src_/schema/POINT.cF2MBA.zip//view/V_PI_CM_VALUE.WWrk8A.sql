create view V_PI_CM_VALUE as
  (select distinct MANAGER_NO ,
area_no,
  TARGET_DATE ,
  TARGET_CODE ,
  TARGET_VALUE from (
 select MANAGER_NO ,
 nvl(area_no,'100') area_no,
  TARGET_DATE ,
  TARGET_CODE ,
  TARGET_VALUE from pi_CM_qty_hand
  union all
 select   MANAGER_NO ,
 nvl(area_no,'100') area_no,
  TARGET_DATE ,
  TARGET_CODE ,
  TARGET_VALUE from pi_CM_qty))
/

