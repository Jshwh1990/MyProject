create view V_CI_CUS_PERSON as
  SELECT A.CUST_NO,
       A.CUST_NAME,
       A.CUST_OTHER_NAME,
       A.CERT_TYPE,
       A.CERT_NO,
       A.SEX,
       A.COUNTRY,
       A.NATION,
       A.MARITAL,
       A.RELIGION,
       A.INDUSTRY_CODE,
       A.CREDIT_RATING,
       A.BIRTHDAY,
       A.BIRTHPLACE,
       A.MAX_EDUCATIONAL,
       A.MAX_DEGREE,
       A.JOB_OCCUPATION,
       A.POSITION,
       A.WHE_BANK_EMP,
       A.WHE_BANK_STOCKHOLDER,
       A.STACK_NUM,
       A.WHE_CREDIT,
       A.WHE_NET_BANKING,
       A.WHE_WARNING,
       A.WHE_FINANACES,
       A.DEPS_BAL,
       A.DEPS_BAL_AVG_M,
       A.DEPS_BAL_AVG_Y,
       A.LOAN_BAL,
       A.FINANCES_BAL,
       A.PROFIT,
       A.USE_POINTS,
       A.TOTAL_POINTS,
       A.WHE_NOTE,
       A.EFF_CST_DT,
       A.IDV_MO_INCM,
       A.IDV_ANUL_ERN,
       A.CVL_F,
       A.OPN_ORG,
       A.CUST_STATUS,
       A.CUST_LEVEL,
       A.ASN_STATUS,
       A.BELONG_ORG_NO,
       A.BELONG_EMP_NO,
       A.HOBB_LEISURE,
       A.HOBB_MEDIA,
       A.HOBB_SPORT,
       A.HOBB_MAGAZINE,
       A.HOBB_TELEVISION,
       A.HOBB_CHANNEL,
       A.HOBB_CONSUMER,
       A.INVEST_KNOWLEDGE,
       A.INVEST_EXPERIENCE,
       A.INVEST_STYLE,
       A.INVEST_BURDEN,
       A.INVEST_LOSTMONEY_MOOD,
       A.INVEST_ORIENTATION,
       A.INVEST_COMMISSION,
       A.INVEST_TRAN_CHANNEL,
       A.BEST_CONTACT_WAY,
       A.BEST_CONTACT_TIME,
       A.CREATE_EMP_NO,
       A.CREATE_TIME,
       A.MODIFY_EMP_NO,
       A.MODIFY_TIME,
       A.CREATE_ORG_NO,
       A.MODIFY_ORG_NO,
       A.LOAN_BAL_M,
       A.LOAN_BAL_Y,
       A.CUST_STAGE,
       A.CUST_CRM_STATUS,
       A.DP_ACCT_CNT,
       A.LN_ACCT_CNT,
       A.ALL_ACCT_CNT,
       A.CARD_CNT,
       A.AGE,
       A.CD_INT_EPS_AMT,
       A.MA_INT_EPS_AMT,
       A.QA_INT_EPS_AMT,
       A.YA_INT_EPS_AMT,
       A.ACCRUAL_SHOULD,
       A.ACCRUAL_SHOULD_A,
       A.ACCRUAL_FACT,
       A.ACCRUAL_FACT_A,
       A.PAID_SALARY,
       A.YMAX_TXN_AMT,
       A.L_DEPS_BAL_AVG_Y
  FROM CI_CUS_PERSON A
 WHERE NOT EXISTS(SELECT 1 FROM CI_CUS_PERSON_COMBINE B
           	      WHERE (A.CUST_NO = B.CUST_NO OR A.CUST_NO = B.COMBINED_CUST_NO)
									AND B.STATE = '1')
UNION ALL
select M.CUST_NO,                   --客户号
       M.CUST_NAME,                 --客户名称
       M.CUST_OTHER_NAME,           --其他名称
       M.CERT_TYPE,                 --证件类型
       M.CERT_NO,                   --证件号码
       M.SEX,                       --性别
       M.COUNTRY,                   --国家
       M.NATION,                    --民族
       M.MARITAL,                   --婚姻状况
       M.RELIGION,                  --宗教信仰
       M.INDUSTRY_CODE,             --所属行业
       M.CREDIT_RATING,             --信用等级
       M.BIRTHDAY,                  --出生日期
       M.BIRTHPLACE,                --出生地
       M.MAX_EDUCATIONAL,           --最高学历
       M.MAX_DEGREE,                --最高学位
       M.JOB_OCCUPATION,            --职业
       M.POSITION,                  --职务
       M.WHE_BANK_EMP,              --是否本行员工
       M.WHE_BANK_STOCKHOLDER,      --是否本行股东
       M.STACK_NUM,                 --持股数量
       M.WHE_CREDIT,                --是否授信客户
       M.WHE_NET_BANKING,           --是否网银客户
       M.WHE_WARNING,               --是否预警客户
       M.WHE_FINANACES,             --是否理财客户
       SUM(N.DEPS_BAL),             --存款余额
       SUM(N.DEPS_BAL_AVG_M),       --存款月日均
       SUM(N.DEPS_BAL_AVG_Y),       --存款年日均
       SUM(N.LOAN_BAL),             --贷款余额
       SUM(N.FINANCES_BAL),         --理财余额
       M.PROFIT,                    --模拟利润
       M.USE_POINTS,                --可用积分
       M.TOTAL_POINTS,              --累计积分
       M.WHE_NOTE,                  --是否短信签约
       M.EFF_CST_DT,                --开户日期
       M.IDV_MO_INCM,               --个人月收入
       M.IDV_ANUL_ERN,              --个人年收入
       M.CVL_F,                     --公务员标志
       M.OPN_ORG,                   --开户机构
       M.CUST_STATUS,               --客户状态
       M.CUST_LEVEL,                --客户等级
       M.ASN_STATUS,                --分配状态
       M.BELONG_ORG_NO,             --归属机构
       M.BELONG_EMP_NO,             --归属人员
       M.HOBB_LEISURE,              --喜好休闲
       M.HOBB_MEDIA,                --喜好媒体
       M.HOBB_SPORT,                --喜好运动
       M.HOBB_MAGAZINE,             --喜好杂志类
       M.HOBB_TELEVISION,           --喜好影视类
       M.HOBB_CHANNEL,              --喜好渠道类
       M.HOBB_CONSUMER,             --喜好消费类
       M.INVEST_KNOWLEDGE,          --投资知识
       M.INVEST_EXPERIENCE,         --投资经验
       M.INVEST_STYLE,              --投资风格
       M.INVEST_BURDEN,             --投资负担
       M.INVEST_LOSTMONEY_MOOD,     --赔钱心里
       M.INVEST_ORIENTATION,        --投资取向
       M.INVEST_COMMISSION,         --投资委托
       M.INVEST_TRAN_CHANNEL,       --交易渠道
       M.BEST_CONTACT_WAY,          --最佳联系方式
       M.BEST_CONTACT_TIME,         --最佳联系时间段
       M.CREATE_EMP_NO,             --创建人
       M.CREATE_TIME,               --创建时间
       M.MODIFY_EMP_NO,             --修改人
       M.MODIFY_TIME,               --修改时间
       M.CREATE_ORG_NO,             --创建机构
       M.MODIFY_ORG_NO,             --修改机构
       SUM(N.LOAN_BAL_M),           --贷款月日均
       SUM(N.LOAN_BAL_Y),           --贷款年日均
       M.CUST_STAGE,                --客户阶段
       M.CUST_CRM_STATUS,           --客户在CRM状态
       SUM(N.DP_ACCT_CNT),          --存款账户数
       SUM(N.LN_ACCT_CNT),          --贷款账户数
       SUM(N.ALL_ACCT_CNT),         --存款和贷款账户数之和
       SUM(N.CARD_CNT),             --卡数
       M.AGE,                       --年龄
       SUM(N.CD_INT_EPS_AMT),       --当日利息支出
       SUM(N.MA_INT_EPS_AMT),       --月累计利息支出
       SUM(N.QA_INT_EPS_AMT),       --季累计利息支出
       SUM(N.YA_INT_EPS_AMT),       --年累计利息支出
       SUM(N.ACCRUAL_SHOULD),       --当日应收利息
       SUM(N.ACCRUAL_SHOULD_A),     --累计应收利息
       SUM(N.ACCRUAL_FACT),         --当日实收利息
       SUM(N.ACCRUAL_FACT_A),       --累计实收利息
       SUM(N.PAID_SALARY),          --批量代付工资
       SUM(N.YMAX_TXN_AMT),         --年单笔最大交易量
       SUM(N.L_DEPS_BAL_AVG_Y)      --去年存款年日均
  FROM(SELECT * FROM CI_CUS_PERSON I
        WHERE EXISTS(SELECT 1 FROM CI_CUS_PERSON_COMBINE K
				               WHERE I.CUST_NO = K.CUST_NO
											      AND K.STATE='1')
			) M
  LEFT JOIN
  (SELECT * FROM CI_CUS_PERSON J
        WHERE EXISTS(SELECT 1 FROM CI_CUS_PERSON_COMBINE L
				               WHERE (J.CUST_NO=L.CUST_NO OR J.CUST_NO=L.COMBINED_CUST_NO)
											       AND L.STATE = '1')
	) N
    ON M.CUST_NO=N.CUST_NO
GROUP BY M.CUST_NO, M.CUST_NAME, M.CUST_OTHER_NAME, M.CERT_TYPE, M.CERT_NO, M.SEX, M.COUNTRY,
         M.NATION, M.MARITAL, M.RELIGION, M.INDUSTRY_CODE, M.CREDIT_RATING, M.BIRTHDAY,
				 M.BIRTHPLACE, M.MAX_EDUCATIONAL, M.MAX_DEGREE, M.JOB_OCCUPATION, M.POSITION, M.WHE_BANK_EMP,
				 M.WHE_BANK_STOCKHOLDER, M.STACK_NUM, M.WHE_CREDIT, M.WHE_NET_BANKING, M.WHE_WARNING,
				 M.WHE_FINANACES, M.WHE_NOTE, M.EFF_CST_DT, M.CVL_F, M.OPN_ORG, M.CUST_STATUS, M.CUST_LEVEL,
				 M.ASN_STATUS, M.BELONG_ORG_NO, M.BELONG_EMP_NO, M.HOBB_LEISURE, M.HOBB_MEDIA, M.HOBB_SPORT,
				 M.HOBB_MAGAZINE, M.HOBB_TELEVISION, M.HOBB_CHANNEL, M.HOBB_CONSUMER, M.INVEST_KNOWLEDGE,
				 M.INVEST_EXPERIENCE, M.INVEST_STYLE, M.INVEST_BURDEN, M.INVEST_LOSTMONEY_MOOD, M.INVEST_ORIENTATION,
				 M.INVEST_COMMISSION, M.INVEST_TRAN_CHANNEL, M.BEST_CONTACT_WAY, M.BEST_CONTACT_TIME, M.CREATE_EMP_NO,
				 M.CREATE_TIME, M.MODIFY_EMP_NO, M.MODIFY_TIME, M.CREATE_ORG_NO, M.MODIFY_ORG_NO, M.CUST_STAGE,
				 M.CUST_CRM_STATUS, M.AGE, M.PROFIT, M.USE_POINTS, M.TOTAL_POINTS, M.IDV_MO_INCM, M.IDV_ANUL_ERN

/

